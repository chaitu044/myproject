package project.feature.steps.definitions;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import project.pageobject.AWBPage;
import project.pageobject.DPWBPage;
import project.pageobject.OpportunityRunsPage;
import project.pageobject.PolicySelectionFiltersection;
import project.pageobject.ReviewWorkedOpportunityPage;
import project.utilities.AppUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;

public class PolicyselectionStepDef extends ScenarioSteps {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	AppUtils oAppUtils;
	GenericUtils oGenericUtils;
	AWBPage oAWBPage;
	OpportunityRunsPage oOpportunityRunsPage;
	PolicySelectionFiltersection oPolicySelectionFiltersection;
	ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage;
	DPWBPage oDPWBPage;
	
	@Step
	public void validate_policy_selection_drawer_with_mongoDB_for_the_displayed(String policyselectiondata, String savings) throws InterruptedException {

      	//Select the policy selection drawer and apply all checkboxes and selecting the given savings in the sort by savings dropdown  in that section
		oPolicySelectionFiltersection.SelectthePolicySelectionDrawerandApplyAllFiltersforSavings(savings);
		switch(policyselectiondata)
		{
		case "Medical Poilcies":
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
			//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
			oPolicySelectionFiltersection.validate_the_medicalpolicies_in_policyselection_with_moongoDB_for_the_savings(
					savings,"","","","");
		break;
		case "Topics":
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
			
			//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
				oPolicySelectionFiltersection.validate_the_topics_in_policyselection_with_moongoDB_for_the_savings(
						savings,"","","","");
		break;
		
		default:
			Assert.assertTrue("Given selection was not found ===>"+policyselectiondata, false);
			break;
		}
		
		
	}

	/*@Step
	public void validate_policy_selection_drawer_with_mongoDB_for_the_given_filters(String policyselectiondata, String savings,
			String Payershorts, String Insuarances, String Claimtypes) throws InterruptedException {
		String sValue=null;
		List<String> Payershortlist=Arrays.asList(Payershorts.split(","));
		List<String> InsuranceList=Arrays.asList(Insuarances.split(","));
		List<String> ClaimtypeList=Arrays.asList(Claimtypes.split(","));
		
		Assert.assertTrue("Unable to click the policy selection drawer link in the AWB Page", oGenericUtils.clickButton(By.xpath(oOpportunityRunsPage.sPolicySelection)));

		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		//Loading POPUP
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		//Verify 'Choose a Medical PolicyTopic' screen

		boolean sGetMedicalPolicy=oGenericUtils.isElementExist("//h3[.='Choose a Medical Policy/Topic']", ProjectVariables.MIN_COUNT);
		if(!sGetMedicalPolicy){
			Assert.assertTrue("Unable to click the policy selection drawer link in the AWB Page", oGenericUtils.clickButton(By.xpath(oOpportunityRunsPage.sPolicySelection)));
		}
		
		//Select All Filters like ''Payer Short,Insurance,Product
				Assert.assertTrue("Unable to UN-check the 'Payershort' header checkbox in the policy selection drawer", oOpportunityRunsPage.ApplyFilters("Payer Short","","UNCHECK",""));
				Assert.assertTrue("Unable to un-check the 'Insurance' header checkbox in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Insurance","","UNCHECK",""));
				Assert.assertTrue("Unable to un-check the 'Product' header checkbox and apply filter button in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Product","","UNCHECK",""));
						
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Payer Short",Payershortlist,"CHECK","");
		
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Insurance",InsuranceList,"CHECK","");
		
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Product",ClaimtypeList,"CHECK",oOpportunityRunsPage.sApplyFilters_PS);
		
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		//Loading POPUP
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		//Select the policy selection drawer and apply all checkboxes and selecting the given savings in the sort by savings dropdown  in that section
		//Assert.assertTrue("Unable to click the 'sort by savings dropdown' in the policy selection drawer", oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ButtonContainsText, "value", "Sort by")));
		
		//AWBPage.defaultWait(ProjectVariables.TImeout_1_Seconds);
		
		switch(savings)
		{
		case "Sort by Raw Opp Savings":
			sValue="rawOppSavings";
			break;
		case "Sort by Agg Opp Savings":
			sValue="aggOppSavings";
			break;
		
		case "Sort by Con Opp Savings":
			sValue="conOppSavings";
			break;
		
		case "Sort by DP Opp Savings":
			sValue="dpSavings";
			break;
		default:
			Assert.assertTrue("Given selection was not found==>"+savings, false);
			break;
		}
		
		Assert.assertTrue("Unable to click the '"+savings+"' in the 'sort by savings dropdown' of policy selection drawer", oAWBPage.SelectDropDownByValue("//option[contains(text(),'Sort by')]/ancestor::select",sValue));
		
		AWBPage.defaultWait(ProjectVariables.TImeout_1_Seconds);
		
		Assert.assertTrue("'"+StringUtils.substringAfter(savings, "Sort by ")+"' coloumn name is not displayed in the header of policy selection drawer grid,after selecting that in the dropdown", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", StringUtils.substringAfter(savings, "Sort by "))));
		
		AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				
				switch(policyselectiondata)
				{
				case "Medical Poilcies":
					
					//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
					oPolicySelectionFiltersection.validate_the_medicalpolicies_in_policyselection_with_moongoDB_for_the_savings(savings,Payershortlist,InsuranceList,ClaimtypeList);
					
				break;
				
				case "Topics":
					
						//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
						oPolicySelectionFiltersection.validate_the_topics_in_policyselection_with_moongoDB_for_the_savings(savings,Payershortlist,InsuranceList,ClaimtypeList);
				break;
				
				default:
					Assert.assertTrue("Given selection was not found ===>"+policyselectiondata, false);
					break;
				}
		
		
		
		
	}*/

	public void validate_the_sorting_functionality_in_the_policy_selection_drawer_by(String policyselectiondata, String savings) throws InterruptedException {
		
		boolean bstatus=false;
		int Medicalpolicysize=0;
		int Topicsize=0;
		String UISavings=null;
		
		ArrayList<String> Policyselection_Medicalpoliciesavings=new ArrayList<>();
		ArrayList<String> Policyselection_Topics=new ArrayList<>();
		
		//Select the policy selection drawer and apply all checkboxes and selecting the given savings in the sort by savings dropdown  in that section
		oPolicySelectionFiltersection.SelectthePolicySelectionDrawerandApplyAllFiltersforSavings(savings);
				
				
				switch(policyselectiondata)
				{
				case "Medical Policies":
					
					
					Medicalpolicysize=oAWBPage.get_Matching_WebElement_count(oAWBPage.MedicalPolicies_In_PolicySelection);
					for (int i = 1; i <=Medicalpolicysize; i++) {
						bstatus=oAWBPage.is_WebElement_Displayed(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]");
						//if(bstatus)
						{
							UISavings=oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(StringUtils.replace(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]", "not", "")));
							System.out.println(i+"."+"UI savings ==>"+UISavings);
							Policyselection_Medicalpoliciesavings.add(UISavings);
						}
						/*else
						{
							Assert.assertTrue("Unable to click the Medical Policy vertical scroll bar of polcy selection section in the AWS page,for the element ==>"+oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]",oAWBPage.Click_Untill_Element_is_displayed_with_the_given_time(20, oAWBPage.MedicalPolicyVerticalscrollbar, oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]"));
							UISavings=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]/../following-sibling::td[contains(@class,'sort policy-level-td')]").replaceAll(",", ""),"$");
							System.out.println(i+"."+"UI savings ==>"+UISavings);
							Policyselection_Medicalpoliciesavings.add(UISavings);
							
						}*/
					}
					
					oPolicySelectionFiltersection.validate_the_sorting_funtionality(Policyselection_Medicalpoliciesavings,"Descending order","MedicalPolicies_"+savings);
					
					
					
				break;
				
				case "Topics":
					//Retrieve Medical Policies and Topics from Mongo DB based on client,release 
					MongoDBUtils.Retrieve_the_medicalpolicy_and_savings_based_on_client_and_release_for_policyselection_Drawer("","","","");
					
					for (String DB_medicalpolicy : ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer) {

						String Exact_DBmedicalpolicy=StringUtils.substringBefore(DB_medicalpolicy, ";Raw");
						
						Assert.assertTrue("Unable to search the DBMedicalpolicy in the search box of policy selection drawer", oAWBPage.Enter_given_Text_Element(oOpportunityRunsPage.sSearchFeild_MP, Exact_DBmedicalpolicy));
						
						OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
						
						Assert.assertTrue("Unable to click the search icon in the policy selection drawer in AWB Page",oAWBPage.clickGivenXpath(oOpportunityRunsPage.sSearchIcon));
						
						OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
						
						Assert.assertTrue("Medicalpolicy '"+Exact_DBmedicalpolicy+"' is not displayed in the filter section of policyselection drawer,after searching", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", Exact_DBmedicalpolicy)));
						
						//Assert.assertTrue("Unable to click the arrow down icon for the searched medicalpolicy '"+Exact_DBmedicalpolicy+"' in the policy selection drawer of AWB Page",oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_with_text, "value", Exact_DBmedicalpolicy)+"/.."+StringUtils.replace(oAWBPage.Span_contains_class, "value", "arrow-right")));
						
						OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
						
						Topicsize=oAWBPage.get_Matching_WebElement_count(oAWBPage.Topics_In_PolicySelection);
						
						for (int i = 1; i <=Topicsize; i++) {
							
							bstatus=oAWBPage.is_WebElement_Displayed(oAWBPage.Topics_In_PolicySelection+"["+i+"]");
							
							//if(bstatus)
							{
								
								UISavings=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(oAWBPage.Topicsavings_In_PolicySelection+"["+i+"]").replaceAll(",", ""), "$");
								System.out.println(i+"."+"UI savings ==>"+UISavings);
								Policyselection_Topics.add(UISavings);
							
							}
							
							
							
							
						}
						
						oPolicySelectionFiltersection.validate_the_sorting_funtionality(Policyselection_Topics,"Descending order","Topics"+savings);
						Policyselection_Topics.clear();
								
					}
						break;
				
				default:
					Assert.assertTrue("Given selection was not found ===>"+policyselectiondata, false);
					break;
				}
				
				
	}

	
	@Step
	public void validate_the_UI_functionality_in_the_policy_selection_drawer_for(String datacriteria, String savingstype) throws InterruptedException {
		boolean bstatus=false;
		List<String> PayershortList = new ArrayList<>();
		ArrayList<String> InsuranceKeyList = new ArrayList<>();
		ArrayList<String> ClaimtypeList = new ArrayList<>();
		ArrayList<String> LCDList = new ArrayList<>();
		ArrayList<String> Policyselection_Topics=new ArrayList<>();
		ArrayList<String> Not_DisplayedTopicslist=new ArrayList<>();
		

		//Select the policy selection drawer and apply all checkboxes and selecting the given savings in the sort by savings dropdown  in that section
		oPolicySelectionFiltersection.SelectthePolicySelectionDrawerandApplyAllFiltersforSavings(savingstype);

		
		//Retrieve Medical Policies and Topics from Mongo DB based on client,release 
		MongoDBUtils.Retrieve_the_medicalpolicy_and_savings_based_on_client_and_release_for_policyselection_Drawer("","","","");
		
		
			String Exact_DBmedicalpolicy=StringUtils.substringBefore(ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.get(0), ";Raw");
			
			Assert.assertTrue("Unable to search the DBMedicalpolicy in the search box of policy selection drawer", oAWBPage.Enter_given_Text_Element(oOpportunityRunsPage.sSearchFeild_MP, Exact_DBmedicalpolicy));
			
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
			
			Assert.assertTrue("Unable to click the search icon in the policy selection drawer in AWB Page",oAWBPage.clickGivenXpath(oOpportunityRunsPage.sSearchIcon));
			
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("Medicalpolicy '"+Exact_DBmedicalpolicy+"' is not displayed in the filter section of policyselection drawer,after searching", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", Exact_DBmedicalpolicy)));
		
			//Assert.assertTrue("Unable to click the 'Display MPs' Dropdown in the policy selection drawer", oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ButtonContainsText, "value", "Display")));
			
			Assert.assertTrue("Unable to click the 'Display MPs' selection in the policy selection drawer", oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Display MPs")));
			
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
			
			int Topicssize=oAWBPage.get_Matching_WebElement_count(oAWBPage.Topics_In_PolicySelection);
			
			for (int i = 1; i <= Topicssize; i++) {
				
				String Topic=oAWBPage.get_TextFrom_Locator(oAWBPage.Topics_In_PolicySelection+"["+i+"]/strong");
				
				String Medicalpolicy=StringUtils.substringBefore(oAWBPage.get_TextFrom_Locator(oAWBPage.Topics_In_PolicySelection+"["+i+"]"), Topic).trim();
				
				if(!Medicalpolicy.equalsIgnoreCase(Exact_DBmedicalpolicy))
				{
					Assert.assertTrue("Medicalpolicy is not matching with DB medicalpolicy in the policyselection grid at the header level for the corresponding topics at 'Display Topics' filter,Expected ==>"+Exact_DBmedicalpolicy+",Actual ==>"+Medicalpolicy, false);
				}
				
				
				
				Policyselection_Topics.add(Topic);
				
			}
			
			System.out.println("Policyselection Topic list ==>"+Policyselection_Topics);
			System.out.println("Policyselection Topic size ==>"+Policyselection_Topics.size());
			
			for (String DB_UITopic : ProjectVariables.Topicwithsavings_PolicySelectiondrawer) {

				String Exact_DBTopic=StringUtils.substringBefore(DB_UITopic, ";Raw");
				System.out.println("DBTopic ==>"+Exact_DBTopic);

				for (String UI_Topic : Policyselection_Topics) {
					
					if(!UI_Topic.equalsIgnoreCase(Exact_DBTopic.trim()))
					{
						bstatus=false;
					}
					else
					{
						bstatus=true;
												
						break;
					}


				}

				if(!bstatus)
				{
					Not_DisplayedTopicslist.add(Exact_DBTopic);	
				}


			}

			Assert.assertTrue("Some Topics are not displaying in Policy Selection Drawer from Mongo DB as expected,Not available topics count ==>"+Not_DisplayedTopicslist.size()+",Not available Topics are ==>"+Not_DisplayedTopicslist+",for client key==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",UI Topic count ==>"+Policyselection_Topics.size()+",DB Topics count ==>"+ProjectVariables.Topicwithsavings_PolicySelectiondrawer.size()+",Medicalpolicy ==>"+Exact_DBmedicalpolicy,Not_DisplayedTopicslist.size()==0);
			
			
			
			
			
			
	}

	@Step
	public void validate_the_policy_release_summary_data_with_mongo_DB_in_page(String pagename) {
		
		if(pagename.equalsIgnoreCase("Review Worked Opportunity"))
		{
			//click on review worked opportunity button and check the page is opening or not
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
		}
		
		//validate the policy release summary with mongo DB for he given page
		oPolicySelectionFiltersection.validate_the_policy_release_summary_data_with_mongo_Db(pagename);
	
	}

	@Step
	public void valiadte_the_policyreleasesummary_data_update_functionality_after_capturing_the_disposition_Present_in_AWB_and_Review_Worked_Opportunity_Page() throws InterruptedException {
		
		
		List<String> checkboxexList=Arrays.asList(ProjectVariables.filters.split(","));
		
		//Capturing the given policy release summay savings data into serenity varaibles from UI 
		Serenity.setSessionVariable("Present DPKeys").to(oAWBPage.get_TextFrom_Locator(StringUtils.replace(oAWBPage.Span_with_text, "value", "DP Dispositions to Present")+"/ancestor::li/strong"));
		Serenity.setSessionVariable("Present Raw savings").to(oPolicySelectionFiltersection.Capture_the_given_policyreleasesummary_savings_data("Present","Raw Savings"));
		Serenity.setSessionVariable("Present Agg savings").to(oPolicySelectionFiltersection.Capture_the_given_policyreleasesummary_savings_data("Present","Agg Savings"));
		Serenity.setSessionVariable("Present Con savings").to(oPolicySelectionFiltersection.Capture_the_given_policyreleasesummary_savings_data("Present","Con Savings"));
		
		System.out.println("Policy release summary savings data ,before capturing the disposition");
		
		System.out.println("Present Raw savings =>"+Serenity.sessionVariableCalled("Present Raw savings"));
		System.out.println("Present Agg savings =>"+Serenity.sessionVariableCalled("Present Agg savings"));
		System.out.println("Present Con savings =>"+Serenity.sessionVariableCalled("Present Con savings"));
		
		Assert.assertTrue("'Flag' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));
		
		//Selecting filter header checkboxes in the AWB page
		for (int i = 0; i < checkboxexList.size(); i++) 
		{
			Assert.assertTrue("'"+checkboxexList.get(i)+"' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "CHECK", ""));
		}
		
		Assert.assertTrue("Savings Status checkbox is unable to un-checked in the AWB Page",oOpportunityRunsPage.ApplyFilters("Saving Status","","UNCHECK",""));

		Assert.assertTrue("Opportunity Savings Status checkbox is unable to checked in the AWB Page",oOpportunityRunsPage.ApplyFilters("Savings Status","Opportunity","CHECK",StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		
		
		//verifying the policy release summary data,after capturing the disposition
		oPolicySelectionFiltersection.validate_the_policyreleasesummary_savings_after_capturing_disposition();
		
		
		
	}
	
	@Step
	public void validate_the_medical_policy_release_summary_data_with_mongo_DB_in_page(String pagename) throws InterruptedException {
		if(pagename.equalsIgnoreCase("Review Worked Opportunity"))
		{
			//click on review worked opportunity button and check the page is opening or not
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			
			oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
		}
		else
		{
			//To retrieve the medicalpolicy from the mongo DB
			MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"),"");
			
			//select the given medicalpolicy in policy selection drawer
			oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(ProjectVariables.DB_Medicalpolicylist.get(0));
			
		}
		

		//validate the medical policy summary with mongo DB for he given page
		oPolicySelectionFiltersection.validate_the_medical_policy_release_summary_data_with_mongo_Db(pagename);
	
		
	}

	public void valiadte_the_medicalpolicy_release_summary_data_update_functionality_after_capturing_the_disposition_in_AWB_and_Review_Worked_Opportunity_Page(String disposition) throws InterruptedException {
		
		List<String> checkboxexList=Arrays.asList(ProjectVariables.filters.split(","));
		
		
		//To retrieve the medicalpolicy from the mongo DB
		MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"),"");
		
		//select the given medicalpolicy in policy selection drawer
		oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(ProjectVariables.DB_Medicalpolicylist.get(0));
		
		
		//Capturing the given policy release summay savings data into serenity varaibles from UI 
		Serenity.setSessionVariable("Filtered Raw savings").to(StringUtils.substringBefore(oPolicySelectionFiltersection.Retrieve_the_exact_savings_from_UI(StringUtils.replace(oPolicySelectionFiltersection.MedicapolicypolicySumarySavings, "svgtype", "Filtered Raw Opportunity Savings")), "Filtered").trim());
		Serenity.setSessionVariable("Filtered Agg savings").to(StringUtils.substringBefore(oPolicySelectionFiltersection.Retrieve_the_exact_savings_from_UI(StringUtils.replace(oPolicySelectionFiltersection.MedicapolicypolicySumarySavings, "svgtype", "Filtered Aggressive Opportunity Savings")), "Filtered").trim());
		
		System.out.println("Policy release summary savings data ,before capturing the disposition");
		
		System.out.println("Filtered Raw savings =>"+Serenity.sessionVariableCalled("Filtered Raw savings"));
		System.out.println("Filtered Agg savings =>"+Serenity.sessionVariableCalled("Filtered Agg savings"));
		
		
		
		//Selecting filter header checkboxes in the AWB page
		for (int i = 0; i < checkboxexList.size(); i++)
		{
			Assert.assertTrue("'"+checkboxexList.get(i)+"' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "CHECK", ""));
		}
		
		Assert.assertTrue("Savings Status checkbox is unable to un-checked in the AWB Page",oOpportunityRunsPage.ApplyFilters("Saving Status","","UNCHECK",""));

		Assert.assertTrue("Opportunity Savings Status checkbox is unable to checked in the AWB Page",oOpportunityRunsPage.ApplyFilters("Saving Status","Opportunity","CHECK",StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		
		
		//verifying the policy release summary data,after capturing the disposition
		oPolicySelectionFiltersection.validate_the_medicalpolicyreleasesummary_savings_after_capturing_disposition(disposition);
		
		//verifying the policy release summary data,after capturing the disposition in Review workred Opportunity page
		validate_the_medical_policy_release_summary_data_with_mongo_DB_in_page("Review Worked Opportunity");
		
		
	}
	
	//############################################### PI-25 Stories ###########################################################//

	@Step
	public void validate_FilterPanel_with_mongoDB_for_the_given_filters(String policyselectiondata, String savings,
			String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) throws InterruptedException {
		String sValue=null;
		List<String> Payershortlist=Arrays.asList(Payershorts.split(","));
		List<String> InsuranceList=Arrays.asList(Insuarances.split(","));
		List<String> ClaimtypeList=Arrays.asList(Claimtypes.split(","));
		List<String> LatestClientDecisionList=Arrays.asList(LatestClientDecision.split(","));
		
		//To Select the filters in FilterPanel
		oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters(Payershorts, Insuarances, Claimtypes, LatestClientDecision);
		
		switch(savings)
		{
		case "Sort by Raw Opp Savings":
			sValue="rawOppSavings";
			break;
		case "Sort by Agg Opp Savings":
			sValue="aggOppSavings";
			break;
		
		case "Sort by Con Opp Savings":
			sValue="conOppSavings";
			break;
		
		case "Sort by DP Opp Savings":
			sValue="dpSavings";
			break;
		default:
			Assert.assertTrue("Given selection was not found==>"+savings, false);
			break;
		}
		
		Assert.assertTrue("Unable to click the '"+savings+"' in the 'sort by savings dropdown' of policy selection drawer", oAWBPage.SelectDropDownByValue("//option[contains(text(),'Sort by')]/ancestor::select",sValue));
		
		AWBPage.defaultWait(ProjectVariables.TImeout_1_Seconds);
		
		Assert.assertTrue("'"+StringUtils.substringAfter(savings, "Sort by ")+"' coloumn name is not displayed in the header of policy selection drawer grid,after selecting that in the dropdown", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", StringUtils.substringAfter(savings, "Sort by "))));
		
		AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				
				switch(policyselectiondata)
				{
				case "Medical Poilcies":
					//To Selcet Display MPs/Topic toggle selection
					oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
					
					//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
					oPolicySelectionFiltersection.validate_the_medicalpolicies_in_policyselection_with_moongoDB_for_the_savings(savings,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
					
				break;
				
				case "Topics":
					//To Selcet Display MPs/Topic toggle selection
					oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
					
						//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
						oPolicySelectionFiltersection.validate_the_topics_in_policyselection_with_moongoDB_for_the_savings(savings,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
				break;
				
				default:
					Assert.assertTrue("Given selection was not found ===>"+policyselectiondata, false);
					break;
				}
		
		
		
		
	}

	//################################# PI-25 Stories ############################################################//
	
	@Step
	public void userSelectsMPTopicsinFilterPanelas(String dataCriteria) throws InterruptedException 
	{
		
		
		switch(dataCriteria)
		{
		case "MPs":
			//To Open filter Panel and select all filters
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters();
			
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
			
			//To select the Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.userSelcetsMultipleMPSTopics(oAWBPage.MedicalPolicies_In_PolicySelection,3);
		break;
		case "Topics":
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
			
			
			//To select the Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.userSelcetsMultipleMPSTopics(oAWBPage.Topics_In_PolicySelection,3);
		break;
		case "AllMPs":
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
			
			//To select the Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.userSelcetsMultipleMPSTopics(dataCriteria,0);
		
		break;
		case "AllTopics":
			//To Selcet Display MPs/Topic toggle selection
			oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
			
			//To select the Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.userSelcetsMultipleMPSTopics(dataCriteria,0);
		
		break;

		default:
			Assert.assertTrue("Case not found==>"+dataCriteria, false);
		break;
		}
		
	}

	@Step
	public void validateTheRetentionfunctionalityinFilterPanel(String dataCriteria) {
		int datasize=0;
		//To Open filter Panel and select all filters
		oOpportunityRunsPage.OpenFilterPanel();
		AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
		
		switch(dataCriteria)
		{
		case "MPs":
			//To validate retain functionality for Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.validateTheRetentionfunctionalityinFilterPanel(oAWBPage.MedicalPolicies_In_PolicySelection+"[count]/ancestor::div[contains(@class,'selected')]","MP",3);
		break;
		case "Topics":
			//To validate retain functionality for Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.validateTheRetentionfunctionalityinFilterPanel(oAWBPage.Topics_In_PolicySelection+"[count]/ancestor::tr[contains(@class,'selected')]","Topic",3);
		break;
		case "AllMPs":
			datasize=oAWBPage.get_Matching_WebElement_count(oAWBPage.MedicalPolicies_In_PolicySelection);
			//To validate retain functionality for Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.validateTheRetentionfunctionalityinFilterPanel(oAWBPage.MedicalPolicies_In_PolicySelection+"[count]/ancestor::div[contains(@class,'selected')]","MP",datasize);
		
		break;
		case "AllTopics":
			datasize=oAWBPage.get_Matching_WebElement_count(oAWBPage.Topics_In_PolicySelection);
			//To validate retain functionality for Multiple MPs and Topics in filter panel
			oPolicySelectionFiltersection.validateTheRetentionfunctionalityinFilterPanel(oAWBPage.Topics_In_PolicySelection+"[count]/ancestor::tr[contains(@class,'selected')]","Topic",datasize);
		
		break;

		default:
			Assert.assertTrue("Case not found==>"+dataCriteria, false);
		break;
		}
		
	}

	@Step
	public void validateTheNoEditsTopicsinfilterpanel() throws ParseException, InterruptedException 
	{
		//Select the policy selection drawer and apply all checkboxes
		oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters();
				
		//To Selcet Display MPs/Topic toggle selection
		oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
		
		//validate the medicalpolicies and corresponding savings with mongo DB in the policy selection Drawer
		oPolicySelectionFiltersection.validateTheNoEditsTopicsinFilterpanel();
	}
	
	@Step
	public void userSelectsgivenPPSandLCDinfilterpanel(String payershort,String Insurance,String product,String latestclientdecision) throws InterruptedException
	{
		oOpportunityRunsPage.OpenFilterPanel();
		//To click on 'Reset' button
		oOpportunityRunsPage.clickGivenXpath(StringUtils.replace(oOpportunityRunsPage.sApplyFilters_PS, "Apply Filters", "Reset"));
		AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
		oOpportunityRunsPage.userSelectsgivenPPSinFilterpanel(payershort, "Payer Short");
		oOpportunityRunsPage.userSelectsgivenPPSinFilterpanel(Insurance, "Insurance");
		oOpportunityRunsPage.userSelectsgivenPPSinFilterpanel(product, "Product");
		oOpportunityRunsPage.userSelectsgivenPPSinFilterpanel(latestclientdecision, "Latest Client Decision");
		oOpportunityRunsPage.clickGivenXpath(oOpportunityRunsPage.sApplyFilters_PS);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
	}

	@Step
	public void verifyMPforNoneinfilterpanel(String criteria,String payershort,String Insurance,String product,String latestclientdecision) throws Exception
	{
		//Serenity.setSessionVariable("clientkey").to("20");
		//Serenity.setSessionVariable("user").to("nkumar");
		if(!latestclientdecision.equalsIgnoreCase("None"))
		{
			payershort=String.join(",", ProjectVariables.payerShortList);
			 Insurance=String.join(",", ProjectVariables.insuranceList);
			 product=String.join(",", ProjectVariables.ClaimtypeList);
			 latestclientdecision=String.join(",", ProjectVariables.lCDlist);
		}
		 
		oPolicySelectionFiltersection.verifyMPsinFilterpanelforgivenPPS(payershort, Insurance, product, latestclientdecision);
	}

	@Step
	public void userSelctsPPScombinationsDynamicallyforgiven(String payercount, String inscount, String productcount, String lcdcount) 
	{
		oOpportunityRunsPage.selectgivennoofPPSandLCDCombination(payercount, inscount, productcount, lcdcount);
		
	}

}

