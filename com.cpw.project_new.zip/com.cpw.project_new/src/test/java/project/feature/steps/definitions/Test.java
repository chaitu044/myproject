package project.feature.steps.definitions;



import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.bson.BsonDocument;
import org.bson.conversions.Bson;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.client.model.Filters;

import net.serenitybdd.core.Serenity;
import project.pageobject.DPWBPage;
import project.pageobject.ServicesPage;
import project.utilities.DBUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.OracleDBQueries;
import project.utilities.ProjectVariables;

public class Test {
	

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

		
		ServicesPage oServicesPage = new ServicesPage();
		DPWBPage oDPWBPage = new DPWBPage();
		
		
		
		Serenity.setSessionVariable("clientkey").to("20");
		Serenity.setSessionVariable("release").to("201911");
		Serenity.setSessionVariable("dpkey").to("6431");
		Serenity.setSessionVariable("Medicalpolicy").to("Physical Medicine Policy");
		ArrayList<String> payershorts=new ArrayList<>();
		ArrayList<Long> dpkeys=new ArrayList<>();
		//List<String> UIPayershortlist=null;
		//ArrayList<String> UIPayershortlist = new ArrayList<>();
		List<String> UIPayershortlist=new ArrayList<>();;
		ArrayList<String> InsuranceKeyList = new ArrayList<>();
		ArrayList<String> ClaimtypeList = new ArrayList<>();
		ArrayList<String> LCDList = new ArrayList<>();
		ArrayList<Integer> svgstatuslist = new ArrayList<>();
		payershorts.add("SACFL");
		payershorts.add("SACKY");
		InsuranceKeyList.add("Medicare");
		InsuranceKeyList.add("Medicaid");
		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		LCDList.add("Reject");
		LCDList.add("Suppress");
		svgstatuslist.add(0);
		//svgstatuslist.add(-1);
		//UIPayershortlist.add("HSPBR");
		List<String> cli=new ArrayList<>();;
		List<String> ins=new ArrayList<>();;
		List<String> lcd=new ArrayList<>();;
		/*cli.add("A");
		ins.add("Medicare");
		lcd.add("Approve Library");*/
		dpkeys.add(8642l);
		
		ArrayList<String> sourcelist = new ArrayList<>();
		
		System.out.println(ProjectVariables.Oracle_query_basedon_client_release_for_rvaunified);
		
		
	
		//MongoDBUtils.verifyMPsinOpptyandeLLhierarchy("", "", "", "");		
		
		//MongoDBUtils.getRVATopicswithNoDisposition("FIDNY", "Medicare,Medicaid,Commercial", "A,F,P", "No Decision,Reject,Suppress","Opportunity");
		
		//GenericUtils.Convert_Epoch_time_to_given_format_for_the_given_date("MM-dd-yyyy", 1522137713000l);
		System.out.println("Scenario Ended TIme ==>"+GenericUtils.SystemDate());
		
		
	}

}


