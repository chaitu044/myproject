package project.feature.steps.definitions;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;

import project.pageobject.AWBPage;
import project.pageobject.DPWBPage;
import project.pageobject.LoginPage;
import project.pageobject.OpportunityRunsPage;
import project.pageobject.PolicySelectionFiltersection;
import project.pageobject.ReviewWorkedOpportunityPage;

import project.utilities.AppUtils;

import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;

import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;

public class CPWStepDef extends ScenarioSteps {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Instance Creation
	LoginPage oLoginPage;
	OpportunityRunsPage oOpportunityRunsPage;
	//NotesPage oNotesPage;
	AWBPage oAWBPage;
	AppUtils oAppUtils;
	//MessagesPage oMessagesPage;
	DPWBPage oDPWBPage;
	GenericUtils oGenericUtils;
	ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage;
	PolicySelectionFiltersection oPolicySelectionFiltersection;
	// ####################################################################################################

	@Step
	public void Verify(String StepDetails, String sStatus) {

		switch (sStatus.toUpperCase()) {

		case "PASSED":
			System.out.println(StepDetails);
			Assert.assertTrue(StepDetails, true);
			break;
		case "FAILED":
			System.out.println(StepDetails);
			Assert.assertTrue(StepDetails, false);
			break;

		}
	}

	// ####################################################################################################

	@Step
	public void the_is_logged_into_the_CPW_application(String arg1) throws Throwable {
		oLoginPage.Login_CPW(arg1);

	}

	

	// ####################################################################################################

	@Step
	public void user_select_Medical_Policy_from_the_policy_selection_through_MongoDB() throws Throwable {

		String DBMedicalpolicy = MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(
				Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "");

		if (DBMedicalpolicy == null) {
			Assert.assertTrue("Retrieved Medical policy is 'null' from the mongoDB for the client ===>"
					+ Serenity.sessionVariableCalled("client") + ",Release ===>"
					+ Serenity.sessionVariableCalled("release"), false);
		}

		Serenity.setSessionVariable("Medicalpolicy").to(DBMedicalpolicy);

		oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DBMedicalpolicy);

		String Payershorts = oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage);

		List<String> UIPayershortlist = Arrays
				.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));

		// String
		// Payershorts=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage).replaceAll("
		// ", ""), "Payer Short: ");

		System.out.println("Payershorts ==>" + UIPayershortlist);

		Serenity.setSessionVariable("Payershorts").to(StringUtils.substringAfter(Payershorts, "Payer Short: "));

		// Assert.assertTrue("Unable to click the 'AWBGrid Hirerarchy'
		// icon",oAWBPage.clickGivenXpath(oAWBPage.AWBGridHirerachy));

		// OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);

		Assert.assertFalse(
				"'No results found that meet the search criteria.' message is displayed in the AWB Grid for the Medical policy ==>"
						+ DBMedicalpolicy,
				oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value",
						"No results found that meet the search criteria.")));
	}

	// ####################################################################################################

	@Step
	public void user_select_Medical_Policy_from_the_policy_selection_through_MongoDB(String sTabname) throws Throwable {
		String DBMedicalpolicy = null;
		if (sTabname.equalsIgnoreCase("eLL")) {
			DBMedicalpolicy = MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel("", "", "", "");
		} else {
			DBMedicalpolicy = MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(
					Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "");
		}

		if (DBMedicalpolicy == null) {
			Assert.assertTrue("Retrieved Medical policy is 'null' from the mongoDB for the client ===>"
					+ Serenity.sessionVariableCalled("client") + ",Release ===>"
					+ Serenity.sessionVariableCalled("release"), false);
		}

		Serenity.setSessionVariable("Medicalpolicy").to(DBMedicalpolicy);

		oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DBMedicalpolicy);

		}
	// ####################################################################################################

	@Step
	public void select_DP_key_in_Opportunity_grid_and_validate_functionality_in_the_Notes_section_of_page(int arg1,
			String arg2, String arg3, String arg4) throws Throwable {
		ArrayList<String> sGetDPItems1 = null;

		if (arg4.equalsIgnoreCase("Review Worked Opportunities")) {
			oGenericUtils.clickOnElement("button", "Review Worked Opportunities");
			// Verify WORKED OPPORTUNITIES screen
			oGenericUtils.clickOnElement("span", "WORKED OPPORTUNITIES");

			Assert.assertTrue("Unable to check the 'Payershort' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Payer Short", "Payer Short", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Insurance' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Insurance", "Insurance", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Latest Client Decision' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Latest Client Decision", "Latest Client Decision", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Current Disposition' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Current Disposition", "Current Disposition", "CHECK",
							StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "apply-filters")));

		}

		Serenity.setSessionVariable("Pagename").to(arg4);

		// if(!arg4.equalsIgnoreCase("Review Worked Opportunities")){
		// selection of data in the Grid
		sGetDPItems1 = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage(arg2, arg1);
		// }

		// Notes section validation
		//oNotesPage.NotesValidations(arg3, sGetDPItems1);
	}

	// ####################################################################################################

	@Step
	public void logout_CPW_application() throws Throwable {
		oLoginPage.Logout_CPW();
	}

	// ####################################################################################################
	@Step
	public void User_click_on_client_with_release_in_the_Opportunity_Dashboard(String client, String release)
			throws IOException {
		String clientkey = "0";
		clientkey = AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(client.trim());

		client = StringUtils.substringBefore(client, ",").trim();

		Serenity.setSessionVariable("client").to(client);
		Serenity.setSessionVariable("clientkey").to(clientkey);

		// To select the given client
		oOpportunityRunsPage.SelectPayer(client);

	}

	// ####################################################################################################

	@Step
	public void UserSelecttheclientinAWBPage(String client) throws IOException {
		String clientkey = "0";
		clientkey = AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(client.trim());

		client = StringUtils.substringBefore(client, ",").trim();

		Serenity.setSessionVariable("client").to(client);
		Serenity.setSessionVariable("clientkey").to(clientkey);

		// To select the given client
		oOpportunityRunsPage.SelectPayer(client);

	}

	// ####################################################################################################
	@Step
	public void Validate_the_Topics_DPs_displayed_in_the_given_page_with_MongoDB(String Griddata, String pagename,
			String client, String release) throws InterruptedException {
		HashSet<String> DB_MPlist=new HashSet<>();
		List<String> DPkeysList=new ArrayList<>();
		List<Long> DB_DPKeylist=new ArrayList<>();
		if(pagename.equalsIgnoreCase("eLL Tab"))
		{	
			//DB method to get eLL MPs
			MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel("","","","");
			DB_MPlist.addAll(ProjectVariables.DB_MPlist);
		}
		else
		{
			//DB method to get RVA MPs
			MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(Serenity.sessionVariableCalled("clientkey"),
					"", "");
			DB_MPlist.addAll(ProjectVariables.DB_Medicalpolicylist);
		}
		
		verify("DB Medical policy size::" + DB_MPlist.size() +",for the client ==>"+ client, true);

		int i = 0;
		for (String DBmedicalpolicy :DB_MPlist ) {
			i = i + 1;
			verify("" + Griddata + " data validation is started for the medical policy::" + DBmedicalpolicy
					+ ",client::"+client+ ",record count::" + i + ",Record size::"+DB_MPlist, true);
			if(pagename.equalsIgnoreCase("eLL Tab"))
			{
				String MP=StringUtils.substringBefore(DBmedicalpolicy, "::").trim();
				DPkeysList=Arrays.asList(StringUtils.substringAfter(DBmedicalpolicy, "::").split(","));
				if(DPkeysList.isEmpty())
				{
					Assert.assertTrue("DPkeys are empty for the selected MP::"+DBmedicalpolicy, false);
				}
				for (int j = 0; j < DPkeysList.size(); j++) {
					DB_DPKeylist.add(Long.valueOf(DPkeysList.get(j)));
				}
				// To select the given medicalpolicy from policy selection
				oOpportunityRunsPage.SelectMPwithoutNoneDecisoin(MP);
				validate_the_grid_columns_in_AWB_Page("eLL");
			}
			else
			{
				// To select the given medicalpolicy from policy selection
				oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DBmedicalpolicy);
				// Get the Topics/DP's from the given client,release and medicalpolicy
				MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_in_AWB(Serenity.sessionVariableCalled("clientkey"),
						DBmedicalpolicy);
				DB_DPKeylist.addAll(ProjectVariables.DB_DpkeyList);
			}
			//To select 'Production' checkbox
			oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
			AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
			
			

			//To validate the DPs in eLL/RVA grid
			oAWBPage.Validate_the_DPs_in_Opportunity_Grid_with_Mongo_DB(client, DBmedicalpolicy,pagename,DB_DPKeylist);
			break;
		}

	}

	// ####################################################################################################

	@Step
	public void Validate_the_capture_and_update_disposition_functionality_with_MongoDB_for(String gridcriteria,
			String criteriatype, String disposition, String updateddisposition) throws InterruptedException {
		ArrayList<String> sGetDPItems=new ArrayList<>();
		// Selecting the checkboxes in the AWB Page
		Assert.assertTrue("Flag filterhead checkbox is unable to checked in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));
		Assert.assertTrue("Latest Client Decision filterhead checkbox is unable to checked in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Latest Client Decision", "", "CHECK", ""));
		Assert.assertTrue("Prior Disposition filterhead checkbox is unable to checked in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Prior Disposition", "", "CHECK", ""));
		Assert.assertTrue("Savings Status filterhead checkbox is unable to checked in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Savings Status", "", "UNCHECK", ""));
		Assert.assertTrue("Opportunity Savings Status checkbox is unable to checked in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Savings Status", "Opportunity", "CHECK",
						StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));

		switch (gridcriteria) {
		case "Topic level":

			oAWBPage.capture_the_data_at_Topic_level(criteriatype, disposition, updateddisposition);

			break;

		case "DP level":

			oAWBPage.capture_the_data_at_DP_level(sGetDPItems,criteriatype, disposition, updateddisposition,"","","");

			break;
		case "Payershort level":

			oAWBPage.capture_the_data_at_payershort_level("","","","","","");

			break;

		default:
			Assert.assertTrue("Given selection was not found ===>" + gridcriteria, false);

			break;
		}

	}

	// ####################################################################################################

	public void validate_the_savings_data_with_MongoDB_for_the_client_with_release_in(String Gridcriteria,
			String client, String release, String savingsstatus, String Pagename) throws InterruptedException {

		//

		// To Get the Medical policies from the given client,release and saving
		// status
		String MonthNum = GenericUtils.RetrivetheExactMonth(release);
		// String DB_Medicalpolicy=
		MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(Serenity.sessionVariableCalled("clientkey"),
				Serenity.sessionVariableCalled("release"), "");

		// ProjectVariables.DB_Medicalpolicylist.add("National Correct Coding
		// Initiative Policy");
		verify("DB Medical policy size ==>" + ProjectVariables.DB_Medicalpolicylist.size() + ",for the client ==>"
				+ client + ",release  ==>" + release, true);

		int i = 0;
		for (String DB_Medicalpolicy : ProjectVariables.DB_Medicalpolicylist) {
			i = i + 1;
			if (Pagename.equalsIgnoreCase("AWB Page")) {
				verify("Savings data validation is started for the medical policy ==>" + DB_Medicalpolicy
						+ ",client ==>" + client + ",release  ==>" + release + ",record count ==>" + i
						+ ",Record size ==>" + ProjectVariables.DB_Medicalpolicylist.size(), true);

				oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DB_Medicalpolicy);

				Assert.assertTrue("Savings Status filterhead checkbox is unable to un-checked in the AWB Page",
						oOpportunityRunsPage.ApplyFilters("Savings Status", "", "UNCHECK", ""));

				Assert.assertTrue("'" + savingsstatus + "' filter checkbox is unable to checked in the AWB Page",
						oOpportunityRunsPage.ApplyFilters("Savings Status", savingsstatus, "CHECK",
								StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));

				Assert.assertTrue("Unable to click the 'AWBGrid Hirerarchy' icon",
						oOpportunityRunsPage.clickGivenXpath(oAWBPage.AWBGridHirerachy));

				OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);

			} else {
				oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();

				oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "", "");
			}

			switch (Gridcriteria) {

			case "MedicalPolicy level":
				oReviewWorkedOpportunityPage.Validate_mediaclpolicy_level_savings_data_in_the_Oppgrid_of_RWO_page(
						client, StringUtils.substringAfter(release, " ") + MonthNum, DB_Medicalpolicy, savingsstatus);
				break;

			case "topic level":

				if (Pagename.equalsIgnoreCase("AWB Page")) {
					oAWBPage.Validate_topic_level_savings_data_in_the_Oppgrid_of_AWB_page(client,
							StringUtils.substringAfter(release, " ") + MonthNum, DB_Medicalpolicy, savingsstatus);
				} else {
					oReviewWorkedOpportunityPage.Validate_topic_level_savings_data_in_the_Oppgrid_of_RWO_page(client,
							StringUtils.substringAfter(release, " ") + MonthNum, savingsstatus);
				}

				break;
			case "DP level":
				if (Pagename.equalsIgnoreCase("AWB Page")) {
					oAWBPage.Validate_the_DPLevel_PayershortLevel_savings_data_in_Opportunity_Grid_of_AWB_Page_with_Mongo_DB(
							client, StringUtils.substringAfter(release, " ") + MonthNum, DB_Medicalpolicy, "DPLevel",
							savingsstatus);
				} else {
					oReviewWorkedOpportunityPage.Validate_DP_level_savings_data_in_the_Oppgrid_of_RWO_page(client,
							StringUtils.substringAfter(release, " ") + MonthNum, savingsstatus);
				}

				break;
			case "Payershort level":
				if (Pagename.equalsIgnoreCase("AWB Page")) {
					oAWBPage.Validate_the_DPLevel_PayershortLevel_savings_data_in_Opportunity_Grid_of_AWB_Page_with_Mongo_DB(
							client, StringUtils.substringAfter(release, " ") + MonthNum, DB_Medicalpolicy,
							"Payershort Level", savingsstatus);
				} else {
					oReviewWorkedOpportunityPage.Validate_Payershort_level_savings_data_in_the_Oppgrid_of_RWO_page(
							client, StringUtils.substringAfter(release, " ") + MonthNum, savingsstatus);
				}

				break;

			default:

				Assert.assertTrue("Given selection was not found ==>" + Gridcriteria, false);
				break;

			}

			break;

		}

	}

	// ####################################################################################################

	@Step
	public void verify(String sDescription, boolean blnStatus) {

		if (blnStatus) {
			System.out.println(sDescription);
			Assert.assertTrue(sDescription, blnStatus);
		} else {

			Assert.assertFalse(sDescription, blnStatus);

		}

	}

	// ####################################################################################################

	@Step
	public void validate_the_filters_checkboxes_funcitonality_in_the_AWB_Page(String checkboxesnames) {
		String sApplyFiltersbutton = null;
		String sResetbutton = null;

		sApplyFiltersbutton = StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")
				+ "/ancestor::button[@disabled]";
		sResetbutton = StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Reset");

		// Assert.assertTrue("Falgs filter checkbox section is enabled,expected
		// should be disabled in the AWB Page ",
		// oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_class,
		// "value", "flags disabled")));

		Assert.assertTrue("'Flag' filterhead checkbox is unable to check in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));

		List<String> checkboxexList = Arrays.asList(checkboxesnames.split(","));

		for (int i = 0; i < checkboxexList.size(); i++) {
			Assert.assertTrue(
					"'" + checkboxexList.get(i) + "' filterhead checkbox is unable to checked in the AWB Page",
					oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "CHECK",
							StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		}

		for (int i = 0; i < checkboxexList.size(); i++) {
			switch (checkboxexList.get(i)) {
			case "Latest Client Decision":
				// validate the default all checkboxes functionality
				oAWBPage.validate_the_all_checkboxes_funtionality(checkboxexList.get(i),
						ProjectVariables.LatestClientDecisionFilterOptions);

				// Validate the applyfilter and reset button functionality for
				// the filterchecbox in the AWB Page
				oAWBPage.validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),
						ProjectVariables.LatestClientDecisionFilterOptions, sApplyFiltersbutton, sResetbutton);

				break;

			case "Prior Disposition":

				// validate the default all checkboxes functionality
				oAWBPage.validate_the_all_checkboxes_funtionality(checkboxexList.get(i),
						ProjectVariables.PriorDispositionFilterOptions);

				// Validate the applyfilter and reset button functionality for
				// the filterchecbox in the AWB Page
				oAWBPage.validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),
						ProjectVariables.PriorDispositionFilterOptions, sApplyFiltersbutton, sResetbutton);

				break;

			case "Savings Status":
				// validate the default all checkboxes functionality
				oAWBPage.validate_the_all_checkboxes_funtionality(checkboxexList.get(i),
						ProjectVariables.SavingStatusFilterOptions);

				// Validate the applyfilter and reset button functionality for
				// the filterchecbox in the AWB Page
				oAWBPage.validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),
						ProjectVariables.SavingStatusFilterOptions, sApplyFiltersbutton, sResetbutton);

				break;

			default:
				Assert.assertTrue("Given selection was not found ===>" + checkboxexList.get(i), false);
				break;

			}

		}

	}

	// ####################################################################################################

	@Step
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filter(String filtername)
			throws InterruptedException {

		List<String> checkboxexList = Arrays.asList(ProjectVariables.filters.split(","));

		String Payershorts = oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage);

		List<String> UIPayershortlist = Arrays
				.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));

		for (int i = 0; i < checkboxexList.size(); i++) {
			Assert.assertTrue(
					"'" + checkboxexList.get(i) + "' filterhead checkbox is unable to checked in the AWB Page",
					oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "CHECK",
							StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		}

		switch (filtername) {
		case "Latest Client Decision":

			oAWBPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(
					filtername, ProjectVariables.LatestClientDecisionFilterOptions, UIPayershortlist);

			break;

		case "Prior Disposition":

			oAWBPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(
					filtername, ProjectVariables.PriorDispositionFilterOptions, UIPayershortlist);

			break;

		case "Savings Status":

			oAWBPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(
					filtername, ProjectVariables.SavingStatusFilterOptions, UIPayershortlist);

			break;

		default:
			Assert.assertTrue("Given selection was not found ===>" + filtername, false);
			break;

		}

	}

	// ####################################################################################################

	@Step
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filter_options(
			String latestclientdecision, String priordisposition, String savingsstatus) throws InterruptedException {
		boolean bstatus = false;
		boolean DBstatus = false;
		List<Long> DB_DPKeylist=null;
		List<String> insurancelist = null;
		List<String> claimtypelist = null;
		List<String> checkboxexList = Arrays.asList(ProjectVariables.filtersWithoutFlag.split(","));

		String Payershorts = oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage);

		List<String> UIPayershortlist = Arrays
				.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));

		Assert.assertTrue("'Flag' filterHead checkbox is unable to un-check in the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));

		for (int i = 0; i < checkboxexList.size(); i++) {
			Assert.assertTrue(
					"'" + checkboxexList.get(i) + "' filterHead checkbox is unable to un-check in the AWB Page",
					oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "UNCHECK", ""));
		}

		Assert.assertTrue(
				"'" + latestclientdecision
						+ "' filter checkbox is unable to checked in the filter 'Latest Client Decsion' of the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Latest Client Decision", latestclientdecision, "CHECK", ""));

		Assert.assertTrue(
				"'" + priordisposition
						+ "' filter checkbox is unable to checked in the filter 'Prior Disposition' of the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Prior Disposition", priordisposition, "CHECK", ""));

		Assert.assertTrue(
				"'" + savingsstatus
						+ "' filter checkbox is unable to checked in the filter 'Savings Status' of the AWB Page",
				oOpportunityRunsPage.ApplyFilters("Saving Status", savingsstatus, "CHECK",
						StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));

		// Wait untill the loading icon is not visible
		oAppUtils.WaitUntilPageLoad();

		bstatus = oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value",
				"No results found that meet the search criteria."));

		// Retrieve the Topics displayed in the AWb grid from Mongo DB as per
		// the filter combination
		DBstatus = MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB(
				Serenity.sessionVariableCalled("Medicalpolicy"), UIPayershortlist, insurancelist, claimtypelist,
				latestclientdecision, priordisposition, savingsstatus, "Combination filter", "AWB");

		if (!(bstatus == !DBstatus)) {
			Assert.assertTrue(
					"'No opportunities available for the selected Medical Policy and filters comination' message is displayed in the AWB Grid as not expected with Mongo DB for the client key ==>"
							+ Serenity.sessionVariableCalled("clientkey") + ",release ==>"
							+ Serenity.sessionVariableCalled("release") + ",Medical policy ==>"
							+ Serenity.sessionVariableCalled("Medicalpolicy") + ",Combination filter options ==>"
							+ latestclientdecision + "," + priordisposition + "," + savingsstatus,
					false);
		} else {
			// validating the Topics displayed in the AWb grid with Mongo DB as
			// per the filter combination
			oAWBPage.Validate_the_Topics_in_Opportunity_Grid_with_Mongo_DB(Serenity.sessionVariableCalled("client"),
					Serenity.sessionVariableCalled("release"), Serenity.sessionVariableCalled("Medicalpolicy"));

			// validating the DP's displayed in the AWb grid with Mongo DB as
			// per the filter combination
			DB_DPKeylist.addAll(ProjectVariables.DB_DpkeyList);
			oAWBPage.Validate_the_DPs_in_Opportunity_Grid_with_Mongo_DB(Serenity.sessionVariableCalled("client"),
					Serenity.sessionVariableCalled("Medicalpolicy"),"AWB",DB_DPKeylist);
		}

	}

	// ####################################################################################################

	public void validate_functionality_under_page(String arg1, String arg2) {
		//oMessagesPage.MessageFunctionality(arg1, arg2, ProjectVariables.sGetDPItems);
	}

	// ####################################################################################################

	@Step
	public void validate_the_DP_Descpopup_with_MongoDB_for_the_savingsstatus_in(String Pagename, String Savingsstatus)
			throws InterruptedException {
		List<String> UIPayershortlist = null;
		/*
		 * if(Pagename.equalsIgnoreCase("AWB")) { String
		 * Payershorts=oAWBPage.get_TextFrom_Locator(oAWBPage.
		 * payershorts_in_AWBPage).replaceAll(" ", "");
		 * 
		 * System.out.println("Payershorts ==>"+Payershorts);
		 * 
		 * UIPayershortlist=Arrays.asList(StringUtils.substringAfter(
		 * Payershorts, "PayerShort:").split(","));
		 * 
		 * System.out.println("payerhsortlist ==>"+UIPayershortlist); }
		 */

		// Select the DPDesc popup from DB in the AWB/Review Worked Opportunity
		// Grid
		oAWBPage.Select_the_DPDesc_in_the_grid_from_DB(Pagename, Savingsstatus, UIPayershortlist);

		// CLick the DPDesc link for the given DPKey
		oAWBPage.Click_the_DPDesc_for_the_given_DPKey(Pagename);

		// validate the DPDesc popup with mongoDB for the given DPkey
		oAWBPage.validate_the_Rules_in_DPDesc_Popup_with_mongodb_for(ProjectVariables.DB_DPKey, Pagename);

		// validate the Rule information in the DP Desc popup with mongo DB
		oAWBPage.validate_the_Rule_information_in_DPDesc_Popup_with_mongodb_for(ProjectVariables.DB_DPKey,
				UIPayershortlist, Pagename, Savingsstatus);

	}

	// ####################################################################################################

	@Step
	public void validate_the_sorting_functionality_for_the_rules_in_the_DPDesc_popup(String Pagename,
			String sortingtype) throws InterruptedException {
		List<String> UIPayershortlist = null;
		if (Pagename.equalsIgnoreCase("AWB")) {
			String Payershorts = oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage);

			UIPayershortlist = Arrays.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));
		}

		// Select the DPDesc popup from DB in the AWB/Review Worked Opportunity
		// Grid
		oAWBPage.Select_the_DPDesc_in_the_grid_from_DB(Pagename, "", UIPayershortlist);

		// CLick the DPDesc link for the given DPKey
		oAWBPage.Click_the_DPDesc_for_the_given_DPKey(Pagename);

		// validate the sorting funtionality Rules in the DP Desc popup with
		// mongo DB
		oAWBPage.validate_the_Rules_sorting_functionality_in_DPDesc_Popup(ProjectVariables.DB_DPKey, Pagename);

	}

	// ####################################################################################################

	@Step
	public void validate_the_popup_data_with_MongoDB_in_the_Page(String popup, String pagename)
			throws InterruptedException {
		List<String> UIPayershortlist = null;
		Serenity.setSessionVariable("Pagename").to(pagename);
		if (pagename.equalsIgnoreCase("AWB")) {
			String Payershorts = oAWBPage.get_TextFrom_Locator(oAWBPage.payershorts_in_AWBPage).replaceAll(" ", "");

			System.out.println("Payershorts ==>" + Payershorts);

			UIPayershortlist = Arrays.asList(StringUtils.substringAfter(Payershorts, "PayerShort:").split(","));

			System.out.println("payerhsortlist ==>" + UIPayershortlist);
		}

		// Retrieve the DPkeys based on the popupname,client,release and
		// payershorts
		MongoDBUtils.Get_the_DPKeys_based_on_client_release_and_Descisions(Serenity.sessionVariableCalled("clientkey"),
				Serenity.sessionVariableCalled("release"), UIPayershortlist, popup, pagename);

		switch (popup) {
		case "latest Client Decision":

			oAWBPage.validate_the_popup_data_with_MongoDB_in_the_Page(popup, ProjectVariables.DB_DPKey, pagename);

			break;

		case "Current Disposition":

			oAWBPage.validate_the_popup_data_with_MongoDB_in_the_Page(popup, ProjectVariables.DB_DPKey, pagename);

			break;

		case "Prior Disposition":

			oAWBPage.validate_the_popup_data_with_MongoDB_in_the_Page(popup, ProjectVariables.DB_DPKey, pagename);

			break;

		default:

			Assert.assertTrue("Given selection is not found ===>" + popup, false);

			break;
		}

	}

	// ####################################################################################################

	@Step
	public void user_select_Medical_Policy_from_the_policy_selection_through_MongoDB_for_the_given_payershort(
			String arg1) throws InterruptedException {
		String DBMedicalpolicy = MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(
				Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), arg1);

		if (DBMedicalpolicy == null) {
			Assert.assertTrue("Retrieved Medical policy is 'null' from the mongoDB for the client ===>"
					+ Serenity.sessionVariableCalled("client") + ",Release ===>"
					+ Serenity.sessionVariableCalled("release"), false);
		}

		Serenity.setSessionVariable("Medicalpolicy").to(DBMedicalpolicy);

		Serenity.setSessionVariable("sPayershort").to(arg1);

		oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DBMedicalpolicy);

		Assert.assertTrue("Unable to click the 'AWBGrid Hirerarchy' icon",
				oAWBPage.clickGivenXpath(oAWBPage.AWBGridHirerachy));

		OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);

	}

	// ####################################################################################################

	@Step
	public void select_DP_key_in_Opportunity_grid_under_page(int arg1, String arg2, String arg3) {
		if (arg3.equalsIgnoreCase("Review Worked Opportunities")) 
		{
			Serenity.setSessionVariable("Pagename").to("RWO");
			oGenericUtils.clickOnElement(
					StringUtils.replace(oAWBPage.Span_contains_text, "value", "Review Worked Opportunities"));
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
			// Verify WORKED OPPORTUNITIES screen
			Assert.assertTrue(
					"Worked Opportunities header is not displaying in the Review WorkedOpp Page,after clicking on that link in AWB Page",
					oOpportunityRunsPage.Wait_Untill_Element_is_displayed(10, oAWBPage.WorkedOpportunityHeader));

			if (Serenity.sessionVariableCalled("sPayershort") != null) {
				Assert.assertTrue("Unable to un-check the 'Payershort' header checkbox in the RWO Page",
						oOpportunityRunsPage.ApplyFilters("Payer Short", "", "UNCHECK", ""));
				Assert.assertTrue(
						"Unable to check the Payershort '" + Serenity.sessionVariableCalled("sPayershort")
								+ "'  checkbox in the RWO Page",
						oOpportunityRunsPage.ApplyFilters("Payer Short", Serenity.sessionVariableCalled("sPayershort"),
								"CHECK", ""));

			} else {
				Assert.assertTrue("Unable to check the 'Payershort' header checkbox in the RWO Page",
						oOpportunityRunsPage.ApplyFilters("Payer Short", "", "CHECK", ""));

			}
			Assert.assertTrue("Unable to check the 'Flag' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Product' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Product", "", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Insurance' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Insurance", "", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Latest Client Decision' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Latest Client Decision", "", "CHECK", ""));
			Assert.assertTrue("Unable to check the 'Current Disposition' header checkbox in the RWO Page",
					oOpportunityRunsPage.ApplyFilters("Current Disposition", "", "CHECK",
							StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));

		}

		Serenity.setSessionVariable("Pagename").to(arg3);
		if (arg3.equalsIgnoreCase("eLL")) {
			Assert.assertTrue("Unable to click the 'eLL' tab in AWBGrid", oAWBPage
					.clickGivenXpath(StringUtils.replace(oAWBPage.Div_contains_text, "value", "Opportunities(eLL)")));
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_10_Seconds);

		}
		
		if(arg3.equalsIgnoreCase("Review Worked Opportunities"))
		{
			ProjectVariables.sGetDPItems = oOpportunityRunsPage.SelectDPKeysInRWOPage(arg2, arg1);
		}
		else
		{
			ProjectVariables.sGetDPItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage(arg2, arg1);	
		}
		

	}

	// ####################################################################################################

	@Step
	public void validate_UI_data_with_MongoDB_under_DPWB_page_from_page(String arg1, String arg2) {
		String sDispostion = null;
		int sRuleinBaseline = 0;
		if (arg2.equalsIgnoreCase("AWB")) {
			sDispostion = "No Disposition";
		} else {
			sDispostion = Serenity.sessionVariableCalled("sCurrentDP");
		}
		String sDPLinkVal = ProjectVariables.sGetDPItems.get(0);
		Serenity.setSessionVariable("dpkey").to(sDPLinkVal);
		System.out.println("DP key:==" + Serenity.sessionVariableCalled("dpkey"));
		String sGetStatus = StringUtils.substringBefore(
				oDPWBPage.ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[2]")),
				"Status").trim();

		if (sGetStatus.equalsIgnoreCase("Opportunity")) {
			sRuleinBaseline = 0;
		} else if (sGetStatus.equalsIgnoreCase("Production")) {
			sRuleinBaseline = -1;
		} else {
			sRuleinBaseline = -0;
		}
		Serenity.setSessionVariable("savingsstatus").to(sRuleinBaseline);
		switch (arg1.toUpperCase()) {
		case "INSURANCE_SECTION":
			oDPWBPage.RetreiveDPWBInsuranceSectionData("Commercial", arg1, sDispostion);
			oDPWBPage.RetreiveDPWBInsuranceSectionData("BlueCard", arg1, sDispostion);
			oDPWBPage.RetreiveDPWBInsuranceSectionData("Dual Eligible", arg1, sDispostion);
			oDPWBPage.RetreiveDPWBInsuranceSectionData("Federal Employee Program", arg1, sDispostion);
			oDPWBPage.RetreiveDPWBInsuranceSectionData("Medicaid", arg1, sDispostion);
			oDPWBPage.RetreiveDPWBInsuranceSectionData("Medicare", arg1, sDispostion);
			break;
		case "SUMMARY_DATA":
			oDPWBPage.sRetrieveSummaryData(sDispostion);
			break;
		case "DP_SUMMARY_SAVINGS":
			oDPWBPage.RetreiveDPWBInsuranceSectionData("", arg1, sDispostion);
			break;
		case "RULE_HEADER_SAVINGS":
			oDPWBPage.RetrieveRuleHeadearSavingsinDPWB(sDispostion);
			break;
		case "RULE_DATA":
			oDPWBPage.RetrieveRuleDatainDPWB(sDispostion);
			break;
		case "RULE_PAYER_GRID":
			oDPWBPage.RetrievePayerGridData(sDispostion);
			break;
		default:
			Assert.assertTrue("Given selection was ot found ==>" + arg1, false);
			break;
		}

	}

	// ####################################################################################################

	@Step
	public void validate_functionality_under_page(String arg1, String arg2, String arg3) {

		String sMessage = "Re: " + Serenity.sessionVariableCalled("sRandomSubject").toString();
		//oMessagesPage.ArchiveMessage(sMessage, arg2);
	}

	// ####################################################################################################

	public void store_and_into_serenity(String arg1, String arg2) {
		// ===========================================================
		Serenity.setSessionVariable("client").to(arg1);
		Serenity.setSessionVariable("policyRelease").to(arg2);
	}

	@Step
	public void Validate_the_opportunity_grid_data_with_mongo_DB(String i) throws Exception {
		String PolicyRelease = null;
		String ClientName = null;
		String Client_TotalEdits = null;
		String Client_RawSavings = null;
		String Client_AggSavings = null;
		String Client_ConSavings = null;
		int pixelsize = 500;
		int iCount = 0;

		// int
		// sRvarunsize=oAWBPage.get_Matching_WebElement_count(oAWBPage.OppGrid_ClientsList);

		// for (int i = 1; i <= sRvarunsize; i++)
		{
			AWBPage.scrollingToGivenElement(getDriver(), oAWBPage.OppGrid_ClientsList + "[" + i + "]");

			PolicyRelease = oAWBPage.get_TextFrom_Locator(oAWBPage.OppGrid_ClientsList + "[" + i + "]");
			ClientName = oAWBPage.get_TextFrom_Locator(
					"(" + oAWBPage.OppGrid_ClientsList + "[" + i + "]/ancestor::td//following-sibling::td)[1]//span");

			Client_TotalEdits = oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(
					"(" + oAWBPage.OppGrid_ClientsList + "[" + i + "]/ancestor::td//following-sibling::td)[2]//span")
					.trim());
			Client_RawSavings = oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(
					"(" + oAWBPage.OppGrid_ClientsList + "[" + i + "]/ancestor::td//following-sibling::td)[3]//span")
					.trim());
			Client_AggSavings = oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(
					"(" + oAWBPage.OppGrid_ClientsList + "[" + i + "]/ancestor::td//following-sibling::td)[4]//span")
					.trim());
			Client_ConSavings = oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(
					"(" + oAWBPage.OppGrid_ClientsList + "[" + i + "]/ancestor::td//following-sibling::td)[5]//span")
					.trim());

			oOpportunityRunsPage.ValidateThepayershortsandSavingswithMongoDb(ClientName, PolicyRelease);

			verify("Opportunity Dashboard DBTotalEdits=>" + Serenity.sessionVariableCalled("ClientTotalEdits")
					+ ",ClientTotalEdits=>" + Client_TotalEdits + ",Client=>" + ClientName + ",PolicyRelease=>"
					+ PolicyRelease,
					Serenity.sessionVariableCalled("ClientTotalEdits").equals(Long.valueOf(Client_TotalEdits)));
			verify("Opportunity Dashboard DBRawsavings=>" + Serenity.sessionVariableCalled("ClientRawsavings")
					+ ",ClientRawSavings=>" + Client_RawSavings + ",Client=>" + ClientName + ",PolicyRelease=>"
					+ PolicyRelease,
					Serenity.sessionVariableCalled("ClientRawsavings").equals(Long.valueOf(Client_RawSavings)));
			verify("Opportunity Dashboard DBAggsavings=>" + Serenity.sessionVariableCalled("ClientAggsavings")
					+ ",ClientAggSavings=>" + Client_AggSavings + ",Client=>" + ClientName + ",PolicyRelease=>"
					+ PolicyRelease,
					Serenity.sessionVariableCalled("ClientAggsavings").equals(Long.valueOf(Client_AggSavings)));
			verify("Opportunity Dashboard DBConsavings=>" + Serenity.sessionVariableCalled("ClientConsavings")
					+ ",Client_ConSavings=>" + Client_ConSavings + ",Client=>" + ClientName + ",PolicyRelease=>"
					+ PolicyRelease,
					Serenity.sessionVariableCalled("ClientConsavings").equals(Long.valueOf(Client_ConSavings)));

			/*
			 * if(i==sRvarunsize) {
			 * 
			 * JavascriptExecutor js = (JavascriptExecutor) getDriver();
			 * js.executeScript(
			 * "document.getElementsByClassName('k-grid-content')[0].scrollTop = "
			 * +pixelsize+""); pixelsize=pixelsize+500; iCount=iCount+1;
			 * sRvarunsize=oAWBPage.get_Matching_WebElement_count(oAWBPage.
			 * OppGrid_ClientsList); }
			 */

		}

	}

	// ########################################### PI-25 Steps
	// #################################################

	@Step
	public void validate_the_clients_in_alphabitical_order_in_AWB_page() {
		// To retrieve the all clients from 'select a client' dropdown in AWB
		// page
		GenericUtils.validate_the_sorting_funtionality(oAWBPage.RetrieveAlltheClientsfromDropdown(), "Ascending order",
				"ClientsList in Dropdown of AWBPage");
		;

	}

	@Step
	public void validateThedatainAWBgridwithDBforthePPS(String tabname, String payershorts, String insurances,
			String products, String LCDS) throws InterruptedException, ParseException {
		String client = Serenity.sessionVariableCalled("client");
		ArrayList<Integer> svgstatuslist = new ArrayList<>();
		List<String> Payershortlist = Arrays.asList(payershorts.split(","));
		List<String> InsuranceList = Arrays.asList(insurances.split(","));
		List<String> ClaimtypeList = Arrays.asList(products.split(","));
		List<String> LatestClientDecisionList = Arrays.asList(LCDS.split(","));
		svgstatuslist.add(0);
		svgstatuslist.add(-1);

		String sDPKey = null;
		int iDPsize = 0;
		int icount = 0;
		String sMP = Serenity.sessionVariableCalled("Medicalpolicy");
		List<String> DPKeysList = null;

		switch (tabname) {
		case "RVA Tab":
			iDPsize = oAWBPage.get_Matching_WebElement_count(
					StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number"));
			if(iDPsize==0)
			{
				Assert.assertTrue("NO dpkey is available in RVA tab for the selected MP::"+Serenity.sessionVariableCalled("Medicalpolict"), false);
			}
			for (int i = 1; i <= iDPsize; i++) {
				sDPKey = oAWBPage.get_TextFrom_Locator(
						StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number") + "[" + i + "]/button");
				System.out.println("############################################################################");
				System.out.println(i + ".DPkey::" + sDPKey + ",DPkeySize::" + iDPsize);
				System.out.println("############################################################################");
				// To retrieve the AWBGrid data from DB based on dpkey
				MongoDBUtils.getAWBGriddatabasedonDPkeyandPPS(sMP,sDPKey, "medPolicyDesc", Payershortlist, InsuranceList,
						ClaimtypeList, LatestClientDecisionList, svgstatuslist);
				// To validate the AWB grid data with mongo DB
				oAWBPage.verifyTheAWBGiddatabasedOnDP(sDPKey, sMP, "MP");
			}
			break;
		case "No Edits DPs":
			// To retrieve the topics with no edits from DB
			MongoDBUtils.getNoEditsTopicsandDPsinAWB("topicDesc", Payershortlist, InsuranceList, ClaimtypeList,
					LatestClientDecisionList);
			// To open filter panel
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters(payershorts, insurances, products,
					LCDS);
			for (int j = 0; j < ProjectVariables.TopicswithMultipleDPs.size(); j++) {
				icount = icount + 1;
				String sTopic = StringUtils.substringBefore(ProjectVariables.TopicswithMultipleDPs.get(j), "::").trim();
				String sDPKeys = StringUtils.substringAfter(ProjectVariables.TopicswithMultipleDPs.get(j), "::").trim();
				System.out.println("############################################################################");
				System.out.println(j + 1 + ".Topic::" + sTopic + ",DPkeys::" + sDPKeys
						+ " validation in AWBGrid,Topicssize::" + ProjectVariables.TopicswithMultipleDPs.size());
				System.out.println("############################################################################");
				if (!oAWBPage.is_WebElement_Displayed("//h3[.='Choose a Medical Policy/Topic']")) {
					// To open filter panel
					oOpportunityRunsPage.OpenFilterPanel();
				}
				// To Selcet Display MPs/Topic toggle selection
				oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
				// Select the policy selection drawer and apply all checkboxes
				oOpportunityRunsPage.SelectGivenMPinFilterPanel(sTopic, "Topic");
				oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
				oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
				AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
				oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
				
				DPKeysList = Arrays.asList(sDPKeys.split(","));
				for (int i = 0; i < DPKeysList.size(); i++) {
					System.out.println("############################################################################");
					GenericUtils.Verify(
							i + 1 + ".NoEdits DPKey::" + DPKeysList.get(i) + " should be displayed in AWBGrid,Topic::"
									+ sTopic+",DPKEYSize::"+DPKeysList.size(),
							oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.ButtonContainsText, "value",
									DPKeysList.get(i).trim())));
					System.out.println("############################################################################");
					// To retrieve the AWBGrid data from DB based on dpkey
					MongoDBUtils.getAWBGriddatabasedonDPkeyandPPS(sTopic,DPKeysList.get(i).trim(), "topicDesc", Payershortlist, InsuranceList,
							ClaimtypeList, LatestClientDecisionList, svgstatuslist);
					// To validate the AWB grid data with mongo DB
					oAWBPage.verifyTheAWBGiddatabasedOnDP(DPKeysList.get(i).trim(), sTopic, "Topic");
				}

				if (icount == 1) {
					break;
				}
			}
			break;
		case "eLL Griddata":
			validate_the_grid_columns_in_AWB_Page("eLL");
			iDPsize = oAWBPage.get_Matching_WebElement_count(oAWBPage.eLL_DP_Column);
			if(iDPsize==0)
			{
				Assert.assertTrue("NO dpkey is available in eLL tab for the selected MP::"+Serenity.sessionVariableCalled("Medicalpolict"), false);
			}
			for (int i = 1; i <= iDPsize; i++) 
			{
				AWBPage.scrollingToGivenElement(getDriver(), oAWBPage.eLL_DP_Column+"["+i+"]");
				AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				sDPKey = oAWBPage.get_TextFrom_Locator(oAWBPage.eLL_DP_Column+"["+i+"]");
				//DB Method to retrieve the ellGrid data based on DPkey
				String status_CDMDecision=MongoDBUtils.getLatestDecisionforgiveneLLDPkeyPPS(sDPKey, payershorts, insurances, products,LCDS);
				GenericUtils.Verify(i+".DPkey::"+sDPKey+",DPkeySize::"+iDPsize, true);
				//To verify eLLgrid with DB
				oAWBPage.verifyeLLGridbasedOnDPKey(sDPKey,sMP,status_CDMDecision);
			}
		break;
		default:
			Assert.assertTrue("Case not found::" + tabname, false);
			break;
		}

	}

	@Step
	public void validate_the_filters_checkboxes_funcitonality_in_the_FilterPanel(String checkboxesnames) {
		// To Open Filter Panel
		oOpportunityRunsPage.OpenFilterPanel();
		// To validate the filter checkboxes functionality in filter panel
		oAWBPage.validate_the_filters_checkboxes_funcitonality(checkboxesnames, "Filter Panel");

	}

	@Step
	public void validate_the_grid_columns_in_AWB_Page(String gridname) {

		oAWBPage.verifygridcolumnsinAWBPae(gridname);

	}

	@Step
	public void userShouldseeinAWBPage(String sClientname) {
		GenericUtils.Verify(
				"Clientname '" + sClientname + "' should be displayed in the AWB page as per Retain functionality",
				oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_with_text, "value", sClientname)));
	}

	public void validateTheDataintheAWBGridwithDB(String sTabname) throws ParseException, InterruptedException {
		String sDPKey = null;
		int iDPsize = 0;
		int icount = 0;
		String sMP = Serenity.sessionVariableCalled("Medicalpolicy");
		List<String> DPKeysList = null;
		List<String> emptyList = new ArrayList<>();

		switch (sTabname) {
		case "RVA Tab":
			iDPsize = oAWBPage.get_Matching_WebElement_count(
					StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number"));
			if(iDPsize==0)
			{
				Assert.assertTrue("NO dpkey is available in RVA tab for the selected MP::"+Serenity.sessionVariableCalled("Medicalpolict"), false);
			}
			for (int i = 1; i <= iDPsize; i++) {
				sDPKey = oAWBPage.get_TextFrom_Locator(
						StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number") + "[" + i + "]/button");
				System.out.println("############################################################################");
				GenericUtils.Verify(i + ".DPkey::" + sDPKey + ",DPkeySize::" + iDPsize, true);
				System.out.println("############################################################################");
				// To retrieve the AWBGrid data from DB based on dpkey
				MongoDBUtils.getAWBGriddatabasedonDPkeyandMP(sDPKey, sMP, "medPolicyDesc");
				// To validate the AWB grid data with mongo DB
				oAWBPage.verifyTheAWBGiddatabasedOnDP(sDPKey, sMP, "MP");
			}
			break;
		case "No Edits DPs":
			// To retrieve the topics with no edits from DB
			MongoDBUtils.getNoEditsTopicsandDPsinAWB("topicDesc", emptyList, emptyList, emptyList, emptyList);
			// To open filter panel
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters();
						
			for (int j = 0; j < ProjectVariables.TopicswithMultipleDPs.size(); j++) {
				icount = icount + 1;
				String sTopic = StringUtils.substringBefore(ProjectVariables.TopicswithMultipleDPs.get(j), "::").trim();
				String sDPKeys = StringUtils.substringAfter(ProjectVariables.TopicswithMultipleDPs.get(j), "::").trim();
				System.out.println("############################################################################");
				GenericUtils.Verify(j + 1 + ".Topic::" + sTopic + ",DPkeys::" + sDPKeys
						+ " validation in AWBGrid,Topicssize::" + ProjectVariables.TopicswithMultipleDPs.size(), true);
				System.out.println("############################################################################");
				if (!oAWBPage.is_WebElement_Displayed("//h3[.='Choose a Medical Policy/Topic']")) {
					// To open filter panel
					oOpportunityRunsPage.OpenFilterPanel();
				}
				// To Selcet Display MPs/Topic toggle selection
				oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
				// Select the policy selection drawer and apply all checkboxes
				oOpportunityRunsPage.SelectGivenMPinFilterPanel(sTopic, "Topic");
				oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
				oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
				AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
				oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);

				DPKeysList = Arrays.asList(sDPKeys.split(","));
				for (int i = 0; i < DPKeysList.size(); i++) {
					System.out.println("############################################################################");
					GenericUtils.Verify(
							i + 1 + ".NoEdits DPKey::" + DPKeysList.get(i) + " should be displayed in AWBGrid,Topic::"
									+ sTopic+",DPKEYSize::"+DPKeysList.size(),
							oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.ButtonContainsText, "value",
									DPKeysList.get(i).trim())));
					System.out.println("############################################################################");
					// To retrieve the AWBGrid data from DB based on dpkey
					MongoDBUtils.getAWBGriddatabasedonDPkeyandMP(DPKeysList.get(i).trim(), sTopic, "topicDesc");
					// To validate the AWB grid data with mongo DB
					oAWBPage.verifyTheAWBGiddatabasedOnDP(DPKeysList.get(i).trim(), sTopic, "Topic");
				}

				if (icount == 1) {
					break;
				}
			}
			break;
		case "eLL Tab":
			DPKeysList=Arrays.asList(oAWBPage.get_All_Text_from_Locator(oAWBPage.eLL_DP_Column));
			if(DPKeysList.size()>0){				
				//hard coding 3 because validating only for first 2 DP's
				for(int i=0;i<2;i++){					
					sDPKey=DPKeysList.get(i);
					GenericUtils.Verify("validation successful for clicking on expand icon for DP:"+sDPKey, oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Span_contains_text, "value", sDPKey)+"/../..//a"));
					AWBPage.defaultWait(ProjectVariables.TImeout_10_Seconds);
					oAppUtils.WaitUntilPageLoad();
					//validate DP Description
					//Validate DP Detail View
					String[] Headers=ProjectVariables.eLL_DP_View_Headers.split(",");
					//Header Validation
					for(int j=0;j<Headers.length;j++){
						GenericUtils.Verify("validation successful for displaying eLL DP dataview header with checkbox as:"+Headers[j], oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.labelWithCheckbox, "svalue", Headers[j])));
					}
					GenericUtils.Verify("validation successful for selcting check box for payershort", oGenericUtils.clickOnElement(oAWBPage.eLL_DP_View_Checkbox));
				if(i==0){
						ArrayList<String> PPS=MongoDBUtils.retrieveThePPSforDPkey(sDPKey,"","","","","");
						//PPS validation with DB
						for(int j=0;j<PPS.size();j++){
							String[] sPPS=PPS.get(j).split(":");
							GenericUtils.Verify("Validation successful for displaying checkbox with PPS combination:"+PPS.get(j),oAWBPage.is_WebElement_Displayed(oAWBPage.PPS_Comb_Checkbox(sPPS[0], sPPS[2], sPPS[1].toLowerCase())));
						}
						GenericUtils.Verify("validation successful for selcting check box for payershort", oGenericUtils.clickOnElement(oAWBPage.eLL_DP_View_Checkbox));
					}else if(i==1){
						sDPKey=DPKeysList.get(i-1);
						//collapse validation
						GenericUtils.Verify("validation successful for collapsing the DP:"+sDPKey, oAWBPage.Get_Value_By_given_attribute("title", StringUtils.replace(oAWBPage.Span_contains_text, "value", sDPKey)+"/../..//a").equals("Expand Details"));
						//retain selection validation
						Assert.assertTrue("Failed to click on expand icon for DPKey:"+sDPKey,oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Span_contains_text, "value", sDPKey)+"/../..//a"));
						GenericUtils.Verify("validation successful for not retaining the checkbox selection", !oAWBPage.is_WebElement_Selected(oAWBPage.eLL_DP_View_Checkbox));
					}												
																								
				}				
			}else{
				GenericUtils.Verify("No DP's are available under Oppurtunity(eLL) grid", false);
			}
			
			break;
		case "eLL Griddata":
			validate_the_grid_columns_in_AWB_Page("eLL");
			oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
			AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
			iDPsize = oAWBPage.get_Matching_WebElement_count(oAWBPage.eLL_DP_Column);
			if(iDPsize==0)
			{
				Assert.assertTrue("No dpkey is available in eLL tab for the selected MP::"+Serenity.sessionVariableCalled("Medicalpolicy"), false);
			}
			for (int i = 1; i <= iDPsize; i++) 
			{
				AWBPage.scrollingToGivenElement(getDriver(), oAWBPage.eLL_DP_Column+"["+i+"]");
				AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				sDPKey = oAWBPage.get_TextFrom_Locator(oAWBPage.eLL_DP_Column+"["+i+"]");
				//DB Method to retrieve the ellGrid data based on DPkey
				String status_CDMDecision=MongoDBUtils.getLatestDecisionforgiveneLLDPkeyPPS(sDPKey, "", "", "", "");
				GenericUtils.Verify(i+".DPkey::"+sDPKey+",DPkeySize::"+iDPsize, true);
				//To verify eLLgrid with DB
				oAWBPage.verifyeLLGridbasedOnDPKey(sDPKey,sMP,status_CDMDecision);
			}
		break;
		default:
			Assert.assertTrue("Case not found::" + sTabname, false);
			break;
		}

	}

	@Step
	public void Validate_the_DPs_displayed_in_the_given_page_with_MongoDB(String tabname, String payershort,
			String insurance, String claimtype, String LCD) throws InterruptedException {

		String client = Serenity.sessionVariableCalled("client");
		List<String> Payershortlist = Arrays.asList(payershort.split(","));
		List<String> InsuranceList = Arrays.asList(insurance.split(","));
		List<String> ClaimtypeList = Arrays.asList(claimtype.split(","));
		List<String> LatestClientDecisionList = Arrays.asList(LCD.split(","));
		List<Long> DB_DPKeylist=new ArrayList<>();
		List<String> DPKeylist=new ArrayList<>();
		List<String> DB_Medicalpolicylist=new ArrayList<>();
		
		
		if(tabname.equalsIgnoreCase("eLL Tab"))
		{	
			//DB method to get eLL MPs
			MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel(payershort,insurance,claimtype,LCD);
			DB_Medicalpolicylist.addAll(ProjectVariables.DB_MPlist);
		}
		else
		{
			MongoDBUtils.Retrieve_the_medicalpolicy_based_on_PPS(payershort,insurance,claimtype,LCD);
			DB_Medicalpolicylist.addAll(ProjectVariables.DB_Medicalpolicylist);
		}
	
		int i = 0;
		for (String DBmedicalpolicy : DB_Medicalpolicylist) {
			i = i + 1;
			
			if(tabname.equalsIgnoreCase("eLL Tab"))
			{
				String MP=StringUtils.substringBefore(DBmedicalpolicy, "::");
				DPKeylist=Arrays.asList(StringUtils.substringAfter(DBmedicalpolicy, "::").split(","));
				for (int j = 0; j < DPKeylist.size(); j++) {
					DB_DPKeylist.add(Long.valueOf(DPKeylist.get(j)));
				}
				oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(MP, payershort, insurance, claimtype, LCD);
				validate_the_grid_columns_in_AWB_Page("eLL");
			}
			else
			{
				MongoDBUtils.Retrieve_the_DPs_based_on_PPS_in_AWB(Payershortlist, InsuranceList, ClaimtypeList,
						LatestClientDecisionList);
				DB_DPKeylist.addAll(ProjectVariables.DB_DpkeyList);
				// To select the given medicalpolicy from policy selection
				selectMPfromFilterpanelForgivenPPS(tabname, payershort, insurance, claimtype, LCD);
				
			}
			//To select 'Production' checkbox
			oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
			AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
			
			// To verify the DPs in AWB grid
			oAWBPage.Validate_the_DPs_in_Opportunity_Grid_with_Mongo_DB(client, DBmedicalpolicy,tabname,DB_DPKeylist);

			break;
		}
		
		

	}

	public void validatetheDispositionpopup(String tabName) throws InterruptedException 
	{
		Serenity.setSessionVariable("Pagename").to(tabName);
		String sDPkey=Serenity.sessionVariableCalled("DPkey");
		switch (tabName) {
		case "eLL":
			// To validate the disposition popup in RVA Tab in awbgrid
			oAWBPage.verifyDispositionPopup(tabName);

			break;
		case "RVA":
			// To validate the disposition popup in RVA Tab in awbgrid
			oAWBPage.verifyDispositionPopup(tabName);
			break;
		case "DPPPS Selectionmessage":
			//to verify selection message at DP+PPS level in the grid to capture
			boolean bstatus=oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", ProjectVariables.DPPPSMessage));
			GenericUtils.Verify("Message should be displayed at PPS level::"+ProjectVariables.DPPPSMessage+",for DPKEY::"+sDPkey, bstatus);
			break;
		default:
			Assert.assertTrue("case not found==>" + tabName, false);
			break;
		}

	}

	@Step
	public void selectMPfromFilterpanelForgivenPPS(String datacriteria, String payershort, String insurance,
			String claimtype, String LCD) throws InterruptedException {
	

		String DBMedicalpolicy = null;
		if (datacriteria.equalsIgnoreCase("eLL")) {
			DBMedicalpolicy = MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel(payershort, insurance, claimtype,
					LCD);
		} else {
			DBMedicalpolicy = MongoDBUtils.Retrieve_the_medicalpolicy_based_on_PPS(payershort, insurance, claimtype,
					LCD);
		}
		Serenity.setSessionVariable("Medicalpolicy").to(DBMedicalpolicy);
		oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(DBMedicalpolicy, payershort, insurance, claimtype,
				LCD);
		//To select 'Production' checkbox
		oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
		oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
		AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
		oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		
		Assert.assertFalse(
				"'No results found that meet the search criteria.' message is displayed in the AWB Grid for the Medical policy ==>"
						+ DBMedicalpolicy,
				oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value",
						"No results found that meet the search criteria.")));

	}

	@Step
	public void userSelectsMPWithoutNoneDecision(String datatype, String NotRequiredDecision)
			throws InterruptedException {
		String DBMedicalpolicy = null;
		if (datatype.equalsIgnoreCase("eLL")) {
			DBMedicalpolicy = MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel("", "", "", "");
		} else {
			DBMedicalpolicy = MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(
					Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "");
		}
		
		if (DBMedicalpolicy == null) {
			Assert.assertTrue("Retrieved Medical policy is 'null' from the mongoDB for the client ===>"
					+ Serenity.sessionVariableCalled("client") , false);
		}
		Serenity.setSessionVariable("Medicalpolicy").to(DBMedicalpolicy);
		oOpportunityRunsPage.SelectMPwithoutNoneDecisoin(DBMedicalpolicy);
		//To open given tab
		validate_the_grid_columns_in_AWB_Page(datatype);
	}

	@Step
	public void verifyPPSinDPviewwithDB(String tabname,
			String UIpayershort,String UIinsurance,String UIclaimtype,String UILCD,String savingsstatus) throws Exception
	{
		String sdpKey=null;
		
		if(!savingsstatus.isEmpty())
		{
			oAWBPage.selectGivensavingsstatus(savingsstatus);
		}
		else
		{
			oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
			AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		}
		int idpSize=oAWBPage.get_Matching_WebElement_count(StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number"));
		if(idpSize==0)
		{
			Assert.assertTrue("DPkey count is zero for the selected MP::"+Serenity.sessionVariableCalled("Medicalpolicy")+" in "+tabname, false);
		}
		/*if(!UILCD.isEmpty()&&!savingsstatus.isEmpty()&&!UILCD.contains(",")&&!savingsstatus.contains(","))
		{
			oAWBPage.verifyLCDandsavingsstatusasperselectioninUI(savingsstatus,UILCD,tabname);
		}*/
		
		for (int i = 1; i <= idpSize; i++) 
		{
			AWBPage.scrollingToGivenElement(getDriver(), 
					StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number") + "[" + i + "]/button");
			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			sdpKey = oAWBPage.get_TextFrom_Locator(
					StringUtils.replace(oAWBPage.Div_contains_class, "value", "dp-number") + "[" + i + "]/button").trim();
			GenericUtils.Verify(i+".DPkey::"+sdpKey+" dpview validation started, DPkeysize::"+idpSize, true);
			//To open dpview of dpkey
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ButtonContainsText, "value", sdpKey)+"/../../preceding-sibling::td[4]/a");
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 5);
		
			//To verify the pps in the dpview
			oAWBPage.verifythePPSinDPviewwithDB(sdpKey, tabname, UIpayershort, UIinsurance, UIclaimtype, UILCD,savingsstatus);
			
			//To close dpview of dpkey
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ButtonContainsText, "value", sdpKey)+"/../../preceding-sibling::td[4]/a");
			oAWBPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 5);
		
		}
	}

	@Step
	public void verifyDPviewRetainfunctionality(String tabname) 
	{
		Assert.assertTrue("'Savings Status' filter checkbox is unable to un-check in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","","UNCHECK",""));
		Assert.assertTrue("'Opportunity' filter checkbox is unable to checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","Opportunity","CHECK",StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		AWBPage.defaultWait(ProjectVariables.TImeout_10_Seconds);
		
		//To verify the DPview Retain functionality
		oAWBPage.verifyRetainfunctionalityofRVADPView(tabname);
		
	}
	
	public void verifyLCDandSavingsstatusChkboxfunctionality(String LCD,String Savingssttaus,String tabname) throws ParseException
	{
		
		//To select given savingsstatus 
		oAWBPage.selectGivensavingsstatus(Savingssttaus);
		if(tabname.equalsIgnoreCase("eLL"))
		{
			validate_the_grid_columns_in_AWB_Page("eLL");
		}
		
		oAWBPage.verifySavningsstatusandLCDinAWBgridbasedonfilter(Savingssttaus,LCD,tabname);
		
		
	}

	@Step
	public void selectMultipleMPs(String sTabname,String requiredcount,
			String payershort, String insurance,
			String claimtype, String LCD) throws Throwable {
		if (sTabname.equalsIgnoreCase("eLL")) 
		{
			MongoDBUtils.retrieveTheeLLMPsbasedonPPSforFilterPanel(payershort, insurance, claimtype,LCD);
		}
		else 
		{
			if(payershort.isEmpty())
			{
				MongoDBUtils.Retrieve_the_medicalpolicy_based_on_client_and_release(Serenity.sessionVariableCalled("clientkey"), "", "");	
			}
			else
			{
				MongoDBUtils.Retrieve_the_medicalpolicy_based_on_PPS(payershort, insurance, claimtype,LCD);
			}
		}
		if(payershort.isEmpty())
		{
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters();
		}
		else
		{
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters(payershort, insurance, claimtype,LCD);
		}
		//To Selcet Display MPs/Topic toggle selection
		oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
		//To select the given MP in filterPanel and applytoopportunity grid
		oOpportunityRunsPage.selectGivenMulipleMPs(ProjectVariables.Medicalpolicy_PolicySelectiondrawer,"MP");
	}

	public void verifyCaptureDispositionFunctionality(String dpkeycount,String Disposition,
			String payershort,String insurance,String claimtype,String LCD,String tabname) throws InterruptedException
	{
		String sCheckboxcriteria=null;
		ArrayList<String> sGetDPItems=new ArrayList<>();
		
		sCheckboxcriteria=StringUtils.substringBefore(dpkeycount, "-");
		dpkeycount=StringUtils.substringAfter(dpkeycount, "-");
		
		//To select savingstatus as 'Opportunity'
		oAWBPage.selectGivensavingsstatus("Opportunity");
		//To select the RVA/eLL grid
		oAWBPage.verifygridcolumnsinAWBPae(tabname);
		
		Serenity.setSessionVariable("Pagename").to(tabname);
		
		sGetDPItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage(sCheckboxcriteria,Integer.valueOf(dpkeycount));
		System.out.println("DP Key ===>"+sGetDPItems);
		System.out.println("Selected the '"+dpkeycount+"' DPKey successfully");
		
		if(sCheckboxcriteria.equalsIgnoreCase("PAYER_CHKBOX"))
		{
			oAWBPage.capture_the_data_at_payershort_level(Disposition, tabname, payershort, insurance, claimtype, LCD);
		}
		else
		{
			//validate the capture disposition functionality at dplevel
			oAWBPage.capture_the_data_at_DP_level(sGetDPItems,Disposition, tabname,payershort, insurance, claimtype,LCD);	
			
			//oAWBPage.validate_the_update_disposition_funtionality_for_captured_pps_in_review_worked_opportunity_page(Updatedisposition, CaptureddataList, capturedtypeofdata);
		}
			
	}

	//##################################### Rule Relationship Methods ##########################################################//
	
	@Step
	public void captureDispositionforRulerelationshipdps(
			String rulerelationship,String tabname,String Disposition,String payershort,String insurance,String claimtype,String LCD) throws InterruptedException
	{
		
		ArrayList<String> sGetDPItems=new ArrayList<>();
		
		//To select the dpkey for the given rulerelationship
		String sDPkeypayershort=oAWBPage.selectDPKeyforgivenRulerelationship(rulerelationship,tabname,payershort, insurance, claimtype,LCD);
		String sDPkey=StringUtils.substringBefore(sDPkeypayershort, "::");
		Serenity.setSessionVariable("DPkey").to(sDPkey);
				
		if(tabname.equalsIgnoreCase("RVA"))
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.ButtonContainsText, "value", sDPkey)+"/../../preceding-sibling::td[3]/mat-checkbox");
		}
		else
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", sDPkey)+"/../preceding-sibling::td[3]/mat-checkbox");
		}
		sGetDPItems.add(sDPkey);
		//validate the capture disposition functionality at dplevel
		oAWBPage.capture_the_data_at_DP_level(sGetDPItems,Disposition, tabname+"-"+rulerelationship,payershort, insurance, claimtype,LCD);	
	}
	
	@Step
	public void captureDispositionforRulerelationshipdpsatPPSlevel(
			String rulerelationship,String Disposition,String payershort,String insurance,String claimtype,String LCD) throws Exception
	{
		/*Serenity.setSessionVariable("clientkey").to("11");
		String sDPkey="9505";
		String Payershort="SADOH";
		Serenity.setSessionVariable("DPkey").to(sDPkey);
		Serenity.setSessionVariable("RRPayershort").to(Payershort);*/
		
		//To select the dpkey for the given rulerelationship
		String sDPkeypayershort=oAWBPage.selectDPKeywithAllPPSforgivenRulerelationship(rulerelationship,"RVA",payershort, insurance, claimtype,LCD);
		String sDPkey=StringUtils.substringBefore(sDPkeypayershort, "::");
		String Payershort=StringUtils.substringAfter(sDPkeypayershort, "::");
		Serenity.setSessionVariable("DPkey").to(sDPkey);
		Serenity.setSessionVariable("RRPayershort").to(Payershort);
		
		//validate the capture disposition functionality at dplevel
		oAWBPage.captureDispositionatPPSLevelforRRDpkey(sDPkey, Payershort, rulerelationship, Disposition);	
	}

	@Step
	public void verifyFlagfilterfunctionality(String tabname,String rulerelationship,
			String payershort, String insurance, String claimtype, String LCD) throws Exception
	{
		/*Serenity.setSessionVariable("clientkey").to("11");
		Serenity.setSessionVariable("Topic").to("Modifier 24 with E/M Services During the Postoperative Period of Minor Procedures");
		Serenity.setSessionVariable("DPkey").to("8580");
		String sDPkey="8580";
		String sPayershort="SAMKS";*/
		//To select the dpkey for the given rulerelationship
		String sDPkeypayershort=oAWBPage.selectDPKeyforgivenRulerelationship(rulerelationship,tabname,payershort, insurance, claimtype,LCD);
		String sDPkey=StringUtils.substringBefore(sDPkeypayershort, "::");
		String sPayershort=StringUtils.substringAfter(sDPkeypayershort, "::");
		
		switch(tabname)
		{
		case "RVA":
			//verify flag filterfunctionality in RVA tab
			oAWBPage.verifyFlagfilterfunctionalityinRVA(rulerelationship,sDPkey,sPayershort);
			break;
		default:
			Assert.assertTrue("Case not found::"+tabname, false);
		break;
		}
		
	}
	
	@Step
	public void verifyRRpopupwithDB(String tabname,String rulerelationship,
			String payershort, String insurance, String claimtype, String LCD) throws Exception
	{
		/*Serenity.setSessionVariable("clientkey").to("11");
		String sDPkey="7222";
		String sPayershort="SACVD";*/
		
		
		//To select the dpkey for the given rulerelationship
		String sDPkeypayershort=oAWBPage.selectDPKeyforgivenRulerelationship(rulerelationship,tabname,payershort, insurance, claimtype,LCD);
		String sDPkey=StringUtils.substringBefore(sDPkeypayershort, "::");
		String sPayershort=StringUtils.substringAfter(sDPkeypayershort, "::");
		
		switch(tabname)
		{
		case "RVA":
			//verify RR popup with DB in RVA tab
			oAWBPage.verifyRRpopupwithDB(rulerelationship,sDPkey,sPayershort);
			break;
		default:
			Assert.assertTrue("Case not found::"+tabname, false);
		break;
		}
		
	}
	
	//###########################################################################################################################
	
	@Step
	public void userSelectsTopicWithoutNoneDecision(String tabname,String payershort,
			String insurance,String claimtype,String LCD)
			throws InterruptedException {
		String clientkey=Serenity.sessionVariableCalled("clientkey");
		Serenity.setSessionVariable("Pagename").to(tabname);
		String dbTopic = null;
		if (tabname.equalsIgnoreCase("eLL")) 
		{
			dbTopic = MongoDBUtils.getpureEllDPkeysfromeLLhierarchy(clientkey,
					payershort, insurance, claimtype,LCD,"Opportunity");
		} else {
			dbTopic = MongoDBUtils.getRVATopicswithNoDisposition(
			payershort, insurance, claimtype,LCD,"Opportunity");
			
		}
		
		Serenity.setSessionVariable("Topic").to(dbTopic);
		//Apply given topic to awb grid without none decision
		oOpportunityRunsPage.applygiventopictoawbgrid(dbTopic,payershort, insurance, claimtype, LCD);
		//To open given tab
		validate_the_grid_columns_in_AWB_Page(tabname);
		Assert.assertFalse("'No results found that meet the search criteria.' message is displayed in the AWB Grid for the Topic::"+dbTopic,oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", "No results found that meet the search criteria.")));

	}

	@Step
	public void verifyCapturedDPkeysinRWO(String dpCriteria,String expCriteria)
	{
		boolean actualStatus=false;
		boolean expectedStatus=false;
		String payershort=null;
		String Insurance=null;
		String claimtype=null;
		String pps=null;
		HashSet<String> payershortList=new HashSet<>();
		HashSet<String> insuranceList=new HashSet<>();
		HashSet<String> claimTypeList=new HashSet<>();
		String sDpkey=Serenity.sessionVariableCalled("DPkey");
		String assignPPS=Serenity.sessionVariableCalled("assignPPS");
		String unassignPPS=Serenity.sessionVariableCalled("unassignPPS");
		String Disposition=Serenity.sessionVariableCalled("Disposition");
		List<String> PPSList=null;;
		//List<String> unassignPPSList=Arrays.asList(unassignPPS.split(","));
		
		if(oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_with_text, "value", "CPW")))
		{
			oLoginPage.navigatetoCPWfromPMapplication();
			getDriver().navigate().refresh();
			AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
			AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
		}
		
		oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
		switch(dpCriteria)
		{
			case "DP Level":
				oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "", "");
			break;
			case "LOB Level-Assign":
				PPSList=Arrays.asList(assignPPS.split(","));
				//To select PPS in RWO Page
				oAWBPage.selectgivenPPSinRWO(PPSList);
			break;
			case "LOB Level-Unassign":
				PPSList=Arrays.asList(unassignPPS.split(","));
				//To select PPS in RWO Page
				oAWBPage.selectgivenPPSinRWO(PPSList);
				break;
			default:
				GenericUtils.Verify("Case not found::"+dpCriteria, false);
			break;
		}
		
		actualStatus=oAWBPage.verifycapturedDPkeysinRWO(sDpkey,dpCriteria,Disposition);
		switch(expCriteria)
		{
		case "Not Displayed":
			expectedStatus=false;
			
		break;
		case "Displayed":
			expectedStatus=true;
			
		break;
		default:
		Assert.assertTrue("Case not found::"+expCriteria, false);	
		break;
		
		}
		
		if(dpCriteria.equalsIgnoreCase("DP Level"))
		{
			GenericUtils.Verify("Captured DPkey::"+sDpkey+" should be "+expCriteria+" in RWO page", !(expectedStatus^actualStatus));
				
		}
		else
		{
			for (int i = 0; i < PPSList.size(); i++)
			{
			    pps=StringUtils.substringBeforeLast(PPSList.get(i), "-");
				payershort=StringUtils.substringBefore(StringUtils.substringBeforeLast(pps, "-"),"-");
				Insurance=StringUtils.substringBetween(pps, "-","-");
				claimtype=StringUtils.substringAfterLast(pps, "-");
				payershortList.add(payershort);
				insuranceList.add(Insurance);
				claimTypeList.add(claimtype);
			}
			GenericUtils.Verify("Captured DPkey::"+sDpkey+" should be "+expCriteria+" in RWO page,PPSList::"+payershortList+";"+insuranceList+";"+claimTypeList, !(expectedStatus^actualStatus));
				
		}
		
	}

	@Step
	public void verifyUpdateDispositionat(String disposition, String criteria) throws InterruptedException
	{
		ArrayList<String> sGetDPItems=new ArrayList<>();
		String sdpKey=Serenity.sessionVariableCalled("DPkey");
		String sPayerkeys=Serenity.sessionVariableCalled("Payerkeys");
		String sPayershort=null;
		ArrayList<String> spayershortList=new ArrayList<>();
		List<String> sPayerkeylist=null;
		sGetDPItems.add(sdpKey);
		switch(criteria)
		{
			case "DP Level":
				oAWBPage.Intialaize_the_Dispositions_fields_to_post(disposition);
				oAWBPage.validate_the_update_disposition_funtionality_for_captured_pps_in_review_worked_opportunity_page(disposition, sGetDPItems, "DPkeys");
				break;
			case "Payer/LOB Level":
				sPayerkeylist=Arrays.asList(sPayerkeys.split(","));
				for (int i = 0; i < sPayerkeylist.size(); i++) 
				{
					sPayershort=MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(sPayerkeylist.get(i).trim(), "PayerKey");
					spayershortList.add(sPayershort);
					
				}
				sPayershort=spayershortList.get(0);
				oAWBPage.verifyUpdateDispositionatPayerLOBLevel(disposition,sdpKey,sPayershort);
				break;
			case "RR-Payer/LOB Level":
				sPayershort=Serenity.sessionVariableCalled("RRPayershort");
				sdpKey=Serenity.sessionVariableCalled("DPkey");
				oAWBPage.verifyUpdateDispositionatPayerLOBLevel(disposition,sdpKey,sPayershort);
				oAWBPage.verifyRRRelatedDPkeysandPPSinRWO(disposition);
				break;
			default:
				Assert.assertTrue("Case not found::"+criteria, false);
				break;
		
		}
		
	}

}
