package project.feature.steps.definitions;

import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import project.pageobject.LoginPage;
import project.pageobject.PMPage;
import project.pageobject.ReviewWorkedOpportunityPage;
import project.pageobject.ServicesPage;

public class PresentationManagerStepDef extends ScenarioSteps {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	PMPage oPMPage;
	ServicesPage oServicesPage;
	LoginPage oLoginPage;
	
	//####################################################################################################
	
	@Step
	public void user_selects_given_value_from_Client_drop_down_list(String arg1) throws Throwable {
		Assert.assertTrue(oPMPage.user_selects_given_value_from_Client_drop_down_list(arg1));
	}

	@Step
	public void validate_the_functionaity_of_assigned_DPkey_for_the_created_presentation(String captureDecision, String DPKeyCriteria) throws org.json.simple.parser.ParseException, IOException 
	{
		String SecondPresentaionName=null;
		if(captureDecision.equalsIgnoreCase("Re-Assign"))
		{
			SecondPresentaionName=StringUtils.substringAfter(oServicesPage.createPresentationThroughService(Serenity.sessionVariableCalled("User"), Serenity.sessionVariableCalled("Client"), "", "", "", ""), "-");
			Serenity.setSessionVariable("SecondPresentationName").to(SecondPresentaionName);
			getDriver().navigate().refresh();
			oPMPage.waitForContentLoad();
			System.out.println(SecondPresentaionName);
			
				
		}
		System.out.println(Serenity.sessionVariableCalled("DPkey").toString());
		//Perform the capture decision operation for the given decision
		oPMPage.Perform_the_CaptureDecision_functionality_for_the_given(Serenity.sessionVariableCalled("DPkey"),captureDecision,DPKeyCriteria,SecondPresentaionName);
		
		//Validate the Presentation deck after UnAssign/ReAssign functionality of captured DPKeys
		oPMPage.validate_the_Presentation_after_capturing_the_decision(SecondPresentaionName,captureDecision,DPKeyCriteria);
		
		Serenity.setSessionVariable("PresentationName").to(SecondPresentaionName);
	}

	@Step
	public void verifyCaptureDPisavaialableinPM()
	{
		String dpkey=Serenity.sessionVariableCalled("DPkey");
		
		//verify captured dpkeys is displayed in availble deck
		oPMPage.validate_the_captured_DPkey_in_available_opportunity_deck(dpkey);
	}
	
	@Step
	public void LogintoPMapplication(String user) throws Exception
	{
		int windowsize=oPMPage.switchWindowCount(5, 2);
		
		if(windowsize==2)
		{
			oPMPage.switchWindowUsingWindowCount(5, 2);
		}
		else
		{
			boolean bstatus=oPMPage.is_WebElement_Displayed(StringUtils.replace(oPMPage.Tag_with_a, "value", "PM"));
			if(!bstatus)
			{
				//Loginto CPW
				oLoginPage.Login_CPW(user);
			}
			
			
			//To navigate to PM application
			oLoginPage.navigatetoPMfromCPWapplication();
		}
		
	}

}
