package project.feature.steps.definitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import project.pageobject.AWBPage;
import project.pageobject.ServicesPage;
import project.utilities.GenericUtils;
import project.utilities.MicroServRestUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;


public class ServicesStepDef extends ScenarioSteps {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	ServicesPage oServicesPage;
	
	@Step
	public void Access_the_Service_URl_to_retrive_the_clientdata(String username, String serviceurl) throws IOException {
		
		//method to retrieve the client data from the service response
		boolean bstatus=ServicesPage.RetrievetheClientdatafromtheResponse(username,serviceurl);
				
		
		Assert.assertTrue("Unable to post the given data for the given service",bstatus);
		
		
	}

	 @Step
     public void Post_the_given_data_validate_the_Savings_summary_of_CPW_Opportunity_Dashboard(String SeriviceURl) throws IOException {
                     boolean bstatus=false;
                     
                     
                     String JsonBody = "{\"userId\" : \"iht_ittest09@ihtech.com\" , \"userName\" : \"Generic09 ITTest\"}\r\n";
                     
                     
                     //Post the data at rule level for the given service url
                     bstatus=oServicesPage.Post_the_given_data_for_the_given_service_and_criteria_with_Rest(JsonBody,SeriviceURl);
                     
                      if(bstatus)
                     {
                            GenericUtils.Verify("Record was inserted successfully at 'Rule Level' through service url using post manager ===>"+SeriviceURl, bstatus);
                     }
                     
                     
                     
     }
	 
	 @Step
	 public void validate_the_service_response_with_collection(String arg1) throws Exception {
	                 
     List<String> ResponseOutput=Arrays.asList(ProjectVariables.ResponseOutput.split("}"));
	 
	 System.out.println("Reponse Output record size ==>"+ResponseOutput.size());
	 System.out.println("First Reponse Output record ==>"+ResponseOutput.get(0));
	 
	 //DB Method for connection
	 MongoDBUtils.retrieveAllDocuments("cpd", "oppty");
	 
	 for (int i = 0; i < ResponseOutput.size(); i++) 
	 {
		 System.out.println(i+1+"."+"Record,TotalRecordssize===>"+ResponseOutput.size());
 
         String Lines=StringUtils.substringBetween(ResponseOutput.get(i), "lines:",",edits");
         String Edits=StringUtils.substringBetween(ResponseOutput.get(i), "edits:",",raw_savings");
         String Rawsavings=StringUtils.substringBetween(ResponseOutput.get(i), "raw_savings:",",aggressive_savings");
         String Aggressivesavings=StringUtils.substringBetween(ResponseOutput.get(i), "aggressive_savings:",",conservative_savings");
         String Conservative_savings=StringUtils.substringBetween(ResponseOutput.get(i), "conservative_savings:",",raw_production_savings");
         String Raw_production_savings=StringUtils.substringBetween(ResponseOutput.get(i), "raw_production_savings:",",raw_opportunity_savings");
         String Raw_opportunity_savings=StringUtils.substringBetween(ResponseOutput.get(i), "raw_opportunity_savings:",",unconfirmed_savings");
         
         if(!String.valueOf(Long.valueOf(Raw_production_savings)+Long.valueOf(Raw_opportunity_savings)).equalsIgnoreCase(String.valueOf(Long.valueOf(Rawsavings))))
         {
           verify("Raw Savings data from service was not matched with summation of Raw_production_savings and Raw_Opportunitysavings,Raw savings from Response ==>"+Rawsavings+",Raw_production_savings ==>"+Raw_production_savings+",Raw_opportunity_savings ==>"+Raw_opportunity_savings+",for the Record ==>"+ResponseOutput.get(i),false);
         }
         
         //DBMethod to validate the service response woth DB        
         MongoDBUtils.Retrieve_the_mongodb_data_to_validate_the_CPW_oppotunityRun_from_Service_reponse(ResponseOutput.get(i));
                 
         //Validate_the_Savings_data_from_response_with_MongoDB_data(Lines,Edits,Rawsavings,Aggressivesavings,Conservative_savings,ResponseOutput.get(i));
         long DBRawSavings=0l;
         long DBAggSavings=0l;
         long DBConSavings=0l;
         long DBEdits=0l;
         long DBlines=0l;
         
         System.out.println("Raw Savings size ===>"+ProjectVariables.RawSavings.size());
                 
         for (int j = 0; j < ProjectVariables.RawSavings.size(); j++) 
         {
             DBRawSavings=DBRawSavings+ProjectVariables.RawSavings.get(j);        
         }
         
         for (int j = 0; j < ProjectVariables.AggSavings.size(); j++) 
         {
        	 DBAggSavings=DBAggSavings+ProjectVariables.AggSavings.get(j);           
         }
         
         for (int j = 0; j < ProjectVariables.ConSavings.size(); j++) 
         {
        	 DBConSavings=DBConSavings+ProjectVariables.ConSavings.get(j);          
         }
         
          for (int j = 0; j < ProjectVariables.Edits.size(); j++) 
          {
             DBEdits=DBEdits+ProjectVariables.Edits.get(j);   
          }
                 
	         System.out.println("DB Raw Savings ===>"+DBRawSavings);
	         System.out.println("DB AggSavings ===>"+DBAggSavings);
	         System.out.println("DB ConSavings ===>"+DBConSavings);
	         System.out.println("DB Edits ===>"+DBEdits);
	         
                 
         if(Long.valueOf(Rawsavings)==DBRawSavings)
         {
             verify("DB Raw Savings data was matched with output from the Reponse Raw savings,Raw savings from Response ==>"+Rawsavings+",DB Raw savings ==>"+DBRawSavings+",for the Record ==>"+ResponseOutput.get(i),true);       
         }
         else
         {
             verify("DB Raw Savings data was not matched with output from the Reponse Raw savings,Raw savings from Response ==>"+Rawsavings+",DB Raw savings ==>"+DBRawSavings+",for the Record ==>"+ResponseOutput.get(i),Long.valueOf(Rawsavings)==DBRawSavings);
         }
                 
                 
         if(Long.valueOf(Aggressivesavings)==DBAggSavings)
         {
             verify("DB Agg Savings data was matched with output from the Reponse Agg savings,Agg savings from Response ==>"+Rawsavings+",DB Agg savings ==>"+DBAggSavings+",for the Record ==>"+ResponseOutput.get(i),true);    
         }
         else
         {
             verify("DB Agg Savings data was not matched with output from the Reponse Agg savings,Agg savings from Response ==>"+Aggressivesavings+",DB Agg savings ==>"+DBAggSavings+",for the Record ==>"+ResponseOutput.get(i),Long.valueOf(Aggressivesavings)==DBAggSavings);
         }
                 
                 
         
         if(Long.valueOf(Conservative_savings)==DBConSavings)
         {
             verify("DB Con Savings data was matched with output from the Reponse Con savings,Con savings from Response ==>"+Conservative_savings+",DB Con savings ==>"+DBConSavings+",for the Record ==>"+ResponseOutput.get(i),true);        
         }
         else
         {
              verify("DB Con Savings data was not matched with output from the Reponse Con savings,Con savings from Response ==>"+Conservative_savings+",DB con savings ==>"+DBConSavings+",for the Record ==>"+ResponseOutput.get(i),Long.valueOf(Conservative_savings)==DBConSavings);
         }
         
         
         if(Long.valueOf(Edits)==DBEdits)
         {
             verify("DB Edits data was matched with output from the Reponse Edits,Edits from Response ==>"+Edits+",DB Edits ==>"+DBEdits+",for the Record ==>"+ResponseOutput.get(i),true);   
         }
         else
         {
             verify("DB Edits data was not matched with output from the Reponse Edits,Edits from Response ==>"+Edits+",DB Edits ==>"+DBEdits+",for the Record ==>"+ResponseOutput.get(i),Long.valueOf(Edits)==DBEdits);
         }
                 
         for (Long DBDAta : ProjectVariables.Lines) {
		
        	 DBlines=DBDAta+DBlines;   
         }        
         
               //for (Long DBLine : ProjectVariables.Lines)
               {
                                 
                     if(Lines.trim().equalsIgnoreCase(String.valueOf(DBlines)))
                     {
                     verify("DB Lines was matched with output from the Reponse Lines,Lines from Response ==>"+Lines+",DB Edits ==>"+DBlines+",for the Record ==>"+ResponseOutput.get(i),true);   
                     }
                     else
                     {
                     verify("DB Lines data was not matched with output from the Reponse Lines,Lines from Response ==>"+Lines+",DB Lines ==>"+DBlines+",for the Record ==>"+ResponseOutput.get(i),Lines.trim().equalsIgnoreCase(String.valueOf(DBlines)));
                     }
                }
                     
                     
                     ProjectVariables.Lines.clear();
                     ProjectVariables.RawSavings.clear();
                     ProjectVariables.AggSavings.clear();
                     ProjectVariables.ConSavings.clear();
                     ProjectVariables.Edits.clear();
          }
	                                 
	                                 
	                                 
	                                 
	                                 
	                 
	                 
	                 
	 }

	  @Step
      public void verify(String sDescription, boolean blnStatus) {

                      if (blnStatus){    
                                      GenericUtils.logMessage(sDescription);
                                      Assert.assertTrue(sDescription,blnStatus);
                      }else{
                                      
                                      Assert.assertTrue(sDescription,blnStatus);
                                      
                      }                              
                      
      }

	 @Step
	public void verifyPPSbetweenOracleandmMDMservice(String clientkey) throws Exception {
		 Serenity.setSessionVariable("clientkey").to(clientkey);
		 oServicesPage.verifyPPSbetweenOracleandService(clientkey);
	}

	 @Step
	public void userlogintoCPDwitservice(String sUserName) throws Exception
	{
		Serenity.setSessionVariable("user").to(sUserName);
		oServicesPage.logintoApplication(sUserName);
		
	}
	
	@Step
	public void createPresentationProfilewithGivenRequest(String sUser, String sClient,String sPayershorts,String sLobs,String sProduct,String sPriority) throws ParseException, IOException {

		Serenity.setSessionVariable("Client").to(sClient);
		if(sUser.isEmpty()||sUser.contains("User"))
		{
			Assert.assertTrue("User is not given from the gherkin::"+sUser, false);
		}
		String sPresentation=oServicesPage.createPresentationThroughService(sUser,sClient,sPayershorts,sLobs,sProduct,sPriority);

		Serenity.setSessionVariable("profileId").to(StringUtils.substringBefore(sPresentation, "-"));
		Serenity.setSessionVariable("PresentationName").to(StringUtils.substringAfter(sPresentation, "-"));


		System.out.println("ProfileID====>"+Serenity.sessionVariableCalled("profileId"));
		System.out.println("PresentationName====>"+Serenity.sessionVariableCalled("PresentationName"));
	}
	
	@Step
	public void assignMultipleDPstoCreatedProfile(String criteria) throws ParseException, IOException {


		oServicesPage.assignMultipleDPstoCreatedProfile(criteria);

	}

	//###################################### Capture Disposition service method #############################################
	
	public void Capture_the_disposition_through_service_from_MongoDBData(String clientname,
			String source,String Disposition, String DPkeyCriteria) throws IOException {
		
		String User=Serenity.sessionVariableCalled("user").toString();
		if (User.isEmpty() || User == null) 
		{
			Assert.assertTrue("Given username is empty or null,username::" + User, false);
		}

		
		Serenity.setSessionVariable("client").to(clientname);
		Serenity.setSessionVariable("Disposition").to(Disposition);
		String sClientkey = AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(clientname.trim());
		Serenity.setSessionVariable("clientkey").to(sClientkey);
		switch(source)
		{
			case "rva":
				// Method to retrieve the data from DB based on the client
				MongoDBUtils.GetAvailableDPKeyfromCPW(sClientkey, DPkeyCriteria, 1);
			break;
			case "eLL":
				//To retrieve pure eLL dpkey
				MongoDBUtils.getpureEllDPkeysfromeLLhierarchy(sClientkey);
				source="ell-gen-oppty";
			break;
			default:
				GenericUtils.Verify("case not found::"+source, false);
			break;
		
		}
		Serenity.setSessionVariable("source").to(source);
		// Captured the data for the given disposition,insurances and user
		oServicesPage.Capture_the_data_for_the_given_disposition(Disposition, ProjectVariables.StaticInsurnaces, User,DPkeyCriteria,source);


	}


}
