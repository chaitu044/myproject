package project.feature.steps.definitions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import project.pageobject.AWBPage;
import project.pageobject.OpportunityRunsPage;
import project.pageobject.ReviewWorkedOpportunityPage;
import project.utilities.AppUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;

public class ReviewWorkedOpportunityStepDef extends ScenarioSteps {

	
	ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage;
	AWBPage oAWBPage;
	OpportunityRunsPage oOpportunityRunsPage;
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	//========================================================Step-Def Methods ====================================================================================//
	
	@Step
	public void validate_the_update_disposition_functionality_at_data_for_Disposition_as(String gridcriteria, String criteriatype, String disposition) throws InterruptedException {
		
		
		//click on review worked opportunity button and check the page is opening or not
		oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
				
				
		//Selecting the checkboxes in the RWO Page
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
		
		switch(gridcriteria)
		{
		case "Medicalpolicy level":
			
			oReviewWorkedOpportunityPage.update_the_disposition_as(criteriatype,disposition,"Medical Policy");
			
		break;
		
		case "Topic level":
			
			oReviewWorkedOpportunityPage.update_the_disposition_as(criteriatype,disposition,"Topic");
			
		break;
		
		case "DPKEY level":
			
			oReviewWorkedOpportunityPage.update_the_disposition_as(criteriatype,disposition,"DPKeys");
			
			
		break;
		case "Payershort level":
			
			oReviewWorkedOpportunityPage.update_the_disposition_as(criteriatype,disposition,"Payershort");
			
			
			
		break;
		
		
		default:
			Assert.assertTrue("Given selection was not found ===>"+gridcriteria, false);
			
		break;
		}
		
		
		
	}

	//############################################################################################################################################################//
	
	@Step
	public void validate_the_filters_checkboxes_funcitonality_in_the_RWO_Page(String checkboxesnames) {
		List<String> checkboxexList=Arrays.asList(checkboxesnames.split(","));
		
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			
			//Assert.assertTrue("Falgs filter checkbox section is enabled,expected should be disabled in the AWB Page ", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_class, "value", "flags disabled")));
			
			Assert.assertTrue("'Flag' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
			
			
			
			for (int i = 0; i < checkboxexList.size(); i++)
			{
				Assert.assertTrue("'"+checkboxexList.get(i)+"' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "CHECK", StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
			}
		
		oAWBPage.validate_the_filters_checkboxes_funcitonality(checkboxesnames,"RWO");
		
		
			
	}
	
	//############################################################################################################################################################//	
	
	@Step
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filter(String filtername) throws InterruptedException {
		
		ArrayList<String> Payers=new ArrayList<>();
		
		
		//Open the Review Worked Opportunity Page
		oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
		
		
		//Selecting the checkboxes in the RWO Page
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
				
		
		switch(filtername)
		{
		case "Latest Client Decision":
			
			oReviewWorkedOpportunityPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(filtername,ProjectVariables.LatestClientDecisionFilterOptions,Payers);
			
		break;
		
		case "Prior Disposition":
			
			oReviewWorkedOpportunityPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(filtername,ProjectVariables.PriorDispositionFilterOptions,Payers);
			
		break;
		
		case "Savings Status":
			
			oReviewWorkedOpportunityPage.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(filtername,ProjectVariables.SavingStatusFilterOptions,Payers);
			
			break;
		
		default:
			Assert.assertTrue("Given selection was not found ===>"+filtername, false);
			break;
		
		}
		
		
	}
	
	//############################################################################################################################################################//
	
	@Step
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filter_options(String payershort,String Insurance,String claimtype,String latestclientdecision,
			String currentdisposition) throws InterruptedException {
		boolean bstatus=false;
		boolean DBstatus=false;
		
		List<String> payershortList=Arrays.asList(payershort.split(","));
		List<String> insurancelist=Arrays.asList(Insurance.split(","));
		List<String> claimtypeList=Arrays.asList(claimtype.split(","));
		
		oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
		
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "", "");
		
		List<String> checkboxexList=Arrays.asList(ProjectVariables.RWO_filters.split(","));
		
		
		for (int i = 0; i < checkboxexList.size(); i++) 
		{
			Assert.assertTrue("'"+checkboxexList.get(i)+"' filterHead checkbox is unable to un-check in the RWO Page", oOpportunityRunsPage.ApplyFilters(checkboxexList.get(i), "", "UNCHECK", ""));
		}
		
		Assert.assertTrue("'"+payershort+"' filter checkbox is unable to checked in the filter 'payershort' of the RWO Page", oOpportunityRunsPage.ApplyFilters("Payer Short",payershort,"CHECK",""));
		Assert.assertTrue("'"+Insurance+"' filter checkbox is unable to checked in the filter 'insurance' of the RWO Page", oOpportunityRunsPage.ApplyFilters("Insurance",Insurance,"CHECK",""));
		Assert.assertTrue("'"+claimtype+"' filter checkbox is unable to checked in the filter 'Product' of the RWO Page", oOpportunityRunsPage.ApplyFilters("Product",claimtype,"CHECK",""));
		Assert.assertTrue("'"+latestclientdecision+"' filter checkbox is unable to checked in the filter 'Latest Client Decsion' of the RWO Page", oOpportunityRunsPage.ApplyFilters("Latest Client Decision",latestclientdecision,"CHECK",""));
		Assert.assertTrue("'"+currentdisposition+"' filter checkbox is unable to checked in the filter 'currentdisposition' of the RWO Page", oOpportunityRunsPage.ApplyFilters("Current Disposition",currentdisposition,"CHECK",StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		
		
		
		bstatus=oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", "No results found that meet the search criteria."));
		
		//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
		DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB(Serenity.sessionVariableCalled("Medicalpolicy"), payershortList,insurancelist,claimtypeList, latestclientdecision, currentdisposition, "", "Combination filter","RWO");
		
		if(!(bstatus==!DBstatus))
		{
			Assert.assertTrue("'No worked opportunities found based on the applied filters.' message is displayed in the AWB Grid as not expected with Mongo DB for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release"), false);
		}
		else
		{	
			//validating the Topics displayed in the RWO grid with Mongo DB as per the filter combination 
			oReviewWorkedOpportunityPage.Validate_the_Data_in_Opportunity_Grid_with_Mongo_DB("Medical Policy","Multiple","Multiple");
			
			oReviewWorkedOpportunityPage.Validate_the_Data_in_Opportunity_Grid_with_Mongo_DB("Topic","Multiple","Multiple");
			
			//validating the DP's displayed in the RWO grid with Mongo DB as per the filter combination 
			oReviewWorkedOpportunityPage.Validate_the_DPs_in_RWO_Grid_with_Mongo_DB();
		
	
		}

	}

	//############################################################################################################################################################//
	
	@Step
	public void Select_the_filters_checkboxes_in_the_page(String filternames, String filteroptions, String pagename) throws InterruptedException {
		
		
		
		List<String> filternamesList=Arrays.asList(filternames.split(","));
		List<String> filteroptionsList=Arrays.asList(filteroptions.split(","));
		
		
		switch(pagename){
		
		case "AWB":
			Serenity.setSessionVariable("Pagename").to("AWB");
			Assert.assertTrue("Unable to the check the filterheader 'Flag' in "+pagename+"", oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));
			for (int i = 0; i < filternamesList.size(); i++) 
			{
				Assert.assertTrue("Unable to the check the filterheader '"+filternamesList.get(i)+"' in "+pagename+"", oOpportunityRunsPage.ApplyFilters(filternamesList.get(i), "", "CHECK", ""));
				
				Assert.assertTrue("Unable to the un-check the filterheader '"+filternamesList.get(i)+"' in "+pagename+"", oOpportunityRunsPage.ApplyFilters(filternamesList.get(i), "", "UNCHECK", ""));
			}
			
			for (int i = 0; i < filteroptionsList.size(); i++) 
			{
				Assert.assertTrue("Unable to the check the filteroption '"+filteroptionsList.get(i)+"' of filter '"+filternamesList.get(i)+"' in "+pagename+"", oOpportunityRunsPage.ApplyFilters(filternamesList.get(i), filteroptionsList.get(i), "CHECK", ""));
			}
			
			Assert.assertTrue("Unable to the click the 'Apply Filters' button in "+pagename+"", oOpportunityRunsPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
			
		break;
		case "RWO":
			Serenity.setSessionVariable("Pagename").to("RWO");
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			
			Assert.assertTrue("Unable to the check the filterheader 'Flag' in "+pagename+"", oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", ""));
			
			for (int i = 0; i < filternamesList.size(); i++) 
			{
				Assert.assertTrue("Unable to the check the filterheader '"+filternamesList.get(i)+"' in "+pagename+"", oOpportunityRunsPage.ApplyFilters(filternamesList.get(i), "", "CHECK", ""));
				
				Assert.assertTrue("Unable to the un-check the filterheader '"+filternamesList.get(i)+"' in "+pagename+"", oOpportunityRunsPage.ApplyFilters(filternamesList.get(i), "", "UNCHECK", ""));
			}
			
			for (int i = 0; i < filternamesList.size(); i++) {
				
				oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page(filternamesList.get(i), filteroptionsList.get(i),"");
			}
			
			Assert.assertTrue("unable to click the 'Apply Filters' button in the RWO Page",oReviewWorkedOpportunityPage.clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
			
			break;
		case "Policy Selection Drawer":
			
			oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters(filteroptionsList.get(0), filteroptionsList.get(1), filteroptionsList.get(2),filteroptionsList.get(3));
			
			Assert.assertTrue("Medical policies are not available inthe policy selection drawer,for the applied filtering criteria", oAWBPage.is_WebElement_Displayed(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]"));
			
			String mediaclpolicy=oAWBPage.get_TextFrom_Locator(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]");
			
			 //Click 'PolicySelection'
	        Assert.assertTrue("Unable to click the Mediaclpolicy '"+mediaclpolicy+"' in the policy selection drawer", oOpportunityRunsPage.clickGivenXpath(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]"));
	        
	        Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",oOpportunityRunsPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
	        
	       
			
			break;
		
		default:
			Assert.assertTrue("Given selection was not found ==>"+pagename, false);
		break;
		
		
		  
		
		}
		
		//Loading POPUP
	      OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
	      oOpportunityRunsPage.DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
	      OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
		
	}

	//############################################################################################################################################################//
	
	@Step
	public void validate_the_retention_funcitonality_for_the_filter_checkboxes(String filternames, String filteroptions, String pagename) throws InterruptedException {
		boolean sItem=false;
		List<String> filternamesList=Arrays.asList(filternames.split(","));
		List<String> filteroptionsList=Arrays.asList(filteroptions.split(","));
		
		
		switch(pagename){
		
		case "AWB":
		
			for (int i = 0; i < filternamesList.size(); i++) 
			{
				sItem=oOpportunityRunsPage.FilterCheckbox_Status(filternamesList.get(i), "");
				
				Assert.assertFalse("'"+filternamesList.get(i)+"' filterheader is checked,expected should be un-checked as per retention functionality in "+pagename+"", sItem);
				
				oReviewWorkedOpportunityPage.verify_retention_functionality_for_the_filter(filternamesList.get(i),filteroptionsList.get(i),pagename);
				
			}
		
		break;
		case "RWO":
			
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			
			for (int i = 0; i < filternamesList.size(); i++) 
			{
				sItem=oOpportunityRunsPage.FilterCheckbox_Status(filternamesList.get(i), "");
				
				/*if(filternamesList.get(i).equalsIgnoreCase("Payer Short"))
				{
					int Payershortsize=oOpportunityRunsPage.get_Matching_WebElement_count("//app-checklist[@title='Payer Short']//div[@class='mat-list-text']");
					
					if(Payershortsize==1)
					{
						sItem=false;
					}
				}*/
				
				Assert.assertFalse("'"+filternamesList.get(i)+"' filterheader is checked,expected should be un-checked as per retention functionality in "+pagename+"", sItem);
				
				oReviewWorkedOpportunityPage.verify_retention_functionality_for_the_filter(filternamesList.get(i),filteroptionsList.get(i),pagename);
				
			}
			break;
		case "Policy Selection Drawer":
			
			//To Open the filter panel
			oOpportunityRunsPage.OpenFilterPanel();
			
			
			for (int i = 0; i < filternamesList.size(); i++) 
			{
				sItem=oOpportunityRunsPage.FilterCheckbox_Status(filternamesList.get(i), "");
				
				/*if(filternamesList.get(i).equalsIgnoreCase("Payer Short"))
				{
					int Payershortsize=oOpportunityRunsPage.get_Matching_WebElement_count("//app-checklist[@title='Payer Short']//div[@class='mat-list-text']");
					
					if(Payershortsize==1)
					{
						sItem=false;
					}
				}
				*/
				
				
				
				
				Assert.assertFalse("'"+filternamesList.get(i)+"' filterheader is checked,expected should be un-checked as per retention functionality in "+pagename+"", sItem);
				
				oReviewWorkedOpportunityPage.verify_retention_functionality_for_the_filter(filternamesList.get(i),filteroptionsList.get(i),pagename);
				
			}
			
			Assert.assertTrue("Medical policies are not available inthe policy selection drawer,for the applied filtering criteria", oAWBPage.is_WebElement_Displayed(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]"));
			
			String mediaclpolicy=oAWBPage.get_TextFrom_Locator(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]");
			
			 //Click 'PolicySelection'
	       // Assert.assertTrue("Unable to click the Mediaclpolicy '"+mediaclpolicy+"' in the policy selection drawer", oOpportunityRunsPage.clickGivenXpath(oAWBPage.MedicalPolicies_In_PolicySelection+"[1]"));
	        
	        Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",oOpportunityRunsPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
	        AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
	       
			
			break;
		
		default:
			Assert.assertTrue("Given selection was not found ==>"+pagename, false);
		break;
		
		}
		
	}

	@Step
	public void validate_the_sorting_funcitonality_in_Page_for_the_coloumn_as(String pagename, String coloumname, String sortingorder) {
	 
		switch(pagename){
		case "Opportunity Dashboard":
			
			//Sorting fucnitonality validation in Opportunity Dashboard
			oOpportunityRunsPage.valdiate_the_sorting_funtionality_of_clients_and_releases_in_Opportunity_dashboard();
			
			break;
		
		default:
			Assert.assertTrue("Given selection was not found ==>"+pagename, false);
		break;
		
		}
		
		
	}
	
	//################################# PI-25 stories #######################################################################
	
		
	}

