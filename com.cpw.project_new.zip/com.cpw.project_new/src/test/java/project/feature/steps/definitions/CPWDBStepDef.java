package project.feature.steps.definitions;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import project.pageobject.AWBPage;
import project.pageobject.ServicesPage;
import project.utilities.DBUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;

public class CPWDBStepDef extends ScenarioSteps {

	ServicesPage oServicesPage;
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Step

	public void verify(String sDescription, boolean blnStatus) {

		if (blnStatus){	
			System.out.println(sDescription);
			Assert.assertTrue(sDescription,blnStatus);
		}else{

			Assert.assertFalse(sDescription,blnStatus);

		}		

	}

	@Step
	public boolean executeMongoQueryForClientData(String queryForTestCase, String clientName, String release) throws IOException {
		boolean flag = true;
		GenericUtils.logMessage("Data Validation for: " + clientName + "-" + release);
		
		String clientkey=AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(clientName.trim());
		Serenity.setSessionVariable("clientkey").to(clientkey);
		
		
		switch (queryForTestCase) {
		case "DataPipeLine_DataValidation_Opportunity":
			// execute the mongodb query in MongoDBUtils
			MongoDBUtils.retrieve_all_DocumentsFromDB("cpd","opportunity-oracle", Serenity.sessionVariableCalled("clientkey"), release);

			
		System.out.println("opportunity collection count for client ===>'"+clientName+"'===>"+ProjectVariables.Opportunity_oracle_collection_data.size());
		System.out.println("opportunity collection First record for client ===>'"+clientName+"'===>"+ProjectVariables.Opportunity_oracle_collection_data.get(0));
		
	
			break;
		case "DataPipeLine_DataValidation_RvaUnified":

			// execute the mongodb query in MongoDBUtils
			List<List<String>> queryDataPipeLineDatValRVAMongoResults = MongoDBUtils.retrieve_all_DocumentsFromDB("rva_data",
					"rva_unified", Serenity.sessionVariableCalled("clientkey"), release);
			
			System.out.println("rvaunified collection count for client ===>'"+clientName+"'===>"+ProjectVariables.rva_unified_collection_data.size());
			System.out.println("rvaunified collection First record for client ===>'"+clientName+"'===>"+ProjectVariables.rva_unified_collection_data.get(0));


			
			break;
			
		case "DataPipeLine_DataValidation_RvaUnified_oracle":

			// execute the mongodb query in MongoDBUtils
			MongoDBUtils.retrieve_all_DocumentsFromDB("rva_data","rva_unified-oracle", Serenity.sessionVariableCalled("clientkey"), release);

					
					System.out.println("rvaunified collection count for client ===>'"+clientName+"'===>"+ProjectVariables.rvaunified_oracle_collection_data.size());
					System.out.println("rvaunified collection First record for client ===>'"+clientName+"'===>"+ProjectVariables.rvaunified_oracle_collection_data.get(0));

			break;
			
			default:
				Assert.assertTrue("Given selection was not found ===>"+queryForTestCase, false);
		}
		return flag;
	}

	@Step
	public void validate_the_data_retrieved_from_both_the_MongoDb_collections_for_client_release_and_record_size(
			String client, String release, String collectionname) {
		
		
		
		System.out.println("Opportunity First Record ===>"+ProjectVariables.Opportunity_collection_data.get(0));
		
		System.out.println("rva_unified First Record ===>"+ProjectVariables.rva_unified_collection_data.get(0));
		
		boolean scenariostatus=true;
		
		verify("Opportunity collection Record count ===>"+ProjectVariables.Opportunity_collection_data.size(), true);
		
		verify("Rva_unified collection Record count ===>"+ProjectVariables.rva_unified_collection_data.size(), true);
		
		
		
		if(!(ProjectVariables.Opportunity_collection_data.size()==ProjectVariables.rva_unified_collection_data.size()))
		{
			verify("Record count was not matching between opportunity and rvaunified collections for the client ===>"+client+",release ==>"+release+"Opportunity collection Record count ===>"+ProjectVariables.Opportunity_collection_data.size()+"Rva_unified collection Record count ===>"+ProjectVariables.rva_unified_collection_data.size(), true);	
		}
		
		
		
		GenericUtils.logMessage("Validation was in progress between opportunity and rva unified collections");
		
		int j=0;
		
		if(collectionname.equalsIgnoreCase("opportunity")){
			for (int i = 0; i < ProjectVariables.Opportunity_collection_data.size(); i++) {
				
				boolean bstatus=ProjectVariables.rva_unified_collection_data.contains(ProjectVariables.Opportunity_collection_data.get(i));
				
				List<String> oppdoc=Arrays.asList(ProjectVariables.Opportunity_collection_data.get(i).split(";"));
				
				String opp_clientKey=oppdoc.get(0);
				String opp_payerKey=oppdoc.get(1);
				String opp_insurancekey=oppdoc.get(2);
				String opp_claimtype=oppdoc.get(3);
				String opp_dataVersion=oppdoc.get(4);
				String opp_midrule=oppdoc.get(5);
				String opp_dpkey=oppdoc.get(6);
				String opp_subrule=oppdoc.get(7);
				
			
				if(bstatus)
				{
					
					if(i%(ProjectVariables.Opportunity_collection_data.size()/10)==0)
					{
						GenericUtils.logMessage("Savings data was matched between rvaunified and opportunity collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataVersion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",subrule ===>"+opp_subrule+",Records size ==>"+ProjectVariables.rva_unified_collection_data.size()+",Record number==>"+i);
					}
					

				}
				else
				{
					j=j+1;
					verify("Savings data was not matching between rvaunified and opportunity collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataVersion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",subrule ===>"+opp_subrule+",Records size ==>"+ProjectVariables.rva_unified_collection_data.size()+",Record number==>"+i, true);
					scenariostatus=false;
				}
				
				}
		
			verify("Data was not matching between Opportunity collection and rvaunified collection,Record count ===>"+j, true);
			
		}
		else if(collectionname.equalsIgnoreCase("rva_unified"))
		{
			for (int i = 0; i < ProjectVariables.rva_unified_collection_data.size(); i++) {
				
				boolean bstatus=ProjectVariables.Opportunity_collection_data.contains(ProjectVariables.rva_unified_collection_data.get(i));
				
				List<String> oppdoc=Arrays.asList(ProjectVariables.rva_unified_collection_data.get(i).split(";"));
				
				String opp_clientKey=oppdoc.get(0);
				String opp_payerKey=oppdoc.get(1);
				String opp_insurancekey=oppdoc.get(2);
				String opp_claimtype=oppdoc.get(3);
				String opp_dataVersion=oppdoc.get(4);
				String opp_midrule=oppdoc.get(5);
				String opp_dpkey=oppdoc.get(6);
				String opp_subrule=oppdoc.get(7);
				
			
				if(bstatus)
				{
					
					if(i%(ProjectVariables.Opportunity_collection_data.size()/10)==0)
					{
						GenericUtils.logMessage("Savings data was matched between rvaunified and opportunity collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataVersion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",subrule ===>"+opp_subrule+",Records size ==>"+ProjectVariables.rva_unified_collection_data.size()+",Record number==>"+i);
					}
					

				}
				else
				{
					j=j+1;
					verify("Savings data was not matching between rvaunified and opportunity collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataVersion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",subrule ===>"+opp_subrule+",Records size ==>"+ProjectVariables.rva_unified_collection_data.size()+",Record number==>"+i, true);
					scenariostatus=false;
				}
				
				}
		
			verify("Data was not matching between Opportunity collection and rvaunified collection,Record count ===>"+j, true);
			
			Assert.assertTrue("Scenario status failed",scenariostatus);
		}
		
	}	
	
	@Step
	public void User_retrieves_data_from_oracle_for_the_given(String oraceldbname, String client, String release) {
		String sqlquery=null;
		if(oraceldbname.equalsIgnoreCase("RVAPRD1 for rva_unified"))
		{
			 sqlquery=StringUtils.replace(ProjectVariables.Oracle_query_basedon_client_release_for_rvaunified, "clientname", client);
			 oraceldbname="RVAPRD1";
			
			 
		}
		else
		{
			 sqlquery=StringUtils.replace(ProjectVariables.Oracle_query_basedon_client_release, "clientname", client);
			
				
		}
		
		
		 DBUtils.executeSQLQuery_for_the_given_DBname(StringUtils.replace(sqlquery, "release", release), oraceldbname);
			
		 System.out.println("Records Size from Oracle ===>"+ProjectVariables.Oracel_results_list.size());
			
			System.out.println("First Record from Oracle ===>"+ProjectVariables.Oracel_results_list.get(0));
			
		
		
		
		
			
	}
	
	@Step
	public void Validate_the_data_retrieved_from_oracle_db_with_mongo_db_collection_for_the_client_release_as(
			String oraclecollection, String mongocollection, String client, String release) {
		boolean scenariostatus=true;
		int j=0;
		switch(mongocollection)
		{
		case "opportunity":
			System.out.println("Opportunity First Record ===>"+ProjectVariables.Opportunity_oracle_collection_data.get(0));
			
			System.out.println("Oracle First Record ===>"+ProjectVariables.Oracel_results_list.get(0));
			
			
			
			verify("Opportunity collection Record count ===>"+ProjectVariables.Opportunity_oracle_collection_data.size(), true);
			
			verify("Oracle collection 'RVAPRD1' Record count ===>"+ProjectVariables.Oracel_results_list.size(), true);
			
			
			
			if(!(ProjectVariables.Opportunity_oracle_collection_data.size()==ProjectVariables.Oracel_results_list.size()))
			{
				Serenity.recordReportData().asEvidence().withTitle("Record count was not matching between 'Opportunity' and 'RVAPRD1' collections for the client ===>"+client+",release ==>"+release+"Opportunity collection Record count ===>"+ProjectVariables.Opportunity_oracle_collection_data.size()+", RVAPRD1 collection Record count ===>"+ProjectVariables.Oracel_results_list.size()).andContents("Passed");
				verify("Record count was not matching between 'Opportunity' and 'RVAPRD1' collections for the client ===>"+client+",release ==>"+release+"Opportunity collection Record count ===>"+ProjectVariables.Opportunity_oracle_collection_data.size()+", RVAPRD1 collection Record count ===>"+ProjectVariables.Oracel_results_list.size(), false);
				scenariostatus=false;
			}
			
			
			
			System.out.println("Validation was in progress between 'opportunity' and 'RVAPRD1' collections");
			
			
			
			
				for (int i = 0; i < ProjectVariables.Opportunity_oracle_collection_data.size(); i++) {
					
					//boolean bstatus=ProjectVariables.Opportunity_oracle_collection_data.contains(ProjectVariables.Oracel_results_list.get(i));
					
					boolean bstatus=ProjectVariables.Oracel_results_list.contains(ProjectVariables.Opportunity_oracle_collection_data.get(i));
					
					List<String> oppdoc=ProjectVariables.Opportunity_oracle_collection_data.get(i);
					
					String opp_rvaKey=oppdoc.get(0);
					String opp_clientKey=oppdoc.get(1);
					String opp_payerKey=oppdoc.get(2);
					String opp_linestotal=oppdoc.get(3);
					String opp_subrulrkey=oppdoc.get(4);
					String opp_midrule=oppdoc.get(5);
					String opp_midruleversion=oppdoc.get(6);
					String opp_medicalpolicykey=oppdoc.get(7);
					String opp_topickey=oppdoc.get(8);
					
					String opp_dpkey=oppdoc.get(9);
					String opp_claimtype=oppdoc.get(10);
					
					String opp_insurancekey=oppdoc.get(11);
					String opp_dataversion=oppdoc.get(23);
					/*String opp_insurancedesc=oppdoc.get(12);
					
					
					String opp_annualpaid=oppdoc.get(18);
					String opp_annualraw=oppdoc.get(19);
					String opp_annualagg=oppdoc.get(20);
					String opp_annualcon=oppdoc.get(21);
					String opp_annualedits=oppdoc.get(22);
					String opp_dataversion=oppdoc.get(23);
					String opp_ruleinbaseline=oppdoc.get(24);*/
					
				
					if(bstatus)
					{
						
						if(i%(ProjectVariables.Opportunity_oracle_collection_data.size()/10)==0)
						{
							verify("Data was matching between oracle 'RVAPRD1' and mongo 'opportunity' collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataversion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",rvakey ===>"+opp_rvaKey+",subrulekey ===>"+opp_subrulrkey+",Records size ==>"+ProjectVariables.Opportunity_oracle_collection_data.size()+",Record number==>"+i,true);
						}
						

					}
					else
					{
						j=j+1;
						Serenity.recordReportData().asEvidence().withTitle("Data was not matching between oracle 'RVAPRD1' and mongo 'opportunity' collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataversion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",rvakey ===>"+opp_rvaKey+",subrulekey ===>"+opp_subrulrkey+",topickey ==>"+opp_topickey+",medicalpolicykey ==>"+opp_medicalpolicykey+",Records size ==>"+ProjectVariables.Opportunity_oracle_collection_data.size()+",Record number==>"+i+",Opportunity record ===>"+ProjectVariables.Opportunity_oracle_collection_data.get(i)).andContents("Passed");
						verify("Data was not matching between oracle 'RVAPRD1' and mongo 'opportunity' collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataversion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",rvakey ===>"+opp_rvaKey+",subrulekey ===>"+opp_subrulrkey+",topickey ==>"+opp_topickey+",medicalpolicykey ==>"+opp_medicalpolicykey+",Records size ==>"+ProjectVariables.Opportunity_oracle_collection_data.size()+",Record number==>"+i+",Opportunity record ===>"+ProjectVariables.Opportunity_oracle_collection_data.get(i), false);
						scenariostatus=false;
					}
					
					}
			
				Serenity.recordReportData().asEvidence().withTitle("Data was not matching between Opportunity collection and oracle collections,Record count ===>"+j).andContents("Passed");
				verify("Data was not matching between Opportunity collection and oracle collections,Record count ===>"+j, false);
				
		
			
				
				Assert.assertTrue("Scenario status failed",scenariostatus);
			
			break;
		case "rva_unified":
			
			System.out.println("rva_unified First Record ===>"+ProjectVariables.rvaunified_oracle_collection_data.get(0));
			
			System.out.println("Oracle First Record ===>"+ProjectVariables.Oracel_results_list.get(0));
			
			
			
			verify("rva_unified collection Record count ===>"+ProjectVariables.rvaunified_oracle_collection_data.size(), true);
			
			verify("Oracle collection 'RVAPRD1' Record count ===>"+ProjectVariables.Oracel_results_list.size(), true);
			
			
			
			if(!(ProjectVariables.rvaunified_oracle_collection_data.size()==ProjectVariables.Oracel_results_list.size()))
			{
				verify("Record count was not matching between 'rva_unified' and 'RVAPRD1' collections for the client ===>"+client+",release ==>"+release+"rva_unified collection Record count ===>"+ProjectVariables.rvaunified_oracle_collection_data.size()+", RVAPRD1 collection Record count ===>"+ProjectVariables.Oracel_results_list.size(), false);	
			}
			
			
			
			System.out.println("Validation was in progress between 'rva_unified' and 'RVAPRD1' collections");
			
			
			
			
				for (int i = 0; i < ProjectVariables.rvaunified_oracle_collection_data.size(); i++) {
					
					boolean bstatus=ProjectVariables.rvaunified_oracle_collection_data.contains(ProjectVariables.Oracel_results_list.get(i));
					
					List<String> oppdoc=ProjectVariables.Oracel_results_list.get(i);
					
					String opp_rvaKey=oppdoc.get(0);
					String opp_clientKey=oppdoc.get(1);
					String opp_payerKey=oppdoc.get(2);
					//String opp_linestotal=oppdoc.get(3);
					String opp_subrulrkey=oppdoc.get(3);
					String opp_midrule=oppdoc.get(4);
					String opp_midruleversion=oppdoc.get(5);
					String opp_medicalpolicykey=oppdoc.get(6);
					String opp_topickey=oppdoc.get(7);
					
					String opp_dpkey=oppdoc.get(8);
					String opp_claimtype=oppdoc.get(9);
					
					String opp_insurancekey=oppdoc.get(10);
					String opp_dataversion=oppdoc.get(21);
					/*String opp_insurancedesc=oppdoc.get(12);
					
					
					String opp_annualpaid=oppdoc.get(18);
					String opp_annualraw=oppdoc.get(19);
					String opp_annualagg=oppdoc.get(20);
					String opp_annualcon=oppdoc.get(21);
					String opp_annualedits=oppdoc.get(22);
					String opp_dataversion=oppdoc.get(23);
					String opp_ruleinbaseline=oppdoc.get(24);*/
					
				
					if(bstatus)
					{
						
						if(i%(ProjectVariables.rvaunified_oracle_collection_data.size()/10)==0)
						{
							System.out.println("Savings data was matched between oracle 'RVAPRD1' and mongo 'rva_unified' collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataversion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",rvakey ===>"+opp_rvaKey+",subrulekey ===>"+opp_subrulrkey+",Records size ==>"+ProjectVariables.rvaunified_oracle_collection_data.size()+",Record number==>"+i);
						}
						

					}
					else
					{
						j=j+1;
						verify("Savings data was not matching between oracle 'RVAPRD1' and mongo 'rva_unified' collections, for the data client key ===>"+opp_clientKey+",payerkey ===>"+opp_payerKey+",insurancekey ===>"+opp_insurancekey+",claimtype ===>"+opp_claimtype+",dataversion ===>"+opp_dataversion+",midrule ===>"+opp_midrule+",dpkey ===>"+opp_dpkey+",rvakey ===>"+opp_rvaKey+",subrulekey ===>"+opp_subrulrkey+",topickey ==>"+opp_topickey+",medicalpolicykey ==>"+opp_medicalpolicykey+",Records size ==>"+ProjectVariables.rvaunified_oracle_collection_data.size()+",Record number==>"+i+",Oracle record ===>"+ProjectVariables.Oracel_results_list.get(i), false);
						scenariostatus=false;
					}
					
					}
			
				verify("Data was not matching between 'rva_unified' collection and 'oracle-RVAPRD1' collections,Record count ===>"+j, false);
				
		
			
				
				Assert.assertTrue("Scenario status failed",scenariostatus);
			
			break;
		default:
		Assert.assertTrue("Given selection was not found ===>"+mongocollection, false);	
		break;
		}
		

		
	}
	
	@Step
	public void User_executes_MongoDB_query_for_the_given(String querycriteria, String release, String environment) 
	{
		Serenity.setSessionVariable("release").to(release);
		switch(querycriteria)
		{
		case "Distinct Clients":
			//Mongo method to retrieve the Distinct clients
			MongoDBUtils.Get_the_distinct_clients_based_on_given(environment,"Clientname");
			
			System.out.println("Client Data retrieved successfully from "+environment+" Database for the release "+release+"");
			
		break;
		case "Distinct Clientkeys":
			//Mongo method to retrieve the Distinct clientkeys
			MongoDBUtils.Get_the_distinct_clients_based_on_given(environment,"ClientKey");
			
			System.out.println("Clientkeys retrieved successfully from "+environment+" Database for the release "+release+"");
			
		break;
		default:
			Assert.assertTrue("Given selection was not found in the switch case ==>"+querycriteria, false);
			break;
		
		
		}
		
		
		
		
	}

	@Step
	public void validate_the_data_retrieved_from_both_DBs_for(String querycriteria) {
		
		
		switch(querycriteria)
		{
		case "Distinct Clients Count":
			
			if(ProjectVariables.PRODClientKeysList.size()!=ProjectVariables.UATClientKeysList.size())
			{
				Assert.assertTrue("Distinct Client count is not matching between UAT and PROD databases,UAT ClientCount==>"+ProjectVariables.UATClientKeysList.size()+",PROD Clientcount=>"+ProjectVariables.PRODClientKeysList.size()+",UAT Clientlist==>"+ProjectVariables.UATClientKeysList+",PROD Clientlist==>"+ProjectVariables.PRODClientKeysList, false);
			}
			else
			{
				System.out.println("Distinct Client count is matching between UAT and PROD databases,UAT ClientCount==>"+ProjectVariables.UATClientKeysList.size()+",PROD Clientcount=>"+ProjectVariables.PRODClientKeysList.size()+",UAT Clientlist==>"+ProjectVariables.UATClientKeysList+",PROD Clientlist==>"+ProjectVariables.PRODClientKeysList);
			}
		
			for (int i = 0; i < ProjectVariables.UATClientKeysList.size(); i++)
			{
				
				if(ProjectVariables.PRODClientKeysList.contains(ProjectVariables.UATClientKeysList.get(i)))
				{
					System.out.println("Clientkey '"+ProjectVariables.UATClientKeysList.get(i)+"'  is available in PROD database as it is in UAT");
				}
				else
				{
					Assert.assertTrue("'Clientkey '"+ProjectVariables.UATClientKeysList.get(i)+"' is not available in PROD database as it is in UAT,PROD Clientlist==>"+ProjectVariables.PRODClientKeysList, false);
				}
				
				
			}
		break;
		
		
		
		
		default:
			Assert.assertTrue("Given selection was not found in the switch case ==>"+querycriteria, false);
			break;
		
		
		}
		
	}

	@Step
	public void validate_the_data_retrieved_from_both_DBs_of_Clientkey_and_release(String clientkey, String release) {
		
		oServicesPage.validate_the_data_retrieved_from_both_DBs_for(clientkey,release);
	}

	
}
