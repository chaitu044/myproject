package project.features.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.PresentationManagerStepDef;


public class PresentationManagerSteps {
	@Steps
	PresentationManagerStepDef oPMStepDef;
	
	@When("^user selects \"([^\"]*)\" from Client drop down list$")
	public void user_selects_from_Client_drop_down_list(String arg1) throws Throwable {
		
		oPMStepDef.user_selects_given_value_from_Client_drop_down_list(arg1);
	}
	

	@Given("^User \"([^\"]*)\" logged into \"([^\"]*)\" application$")
	public void user_logged_into_application(String arg1, String arg2) throws Exception 
	{
		oPMStepDef.LogintoPMapplication(arg1);
	   
	}
	
	@Then("^validate the \"([^\"]*)\" functionaity of assigned \"([^\"]*)\" DPkey for the created presentation$")
	public void validate_the_functionaity_of_assigned_DPkey_for_the_created_presentation(String arg1, String arg2) throws Throwable {
		oPMStepDef.validate_the_functionaity_of_assigned_DPkey_for_the_created_presentation(arg1,arg2);
	   
	}
	

	
}
