package project.features.steps;

import java.io.IOException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.ServicesStepDef;

public class ServicesSteps {
	
	@Steps
	ServicesStepDef oServicesStepDef;

	
	@Given("^User \"([^\"]*)\" access the Service URl \"([^\"]*)\" to retrive the clientdata$")
	public void user_access_the_Service_URl_to_retrive_the_clientdata(String username, String serviceurl) throws Throwable {
		oServicesStepDef.Access_the_Service_URl_to_retrive_the_clientdata(username,serviceurl);
	    
	}
	
	@Given("^the user access \"([^\"]*)\" to post data to validate the Savings summary of CPW Opportunity Dashboard$")
	public void the_user_access_to_post_data_to_validate_the_Savings_summary_of_CPW_Opportunity_Dashboard(String arg1) throws Throwable {
		oServicesStepDef.Post_the_given_data_validate_the_Savings_summary_of_CPW_Opportunity_Dashboard(arg1);
	    
	}

	@Then("^validate the service response with \"([^\"]*)\" collection$")
	public void validate_the_service_response_with_collection(String arg1) throws Throwable {
		oServicesStepDef.validate_the_service_response_with_collection(arg1);
	    
	}
	
	@Then("^verify PPS for \"([^\"]*)\" b/w oracle and mdm service$")
	public void verify_PPS_for_b_w_oracle_and_mdm_service(String arg1) throws Exception {
		oServicesStepDef.verifyPPSbetweenOracleandmMDMservice(arg1);
	}

	@Given("^\"([^\"]*)\" is login into CPD with services$")
	public void is_login_into_CPD_with_services(String arg1) throws Exception {
		oServicesStepDef.userlogintoCPDwitservice(arg1);
	}
	
	@Then("^Create the presenatation profile with given request data client \"([^\"]*)\" payershort \"([^\"]*)\" lob \"([^\"]*)\" product \"([^\"]*)\" and prority \"([^\"]*)\" with \"([^\"]*)\"$")
	public void create_the_presenatation_profile_with_given_request_data_client_payershort_lob_product_and_prority_with(String sClient, String sPayershorts, String sLobs, String sProduct, String sPriority, String sUser) throws Throwable {
		oServicesStepDef.createPresentationProfilewithGivenRequest(sUser,sClient,sPayershorts,sLobs,sProduct,sPriority);
	}
	
	@Then("^assign multiple dps to created profile at \"([^\"]*)\"$")
	public void assignMultipleDPstoCreatedProfile(String arg1) throws Throwable {
		oServicesStepDef.assignMultipleDPstoCreatedProfile(arg1);	    
	}
	
	
	@When("^user captures disposition through service for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_captures_disposition_through_service_for(String arg1, String arg2, String arg3, String arg4) throws IOException {
		oServicesStepDef.Capture_the_disposition_through_service_from_MongoDBData(arg1, arg2, arg3, arg4);
	}

	
}
