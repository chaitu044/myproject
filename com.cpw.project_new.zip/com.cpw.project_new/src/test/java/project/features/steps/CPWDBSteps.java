package project.features.steps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.CPWDBStepDef;

public class CPWDBSteps {

	@Steps
	CPWDBStepDef oCPWDBStepDef;

	
	 @When("^The user executes MongoDB query for \"([^\"]*)\" to get client \"([^\"]*)\" data for \"([^\"]*)\" release$")
		public void the_user_executes_MongoDB_query_for_to_get_client_data(String queryForTestCase, String clientName, String release) throws Throwable {
		 oCPWDBStepDef.executeMongoQueryForClientData(queryForTestCase, clientName, release);
		}	
	    
	    
	    @Then("^The user validates the data retrieved from both the MongoDb collections for client \"([^\"]*)\" data for \"([^\"]*)\" release and collection \"([^\"]*)\"$")
		public void the_user_validates_the_data_retrieved_from_both_the_MongoDb_collections_for_client_data_for_release_and_collection(String arg1, String arg2, String arg3) throws Throwable {
	    	oCPWDBStepDef.validate_the_data_retrieved_from_both_the_MongoDb_collections_for_client_release_and_record_size(arg1,arg2,arg3);
		}
	    
	    @When("^The user executes the sql query from \"([^\"]*)\" for client \"([^\"]*)\",release \"([^\"]*)\"$")
		public void the_user_executes_the_sql_query_from_for_client_release(String arg1, String arg2, String arg3) throws Throwable {
	    	oCPWDBStepDef.User_retrieves_data_from_oracle_for_the_given(arg1,arg2,arg3);
		 
		}
	    
	    @Then("^The user validates the data retrieved from oracel db \"([^\"]*)\" with mongo db collection \"([^\"]*)\" for the client \"([^\"]*)\",release \"([^\"]*)\"$")
		public void the_user_validates_the_data_retrieved_from_oracle_db_with_mongo_db_collection_for_the_client_release(String arg1, String arg2, String arg3, String arg4) throws Throwable {
	    	oCPWDBStepDef.Validate_the_data_retrieved_from_oracle_db_with_mongo_db_collection_for_the_client_release_as(arg1,arg2,arg3,arg4);
		   
		}
	
	    @When("^the user executes MongoDB query for \"([^\"]*)\" and the release as \"([^\"]*)\" in the \"([^\"]*)\" environment$")
	    public void the_user_executes_MongoDB_query_for_and_the_release_as_in_the_environment(String arg1, String arg2, String arg3) throws Throwable {
	    	oCPWDBStepDef.User_executes_MongoDB_query_for_the_given(arg1,arg2,arg3);
	        
	    }

	    @Then("^validate the data retrieved from both DBs of \"([^\"]*)\"$")
	    public void validate_the_data_retrieved_from_both_DBs_of(String arg1) throws Throwable {
	    	oCPWDBStepDef.validate_the_data_retrieved_from_both_DBs_for(arg1);
	        
	    }
	    
	    @Then("^validate the data retrieved from both DBs of Clientkey \"([^\"]*)\" and release \"([^\"]*)\"$")
	    public void validate_the_data_retrieved_from_both_DBs_of_Clientkey_and_release(String arg1, String arg2) throws Throwable {
	    	oCPWDBStepDef.validate_the_data_retrieved_from_both_DBs_of_Clientkey_and_release(arg1,arg2);

	    }

}
