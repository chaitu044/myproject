package project.features.steps;

import java.io.IOException;
import java.text.ParseException;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.CPWStepDef;
import project.feature.steps.definitions.PolicyselectionStepDef;
import project.feature.steps.definitions.ReviewWorkedOpportunityStepDef;



public class CPWSteps  {

	@Steps
	CPWStepDef oCPWStepDef;
	//PolicyselectionStepDef oPolicyselectionStepDef;
	//ReviewWorkedOpportunityStepDef oReviewWorkedOpportunityStepDef;

	@Given("^the \"([^\"]*)\" is logged into the CPW application$")
	public void the_is_logged_into_the_CPW_application(String arg1) throws Throwable {
		oCPWStepDef.the_is_logged_into_the_CPW_application(arg1);	   
	}
	@When("^user click on given client with the given release$")
	public void user_click_on_given_client_with_the_given_release() throws Throwable {
		//oCPWStepDef.user_click_on_given_client_with_the_given_release();
	}

	@When("^user select Medical Policy from the policy selection through MongoDB$")
	public void user_select_Medical_Policy_from_the_policy_selection_through_MongoDB() throws Throwable {
		oCPWStepDef.user_select_Medical_Policy_from_the_policy_selection_through_MongoDB();
	}
	
	@Given("^select \"([^\"]*)\",\"([^\"]*)\" DP key in Opportunity grid and validate \"([^\"]*)\" functionality  in the Notes section of \"([^\"]*)\" page$")
	public void select_DP_key_in_Opportunity_grid_and_validate_functionality_in_the_Notes_section_of_page(int arg1, String arg2, String arg3, String arg4) throws Throwable {
		oCPWStepDef.select_DP_key_in_Opportunity_grid_and_validate_functionality_in_the_Notes_section_of_page(arg1, arg2, arg3,arg4);
	}
	
	@Then("^Logout CPW application$")
	public void logout_CPW_application() throws Throwable {
		oCPWStepDef.logout_CPW_application();
	}

	@When("^user click on client \"([^\"]*)\" with release \"([^\"]*)\" in the Opportunity Dashboard$")
	public void user_click_on_client_with_release_in_the_Opportunity_Dashboard(String arg1, String arg2) throws Throwable {

		oCPWStepDef.User_click_on_client_with_release_in_the_Opportunity_Dashboard(arg1,arg2);
	}

	@Then("^validate the \"([^\"]*)\" savings data with MongoDB for the client \"([^\"]*)\" with release \"([^\"]*)\" and savingsstatus as \"([^\"]*)\" in \"([^\"]*)\"$")
	public void validate_the_savings_data_with_MongoDB_for_the_client_with_release_and_savingsstatus_as_in(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException {
		oCPWStepDef.validate_the_savings_data_with_MongoDB_for_the_client_with_release_in(arg1,arg2,arg3,arg4,arg5);
	}
	
	/*@Then("^validate the \"([^\"]*)\" savings data with MongoDB for the client \"([^\"]*)\" with release \"([^\"]*)\" in \"([^\"]*)\"$")
	public void validate_the_savings_data_with_MongoDB_for_the_client_with_release_in(String arg1, String arg2, String arg3, String arg4) throws Throwable {

		oCPWStepDef.validate_the_savings_data_with_MongoDB_for_the_client_with_release_in(arg1,arg2,arg3,arg4);
	}
*/
	@Then("^validate the \"([^\"]*)\" displayed in the \"([^\"]*)\" with MongoDB for the client \"([^\"]*)\" with release \"([^\"]*)\"$")
	public void validate_the_displayed_in_the_with_MongoDB_for_the_client_with_release(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		oCPWStepDef.Validate_the_Topics_DPs_displayed_in_the_given_page_with_MongoDB(arg1,arg2,arg3,arg4);
	}

	@Then("^validate the capture and update disposition functionality at \"([^\"]*)\" data for \"([^\"]*)\",Disposition as \"([^\"]*)\",update disposition \"([^\"]*)\" with MongoDB$")
	public void validate_the_capture_and_update_disposition_functionality_at_data_for_Disposition_as_update_disposition_with_MongoDB(String arg1, String arg2, String arg3, String arg4) throws InterruptedException {
		oCPWStepDef.Validate_the_capture_and_update_disposition_functionality_with_MongoDB_for(arg1,arg2,arg3,arg4);
	}

	@Then("^validate the filters checkboxes funcitonality \"([^\"]*)\" in the AWB Page$")
	public void validate_the_filters_checkboxes_funcitonality_in_the_AWB_Page(String arg1) {
	 
		oCPWStepDef.validate_the_filters_checkboxes_funcitonality_in_the_AWB_Page(arg1);
	}
	
	@Then("^validate the opportunitygrid data with mongo DB in the AWB page based on the filter \"([^\"]*)\"$")
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filter(String arg1) throws InterruptedException {
	 
		oCPWStepDef.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filter(arg1);
	}
	
	@Then("^validate the opportunitygrid data with mongo DB in the AWB page based on the filters \"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filters_and(String arg1, String arg2, String arg3) throws InterruptedException {
		oCPWStepDef.validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filter_options(arg1,arg2,arg3);
	 
	}
	
	@When("^validate \"([^\"]*)\" functionality under \"([^\"]*)\" page$")
	public void validate_functionality_under_page(String arg1, String arg2) {
		oCPWStepDef.validate_functionality_under_page(arg1, arg2);
	}
	
	@Then("^validate the DP Descpopup with MongoDB in the \"([^\"]*)\" Page for the savingsstatus \"([^\"]*)\"$")
	public void validate_the_DP_Descpopup_with_MongoDB_in_the_Page_for_the_savingsstatus(String arg1, String arg2) throws InterruptedException {
		oCPWStepDef.validate_the_DP_Descpopup_with_MongoDB_for_the_savingsstatus_in(arg1,arg2);
	}

	@Then("^validate the sorting functionality for the rules in the DPDesc popup in the \"([^\"]*)\" page for the sorting type \"([^\"]*)\"$")
	public void validate_the_sorting_functionality_for_the_rules_in_the_DPDesc_popup_in_the_page_for_the_sorting_type(String pagename, String sortingtype) throws InterruptedException {
		oCPWStepDef.validate_the_sorting_functionality_for_the_rules_in_the_DPDesc_popup(pagename,sortingtype);
	}
	
	@Then("^validate the \"([^\"]*)\" popup data with MongoDB in the \"([^\"]*)\" Page$")
	public void validate_the_popup_data_with_MongoDB_in_the_Page(String arg1, String arg2) throws InterruptedException {
		oCPWStepDef.validate_the_popup_data_with_MongoDB_in_the_Page(arg1,arg2);

	}
	
	//***********************************************************************************************************************************************************
	
    @Given("^user select Medical Policy from the policy selection through MongoDB for the given payershort \"([^\"]*)\"$")
    public void user_select_Medical_Policy_from_the_policy_selection_through_MongoDB_for_the_given_payershort(String arg1) throws InterruptedException {
    oCPWStepDef.user_select_Medical_Policy_from_the_policy_selection_through_MongoDB_for_the_given_payershort(arg1);
    }
    @Given("^select \"([^\"]*)\",\"([^\"]*)\" DP key in Opportunity grid under \"([^\"]*)\" page$")
    public void select_DP_key_in_Opportunity_grid_under_page(int arg1, String arg2, String arg3) {
           oCPWStepDef.select_DP_key_in_Opportunity_grid_under_page(arg1, arg2, arg3);
    }
    @Then("^validate UI \"([^\"]*)\" data with MongoDB under DPWB page from \"([^\"]*)\" page$")
    public void validate_UI_data_with_MongoDB_under_DPWB_page_from_page(String arg1, String arg2) {
           oCPWStepDef.validate_UI_data_with_MongoDB_under_DPWB_page_from_page(arg1, arg2);
    }

    @Given("^store \"([^\"]*)\" and \"([^\"]*)\"  into serenity$")
    public void store_and_into_serenity(String arg1, String arg2) {
           oCPWStepDef.store_and_into_serenity(arg1, arg2);
    }

    @Given("^validate \"([^\"]*)\",\"([^\"]*)\" functionality under \"([^\"]*)\" page$")
    public void validate_functionality_under_page(String arg1, String arg2, String arg3) {
           oCPWStepDef.validate_functionality_under_page(arg1, arg2, arg3);
    }

    @Then("^Validate the Opportunity Grid data with MongoDB for the client \"([^\"]*)\"$")
	public void validate_the_Opportunity_Grid_data_with_MongoDB_for_the_client(String arg1) throws Throwable {
    	oCPWStepDef.Validate_the_opportunity_grid_data_with_mongo_DB(arg1);
	}
    
  //****************************************** PI-25 Steps ************************************************************************************
    @Then("^validate the clients in alphabitical order in  AWB page$")
    public void validate_the_clients_in_alphabitical_order_in_AWB_page() 
    {
    	oCPWStepDef.validate_the_clients_in_alphabitical_order_in_AWB_page();
    }
    
    @When("^user select the \"([^\"]*)\" in AWB page$")
    public void user_select_the_in_AWB_page(String arg1) throws IOException 
    {
    	oCPWStepDef.UserSelecttheclientinAWBPage(arg1);
    }
    
	@Then("^validate the filters checkboxes funcitonality \"([^\"]*)\" in the FilterPanel$")
	public void validate_the_filters_checkboxes_funcitonality_in_the_FilterPanel(String arg1) 
	{
		//Serenity.setSessionVariable("Pagename").to("AWB");
		oCPWStepDef.validate_the_filters_checkboxes_funcitonality_in_the_FilterPanel(arg1);
	}
    
	/*@Then("^validate the \"([^\"]*)\" displayed in the \"([^\"]*)\" with MongoDB for the filters \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void validate_the_displayed_in_the_with_MongoDB_for_the_filters(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws InterruptedException {
		oCPWStepDef.validateThedatainAWBgridwithDBfortheGivenFilters(arg1,arg2,arg3,arg4,arg5,arg6);
	}*/
	
	@Then("^Validate the \"([^\"]*)\" grid columns in AWB Page$")
	public void validate_the_grid_columns_in_AWB_Page(String arg1) {
		oCPWStepDef.validate_the_grid_columns_in_AWB_Page(arg1);
	 
	}
	
	@Then("^user should see \"([^\"]*)\" in AWB Page$")
	public void user_should_see_in_AWB_Page(String arg1) {
		oCPWStepDef.userShouldseeinAWBPage(arg1);
	}
		
	@Then("^validate \"([^\"]*)\" in AWB grid with DB$")
	public void validate_in_AWB_grid_with_DB(String arg1) throws ParseException, InterruptedException 
	{
		oCPWStepDef.validateTheDataintheAWBGridwithDB(arg1);
	}
	
	@When("^user select \"([^\"]*)\" MedicalPolicy from filterPanel through MongoDB$")
	public void user_select_MedicalPolicy_from_filterPanel_through_MongoDB(String arg1) throws Throwable {
		oCPWStepDef.user_select_Medical_Policy_from_the_policy_selection_through_MongoDB(arg1);
	    
	}

	@Then("^validate the disposition popup \"([^\"]*)\"$")
	public void validate_the_disposition_popup_in(String arg1) throws InterruptedException {
		oCPWStepDef.validatetheDispositionpopup(arg1);
	}
	
	@When("^user selects \"([^\"]*)\" MP from filter panel for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_selects_MP_from_filter_panel_for_and(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException {
		oCPWStepDef.selectMPfromFilterpanelForgivenPPS(arg1,arg2,arg3,arg4,arg5);
	}

	@Then("^verify DPs in \"([^\"]*)\" AWBgrid for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void verify_DPs_in_AWBgrid_for_and(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException {
		oCPWStepDef.Validate_the_DPs_displayed_in_the_given_page_with_MongoDB(arg1, arg2, arg3, arg4, arg5);
	}

	@Then("^validate \"([^\"]*)\" in AWB grid with DB for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and \"([^\"]*)\"$")
	public void validate_in_AWB_grid_with_DB_for_and(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException, ParseException {
		oCPWStepDef.validateThedatainAWBgridwithDBforthePPS(arg1, arg2, arg3, arg4, arg5);
	}

	@When("^user select \"([^\"]*)\" MP from Filterpanel through MongoDB without \"([^\"]*)\" Decision$")
	public void user_select_MP_from_Filterpanel_through_MongoDB_without_Decision(String arg1, String arg2) throws InterruptedException {
		oCPWStepDef.userSelectsMPWithoutNoneDecision(arg1,arg2);
	}
	
	
	@Then("^validate DPview of \"([^\"]*)\" tab for PPS \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void validate_DPview_of_tab_for_PPS(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Exception {
		oCPWStepDef.verifyPPSinDPviewwithDB(arg1, arg2, arg3, arg4, arg5,arg6);
	}
	
	@Then("^verify DPview retain functionality in \"([^\"]*)\" tab$")
	public void verify_DPview_retain_fucntionality_in_tab(String arg1) {
		oCPWStepDef.verifyDPviewRetainfunctionality(arg1);
	}
	

	@Then("^verify LCD \"([^\"]*)\" and savingsstatus \"([^\"]*)\" in \"([^\"]*)\"$")
	public void verify_LCD_and_savingsstatus_in(String arg1, String arg2, String arg3) throws ParseException {
		oCPWStepDef.verifyLCDandSavingsstatusChkboxfunctionality(arg1, arg2,arg3);
	}

	@Then("^verify capture disposition functionality for \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" in \"([^\"]*)\"$")
	public void verify_capture_disposition_functionality_for_in(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws InterruptedException {
		oCPWStepDef.verifyCaptureDispositionFunctionality(arg1, arg2, arg3,arg4,arg5,arg6,arg7);
	}


	@Then("^verify rulerelationship alert for \"([^\"]*)\" rules in \"([^\"]*)\" tab for capture disposition \"([^\"]*)\" and PPS \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void verify_rulerelationship_alert_for_rules_in_tab_for_capture_disposition_and_PPS(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6, String arg7) throws InterruptedException {
		oCPWStepDef.captureDispositionforRulerelationshipdps(arg1, arg2, arg3,arg4,arg5,arg6,arg7);
	}


	@Then("^verify flag filters in \"([^\"]*)\" DPView for \"([^\"]*)\" and PPS \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void verify_flag_filters_in_DPView_for_and_PPS(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Exception {
		oCPWStepDef.verifyFlagfilterfunctionality(arg1, arg2, arg3,arg4,arg5,arg6);
	}
	
	@Then("^verify RR popup in \"([^\"]*)\" DPView for \"([^\"]*)\" and PPS \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void verify_RR_popup_in_DPView_for_and_PPS(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Exception {
		oCPWStepDef.verifyRRpopupwithDB(arg1, arg2, arg3,arg4,arg5,arg6);
	   
	}
	@When("^user selects \"([^\"]*)\" topic in policydrawer for PPS \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_selects_topic_in_policydrawer_for_PPS(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException {
		oCPWStepDef.userSelectsTopicWithoutNoneDecision(arg1, arg2, arg3, arg4, arg5);
	}

	@Then("^capture disposition at payerLOB level for rulerelationship \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void capture_disposition_at_payerLOB_level_for_rulerelationship(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws Exception {
		oCPWStepDef.captureDispositionforRulerelationshipdpsatPPSlevel(arg1, arg2, arg3, arg4, arg5, arg6);
	}

	@Then("^verify captured DP/PPS at \"([^\"]*)\" in RWO as \"([^\"]*)\"$")
	public void verify_captured_DP_PPS_at_in_RWO_as(String arg1, String arg2) {
		oCPWStepDef.verifyCapturedDPkeysinRWO(arg1,arg2);
	}
	
	@Then("^user update disposition as \"([^\"]*)\" at \"([^\"]*)\"$")
	public void user_update_disposition_as_at(String arg1, String arg2) throws InterruptedException {
		oCPWStepDef.verifyUpdateDispositionat(arg1,arg2);
	}
}
