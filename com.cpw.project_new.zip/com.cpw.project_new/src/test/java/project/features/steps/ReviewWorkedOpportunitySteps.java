package project.features.steps;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.PolicyselectionStepDef;
import project.feature.steps.definitions.ReviewWorkedOpportunityStepDef;

public class ReviewWorkedOpportunitySteps {
	@Steps
	ReviewWorkedOpportunityStepDef oReviewWorkedOpportunityStepDef;
	
	//========================================================Steps ====================================================================================//
	
	
	@Then("^validate the update disposition functionality at \"([^\"]*)\" data for \"([^\"]*)\",Disposition as \"([^\"]*)\"$")
	public void validate_the_update_disposition_functionality_at_data_for_Disposition_as(String arg1, String arg2, String arg3) throws InterruptedException {
		oReviewWorkedOpportunityStepDef.validate_the_update_disposition_functionality_at_data_for_Disposition_as(arg1,arg2,arg3);
	}
	
	

	@Then("^validate the filters checkboxes funcitonality \"([^\"]*)\" in the RWO Page$")
	public void validate_the_filters_checkboxes_funcitonality_in_the_RWO_Page(String arg1) throws Throwable {
		oReviewWorkedOpportunityStepDef.validate_the_filters_checkboxes_funcitonality_in_the_RWO_Page(arg1);
	   
	}
	
	@Then("^validate the opportunitygrid data with mongo DB in the RWO page based on the filter \"([^\"]*)\"$")
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filter(String arg1) throws Throwable {
	    
		oReviewWorkedOpportunityStepDef.validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filter(arg1);
	}
	
	@Then("^validate the opportunitygrid data with mongo DB in the RWO page based on the filters \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filters(String arg1, String arg2, String arg3, String arg4, String arg5) throws Throwable {
		oReviewWorkedOpportunityStepDef.validate_the_opportunitygrid_data_with_mongo_DB_in_the_RWO_page_based_on_the_filter_options(arg1,arg2,arg3,arg4,arg5);
	    
	}
	
	@When("^select the filters checkboxes \"([^\"]*)\" as \"([^\"]*)\" in \"([^\"]*)\"$")
	public void select_the_filters_checkboxes_as_in(String arg1, String arg2, String arg3) throws Throwable {
		oReviewWorkedOpportunityStepDef.Select_the_filters_checkboxes_in_the_page(arg1,arg2,arg3);
	}
	
	

    @Then("^validate the retention funcitonality for the filters checkboxes \"([^\"]*)\" as \"([^\"]*)\" in \"([^\"]*)\"$")
    public void validate_the_retention_funcitonality_for_the_filters_checkboxes_as_in(String arg1, String arg2, String arg3) throws Throwable {
       
    	oReviewWorkedOpportunityStepDef.validate_the_retention_funcitonality_for_the_filter_checkboxes(arg1,arg2,arg3);
    }
    
    @Then("^validate the sorting funcitonality in \"([^\"]*)\" Page for the coloumn \"([^\"]*)\" as \"([^\"]*)\"$")
    public void validate_the_sorting_funcitonality_in_Page_for_the_coloumn_as(String arg1, String arg2, String arg3) throws Throwable {
    	oReviewWorkedOpportunityStepDef.validate_the_sorting_funcitonality_in_Page_for_the_coloumn_as(arg1,arg2,arg3);
     
    }
}
