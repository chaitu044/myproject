package project.features.steps;

import java.text.ParseException;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;
import project.feature.steps.definitions.PolicyselectionStepDef;

public class PolicyselectionSteps {
	@Steps
	PolicyselectionStepDef oPolicyselectionStepDef;
	
	@Then("^validate the \"([^\"]*)\"  with corresponding \"([^\"]*)\" savings displayed in the policy selection drawer with mongoDB$")
	public void validate_the_with_corresponding_savings_displayed_in_the_policy_selection_drawer_with_mongoDB(String arg1, String arg2) throws InterruptedException {
		oPolicyselectionStepDef.validate_policy_selection_drawer_with_mongoDB_for_the_displayed(arg1,arg2);
	}
	
	/*@Then("^validate the \"([^\"]*)\"  with corresponding \"([^\"]*)\" savings displayed in the policy selection drawer with mongoDB for the filters \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void validate_the_with_corresponding_savings_displayed_in_the_policy_selection_drawer_with_mongoDB_for_the_filters(String arg1, String arg2, String arg3, String arg4, String arg5) throws InterruptedException {
	 
		//oPolicyselectionStepDef.validate_policy_selection_drawer_with_mongoDB_for_the_given_filters(arg1,arg2,arg3,arg4,arg5);
	}*/
	
	
	@Then("^validate the sorting functionality for the \"([^\"]*)\" in the policy selection drawer by \"([^\"]*)\"$")
	public void validate_the_sorting_functionality_for_the_in_the_policy_selection_drawer_by(String arg1, String arg2) throws InterruptedException {
		oPolicyselectionStepDef.validate_the_sorting_functionality_in_the_policy_selection_drawer_by(arg1,arg2);

	}

	@Then("^validate the UI functionality for the \"([^\"]*)\" in the policy selection drawer by \"([^\"]*)\"$")
	public void validate_the_UI_functionality_for_the_in_the_policy_selection_drawer_by(String arg1, String arg2) throws InterruptedException {
	   
		oPolicyselectionStepDef.validate_the_UI_functionality_in_the_policy_selection_drawer_for(arg1,arg2);
	}

	@Then("^validate the policy release summary data with mongo DB in \"([^\"]*)\" page$")
	public void validate_the_policy_release_summary_data_with_mongo_DB_in_page(String arg1) {
		oPolicyselectionStepDef.validate_the_policy_release_summary_data_with_mongo_DB_in_page(arg1);
	 
	}
	
	
	@Then("^valiadte the policyreleasesummary data update functionality after capturing the disposition 'Present' in AWB and Review Worked Opportunity Page$")
	public void valiadte_the_policyreleasesummary_data_update_functionality_after_capturing_the_disposition_Present_in_AWB_and_Review_Worked_Opportunity_Page() throws InterruptedException {
		oPolicyselectionStepDef.valiadte_the_policyreleasesummary_data_update_functionality_after_capturing_the_disposition_Present_in_AWB_and_Review_Worked_Opportunity_Page();
	}


	@Then("^validate the medical policy release summary data with mongo DB in \"([^\"]*)\" page$")
	public void validate_the_medical_policy_release_summary_data_with_mongo_DB_in_page(String arg1) throws InterruptedException {
		oPolicyselectionStepDef.validate_the_medical_policy_release_summary_data_with_mongo_DB_in_page(arg1);
	}


	@Then("^valiadte the medicalpolicy release summary data update functionality after capturing the disposition \"([^\"]*)\" in AWB and Review Worked Opportunity Page$")
	public void valiadte_the_medicalpolicy_release_summary_data_update_functionality_after_capturing_the_disposition_in_AWB_and_Review_Worked_Opportunity_Page(String arg1) throws InterruptedException {
		oPolicyselectionStepDef.valiadte_the_medicalpolicy_release_summary_data_update_functionality_after_capturing_the_disposition_in_AWB_and_Review_Worked_Opportunity_Page(arg1);
	}

	//######################################## PI-25 Stories ###########################################################################//
	
	@Then("^validate the \"([^\"]*)\"  with corresponding \"([^\"]*)\" savings displayed in FilterPanel with mongoDB for the filters \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void validate_the_with_corresponding_savings_displayed_in_FilterPanel_with_mongoDB_for_the_filters(String arg1, String arg2, String arg3, String arg4, String arg5, String arg6) throws InterruptedException {
		oPolicyselectionStepDef.validate_FilterPanel_with_mongoDB_for_the_given_filters(arg1,arg2,arg3,arg4,arg5,arg6);
	}
	
	@When("^user selects multiple \"([^\"]*)\" in filter panel$")
	public void user_selects_multiple_in_filter_panel(String arg1) throws InterruptedException 
	{
		oPolicyselectionStepDef.userSelectsMPTopicsinFilterPanelas(arg1);
	}

	@Then("^validate the retain functinality in filter Panel for multiple \"([^\"]*)\" in filter Panel$")
	public void validate_the_retain_functinality_in_filter_Panel_for_multiple_in_filter_Panel(String arg1) 
	{
		oPolicyselectionStepDef.validateTheRetentionfunctionalityinFilterPanel(arg1);

	}
	
	@Then("^validate the topics with no edits in filter panel$")
	public void validate_the_topics_with_no_edits_in_filter_panel() throws ParseException, InterruptedException {
		oPolicyselectionStepDef.validateTheNoEditsTopicsinfilterpanel();
	 }

	@When("^user selects PPS as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and LCD as \"([^\"]*)\"$")
	public void user_selects_PPs_as_and_LCD_as(String arg1, String arg2, String arg3, String arg4) throws InterruptedException {
		oPolicyselectionStepDef.userSelectsgivenPPSandLCDinfilterpanel(arg1, arg2, arg3, arg4);
	}
	
	@Then("^verify \"([^\"]*)\" in filterpanel PPS as \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\" and LCD as \"([^\"]*)\"$")
	public void verify_in_filterpanel_PPS_as_and_LCD_as(String arg1, String arg2, String arg3, String arg4, String arg5) throws Exception {
		oPolicyselectionStepDef.verifyMPforNoneinfilterpanel(arg1, arg2, arg3, arg4,arg5);
	}
	
	@When("^user selects PPS combination dynamically with given \"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\",\"([^\"]*)\"$")
	public void user_selects_PPS_combination_dynamically_with_given(String arg1, String arg2, String arg3, String arg4) {
		oPolicyselectionStepDef.userSelctsPPScombinationsDynamicallyforgiven(arg1,arg2,arg3,arg4);
	   
	}
}
