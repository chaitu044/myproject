package project.pageobject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;

import project.utilities.DBUtils;
import project.utilities.ExcelUtils;
import project.utilities.GenericUtils;
import project.utilities.MicroServRestUtils;
import project.utilities.MongoDBUtils;
import project.utilities.OracleDBQueries;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;



public class ServicesPage extends SeleniumUtils {
	//MicroServRestUtils oMicroServRestUtils;
	

	public static boolean RetrievetheClientdatafromtheResponse(String username, String serviceurl) throws IOException {
		int j=0;
		String  ClientKey=null;
		String  Clientname=null;
		ArrayList<String> Clientlist=new ArrayList<>();
		ArrayList<String> Clientkeylist=new ArrayList<>();
	
		boolean bstatus=false;
		
		String ServiceRequestBody= "{\r\n" +"	\"userName\": \""+username+"\"\r\n" +"}\r\n";
		
		//method to post the given data in the given service
		bstatus=MicroServRestUtils.Post_the_Data_with_Rest_Assured(ServiceRequestBody, serviceurl);
		
		List<String> OutputList=Arrays.asList(ProjectVariables.ResponseOutput.split("}"));
		
		for (int i = 0; i < OutputList.size(); i++) {
			j=j+1;
			String Exactdata=StringUtils.substringAfter(OutputList.get(i), "{");
			ClientKey=StringUtils.substringBetween(Exactdata, "clientId:",",clientName");
			Clientname=StringUtils.substringAfterLast(Exactdata, "clientName:");
			Clientlist.add(Clientname.trim());
			ProjectVariables.Clientkeylist.add(Long.valueOf(ClientKey));
			
		}

		
		System.out.println("Total Assigned CLients ==>"+j);
		System.out.println("Total Clients ==>"+Clientlist);
		System.out.println("Total ClientKeys ==>"+ProjectVariables.Clientkeylist);
		return bstatus;
	}

	public void validate_the_data_retrieved_from_both_DBs_for(String clientkey,
			String release) {
		
		Serenity.setSessionVariable("clientkey").to(clientkey);
		Serenity.setSessionVariable("release").to(release);
		
		ArrayList<String> NotAvailable_Recordcount=new ArrayList<>();
		
		//Mongo method to retrieve the data based on clientkey,release and environment
		MongoDBUtils.Get_the_client_data_based_on_given("UAT");
		MongoDBUtils.Get_the_client_data_based_on_given("PROD");
		
		//Comparing records count of both databases
		if(ProjectVariables.UAT_Opportunity_collection_data.size()==ProjectVariables.PROD_Opportunity_collection_data.size())
		{
			System.out.println("Opportunity collection record count is matching between 'UAT' and 'PROD' Databases for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size());
		}
		else
		{
			System.out.println("Opportunity collection record count is not matching between 'UAT' and 'PROD' Databases for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size());
			//Assert.assertTrue("Opportunity collection record count is not matching between 'UAT' and 'PROD' Databases for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size(), false);
		}
		
		int j=1;
		
		//Comparing the records of two environments 
		for (int i = 0; i < ProjectVariables.UAT_Opportunity_collection_data.size(); i++) 
		{
			if(ProjectVariables.PROD_Opportunity_collection_data.contains(ProjectVariables.UAT_Opportunity_collection_data.get(i)))
			{
				System.out.println("Opportunity collection record '"+j+"' is matching between 'UAT' and 'PROD' Databases for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size());
			}
			else
			{
				
				NotAvailable_Recordcount.add(ProjectVariables.UAT_Opportunity_collection_data.get(i));
				
			}
			
			j=j+1;
		}
		
		System.out.println("Total'"+NotAvailable_Recordcount.size()+"' records were not available in 'PROD' Database as those are in 'UAT', for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size());
		System.out.println(NotAvailable_Recordcount.get(0));
		
		Assert.assertTrue("Total'"+NotAvailable_Recordcount.size()+"' records were not available in 'PROD' Database as those are in 'UAT', for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size(), false);
//		Assert.assertTrue("Total'"+NotAvailable_Recordcount.size()+"' records were not available in 'PROD' Database as those are in 'UAT', for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",Release==>"+Serenity.sessionVariableCalled("release")+",UAT Record count==>"+ProjectVariables.UAT_Opportunity_collection_data.size()+",PROD Record count==>"+ProjectVariables.PROD_Opportunity_collection_data.size()+",Not available Records are==>"+NotAvailable_Recordcount, false);

		
	}

	public boolean Post_the_given_data_for_the_given_service_and_criteria_with_Rest(String jsonBody, String seriviceURl) throws IOException {
		boolean bstatus=false;
		
		
		System.out.println("Json Message body ====>"+jsonBody);
		bstatus=MicroServRestUtils.Post_the_Data_with_Rest_Assured(jsonBody, seriviceURl);
		
		
		if(bstatus)
		{
			GenericUtils.logMessage("Record was posted successfully through service url using post manager ===>"+seriviceURl);
			
			
			return bstatus;
		}
		else
		{
			//Assert.assertTrue("Record was not posted through service url using post manager ===>"+seriviceURl+" ,Service Reponse code was ====>"+Serenity.sessionVariableCalled("ResponseCode")+" ,Json body was ====>"+jsonBody, bstatus);
		
			return false;
			
		}
		
		
	}
	
	public void logintoApplication(String sUserName) throws Exception {
		LoginPage oLoginPage=this.switchToPage(LoginPage.class);
		MicroServRestUtils oMicroServRestUtils=this.switchToPage(MicroServRestUtils.class);
		Serenity.setSessionVariable("User").to(sUserName);
		//To load the services from excel into hashmap
		ExcelUtils.loadServices();

		String sRequiredPassword=oLoginPage.Get_Password_For_the_given_url(sUserName);

		HashMap<String,Object> parametersMap = new HashMap<String,Object>();
		parametersMap.put("userName", sUserName);
		parametersMap.put("password", sRequiredPassword);
		String sBody = MicroServRestUtils.getRequestPayload("getLogin",parametersMap);
		String sEndPoint = ProjectVariables.sServices.get("getLogin").get("EndpointURL");

		io.restassured.path.json.JsonPath oResponseBody = oMicroServRestUtils.getResponseBodyPostService(sEndPoint,sBody);
		Serenity.setSessionVariable("oLoginResponse").to(oResponseBody);
		String sSessionID = oResponseBody.get("sessionId");
		Serenity.setSessionVariable("sessionID").to(sSessionID);
		Serenity.setSessionVariable("User").to(sUserName);
		
		System.out.println("Session ID ==>"+sSessionID);

	}

	public void getUniquePPSfromClientconfigService() throws Exception
	{
		MicroServRestUtils oMicroServRestUtils=this.switchToPage(MicroServRestUtils.class);
		HashMap<String,Object> parametersMap = new HashMap<String,Object>();
		
		//To loginto CPD with service
		logintoApplication(Serenity.sessionVariableCalled("user"));
		
		parametersMap.put("userName", Serenity.sessionVariableCalled("user"));
		String sEndPoint = ProjectVariables.sServices.get("getClientConfig").get("EndpointURL");

		Response oResponseBody = oMicroServRestUtils.getRequestWithPathParams(sEndPoint+Serenity.sessionVariableCalled("clientkey"));
		//System.out.println(oResponseBody.jsonPath().getString("result"));
		String sResult=oResponseBody.jsonPath().getString("result");
		List<String> sList=Arrays.asList(sResult.split("],"));
		for (int i = 0; i < sList.size(); i++) 
		{
			//System.out.println(sList.get(i));
			String spayer=StringUtils.substringBetween(sList.get(i), "payer_short:", ", insurance_key").trim();
			String sinsurancekey=StringUtils.substringBetween(sList.get(i), "insurance_key:", ", policy_set_key").trim();
			String sclaimtype=StringUtils.substringBetween(sList.get(i), "claim_type:", ", payer_short").trim();
			String sinsurance=GenericUtils.Retrieve_the_insuranceDesc_from_insuranceKey(sinsurancekey).trim();
			if(!sclaimtype.equalsIgnoreCase("D")&&!sclaimtype.equalsIgnoreCase("H"))
			{
				ProjectVariables.PPSList.add(spayer+":"+sinsurance+":"+sclaimtype);	
			}
			
			//System.out.println(spayer+":"+sinsurance+":"+sclaimtype);
		}
		System.out.println("####################### Service PPS ###############################");
		for (String pps : ProjectVariables.PPSList) {
			System.out.println(pps);
		}
		System.out.println("DistinctPPS Size::"+ProjectVariables.PPSList.size());
	}

	public void verifyPPSbetweenOracleandService(String clientkey) throws Exception {
		// TODO Auto-generated method stub
		boolean bstatus=false;
		HashSet<String> oraclePPSList=new HashSet<>();
		Serenity.setSessionVariable("clientkey").to(clientkey);
		
		//To get distinct pps from mdm service
		getUniquePPSfromClientconfigService();
		
		//To get distinct pps from oracle
		oraclePPSList.addAll(DBUtils.getDistinctPPSfromDB(StringUtils.replace(OracleDBQueries.DistinctPPS, "clientkey", clientkey), "VPMTST1"));
		
		bstatus=ProjectVariables.PPSList.size()==oraclePPSList.size();
		
		GenericUtils.Verify("Oracel Distinct PPS count::"+oraclePPSList.size()+",Service Distinct PPS count::"+ProjectVariables.PPSList.size(), bstatus);
		
		for (String oraclepps : oraclePPSList) 
		{
			if(!ProjectVariables.PPSList.contains(oraclepps))
			{
				GenericUtils.Verify("oracle PPS=>'"+oraclepps+"' is not available in MDM Service",false);
			}
			else
			{
				GenericUtils.Verify("oracle PPS=>'"+oraclepps+"' is available in MDM Service",true);
			}
		}
		
		for (String servicepps : ProjectVariables.PPSList) 
		{
			if(!oraclePPSList.contains(servicepps))
			{
				GenericUtils.Verify("MDMservice PPS=>'"+servicepps+"' is not available in oracle",false);
			}
			else
			{
				GenericUtils.Verify("MDMservice PPS=>'"+servicepps+"' is available in oracle",true);
			}
		}
		
	}
	
	public String createPresentationThroughService(String sUser, String sClient, String sPayershorts, String sLobs,
			String sProduct, String sPriority) throws ParseException, IOException {
		MicroServRestUtils oMicroServRestUtils=this.switchToPage(MicroServRestUtils.class);
		String sClientKey=null;
		if(Serenity.sessionVariableCalled("clientkey")==null)
		{
			sClientKey=AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(sClient);
			
			Serenity.setSessionVariable("clientkey").to(sClientKey);
		}
		else
		{
			sClientKey=Serenity.sessionVariableCalled("clientkey");
		}
		HashMap<String,Object> sFields = new HashMap<String,Object>();
		sFields.put("profileName", "AutoService"+GenericUtils.GetRandomNumber());
		sFields.put("targetDate", "2019-09-12");
		sFields.put("createdUser", sUser);
		sFields.put("clientKey", sClientKey);
		sFields.put("lobs", sLobs.split(";"));
		sFields.put("products", sProduct.split(";"));
		sFields.put("priorities",sPriority.split(";"));
		sFields.put("payerShorts",sPayershorts.split(";"));
		sFields.put("note", "Notes"+GenericUtils.GetRandomNumber());

		String sBody = project.utilities.JsonBody.getRequestPayload("createPresentationProfile", sFields);
		String sEndpoint = ProjectVariables.sServices.get("createPresentationProfile").get("EndpointURL");
		io.restassured.path.json.JsonPath oReponse = oMicroServRestUtils.getResponseBodyforPostServiceWithSessionID(sEndpoint, sBody);
		String sProfileID = oReponse.get("id");		
		String sProfileName = oReponse.get("profileName");

		return sProfileID+"-"+sProfileName;
		
		
		
	}
	
	public void assignMultipleDPstoCreatedProfile(String criteria) 
	{
		MicroServRestUtils oMicroServRestUtils=this.switchToPage(MicroServRestUtils.class);
	List<Map<String , Object>> ppslist  = new ArrayList<Map<String,Object>>();
	HashMap<String,Object> oPPS = new HashMap<String,Object>();
	ArrayList<String> AssignedInsuranceList=new ArrayList<>();
	ArrayList<String> UnAssignedInsuranceList=new ArrayList<>();
	String Insurance=null;
	String payerkey=null;
	int insuranceKey=0;
	String payershort=null;
	String claimtype=null;
	String clientname=Serenity.sessionVariableCalled("client");
	List<String> DPKeysList=Arrays.asList(Serenity.sessionVariableCalled("DPkey").toString().split(","));
	int iClientKey = Integer.parseInt(Serenity.sessionVariableCalled("clientkey"));
	String user=Serenity.sessionVariableCalled("user");
	for (int p = 0; p < DPKeysList.size(); p++){
		
		ProjectVariables.CapturedDPkey=Long.valueOf(DPKeysList.get(p).trim());
		String sTopicKey = MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(Serenity.sessionVariableCalled("Topic").toString(), "Topic Based on DP");
		int iTopicKey = Integer.parseInt(sTopicKey);
		String sMPkey = MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(Serenity.sessionVariableCalled("Medicalpolicy").toString(), "MP");
		int iMPKey = Integer.parseInt(sMPkey);

		String sDPKey = DPKeysList.get(p).trim();
		int iDPKey= Integer.parseInt(sDPKey);
	
		//To Retrieve the payer and Lobs from the captured DP
	MongoDBUtils.GettheCapturedDispositionPayerLOBsFromtheGiven(Serenity.sessionVariableCalled("Medicalpolicy"), "Present", sDPKey);
	
	switch(criteria)
	{
		case "DP Level":
			AssignedInsuranceList.addAll(ProjectVariables.CapturedInsuranceList);
			break;
		case "LOB Level":
			for (int i = 0; i < ProjectVariables.CapturedInsuranceList.size(); i++)
			{
				if(i==0)
				{
					AssignedInsuranceList.add(ProjectVariables.CapturedInsuranceList.get(i));
				}
				else
				{
					UnAssignedInsuranceList.add(ProjectVariables.CapturedInsuranceList.get(i));	
				}
			}
			String assignPPS=String.join(",", AssignedInsuranceList);
			String unassignPPS=String.join(",", UnAssignedInsuranceList);
			Serenity.setSessionVariable("assignPPS").to(assignPPS);
			Serenity.setSessionVariable("unassignPPS").to(unassignPPS);
			System.out.println("assignPPS::"+assignPPS);
			System.out.println("unassignPPS::"+unassignPPS);
			System.out.println("assignPPS Count::"+AssignedInsuranceList.size());
			System.out.println("unassignPPS Count::"+UnAssignedInsuranceList.size());
		break;
		default:
			GenericUtils.Verify("case not found::"+criteria, false);
		break;
	}
	
	for (int i = 0; i < AssignedInsuranceList.size(); i++) 
	{
		String pps=StringUtils.substringBeforeLast(AssignedInsuranceList.get(i), "-");
		payershort=StringUtils.substringBefore(StringUtils.substringBeforeLast(pps, "-"),"-");
		Insurance=StringUtils.substringBetween(pps, "-","-");
		claimtype=StringUtils.substringAfterLast(pps, "-");
		
		insuranceKey=Integer.valueOf(GenericUtils.Retrieve_the_insuranceKey_from_insurance(Insurance));
		payerkey=StringUtils.substringAfterLast(AssignedInsuranceList.get(i), "-");;
		
			oPPS.put("\"payerKey\"", Integer.valueOf(payerkey));
			oPPS.put("\"insuranceDesc\"", "\""+Insurance+"\"");
			oPPS.put("\"claimType\"", "\""+claimtype+"\"");
			oPPS.put("\"insuranceKey\"", Integer.valueOf(insuranceKey));
			oPPS.put("\"payerShort\"", "\""+payershort+"\"");
	
			ppslist.add(oPPS);
	
			String RequestBody = "{\"isAssign\":true,\"clientKey\":"+iClientKey+",\"clientDesc\":\""+clientname+"\",\"userId\":\""+user+"\",\"profileTopics\":[{\"topicKey\":"+iTopicKey+",\"medicalPolicyKey\":"+iMPKey+",\"dps\":["+iDPKey+"],\"pps\":"+ppslist+"}],\"presentationAddition\":{\"profileId\":\""+Serenity.sessionVariableCalled("profileId")+"\",\"profileName\":\""+Serenity.sessionVariableCalled("PresentationName")+"\"},\"presentationDeletion\":null,\"assignedOpp\":1,\"reload\":true}\r\n";
			String sUpdateAssignmentEndPnt= ProjectVariables.sServices.get("updateAssignments").get("EndpointURL");
	
			Response sResponse = oMicroServRestUtils.PostServiceWithSessionID(sUpdateAssignmentEndPnt, RequestBody.replaceAll("=", ":"));
	
	
	
			System.out.println(sResponse.getStatusCode());
	
			if(sResponse.getStatusCode()==200||sResponse.getStatusCode()==201)
			{
				System.out.println(payershort+","+Insurance+" was assigned successfully");
			}
			else
			{
				Assert.assertTrue(payershort+","+Insurance+" was unable assigned,requestBody=>"+RequestBody.replaceAll("=", ":")+",Response=>"+sResponse.getStatusCode(), false);
			}
	
	
			ppslist.clear();
			oPPS.clear();
	
			System.out.println("Request Body===>"+RequestBody.replaceAll("=", ":"));
			System.out.println("profileName===>"+Serenity.sessionVariableCalled("PresentationName"));
			System.out.println("DPKeys===>"+Serenity.sessionVariableCalled("DPkey"));
			//}
	
	
		}
	
	}

}

	//############################################## Capture service method ##############################################################################
	
	public void Capture_the_data_for_the_given_disposition(String Disposition, String InsuranceKeys, String User,
			String DPkeyCriteria,String sSource) {
		List<String> DPKeysList = null;
		String Requestbody = null;
		String capturedcommand = null;
		Serenity.setSessionVariable("Disposition").to(Disposition);

		if (DPkeyCriteria.contains("Same RVA")||DPkeyCriteria.contains("Same eLL")) 
		{
			capturedcommand = "update";
		} 
		else 
		{
			capturedcommand = "insert";
		}
		// To capture the disposition for retrieved Mongo Data through the service
		DPKeysList = Arrays.asList(Serenity.sessionVariableCalled("DPkey").toString().split(","));

		for (int i = 0; i < DPKeysList.size(); i++) 
		{
			ProjectVariables.CapturedDPkey = Long.valueOf(DPKeysList.get(i).trim());
			switch(Disposition)
			{
			case "Present":
				Requestbody = "{\r\n" + "	\"client_key\":" + Serenity.sessionVariableCalled("clientkey") + ",\r\n"
						+ "	\"clientDesc\": \"" + Serenity.sessionVariableCalled("client") + "\",\r\n"
						+ "	\"decision_points\":[\r\n" + "		{\"decision_point_id\":" + DPKeysList.get(i).trim()
						+ ",\r\n" + "		\"payerPolicySet\":[],\r\n" + "		\"opptySource\":\""+sSource+"\",\"payer_ids\":["
						+ Serenity.sessionVariableCalled("Payerkeys") + "],\r\n" + "		\"lob_ids\":["
						+ InsuranceKeys + "],\r\n"
						+ "		\"claim_type_ids\":[\"A\",\"F\",\"P\",\"I\",\"O\",\"S\"]}],\r\n"
						+ "	\"do_not_present_until_next_run\":false,\r\n" + "	\"operation\":\"" + capturedcommand
						+ "\",\r\n" + "	\"userId\":\"" + User + "\",\r\n" + "	\"userName\":\"" + User
						+ "@ihtech.com\",\r\n" + "	\"disposition\":\"" + Disposition + "\",\r\n"
						+ "	\"page_id\":\"Analysis\",\r\n" + "	\"note\":\"Testing by "+User+"\",\r\n"
						+ "	\"reasons\":[\"High savings\",\"Business Reason\",\"Client Requested\"],\r\n"
						+ "	\"priority\":\"High\"\r\n" + "}\r\n";
			break;
			case "Not Reviewed":
				// Requestbody				
				Requestbody = "{\r\n" + "	\"client_key\":" + Serenity.sessionVariableCalled("clientkey") + ",\r\n"
						+ "	\"clientDesc\": \"" + Serenity.sessionVariableCalled("client") + "\",\r\n"
						+ "	\"decision_points\":[\r\n" + "		{\"decision_point_id\":" + DPKeysList.get(i).trim()
						+ ",\r\n" + "		\"payerPolicySet\":[],\r\n" + "		\"opptySource\":\""+sSource+"\",\"payer_ids\":["
						+ Serenity.sessionVariableCalled("Payerkeys") + "],\r\n" + "		\"lob_ids\":["
						+ InsuranceKeys + "],\r\n"
						+ "		\"claim_type_ids\":[\"A\",\"F\",\"P\",\"I\",\"O\",\"S\"]}],\r\n"
						+ "	\"do_not_present_until_next_run\":false,\r\n" + "	\"operation\":\"" + capturedcommand
						+ "\",\r\n" + "	\"userId\":\"" + User + "\",\r\n" + "	\"userName\":\"" + User
						+ "@ihtech.com\",\r\n" + "	\"disposition\":\"" + Disposition + "\",\r\n"
						+ "	\"page_id\":\"Analysis\",\r\n" + "	\"note\":\"Testing by "+User+"\",\r\n" + "	\"reasons\":[],\r\n"
						+ "	\"priority\":\"\"\r\n" + "}\r\n";
			break;
			case "Invalid":
				// Requestbody				
				Requestbody = "{\r\n" + "	\"client_key\":" + Serenity.sessionVariableCalled("clientkey") + ",\r\n"
						+ "	\"clientDesc\": \"" + Serenity.sessionVariableCalled("client") + "\",\r\n"
						+ "	\"decision_points\":[\r\n" + "		{\"decision_point_id\":" + DPKeysList.get(i).trim()
						+ ",\r\n" + "		\"payerPolicySet\":[],\r\n" + "		\"opptySource\":\""+sSource+"\",\"payer_ids\":["
						+ Serenity.sessionVariableCalled("Payerkeys") + "],\r\n" + "		\"lob_ids\":["
						+ InsuranceKeys + "],\r\n"
						+ "		\"claim_type_ids\":[\"A\",\"F\",\"P\",\"I\",\"O\",\"S\"]}],\r\n"
						+ "	\"do_not_present_until_next_run\":false,\r\n" + "	\"operation\":\"" + capturedcommand
						+ "\",\r\n" + "	\"userId\":\"" + User + "\",\r\n" + "	\"userName\":\"" + User
						+ "@ihtech.com\",\r\n" + "	\"disposition\":\"" + Disposition + "\",\r\n"
						+ "	\"page_id\":\"Analysis\",\r\n" + "	\"note\":\"Testing by "+User+"\",\r\n" + "	\"reasons\":[\"Adverse quality score impact\"],\r\n"
						+ "	\"priority\":\"\"\r\n" + "}\r\n";
			break;
			default:
				GenericUtils.Verify("case not found::"+Disposition, false);
			break;
			}
			
			 
			// Method to capture the disposition from CPW through service
			Capture_the_disposition_through_service(Requestbody);
		}

	}
	
	public void Capture_the_disposition_through_service(String Requestbody) {
		MicroServRestUtils oMicroServRestUtils=this.switchToPage(MicroServRestUtils.class);
		System.out.println("Requestbody==>" + Requestbody);

		// Service method to post the data
		Response response = oMicroServRestUtils
				.PostServiceWithSessionID(ProjectVariables.CaptureDispositionServiceUrl, Requestbody);

		System.out.println("ResponseCode ==>" + response.getStatusCode());

		if (response.getStatusCode() == 200 || response.getStatusCode() == 201) {
			System.out.println("Disposition was captured successfully through the service,status code ==>"
					+ response.getStatusCode() + ",ServiceUrl==>" + ProjectVariables.CaptureDispositionServiceUrl
					+ ",RequestBody==>" + Requestbody);
		} else {
			Assert.assertTrue("Disposition was unable to captured through the service,status code ==>"
					+ response.getStatusCode() + ",ServiceUrl==>" + ProjectVariables.CaptureDispositionServiceUrl
					+ ",RequestBody==>" + Requestbody, false);
		}

		// validate the captured data with MongoDB
		MongoDBUtils.Check_the_captured_record_exists_or_not();

		

	}
	
	//get the pps from the given ppsList
	public static void getPPSfromthegiven(List<String> PPSList)
	{
		HashSet<String> insuranceKeys = new HashSet<>();
		HashSet<String> payerKeys = new HashSet<>();
		HashSet<String> Claimtype = new HashSet<>();
		String[] sPPsList = StringUtils.split(PPSList.get(0),";");
		
	
		for (String pps : sPPsList) 
		{
			String payerShort=StringUtils.substringBefore(StringUtils.substringBeforeLast(pps, "-"), "-");
			String insurance=StringUtils.substringBetween(pps, "-", "-");
			String claimType=StringUtils.substringAfterLast(pps, "-");
			payerKeys.add(MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(payerShort, "Payershort"));
			insuranceKeys.add(MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(insurance, "Insurance"));
			Claimtype.add("\""+claimType+"\"");
		}
		
		String sInsuranceKeys=String.join(",", insuranceKeys);
		Serenity.setSessionVariable("Payerkeys").to(String.join(",", payerKeys));
		Serenity.setSessionVariable("Claimtypes").to(Claimtype);
		Serenity.setSessionVariable("Insurancekeys").to(sInsuranceKeys);
	}
	
}
