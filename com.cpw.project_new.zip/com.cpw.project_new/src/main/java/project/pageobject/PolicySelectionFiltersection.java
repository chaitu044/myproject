package project.pageobject;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;

public class PolicySelectionFiltersection extends SeleniumUtils{
	//========================================================Page Locators & Instances ====================================================================================//
	
	OpportunityRunsPage oOpportunityRunsPage;
	AWBPage oAWBPage;
	
	public String policyreleasesummary_chevrons="//span[contains(@class,'mat-select')]/span[contains(text(),'value')]";
	
	public String policyreleasesumamry_savings_dropdown="//span[contains(@class,'mat-option') and contains(text(),'svgtype')]";
	
	public String policyreleasesumamry_savings="//span[contains(text(),'svgtype')]/ancestor::li/strong";
	
	public String Total_Edits_Linesrun="//span[text()='Total Edits vs. Total Lines Run']/..//strong";
	
	public String MedicapolicypolicySumarySavings="//span[text()='svgtype']/ancestor::p";
	
	public String StrongtagWithtext="//strong[text()=value]";
	public String StrongtagContainstext="(//strong[contains(text(),value)])";
	
	//======================================================== Methods ====================================================================================//
	
	public void validate_the_medicalpolicies_in_policyselection_with_moongoDB_for_the_savings(String savings,
			String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) {
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		boolean bstatus=false;
		int Medicalpolicysize=0;
		String UIMedicalpolicy=null;
		String UISavings=null;
		String Exact_DBMPSavings=null;
		String Savingsvalue=null;
		String SavingsLocator=null;
		
		ArrayList<String> Policyselection_Medicalpolicies=new ArrayList<>();
		
		ArrayList<String> Not_DisplayedMedicalpolicylist=new ArrayList<>();
		
		ArrayList<String> NotMatchedSavingsMedicalpolicylist=new ArrayList<>();
		
		if(!savings.equalsIgnoreCase("Sort by DP Opp Savings"))
		{
			//Retrieve Medical Policies and Topics from Mongo DB based on client,release 
			MongoDBUtils.Retrieve_the_medicalpolicy_and_savings_based_on_client_and_release_for_policyselection_Drawer(Payershorts, Insuarances, Claimtypes, LatestClientDecision);
			
		}
	
		Medicalpolicysize=oAWBPage.get_Matching_WebElement_count(oAWBPage.MedicalPolicies_In_PolicySelection);
		
		for (int i = 1; i <=Medicalpolicysize; i++) 
		{
			
			bstatus=oAWBPage.is_WebElement_Displayed(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]");
			
			SavingsLocator=StringUtils.replace(oAWBPage.MedicalPolicies_In_PolicySelection, "not", "")+"["+i+"]";
			UIMedicalpolicy=oAWBPage.get_TextFrom_Locator(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]");
			UISavings=oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(SavingsLocator)).trim();
			System.out.println(i+"."+"UI Medical Policy ==>"+UIMedicalpolicy);
			System.out.println(i+"."+"UI savings ==>"+UISavings);
			//Policyselection_Medicalpolicies.add(UIMedicalpolicy+";"+UISavings);
			Policyselection_Medicalpolicies.add(UIMedicalpolicy);
		}
		
		System.out.println("Policyselection Medical Policy list ==>"+Policyselection_Medicalpolicies);
		System.out.println("Policyselection Medical Policy size ==>"+Policyselection_Medicalpolicies.size());
	
	//###############################################################################################################		
		int z=1;
		for (String UI_MP : Policyselection_Medicalpolicies) {
			String Exact_UIMP=StringUtils.substringBefore(UI_MP, ";");
			String Exact_UIMPsavings=StringUtils.substringAfter(UI_MP, ";");
			
			if(!ProjectVariables.Medicalpolicy_PolicySelectiondrawer.contains(Exact_UIMP))
			{
				System.out.println(z+"."+Exact_UIMP);
				Not_DisplayedMedicalpolicylist.add(Exact_UIMP);
				z=z+1;
			}


		}
		
		/*for (String DBMP : ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer) {
			//String Exact_DBmedicalpolicy=StringUtils.substringBefore(DBMP, ";Raw");
			
			if(!Policyselection_Medicalpolicies.contains(DBMP.trim()))
			{
				System.out.println(z+"."+DBMP);
				Not_DisplayedMedicalpolicylist.add(DBMP);
				z=z+1;
			}


		}
		*/
		
		
		System.out.println("Not IN DB::"+Not_DisplayedMedicalpolicylist);
		System.out.println("Not IN DB Size::"+Not_DisplayedMedicalpolicylist.size());
		
		
		
//############################################################################################################################3		
		/*if(!savings.equalsIgnoreCase("Sort by DP Opp Savings"))
		{
			for (String DB_medicalpolicy : ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer) {

				String Exact_DBmedicalpolicy=StringUtils.substringBefore(DB_medicalpolicy, ";Raw");
				switch(savings)
				{
				case "Sort by Raw Opp Savings":
					Exact_DBMPSavings=StringUtils.substringBetween(DB_medicalpolicy, "Raw-",";Agg");
					
				break;
				case "Sort by Agg Opp Savings":
					Exact_DBMPSavings=StringUtils.substringBetween(DB_medicalpolicy, "Agg-",";Con");
					
				break;
				case "Sort by Con Opp Savings":
					Exact_DBMPSavings=StringUtils.substringAfter(DB_medicalpolicy, "Con-");
					
				break;
				case "Sort by DP Opp Savings":
					Exact_DBMPSavings=StringUtils.substringBetween(DB_medicalpolicy, "Raw-",";Agg");
					
				break;
				default:
					Assert.assertTrue("Given selection was not found ===>"+savings, false);
					
				break;
				
				
				}
				
				 
				
				System.out.println("DBMedicalpolicy ==>"+Exact_DBmedicalpolicy);

				for (String UI_MP : Policyselection_Medicalpolicies) {
					String Exact_UIMP=StringUtils.substringBefore(UI_MP, ";");
					String Exact_UIMPsavings=StringUtils.substringAfter(UI_MP, ";");

					if(!Exact_UIMP.equalsIgnoreCase(Exact_DBmedicalpolicy.trim()))
					{
						bstatus=false;
					}
					else
					{
						bstatus=true;
						if(!Exact_UIMPsavings.equalsIgnoreCase(Exact_DBMPSavings))
						{
							NotMatchedSavingsMedicalpolicylist.add(Exact_UIMP);
						}
						
						break;
					}


				}

				if(!bstatus)
				{
					Not_DisplayedMedicalpolicylist.add(Exact_DBmedicalpolicy);	
				}


			}

			System.out.println("Savings are not matching with Db for the Medicalpolicies ==>"+NotMatchedSavingsMedicalpolicylist);
			
			Assert.assertTrue("Some MedicalPolicies are not displaying in Policy Selection Drawer from Mongo DB as expected,Not available MedicalPolicies count ==>"+Not_DisplayedMedicalpolicylist.size()+",Not available MedicalPolicies are ==>"+Not_DisplayedMedicalpolicylist+",for client key==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",UI MedicalPolicy count ==>"+Policyselection_Medicalpolicies.size()+",DB MedicalPolicy count ==>"+ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.size(),Not_DisplayedMedicalpolicylist.size()==0);
			
			if(Not_DisplayedMedicalpolicylist.size()==0)
			{
				Assert.assertTrue("Some MedicalPolicie savings are not matching with DB in Policy Selection Drawer from Mongo DB as expected,Not matching MedicalPolicies count ==>"+NotMatchedSavingsMedicalpolicylist.size()+",Not matching MedicalPolicies are ==>"+NotMatchedSavingsMedicalpolicylist+",for client key==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",UI MedicalPolicy count ==>"+Policyselection_Medicalpolicies.size()+",DB MedicalPolicy count ==>"+ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.size(),NotMatchedSavingsMedicalpolicylist.size()==0);
			}
		}
		else
		{
			for (String UI_MP : Policyselection_Medicalpolicies) 
			{
				String Exact_UIMP=StringUtils.substringBefore(UI_MP, ";");
				String Exact_UIMPsavings=StringUtils.substringAfter(UI_MP, ";");
				
				//To Get DPRawsavings for the given MP
				String DBsavings=MongoDBUtils.GetTheDPRawsavingsInFilterPanel(Exact_UIMP, Serenity.sessionVariableCalled("clientkey"),"MP");
				
				GenericUtils.Verify("'Sort by DP Opp savings' for the MP=>"+Exact_UIMP+",Expected=>"+DBsavings+",Actual=>"+Exact_UIMPsavings, Exact_UIMPsavings.equalsIgnoreCase(DBsavings));
			}
		}*/
		
		

		

		
		
	}

	public void SelectthePolicySelectionDrawerandApplyAllFiltersforSavings(String savings) throws InterruptedException {
		String sValue=null;
		//Select the policy selection drawer and apply all checkboxes
		oOpportunityRunsPage.SelectthePolicySelectionDrawerandApplyAllFilters();
		
		AWBPage.defaultWait(ProjectVariables.TImeout_1_Seconds);
		
		switch(savings)
		{
		case "Sort by Raw Opp Savings":
			sValue="rawOppSavings";
			break;
		case "Sort by Agg Opp Savings":
			sValue="aggOppSavings";
			break;
		
		case "Sort by Con Opp Savings":
			sValue="conOppSavings";
			break;
		
		case "Sort by DP Opp Savings":
			sValue="dpSavings";
			break;
		default:
			Assert.assertTrue("Given selection was not found==>"+savings, false);
			break;
		}
		
		
		Assert.assertTrue("Unable to click the '"+savings+"' in the 'sort by savings dropdown' of policy selection drawer", oAWBPage.SelectDropDownByValue("//option[contains(text(),'Sort by')]/ancestor::select",sValue));
		
		AWBPage.defaultWait(ProjectVariables.TImeout_1_Seconds);
		
		
		/*if(savings.equalsIgnoreCase("Sort by DP Opp Savings"))
		{
			savings="Sort by Raw Opp Savings";
		}*/
		
		Assert.assertTrue("'"+StringUtils.substringAfter(savings, "Sort by ")+"' coloumn name is not displayed in the header of policy selection drawer grid,after selecting that in the dropdown", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", StringUtils.substringAfter(savings, "Sort by "))));
		defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
		
		
	}

	public void validate_the_topics_in_policyselection_with_moongoDB_for_the_savings(String savings,
			String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) {
		GenericUtils oGenericUtils=this.switchToPage(GenericUtils.class);
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		boolean bstatus=false;
		
		int Topicsize=0;
		String UITopic=null;
		String UISavings=null;
		String Exact_DBTopicSavings=null;
		
		ArrayList<String> Policyselection_Topics=new ArrayList<>();
		
		ArrayList<String> Not_DisplayedTopicslist=new ArrayList<>();
		
		ArrayList<String> NotMatchedSavingsTopicslist=new ArrayList<>();
		
		//Retrieve Medical Policies and Topics from Mongo DB based on client,release 
		MongoDBUtils.Retrieve_the_medicalpolicy_and_savings_based_on_client_and_release_for_policyselection_Drawer(
				Payershorts, Insuarances, Claimtypes, LatestClientDecision);
		
		
		//ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.add("Diagnosis Procedure Policy;Raw-9681081");
		
		
		System.out.println("DB_Medical policies list ==>"+ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer);
		System.out.println("DB_Medical policies size ==>"+ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.size());
		
		
		for (String DB_medicalpolicy : ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer) {

			String Exact_DBmedicalpolicy=StringUtils.substringBefore(DB_medicalpolicy, ";Raw");
			
			Assert.assertTrue("Unable to search the DBMedicalpolicy in the search box of policy selection drawer", oAWBPage.Enter_given_Text_Element(oOpportunityRunsPage.sSearchFeild_MP, Exact_DBmedicalpolicy));
			
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
			
			Assert.assertTrue("Unable to click the search icon in the policy selection drawer in AWB Page",oAWBPage.clickGivenXpath(oOpportunityRunsPage.sSearchIcon));
			
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("Medicalpolicy '"+Exact_DBmedicalpolicy+"' is not displayed in the filter section of policyselection drawer,after searching", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", Exact_DBmedicalpolicy)));
			
			//Assert.assertTrue("Unable to click the arrow down icon for the searched medicalpolicy '"+Exact_DBmedicalpolicy+"' in the policy selection drawer of AWB Page",oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_with_text, "value", Exact_DBmedicalpolicy)+"/.."+StringUtils.replace(oAWBPage.Span_contains_class, "value", "arrow-right")));
			
			//String arrowiconsstatus=Get_Value_By_given_attribute("aria-expanded", StringUtils.replace(oAWBPage.Div_contains_text, "value", Exact_DBmedicalpolicy)+"/ancestor::td");
			
			///if(arrowiconsstatus.equalsIgnoreCase("false"))
			{
			//	Assert.assertTrue("Unable to click the arrow down icon for the searched medicalpolicy '"+Exact_DBmedicalpolicy+"' in the policy selection drawer of AWB Page",oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Div_contains_text, "value", Exact_DBmedicalpolicy)+"/ancestor::td//a"));
			}
			
			if(!savings.equalsIgnoreCase("Sort by DP Opp Savings"))
			{
			//Retrieve Medical Policies and Topics from Mongo DB based on client,release 
			MongoDBUtils.Retrieve_the_Topics_and_savings_based_on_client_release_and_medicalpolicy_for_policyselection_Drawer(
					Exact_DBmedicalpolicy,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
			}
		
		Topicsize=oAWBPage.get_Matching_WebElement_count(oAWBPage.Topics_In_PolicySelection);
		
		for (int i = 1; i <=Topicsize; i++) {
			
			bstatus=oAWBPage.is_WebElement_Displayed(oAWBPage.Topics_In_PolicySelection+"["+i+"]");
			
			//if(bstatus)
			{
				UITopic=oAWBPage.get_TextFrom_Locator(oAWBPage.Topics_In_PolicySelection+"["+i+"]").trim();
				
				{
					UISavings=oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(oAWBPage.Topicsavings_In_PolicySelection+"["+i+"]"));
				}
				
				
				System.out.println(i+"."+"UI Topic ==>"+UITopic);
				System.out.println(i+"."+"UI savings ==>"+UISavings);
				Policyselection_Topics.add(UITopic+";"+UISavings);
			
			}
			
			
			
		}
		
		System.out.println("Policyselection Topic list ==>"+Policyselection_Topics);
		System.out.println("Policyselection Topic size ==>"+Policyselection_Topics.size());
		
		if(!savings.equalsIgnoreCase("Sort by DP Opp Savings"))
			{
			for (String DB_UITopic : ProjectVariables.Topicwithsavings_PolicySelectiondrawer) {
	
				String Exact_DBTopic=StringUtils.substringBefore(DB_UITopic, ";Raw");
				switch(savings)
				{
				case "Sort by Raw Opp Savings":
					Exact_DBTopicSavings=StringUtils.substringBetween(DB_UITopic, "Raw-",";Agg");
					
				break;
				case "Sort by Agg Opp Savings":
					Exact_DBTopicSavings=StringUtils.substringBetween(DB_UITopic, "Agg-",";Con");
					
				break;
				case "Sort by Con Opp Savings":
					Exact_DBTopicSavings=StringUtils.substringAfter(DB_UITopic, "Con-");
					
				break;
				case "Sort by DP Opp Savings":
					Exact_DBTopicSavings=StringUtils.substringBetween(DB_UITopic, "Raw-",";Agg");
					
				break;
				default:
					Assert.assertTrue("Given selection was not found ===>"+savings, false);
					
				break;
				
				
				}
				
				 
				
				System.out.println("DBTopic ==>"+Exact_DBTopic);
	
				for (String UI_Topic : Policyselection_Topics) {
					String Exact_UITopic=StringUtils.substringBefore(UI_Topic, ";");
					String Exact_UITopicsavings=StringUtils.substringAfter(UI_Topic, ";");
	
					if(!Exact_UITopic.equalsIgnoreCase(Exact_DBTopic.trim()))
					{
						bstatus=false;
					}
					else
					{
						bstatus=true;
						if(!Exact_UITopicsavings.equalsIgnoreCase(Exact_DBTopicSavings))
						{
							NotMatchedSavingsTopicslist.add(Exact_DBTopic);
						}
						
						break;
					}
	
	
				}
	
				if(!bstatus)
				{
					Not_DisplayedTopicslist.add(Exact_DBTopic);	
				}
	
	
			}
	
			Assert.assertTrue("Some Topics are not displaying in Policy Selection Drawer from Mongo DB as expected,Not available topics count ==>"+Not_DisplayedTopicslist.size()+",Not available Topics are ==>"+Not_DisplayedTopicslist+",for client key==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",Medical policy==>"+DB_medicalpolicy+",UI Topic count ==>"+Policyselection_Topics.size()+",DB Topics count ==>"+ProjectVariables.Topicwithsavings_PolicySelectiondrawer.size()+",Medicalpolicy ==>"+DB_medicalpolicy,Not_DisplayedTopicslist.size()==0);
			
			if(Not_DisplayedTopicslist.size()==0)
			{
				Assert.assertTrue("Some Topics savings are not matching with DB in Policy Selection Drawer from Mongo DB as expected,Not matching topics count ==>"+NotMatchedSavingsTopicslist.size()+",Not matching topics are ==>"+NotMatchedSavingsTopicslist+",for client key==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",UI Topics count ==>"+Policyselection_Topics.size()+",DB Topics count ==>"+ProjectVariables.Topicwithsavings_PolicySelectiondrawer.size()+",MedicalPolicy ==>"+DB_medicalpolicy,NotMatchedSavingsTopicslist.size()==0);
			}
		}
	else
	{
		for (String UI_Topic : Policyselection_Topics) 
		{
			String Exact_UITopic=StringUtils.substringBefore(UI_Topic, ";");
			String Exact_UITopicsavings=StringUtils.substringAfter(UI_Topic, ";");

			//To Get DPRawsavings for the given MP
			String DBsavings=MongoDBUtils.GetTheDPRawsavingsInFilterPanel(Exact_UITopic, Serenity.sessionVariableCalled("clientkey"),"Topic");
			
			GenericUtils.Verify("'Sort by DP Opp savings' for the Topic=>"+Exact_UITopic+",Expected=>"+DBsavings+",Actual=>"+Exact_UITopicsavings, Exact_UITopicsavings.equalsIgnoreCase(DBsavings));
		}
	}
		break;
		
		}
		
		
	}

	public void SelelctthegivenfilterscheckboxesInPolicySelection(String checkboxname,List<String> checkboxeslist,String checkboxoperation,String applyfilters) {
		OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
		
		for (int i = 0; i < checkboxeslist.size(); i++) {
			Assert.assertTrue(""+checkboxname+" '"+checkboxeslist.get(i)+"' filter checkbox is unable to "+checkboxoperation+" in the policysection filters of AWB Page", oOpportunityRunsPage.ApplyFilters(checkboxname, checkboxeslist.get(i), checkboxoperation, ""));
		}
		
		if(!applyfilters.isEmpty())
		{
			Assert.assertTrue("Unable to click the 'Applyfilters' button in the policy selection drawer filter section", clickGivenXpath(applyfilters));
		}
		
	}

	public void validate_the_sorting_funtionality(ArrayList<String> savingslist,String Order,String colname) {
		
		System.out.println("sorting list size ==>"+savingslist.size());
		
		for (int k = 0; k < (savingslist.size()- 1); k++) {

			int compare = Double.valueOf(savingslist.get(k).trim()).compareTo(Double.valueOf(savingslist.get(k + 1).trim()));

			System.out.println(savingslist.get(k).trim() + "," + savingslist.get(k + 1).trim());

			System.out.println(compare);

			
				if (Order.equalsIgnoreCase("Ascending order") || Order.equalsIgnoreCase("Sort Ascending")) {
					if (compare == 0 || compare < 0) {
						System.out.println( colname + " column data is displayed successfully in " + Order + ",for the data:"+savingslist.get(k).trim() + "," + savingslist.get(k + 1).trim());
					} else {
						Assert.assertTrue(colname + " column data is not displayed in " + Order + ",for the data:"+savingslist.get(k).trim() + "," + savingslist.get(k + 1).trim(), false);
					}
				} else {
					if (compare < 0) {
						Assert.assertTrue(colname + " column data is not displayed in " + Order + ",for the data:"+savingslist.get(k).trim() + "," + savingslist.get(k + 1).trim(), false);

					} else {
						System.out.println(colname + " column data is displayed succesfully in " + Order + ",for the data:"+savingslist.get(k).trim() + "," + savingslist.get(k + 1).trim());
					}
				}

			
		}
		
	}

	public void validate_the_policy_release_summary_data_with_mongo_Db(String Pagename)
	{
		
		//Policy release summary data
		String DPDispositions_to_present=get_TextFrom_Locator(StringUtils.replace(oAWBPage.Span_with_text, "value", "DP Dispositions to Present")+"/..//strong");
		String TotalEdits=StringUtils.substringBefore(get_TextFrom_Locator(Total_Edits_Linesrun), "/").replaceAll(",", "");
		String TotalLinesRun=StringUtils.substringAfter(get_TextFrom_Locator(Total_Edits_Linesrun), "/").replaceAll(",", "");
		
		//mongo Db method to retrieve the policy release summary savings data
		MongoDBUtils.Get_the_policyreleasesummary_based_on_client_release_and_savingsstatus(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "Opportunity");
		
		
		//validate the policy release summary savings data with mongo DB
		Assert.assertTrue("'DP Dispositions to Present' Dpkey count of policy release summary data was not matching with MongoDB,Expected ==>"+ProjectVariables.DB_DPKey+",Actual ==>"+DPDispositions_to_present, DPDispositions_to_present.equalsIgnoreCase(ProjectVariables.DB_DPKey));
		
		
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Present","Raw Savings",ProjectVariables.RawSavings.get(0));
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Present","Agg Savings",ProjectVariables.AggSavings.get(0));
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Present","Con Savings",ProjectVariables.ConSavings.get(0));
		
		
		//mongo Db method to retrieve the policy release summary savings data
		MongoDBUtils.Get_the_policyreleasesummary_based_on_client_release_and_savingsstatus(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "Production");
				
		//validate the policy release summary savings data with mongo DB
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Production","Raw Savings",ProjectVariables.RawSavings.get(0));
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Production","Agg Savings",ProjectVariables.AggSavings.get(0));
		verify_the_policy_release_summary_savings_data_with_mongo_Db_for("Production","Con Savings",ProjectVariables.ConSavings.get(0));
				
		//mongo Db method to retrieve the policy release summary savings data
		MongoDBUtils.Get_the_policyreleasesummary_based_on_client_release_and_savingsstatus(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), "Total Edits");
				
		
		Assert.assertTrue("'Total Edits' of policy release summary data was not matching with MongoDB,Expected ==>"+ProjectVariables.Edits+",Actual ==>"+TotalEdits, TotalEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));
		
		//Have to include Total Lines run validation also
		
	}

	public void verify_the_policy_release_summary_savings_data_with_mongo_Db_for(String savingstype,String savings,Long Expectedsavings) {

		//Select the savings type dropdown and the given savaings data
		Click_the_savings_dropdown_and_select_the_savings_data(savingstype,savings);
		
		String savingsdata=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(policyreleasesumamry_savings, "svgtype", savingstype+" "+savings)), "$").replaceAll(",", "");
		
		Assert.assertTrue("'"+savings+"' of policy release summary data was not matching with MongoDB,Expected ==>"+Expectedsavings+",Actual ==>"+savingsdata, savingsdata.equalsIgnoreCase(String.valueOf(Expectedsavings)));
		
		
	}

	public void Click_the_savings_dropdown_and_select_the_savings_data(String savingstype, String savings) {
		
		String savingstypeLocator=StringUtils.replace(policyreleasesumamry_savings_dropdown, "svgtype", savings);

		Assert.assertTrue("Unable to click the '"+savingstype+"' savings chevron icon in the policy release summary section", oAWBPage.clickGivenXpath(StringUtils.replace(policyreleasesummary_chevrons, "value",savingstype)));
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		Assert.assertTrue("Unable to click the '"+savings+"' savings in the dropdown of policy release summary section", oAWBPage.clickGivenXpath(savingstypeLocator));
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		
	}

	public String Capture_the_given_policyreleasesummary_savings_data(String savingstype, String savings) {
		//Select the savings type dropdown and the given savaings data
				Click_the_savings_dropdown_and_select_the_savings_data(savingstype,savings);
				
				String Savingsdata=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(policyreleasesumamry_savings, "svgtype", savingstype+" "+savings)), "$").replaceAll(",", "");
				
				return Savingsdata;
						
		
	}

	public void validate_the_policyreleasesummary_savings_after_capturing_disposition() throws InterruptedException {
		ArrayList<String> sGetDPItems=new ArrayList<>();
		
		//selecting the topic from the AWB grid
		sGetDPItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage("TOPIC_DPKEY_CHECKBOX",1);
		System.out.println("DPKey ===>"+sGetDPItems);
			
		String savingslocator=StringUtils.replace(oAWBPage.DPsavings_in_oppgrid, "value", sGetDPItems.get(0).trim());

		String UIRawsavings=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(savingslocator+"[3]"),"$").replaceAll(",", "");
		String UIAggsavings=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(savingslocator+"[4]"),"$").replaceAll(",", "");
		String UIConsavings=StringUtils.substringAfter(oAWBPage.get_TextFrom_Locator(savingslocator+"[5]"),"$").replaceAll(",", "");
				
				
		//To Initialize the disposition fields
		oAWBPage.Intialaize_the_Dispositions_fields_to_post("Present");
				
		//Capturing the disposition operation for the given client,release and disposition
		oAWBPage.Perform_the_capture_disposition_operation("Present",ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage","");
				
		System.out.println("Successsfully captured the Disposition 'Present' for the selected DPkey ==>"+sGetDPItems);
			
		
		//Capturing the policy release summary savings data from UI,after capturing the disposition 
		String DPDispositions_to_present=oAWBPage.get_TextFrom_Locator(StringUtils.replace(oAWBPage.Span_with_text, "value", "DP Dispositions to Present")+"/ancestor::li/strong");
		String PresentRawsavings=Capture_the_given_policyreleasesummary_savings_data("Present","Raw Savings");
		String PresentAggsavings=Capture_the_given_policyreleasesummary_savings_data("Present","Agg Savings");
		String PresentConsavings=Capture_the_given_policyreleasesummary_savings_data("Present","Con Savings");
				
		Long Expected_DPkeys=Long.valueOf(Serenity.sessionVariableCalled("Present DPKeys").toString())+1;
		Long Expected_PresentRawsavings=Long.valueOf(UIRawsavings)+Long.valueOf(Serenity.sessionVariableCalled("Present Raw savings").toString());
		Long Expected_PresentAggsavings=Long.valueOf(UIAggsavings)+Long.valueOf(Serenity.sessionVariableCalled("Present Agg savings").toString());
		Long Expected_PresentConsavings=Long.valueOf(UIConsavings)+Long.valueOf(Serenity.sessionVariableCalled("Present Con savings").toString());
		
		Assert.assertTrue("'DP Dispositions to Present' count  of policy release summary data was not updated,after capturing the disposition 'Present',Expected ==>"+Expected_DPkeys+",Actual ==>"+DPDispositions_to_present, DPDispositions_to_present.equalsIgnoreCase(String.valueOf(Expected_DPkeys)));
		
		Assert.assertTrue("'Present Raw savings' of policy release summary data was not updated,after capturing the disposition 'Present',Expected ==>"+Expected_PresentRawsavings+",Actual ==>"+PresentRawsavings, PresentRawsavings.equalsIgnoreCase(String.valueOf(Expected_PresentRawsavings)));
				
		Assert.assertTrue("'Present Agg savings' of policy release summary data was not updated,after capturing the disposition 'Present',Expected ==>"+Expected_PresentAggsavings+",Actual ==>"+PresentAggsavings, PresentAggsavings.equalsIgnoreCase(String.valueOf(Expected_PresentAggsavings)));
		
		Assert.assertTrue("'Present Con savings' of policy release summary data was not updated,after capturing the disposition 'Present',Expected ==>"+Expected_PresentConsavings+",Actual ==>"+PresentConsavings, PresentConsavings.equalsIgnoreCase(String.valueOf(Expected_PresentConsavings)));
	}

	public void validate_the_medical_policy_release_summary_data_with_mongo_Db(String pagename) {
		String RawOppsavings=null;
		String AggOppsavings=null;
		String RawProdsavings=null;
		
		//Retrieve the exact UI savings from DB
		RawOppsavings=StringUtils.substringBefore(Retrieve_the_exact_savings_from_UI(StringUtils.replace(MedicapolicypolicySumarySavings, "svgtype", "Filtered Raw Opportunity Savings")), "Filtered").trim();
		AggOppsavings=StringUtils.substringBefore(Retrieve_the_exact_savings_from_UI(StringUtils.replace(MedicapolicypolicySumarySavings, "svgtype", "Filtered Aggressive Opportunity Savings")), "Filtered").trim();

		switch(pagename)
		{
		case "AWB":
			
			RawProdsavings=StringUtils.substringBefore(Retrieve_the_exact_savings_from_UI(StringUtils.replace(MedicapolicypolicySumarySavings, "svgtype", "Raw Production Savings")),"Raw Production Savings").trim();
			
			//DB Method to retrieve Raw opportunity and aggressive savings for medicalpolicy summary
			MongoDBUtils.Get_the_MedicalPolicySummary_based_on_client_release_and_savingsstatus(ProjectVariables.DB_Medicalpolicylist.get(0), "Production", "AWB");

			System.out.println(RawProdsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
			
			Assert.assertTrue("Raw production savings is not maching with DB under medicalpolicy summary section of AWB page,for the medicalpolicy =>"+ProjectVariables.DB_Medicalpolicylist.get(0)+",Expected ==>"+ProjectVariables.RawSavings.get(0)+",Actual ==>"+RawProdsavings, RawProdsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));

			
			//DB Method to retrieve Raw opportunity and aggressive savings for medicalpolicy summary
			MongoDBUtils.Get_the_MedicalPolicySummary_based_on_client_release_and_savingsstatus(ProjectVariables.DB_Medicalpolicylist.get(0), "Opportunity", "AWB");

			Assert.assertTrue("Filtered Raw opportunity savings is not maching with DB under medicalpolicy summary section of AWB page,for the medicalpolicy =>"+ProjectVariables.DB_Medicalpolicylist.get(0)+",Expected ==>"+ProjectVariables.RawSavings.get(0)+",Actual ==>"+RawOppsavings, RawOppsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
			
			Assert.assertTrue("Filtered Agg opportunity savings is not maching with DB under medicalpolicy summary section of AWB page,for the medicalpolicy =>"+ProjectVariables.DB_Medicalpolicylist.get(0)+",Expected ==>"+ProjectVariables.AggSavings.get(0)+",Actual ==>"+AggOppsavings, AggOppsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));
			
			System.out.println("Medical policy summary data was matched with DB in AWB page");
			
		break;
		case "Review Worked Opportunity":
			
			defaultWait(ProjectVariables.TImeout_5_Seconds);
			
			//DB Method to retrieve Raw opportunity and aggressive savings for medicalpolicy summary
			MongoDBUtils.Get_the_MedicalPolicySummary_based_on_client_release_and_savingsstatus("", "Opportunity", "RWO");

			Assert.assertTrue("Filtered Raw opportunity savings is not maching with DB under Detail summary section of RWO page,Expected ==>"+ProjectVariables.RawSavings.get(0)+",Actual ==>"+RawOppsavings, RawOppsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
			
			Assert.assertTrue("Filtered Agg opportunity savings is not maching with DB under Detail summary section of RWO page,Expected ==>"+ProjectVariables.AggSavings.get(0)+",Actual ==>"+AggOppsavings, AggOppsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));
			
			System.out.println("Detail summary data was matched with DB in Review Worked Opportunity page");
			
		break;
	
		default:
		Assert.assertTrue("Given selection was not found ==>"+pagename, false);
		break;
		}
		
	}

	public String Retrieve_the_exact_savings_from_UI(String savingslocator) {
		
		String Savings=get_TextFrom_Locator(savingslocator);
		
		if(Savings.substring(0, 1).equalsIgnoreCase("-")){
			
			return "-"+StringUtils.substringAfter(Savings,"$").replaceAll(",", "");
			
		}
		else
		{
			return StringUtils.substringAfter(Savings,"$").replaceAll(",", "");
		}
		
		
	}

	public void validate_the_medicalpolicyreleasesummary_savings_after_capturing_disposition(String disposition) throws InterruptedException {
		
		ArrayList<String> sGetTopics=new ArrayList<>();
		
		//selecting the topic from the AWB grid
		sGetTopics = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage("TOPIC",1);
		System.out.println("Topics ===>"+sGetTopics);
			
		String savingslocator=StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", sGetTopics.get(0).trim());

		String UIRawsavings=Retrieve_the_exact_savings_from_UI(savingslocator+"[3]").trim();
		String UIAggsavings=Retrieve_the_exact_savings_from_UI(savingslocator+"[4]").trim();
		
				
				
		//To Initialize the disposition fields
		oAWBPage.Intialaize_the_Dispositions_fields_to_post(disposition);
				
		//Capturing the disposition operation for the given client,release and disposition
		oAWBPage.Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage","");
				
		System.out.println("Successsfully captured the Disposition '"+disposition+"' for the selected Topic ==>"+sGetTopics);
			
		
		//Capturing the Medical policy release summary savings data from UI,after capturing the disposition
		String FilteredRawsavings=StringUtils.substringBefore(Retrieve_the_exact_savings_from_UI(StringUtils.replace(MedicapolicypolicySumarySavings, "svgtype", "Filtered Raw Opportunity Savings")), "Filtered Raw Opportunity Savings").trim();
		String FilteredAggsavings=StringUtils.substringBefore(Retrieve_the_exact_savings_from_UI(StringUtils.replace(MedicapolicypolicySumarySavings, "svgtype", "Filtered Aggressive Opportunity Savings")),"Filtered Aggressive Opportunity Savings").trim();

		
		Long Expected_FilteredRawsavings=Long.valueOf(Serenity.sessionVariableCalled("Filtered Raw savings").toString())-Long.valueOf(UIRawsavings);
		Long Expected_FilteredAggsavings=Long.valueOf(Serenity.sessionVariableCalled("Filtered Agg savings").toString())-Long.valueOf(UIAggsavings);
		
		Assert.assertTrue("'Filtered Raw savings' of medical policy release summary data was not updated in AWB page,after capturing the disposition '"+disposition+"',Expected ==>"+Expected_FilteredRawsavings+",Actual ==>"+FilteredRawsavings, FilteredRawsavings.equalsIgnoreCase(String.valueOf(Expected_FilteredRawsavings)));
				
		Assert.assertTrue("'Filtered Agg savings' of policy release summary data was not updated in AWB page,after capturing the disposition 'Present',Expected ==>"+Expected_FilteredAggsavings+",Actual ==>"+FilteredAggsavings, FilteredAggsavings.equalsIgnoreCase(String.valueOf(Expected_FilteredAggsavings)));
		
		
	
		
	}

	//########################################### PI-25 Methods ###############################################################//
	
	public void userSelcetsMultipleMPSTopics(String MPTopicLocator,int MPTopicnumber) 
	{
		GenericUtils oGenericUtils=this.switchToPage(GenericUtils.class);
		
		if(MPTopicLocator.equalsIgnoreCase("AllMPs")||MPTopicLocator.equalsIgnoreCase("AllTopics"))
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Div_contains_class, "value", "selectall-reset-buttons")+"/button[1]");
			AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
			
		}
		else
		{
			for (int i = 1; i <= MPTopicnumber; i++) 
			{
				clickGivenXpath(MPTopicLocator+"["+i+"]");	
			}
		}
		
		System.out.println(is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
		
		System.out.println(get_Matching_WebElement_count(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
		
		oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid"));
		
		//Click on 'Apply to Opportunity Grid'
		//Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
		//Loading POPUP	
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 10);
		
		GenericUtils.Verify("Filter Panel should be closed,after clicking on Applyfiilters", !is_WebElement_Displayed("//h3[.='Choose a Medical Policy/Topic']"));
		
	}

	public void validateTheRetentionfunctionalityinFilterPanel(String MPTopicLocator,String datatype, int MPTopicCount) 
	{
		if(MPTopicCount==0)
		{
			Assert.assertTrue("'"+datatype+"' were not selected as retain fucntionality in filter Panel", false);
		}
		
		
		for (int i = 1; i <= MPTopicCount; i++) 
		{
			GenericUtils.Verify(""+datatype+" '"+i+"' should be selected as per retention functionality", is_WebElement_Displayed(StringUtils.replace(MPTopicLocator, "count", String.valueOf(i))));	
		}
		
		
	}
	
	public void SelectTheDisplayMPTopicToggleinFilterPanel(String dataCriteria)
	{
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		boolean bstatus=false;
		String dataType=null;
		switch(dataCriteria)
		{
		case "MP":
			bstatus=is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Display "+dataCriteria+""));
			if(!bstatus)
			{
				dataType="Topic";
			}
		break;
		case "Topic":
			bstatus=is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Display "+dataCriteria+""));
			if(!bstatus)
			{
				dataType="MP";
			}
		break;
		default:
			Assert.assertTrue("Case not found==>"+dataCriteria,false);
		break;
		}
		
		
		if(!bstatus)
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Display "+dataType+""));
			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 10);
			DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 10);
			GenericUtils.Verify("'Display "+dataCriteria+"' Toggle selection should be displayed in filterpanel", oAWBPage.is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Display "+dataCriteria+"")));
				
		}
		else
		{
			GenericUtils.Verify("'Display "+dataCriteria+"' Toggle selection is displayed in filterpanel", true);
		}
		
	}

	public void validateTheNoEditsTopicsinFilterpanel() throws ParseException 
	{
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		ArrayList<String> TopicswithDPs=new ArrayList<>();
		List<String> emptyList=new ArrayList<>();
		boolean bstatus=false;
		String sLocator=null;
		//To retrieve the topics with no edits from DB 
		TopicswithDPs.addAll(MongoDBUtils.getNoEditsTopicsandDPsinAWB("topicDesc",emptyList,emptyList,emptyList,emptyList));
		
		for (int i = 0; i < TopicswithDPs.size(); i++) 
		{
			String sTopic=StringUtils.substringBefore(TopicswithDPs.get(i),"::").trim();
			bstatus=is_WebElement_Displayed(StringUtils.replace(StrongtagWithtext, "value", "\""+sTopic+"\""));
			//System.out.println(StringUtils.replace(StrongtagWithtext, "value", "\""+sTopic+"\""));
			sLocator=StrongtagWithtext;
			if(!bstatus)
			{
				bstatus=is_WebElement_Displayed(StringUtils.replace(StrongtagContainstext, "value", "\""+sTopic+"\""));
				sLocator=StrongtagContainstext;
				//System.out.println(StringUtils.replace(StrongtagContainstext, "value", "\""+sTopic+"\""));
			}
			
			GenericUtils.Verify(i+1+".Topic has no edits::'"+sTopic+"' should be displayed in filterPanel as DB,Topicssize::"+TopicswithDPs.size(), bstatus);
			
			String srawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(sLocator, "value", "\""+sTopic+"\"")+"/../..//div[contains(@class,'raw')]"));
			GenericUtils.Verify("UIrawsavings::"+srawsavings+",DBRawsavings::0,Topic::'"+sTopic+"' in filterpanel", srawsavings.equalsIgnoreCase("0"));
		}
		
		
	}
	
	public void verifyMPsinFilterpanelforgivenPPS(
			String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) throws Exception {
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		int Medicalpolicysize=0;
		String UIMedicalpolicy=null;
		String UISavings=null;
		String Exact_DBMPSavings=null;
		String Savingsvalue=null;
		String SavingsLocator=null;
		ArrayList<String> Policyselection_Medicalpolicies=new ArrayList<>();
		ArrayList<String> Not_DisplayedMedicalpolicylist=new ArrayList<>();
		ArrayList<String> NotMatchedSavingsMedicalpolicylist=new ArrayList<>();
		
		//Service method to get distinct pps from mdm service
		oServicesPage.getUniquePPSfromClientconfigService();
		//DB method to get RVA and eLL MPs
		MongoDBUtils.getRVAMPsforNoneScenarios(Payershorts, Insuarances, Claimtypes, LatestClientDecision);
		MongoDBUtils.geteLLMPsfornone(Payershorts, Insuarances, Claimtypes, LatestClientDecision);
		System.out.println("Total None MPsize::"+ProjectVariables.DB_NoneMPlist.size());
		
		//To retrieve the UI MPs
		Medicalpolicysize=oAWBPage.get_Matching_WebElement_count(oAWBPage.MedicalPolicies_In_PolicySelection);
		for (int i = 1; i <=Medicalpolicysize; i++) 
		{
			SavingsLocator=StringUtils.replace(oAWBPage.MedicalPolicies_In_PolicySelection, "not", "")+"["+i+"]";
			UIMedicalpolicy=oAWBPage.get_TextFrom_Locator(oAWBPage.MedicalPolicies_In_PolicySelection+"["+i+"]");
			UISavings=oDPWBPage.ReturnValue(oAWBPage.get_TextFrom_Locator(SavingsLocator)).trim();
			System.out.println(i+"."+"UI MP::"+UIMedicalpolicy+"::"+UISavings);
			Policyselection_Medicalpolicies.add(UIMedicalpolicy);
		}
		System.out.println("UI MPlist ==>"+Policyselection_Medicalpolicies);
		System.out.println("UI MPsize ==>"+Policyselection_Medicalpolicies.size());
		
		//Verifying all the DB Mps are displayed in filterpanel or not for none decision	
		int z=1;
		for (String DBMP : ProjectVariables.DB_NoneMPlist) 
		{
			//String Exact_DBmedicalpolicy=StringUtils.substringBefore(DBMP, ";Raw");
			if(!Policyselection_Medicalpolicies.contains(DBMP.trim()))
			{
				System.out.println(z+"."+DBMP);
				Not_DisplayedMedicalpolicylist.add(DBMP);
				z=z+1;
			}
		}
		System.out.println("Not In UI::"+Not_DisplayedMedicalpolicylist);
		System.out.println("Total None DBMPsize::"+ProjectVariables.DB_NoneMPlist.size());
		System.out.println("UI MPsize::"+Policyselection_Medicalpolicies.size());
		System.out.println("Not In UI Size::"+Not_DisplayedMedicalpolicylist.size());
		
		//Verifying not displayed UI mps with DB to check whether they have none decision in latest decision/eLLhierarchy collection as per mdm service
		verifyThegivenMPishavingNoneDecisioninDB(Not_DisplayedMedicalpolicylist,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
		
		//Verifying all the UI Mps,which are avaialble in DB of filterpanel or not for none decision
		Not_DisplayedMedicalpolicylist.clear();
		z=0;
		for (String UI_MP : Policyselection_Medicalpolicies) 
		{
			String Exact_UIMP=StringUtils.substringBefore(UI_MP, ";");
			String Exact_UIMPsavings=StringUtils.substringAfter(UI_MP, ";");
			if(!ProjectVariables.DB_NoneMPlist.contains(Exact_UIMP))
			{
				z=z+1;
				System.out.println(z+"."+Exact_UIMP);
				Not_DisplayedMedicalpolicylist.add(Exact_UIMP);
				z=z+1;
			}
		}
		System.out.println("Not IN DB::"+Not_DisplayedMedicalpolicylist);
		System.out.println("Total None DBMPsize::"+ProjectVariables.DB_NoneMPlist.size());
		System.out.println("UI MPsize::"+Policyselection_Medicalpolicies.size());
		System.out.println("Not IN DB Size::"+Not_DisplayedMedicalpolicylist.size());
		//Verifying not displayed UI mps with DB to check whether they have none decision in latest decision/eLLhierarchy collection as per mdm service
		verifyThegivenMPishavingNoneDecisioninDB(Not_DisplayedMedicalpolicylist,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
				
	}

	private void verifyThegivenMPishavingNoneDecisioninDB(ArrayList<String> MPlist,
			String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) 
	{
		int i=1;
		boolean bstatus=false;
	
		if(!MPlist.isEmpty())
		{
			if(LatestClientDecision.contains("None"))
			{
				for (String mp : MPlist) 
				{
					System.out.println("Total MPs::"+MPlist.size());
					bstatus=MongoDBUtils.verifygivenMPishavingNonedecision(mp,Payershorts, Insuarances, Claimtypes, LatestClientDecision);
					if(bstatus)
					{
						GenericUtils.Verify(i+".MP '"+mp+"' shouldn't display in filterpanel as it doesn't have dps with 'none' decisions as per latestdecisoin collection and mdm service",false);
					}
					else
					{
						System.out.println(i+".MP '"+mp+"' should be displayed in filterpanel as it's having dps with 'none' decisions as per latestdecisoin collection and mdm service");	
					}
					i=i+1;
				}
			}
			else
			{
				GenericUtils.Verify("MPs '"+MPlist+"' should be there in filterpanel as per the pps selection,MP Size::"+MPlist.size(),false);
			}
			
		}
		
		
		
	}
	
}

