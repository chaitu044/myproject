package project.pageobject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.WebElementFacade;

import project.utilities.GenericUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;


public class PMPage extends SeleniumUtils 
{
	// Dynamic xPaths
	private WebElementFacade ElementClient;
	public String sClientDropdown="//mat-toolbar//mat-select[@placeholder='Select Client']";
	private final String partial_xPathSelectClientList_part1 = "//div[contains(@id,\"cdk-overlay\")]//div//div//mat-option//span[contains(text(),\"";
	private final String partial_xPathSelectClientList_part2 = "\")]";
	public String Pres_Payer_LOB_All_Chkbox="//b[text()='filter']/../..//div[contains(text(),'All')]";
	public String Span_contains_text = "(//span[contains(text(),'value')])";
	public String Tag_contains_b="//b[contains(text(),'value')]";
	public String ButtonWithText = "//button[text()='svalue']";
	public String Medicalpolicy_Checkbox="//div[contains(text(),'value')]/../..//div//span/..";
	public String  MedPolicyFilterApplyBtn = "(//app-cpd-medical-policy-filter//jqxbutton)[2]/button";
	public  String labelwithtext = "//label[text()='svalue']";
	public String Span_with_text="(//span[text()='value'])";
	public String InsuranceChkbox_in_Presentation="//th//span[text()='value']/..//label//span";
	public String ButtonContainsClass = "//button[contains(@class,'value')]";
	public String CaptureDecison_text = "//div[@class='mat-radio-label-content' and contains(text(), 'value')]";
	public String ButtonContainsText = "//button[contains(text(),'value')]";
	public String Div_contains_Class = "//div[contains(@class,'value')]";
	public String Div_contains_text = "//div[contains(text(),'value')]";
	public String Tag_with_P="//p[text()='value']";
	public String Tag_with_a="//a[text()='value']";
	//########################################################################################################	
	
	public WebElementFacade getElementClient(String arg1) {
		ElementClient = find(
				By.xpath(partial_xPathSelectClientList_part1 + arg1 + partial_xPathSelectClientList_part2));
		return ElementClient;
	}
	
	public boolean user_selects_given_value_from_Client_drop_down_list(String arg1) throws Throwable {
		GenericUtils oGenericUtils=this.switchToPage(GenericUtils.class);		
		
		oGenericUtils.clickOnElement("//span[contains(text(),'NPP Opportunities')]/span");
		
		oGenericUtils.clickOnElement(sClientDropdown);
		if (arg1 == "random") {
			List<WebElement> AllClients =  new ArrayList<WebElement>();			
			AllClients  = getElementsList("XPATH","//div[@id='cdk-overlay-0']//div//div//mat-option//span");  	
			int NoOfClients = AllClients.size();
			Random RandGenerator = new Random();
			int RandomInt =  RandGenerator.nextInt(NoOfClients)+1;		
			oGenericUtils.clickOnElement("(//div[@id='cdk-overlay-0']//div//div//mat-option//span)["+RandomInt+"]");
			return oGenericUtils.clickOnElement("//span[contains(text(),'NPP Opportunities')]/span");
		} else {			
			waitForContentLoad();
			getElementClient(arg1).click();
			Serenity.setSessionVariable("SelectClientName").to(arg1);
			defaultWait(ProjectVariables.TImeout_5_Seconds);	
			waitForContentLoad();
			defaultWait(ProjectVariables.TImeout_5_Seconds);
			if(arg1.isEmpty())
			{
				arg1=Serenity.sessionVariableCalled("Client");
			}
			
			if(Serenity.sessionVariableCalled("clientkey")==null&&!arg1.contains("Horizon Healthcare Services"))
			{
				
				//To retrieve the client key from the given client
				String sClientkey=AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(arg1);
				
				Serenity.setSessionVariable("clientkey").to(sClientkey);
				
				System.out.println("ClientKey==>"+Serenity.sessionVariableCalled("clientkey"));
			}
		}
		
		return oGenericUtils.clickOnElement("//span[contains(text(),'NPP Opportunities')]/span");
	}
	
	public void Select_the_Available_OpportunityDeck_from_Presentationview() 
	{
	
		clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "NPP Opportunities")+"/span");
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		waitForContentLoad();
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		waitForContentLoad();
		clickGivenXpath(StringUtils.replace(ButtonWithText, "svalue", "Get Available Opportunities"));
		//defaultWait(ProjectVariables.TImeout_2_Seconds);
		waitForContentLoad();
		clickGivenXpath(StringUtils.replace(Tag_contains_b, "value", "Payer Shorts"));
		clickGivenXpath(StringUtils.replace(Tag_contains_b, "value", "LOB"));
		clickGivenXpath(StringUtils.replace(Tag_contains_b, "value", "ClaimType"));
		clickGivenXpath(StringUtils.replace(ButtonWithText, "svalue", "Apply"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		//oFilterDrawer.selectMedicalPolicyAndTopic("Topic", Serenity.sessionVariableCalled("Topic"), "Select");
	}
	
	public boolean Enter_the_given_MP_Topic_in_filter_Drawer(String MP_Topic) {
		
		boolean bstatus=false;
		 //Enter the captured medicalpolicy in the search field 
		  Enter_given_Text_Element("//input[@placeholder='Search for Medical Policy / Topic']", MP_Topic);
		  
		  //click the search button of search field
		  clickGivenXpath("//button[@class='searchbutton']");
		  defaultWait(ProjectVariables.TImeout_3_Seconds);
		  bstatus=is_WebElement_Displayed(StringUtils.replace(Medicalpolicy_Checkbox, "value", MP_Topic));
		
		return bstatus;
	}
	
	public void validate_the_captured_DPkey_in_available_opportunity_deck(String DPkey) 
	{
		boolean bstatus=false;
		
		//Method to select the Captured Topic in subsequent RVA run from Presentation View
		 Select_the_Available_OpportunityDeck_from_Presentationview();
		 
		 bstatus=Enter_the_given_MP_Topic_in_filter_Drawer(Serenity.sessionVariableCalled("Topic"));
		 
		Assert.assertTrue("Captured topic was not displayed,after seraching in filter drawer,Medicalpolicy=>"+Serenity.sessionVariableCalled("Medicalpolicy"), bstatus);
		
		clickGivenXpath(StringUtils.replace(Medicalpolicy_Checkbox, "value", Serenity.sessionVariableCalled("Topic")));
		 
		 user_filters_by_clicking_on_Apply_for_Medical_Policy_Topic();
		 
		 bstatus=is_WebElement_Displayed(StringUtils.replace(labelwithtext, "svalue", "DP "+DPkey+""));

		 GenericUtils.Verify("Captured DPkey Should be displayed in the Available opportunity deck of PM from CPW,DPKey::"+DPkey+",Topic::"+Serenity.sessionVariableCalled("Topic"), bstatus);
	}

	public boolean user_filters_by_clicking_on_Apply_for_Medical_Policy_Topic() {
		SeleniumUtils objSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		if(objSeleniumUtils.is_WebElement_Displayed(MedPolicyFilterApplyBtn))
		{
			//objSeleniumUtils.highlightElement(MedPolicyFilterApplyBtn);
			objSeleniumUtils.clickGivenXpath(MedPolicyFilterApplyBtn);	
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			objSeleniumUtils.waitForContentLoad();
		
		}	
		return true;
	}

	public void Perform_the_CaptureDecision_functionality_for_the_given(String DPKey,String captureDecision, String DPKeyCriteria, String ReAssignedPresentaionName) 
	{
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		String sInsurance=null;
		String sPayershorts=null;
		List<String> DPKeyList=null;
		
		switch(DPKeyCriteria)
		{
		case "DPLOBLevel":
		case "First-DPLOBLevel":
		case "First-DPLevel":
			System.out.println("PresentationName==>"+Serenity.sessionVariableCalled("PresentationName"));
			//Select the given presentation and DPkey
			Assert.assertTrue("uanble to select the DPKey from given presentation,Presname==>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey===>"+DPKey, select_the_given_DPkey_at_Presentation_view(Serenity.sessionVariableCalled("PresentationName"), DPKey));
			
			clickGivenXpath(StringUtils.replace(labelwithtext, "svalue", "DP "+DPKey+"")+"[@class='dpIdLabel']");
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			if(DPKeyCriteria.equalsIgnoreCase("First-DPLevel"))
			{
				clickGivenXpath(StringUtils.replace(Span_with_text, "value", "ALL")+"/..//span[@class='checkmark']");	
			}
			else if(DPKeyCriteria.equalsIgnoreCase("First-DPLOBLevel")||DPKeyCriteria.equalsIgnoreCase("DPLOBLevel"))
			{
				System.out.println("CapturedPayerLOB=>"+ProjectVariables.CapturedPayerLOBList);
				System.out.println(ProjectVariables.CapturedPayerLOBList.get(0));
				sInsurance=StringUtils.substringBefore(ProjectVariables.CapturedPayerLOBList.get(0), "-");
				sPayershorts=StringUtils.substringAfter(ProjectVariables.CapturedPayerLOBList.get(0), "-");
				
				clickGivenXpath(StringUtils.replace(InsuranceChkbox_in_Presentation, "value", sInsurance));
			}
			
		break;
		case "Last-DPLevel":
			DPKeyList=Arrays.asList(DPKey.split(","));
			
			//Select the given presentation and DPkey
			Assert.assertTrue("uanble to select the DPKey from given presentation,Presname==>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey===>"+DPKeyList.get(0).trim(), select_the_given_DPkey_at_Presentation_view(Serenity.sessionVariableCalled("PresentationName"), DPKeyList.get(0).trim()));
			
			clickGivenXpath(StringUtils.replace(labelwithtext, "svalue", "DP "+DPKeyList.get(0).trim()+""));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			while(is_WebElement_enabled(StringUtils.replace(ButtonWithText, "svalue", "Next")))
			{
				clickGivenXpath(StringUtils.replace(ButtonWithText, "svalue", "Next"));
			}
			
			String CapturedDPkey=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(Span_contains_text, "value", "DP")), "DP ");
			Serenity.setSessionVariable("CapturedDPKey").to(CapturedDPkey);
			
			clickGivenXpath(StringUtils.replace(Span_with_text, "value", "ALL")+"/..//span[@class='checkmark']");
			
			break;
		default:
			Assert.assertTrue("Case not found===>"+DPKeyCriteria, false);
		break;
		}
		
		//Capture the given decision
		clickGivenXpath(StringUtils.replace(ButtonContainsClass, "value", "capture"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		//clickGivenXpath(StringUtils.replace(Div_contains_text, "value", captureDecision));		
		clickGivenXpath(StringUtils.replace(CaptureDecison_text, "value", captureDecision));
		if(captureDecision.equalsIgnoreCase("Re-Assign"))
		{
			clickGivenXpath(StringUtils.replace(Div_contains_Class, "value", "assign-popover")+"/.."+StringUtils.replace(Div_contains_text, "value", ReAssignedPresentaionName));
			clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", "Assign"));
		}
		else if(captureDecision.equalsIgnoreCase("Unassign"))
		{
			clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", "Capture"));	
			clickGivenXpath("//footer//button[contains(text(),'Capture')]");
		}
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		
	}

	public void validate_the_Presentation_after_capturing_the_decision(String ReAssignedPresentaionName, String captureDecision, String DPKeyCriteria) 
	{
		
		boolean bStatus=false;
		switch(DPKeyCriteria)
		{
		case "First-DPLevel":
			
			bStatus=is_WebElement_Displayed(StringUtils.replace(Tag_with_P, "value", "This presentation has no content yet."));
				
			if(captureDecision.equalsIgnoreCase("Re-Assign"))
			{
				Assert.assertTrue("'This presentation has no content yet' message is not displayed,after '"+captureDecision+"' DPkey also,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("DPkey"), bStatus);
				//Select the given presentation and DPkey
				Assert.assertTrue("Unable to see the re-assigned DPkey in PresentationDeck,Presname==>"+ReAssignedPresentaionName+",DPkey===>"+Serenity.sessionVariableCalled("DPkey"), select_the_given_DPkey_at_Presentation_view(ReAssignedPresentaionName, Serenity.sessionVariableCalled("DPkey")));
			}
			else
			{
				Assert.assertTrue("'This presentation has no content yet' message is not displayed,after '"+captureDecision+"' DPkey also,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("DPkey"), bStatus);
				
				//validate the unassigned DPkey in available opportunity deck
				validate_the_captured_DPkey_in_available_opportunity_deck(Serenity.sessionVariableCalled("DPkey"));
				
				
			}
			System.out.println("'"+captureDecision+"' functionality is validated successfully for the captured DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",PresenationNames=>"+Serenity.sessionVariableCalled("PresentationName")+","+ReAssignedPresentaionName);
		
		break;
		case "First-DPLOBLevel":
			
			bStatus=is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "DP "+Serenity.sessionVariableCalled("DPkey")+""));
			Assert.assertTrue("DPKey is not displayed,after '"+captureDecision+"' one of the PPS,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",'"+captureDecision+"' PPS=>"+ProjectVariables.CapturedPayerLOBList.get(0), bStatus);	
			if(captureDecision.equalsIgnoreCase("Re-Assign"))
			{
				//Select the given presentation and DPkey
				Assert.assertTrue("Unable to see the re-assigned DPkey in PresentationDeck,Presname==>"+ReAssignedPresentaionName+",DPkey===>"+Serenity.sessionVariableCalled("DPkey"), select_the_given_DPkey_at_Presentation_view(ReAssignedPresentaionName, Serenity.sessionVariableCalled("DPkey")));
				clickGivenXpath(StringUtils.replace(labelwithtext, "svalue", "DP "+Serenity.sessionVariableCalled("DPkey")+"")+"[@class='dpIdLabel']");
				defaultWait(ProjectVariables.TImeout_3_Seconds);
				
				Assert.assertTrue("Unable to see the re-assigned PPS of DPkey in PresentationDeck,Presname==>"+ReAssignedPresentaionName+",DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",PPS=>"+ProjectVariables.CapturedPayerLOBList.get(0), is_WebElement_Displayed(StringUtils.replace(InsuranceChkbox_in_Presentation, "value", StringUtils.substringBefore(ProjectVariables.CapturedPayerLOBList.get(0), "-"))));
				
			}
			else
			{
				//validate the unassigned DPkey in available opportunity deck
				validate_the_captured_DPkey_in_available_opportunity_deck(Serenity.sessionVariableCalled("DPkey"));
				
			}
			System.out.println("'"+captureDecision+"' functionality is validated successfully at LOB level of the captured DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",PresenationNames=>"+Serenity.sessionVariableCalled("PresentationName")+","+ReAssignedPresentaionName);
		
		break;
		case "Last-DPLevel":
			bStatus=is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "DP "+Serenity.sessionVariableCalled("CapturedDPKey")+""));
			Assert.assertFalse("DPKey is still displayed,after '"+captureDecision+"' DPkey,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("CapturedDPKey"), bStatus);	
			
			if(captureDecision.equalsIgnoreCase("Re-Assign"))
			{
				//Select the given presentation and DPkey
				Assert.assertTrue("Unable to see the re-assigned DPkey in PresentationDeck,Presname==>"+ReAssignedPresentaionName+",DPkey===>"+Serenity.sessionVariableCalled("CapturedDPKey"), select_the_given_DPkey_at_Presentation_view(ReAssignedPresentaionName, Serenity.sessionVariableCalled("CapturedDPKey")));
				
				
			}
			else
			{
				//validate the unassigned DPkey in available opportunity deck
				validate_the_captured_DPkey_in_available_opportunity_deck(Serenity.sessionVariableCalled("CapturedDPKey"));
				
			}
			System.out.println("'"+captureDecision+"' functionality is validated successfully at LOB level of the captured DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",PresenationNames=>"+Serenity.sessionVariableCalled("PresentationName")+","+ReAssignedPresentaionName);
		
			break;
		case "DPLOBLevel":
			System.out.println("CapturedPayerLOB=>"+ProjectVariables.CapturedPayerLOBList);
			System.out.println(ProjectVariables.CapturedPayerLOBList.get(0));
			String sInsurance=StringUtils.substringBefore(ProjectVariables.CapturedPayerLOBList.get(0), "-");
			
			bStatus=is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "DP "+Serenity.sessionVariableCalled("DPkey")+""));
			GenericUtils.Verify("DPKey should be displayed,after '"+captureDecision+"' one of the PPS,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",Decision==>'"+Serenity.sessionVariableCalled("Decision")+"' PPS=>"+ProjectVariables.CapturedPayerLOBList.get(0), bStatus);	
			bStatus=is_WebElement_Displayed(StringUtils.replace(InsuranceChkbox_in_Presentation, "value", sInsurance));
			GenericUtils.Verify("LOB should be displayed,after '"+captureDecision+"' one of the PPS,PresName=>"+Serenity.sessionVariableCalled("PresentationName")+",DPkey=>"+Serenity.sessionVariableCalled("DPkey")+",Decision==>'"+Serenity.sessionVariableCalled("Decision")+"' PPS=>"+ProjectVariables.CapturedPayerLOBList.get(0), bStatus);
			break;
		default:
			Assert.assertTrue("Case not found===>"+DPKeyCriteria, false);
		break;
		}
		
		
	}
	
	public boolean select_the_given_DPkey_at_Presentation_view(String Presentationname, String DPkey) {
		
		
		
		SeleniumUtils oSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		
		boolean bstatus=false;
		
		oSeleniumUtils.clickGivenXpath(StringUtils.replace(Span_contains_text, "value", Presentationname));
		oSeleniumUtils.waitForContentLoad();
      	oSeleniumUtils.waitForContentLoad();
		
		
		if(oSeleniumUtils.is_WebElement_Displayed(StringUtils.replace(Tag_with_P, "value", "This presentation has no content yet.")))
		{
			return false;
		}
		
		//To select the all PPs in Presentation Deck in filterdrawer section
		selectTheAllPPSinPresentationDeck();
		
		
		bstatus=oSeleniumUtils.is_WebElement_Displayed(StringUtils.replace(labelwithtext, "svalue", "DP "+DPkey+"")+"[@class='dpIdLabel']");
		
		return bstatus;
		
	
		
	
	
		
	}
	
	public void selectTheAllPPSinPresentationDeck() 
	{
		SeleniumUtils oSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		String CheckboxStatus=null;
		CheckboxStatus=oSeleniumUtils.Get_Value_By_given_attribute("aria-checked", StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "Payers"));
		if(CheckboxStatus==null)
		{
			Assert.assertTrue("Unable to retrive the checkbox status of Payers in Presentaion view", false);
		}
		if(CheckboxStatus.equalsIgnoreCase("false"))
		{
			oSeleniumUtils.clickGivenXpath(StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "Payers"));
		}
		
		CheckboxStatus=oSeleniumUtils.Get_Value_By_given_attribute("aria-checked", StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "LOB"));
		if(CheckboxStatus==null)
		{
			Assert.assertTrue("Unable to retrive the checkbox status of LOB in Presentaion view", false);
		}
		if(CheckboxStatus.equalsIgnoreCase("false"))
		{
			oSeleniumUtils.clickGivenXpath(StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "LOB"));
		}
		CheckboxStatus=oSeleniumUtils.Get_Value_By_given_attribute("aria-checked", StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "Claim Type"));
		if(CheckboxStatus==null)
		{
			Assert.assertTrue("Unable to retrive the checkbox status of Claim Type in Presentaion view", false);
		}
		if(CheckboxStatus.equalsIgnoreCase("false"))
		{
			oSeleniumUtils.clickGivenXpath(StringUtils.replace(Pres_Payer_LOB_All_Chkbox, "filter", "Claim Type"));
		}
		oSeleniumUtils.defaultWait(ProjectVariables.TImeout_3_Seconds);
		oSeleniumUtils.clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Apply"));
		//oSeleniumUtils.defaultWait(ProjectVariables.TImeout_3_Seconds);
		oSeleniumUtils.waitForContentLoad();
		
	}
	
}
