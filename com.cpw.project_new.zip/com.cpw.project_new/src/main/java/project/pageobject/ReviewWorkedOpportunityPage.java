package project.pageobject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import project.utilities.AppUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;

public class ReviewWorkedOpportunityPage extends SeleniumUtils{
	
	//========================================================Page Locators & Instances ====================================================================================//
	
	//OpportunityRunsPage oOpportunityRunsPage;
	//AWBPage oAWBPage;
	//AppUtils oAppUtils;
	
	
	
	
	
	//========================================================Page Methods ====================================================================================//
	
	public void select_the_filters_in_RWO_Page(String filtername,String filterdata,String applyfiltersbutton)
	{
		AppUtils oAppUtils=this.switchToPage(AppUtils.class);
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		//GenericUtils oGenericUtils=this.switchToPage(GenericUtils.class);
		OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
		Serenity.setSessionVariable("Pagename").to("RWO");
		List<String> PPSList=Arrays.asList(filterdata.split(","));
		
		if(filtername.isEmpty())
		{
					
			clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Reset"));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			Assert.assertTrue("unable to click the 'Apply Filters' button in the RWO Page",clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
			
			
		}
		else
		{
			
			Assert.assertTrue("'"+filtername+"' filterhead checkbox is unable to un-check in the RWO Page",oOpportunityRunsPage.ApplyFilters(filtername,"","UNCHECK",""));
			
			for (int i = 0; i < PPSList.size(); i++)
			{
				if(applyfiltersbutton.isEmpty())
				{
					oOpportunityRunsPage.ApplyFilters(filtername,PPSList.get(i).trim(),"CHECK","");	
				}
				else
				{
					oOpportunityRunsPage.ApplyFilters(filtername,PPSList.get(i).trim(),"CHECK",applyfiltersbutton);
				}
			}
			
			
		}
		
		//combination of Static and dynamic wait 
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
	}

	//===========================================================================================================================================================//
	
	public void Open_the_Review_Worked_Opportunity_Page() {
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		AppUtils oAppUtils=this.switchToPage(AppUtils.class);
			//StringUtils.replace(oAWBPage.ButtonWithText, "svalue", "Review Worked Opportunities")	
		
		
		if(!is_WebElement_Displayed(oAWBPage.WorkedOpportunityHeader))
		{
			Assert.assertTrue("Reviewed Worked Opportunity button was unable to clicked in AWB page", clickGivenXpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Review Worked Opportunities")));
			
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
			
			defaultWait(ProjectVariables.TImeout_5_Seconds);
			
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
			
			Assert.assertTrue("Worked Opportunities header is not displaying in the Review WorkedOpp Page,after clicking on that link in AWB Page", Wait_Untill_Element_is_displayed(10, oAWBPage.WorkedOpportunityHeader));
	
			
		}
		
			
		}

	//===========================================================================================================================================================//

	public void update_the_disposition_as(String criteriatype, String disposition, String datatype) throws InterruptedException
	{
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
		ArrayList<String> sGetItems=new ArrayList<>();
		
	if(!criteriatype.contains("Payershort"))
	{
		if(criteriatype.contains("Single"))
		{
			sGetItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage(datatype,1);
    		System.out.println(""+datatype+" name ===>"+sGetItems);
    		System.out.println("Selected the single "+datatype+" successfully");
		}
		else if(criteriatype.contains("Multiple"))
		{
			sGetItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage(datatype,4);
    		System.out.println(""+datatype+" name ===>"+sGetItems);
    		System.out.println("Selected the Multiple "+datatype+" successfully");
		}
		else
		{
			Assert.assertTrue("Given selection was not found ==>"+criteriatype, false);
		}
	}
	else
	{
		if(criteriatype.equalsIgnoreCase("Single Payershort"))
		{
			sGetItems = oAWBPage.SelectPayershortsInOpportunityGridofAWBPage("Payershort_Checkbox",1);
    		System.out.println("payershort ===>"+sGetItems);
    		System.out.println("Selected the single payershort successfully");
		}
		else if(criteriatype.equalsIgnoreCase("Multiple Payershorts"))
		{
			sGetItems = oAWBPage.SelectPayershortsInOpportunityGridofAWBPage("Payershort_Checkbox",3);
    		System.out.println("payershorts ===>"+sGetItems);
    		System.out.println("Selected the multiples payershorts successfully");
		}
		else
		{
			Assert.assertTrue("Given selection was not found ==>"+criteriatype, false);
		}
		
		ProjectVariables.sGetPayershorts.addAll(sGetItems);
		
		sGetItems.clear();
		
		sGetItems.add(Serenity.sessionVariableCalled("DPKey"));
		
	}
		
    		//To Initialize the disposition fields
    		oAWBPage.Intialaize_the_Dispositions_fields_to_post(disposition);
    		
    		//Capturing the disposition operation for the given client,release and disposition
    		oAWBPage.Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"Review Worked Opportunity","");
    		
    		System.out.println("Successsfully updated the Disposition to '"+disposition+"' for the selected medicalpolicy ==>"+sGetItems);
    		
    		//validate the captured PPS disposition in Review worked Opportunity Page 
    		oAWBPage.validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetItems,datatype,"RWO");
    
		
	}

	//===========================================================================================================================================================//

	public void Validate_mediaclpolicy_level_savings_data_in_the_Oppgrid_of_RWO_page(String client, String release,
			String dB_Medicalpolicy, String savingsstatus) {
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);

		String UIMPname=null;
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		HashSet<String> UIMPlist = new HashSet<>();
		ArrayList<String> payershorts=new ArrayList<>();

		//Connection method to Mongo DB
		MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

		int UI_medicalpolicysize=get_Matching_WebElement_count(oAWBPage.Medicalpolicy_in_oppgrid);

		for (int i = 1; i <= UI_medicalpolicysize; i++)
		{
			System.out.println("UI Medicalpolicies size in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",Medicalpolicy size==>"+UI_medicalpolicysize);

			//if(is_WebElement_Displayed(oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]"))
			//{
				scrollingToGivenElement(getDriver(), oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]");
				UIMPname=get_TextFrom_Locator(oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]");


				if(!UIMPlist.contains(UIMPname))
				{
					System.out.println(i+"."+UIMPname);
					//String savingslocator=StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIMPname.trim());

					UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIMPname.trim())+"[3]").trim());
					UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIMPname.trim())+"[4]").trim());
					//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIMPname.trim())+"[5]").trim());
					UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIMPname.trim())+"[5]").trim());

					
					
					//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
					MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(payershorts,UIMPname, "", "", "", "ReviewGrid");


					Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at MP level in the oppgrid of RWO Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));

					Assert.assertTrue("UIAggsavings data was not matched with DB_Rawsavings at MP level in the oppgrid of RWO Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));

					//Assert.assertTrue("UIConsavings data was not matched with DB_Rawsavings at MP level in the oppgrid of RWO Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));

					Assert.assertTrue("UIEdits data was not matched with DB_Rawsavings at MP level in the oppgrid of RWO Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));

					System.out.println("All the Savings data was matching with DB_Savings at MP level in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+",UI MP's size ==>"+UIMPlist+",MP number ==>"+i);

					UIMPlist.add(UIMPname);



				}
/*
			}
			else
			{
				Click_Untill_Element_is_not_displayed_with_the_given_time(10,oAWBPage.Verticlescrollbtn_in_Oppgrid,oAWBPage.Verticalscrollbar_Freespace);
				UI_medicalpolicysize=get_Matching_WebElement_count(oAWBPage.Medicalpolicy_in_oppgrid);
				i=1;
			}*/
		}

		
		System.out.println("All the MedicalPolicies savings are matched with Mongo DB in RWO Grid");


	}

	
	//===========================================================================================================================================================//
	
	public void Capturing_the_MPs_from_the_oppgrid_of_RWO_page() {
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		ProjectVariables.UIMPslist.clear();

		String UIMP=null;

		int UI_MPsize=get_Matching_WebElement_count(oAWBPage.Medicalpolicy_in_oppgrid);


		for (int i = 1; i <= UI_MPsize; i++)
		{
			int j=1;
			boolean elementstatus=is_WebElement_Displayed(oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]");
			//if(elementstatus)
			{
				scrollingToGivenElement(getDriver(), oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]");
				UIMP=get_TextFrom_Locator(oAWBPage.Medicalpolicy_in_oppgrid+"["+i+"]");
				System.out.println(i+"."+UIMP);
				
				ProjectVariables.UIMPslist.add(UIMP);
				
				
				
			}
			/*else if(!elementstatus||is_WebElement_Displayed(oAWBPage.Verticalscrollbar_Freespace))
			{

				if(is_WebElement_Displayed("//div[@id='jqxScrollBtnDownverticalScrollBarjqxOppGrid']"))
				{
					do{
						oAWBPage.PerformTheScrollingOperation();
						i = 1;
						j = j + 1;
					} while (is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_with_text, "value", UIMP)) ^ j == 20);
				}
				if (is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_with_text, "value", UIMP))) 
				{
					if (!(get_Matching_WebElement_count("//div[text()='"+UIMP+"' and @class='aw-policy-cell-content']/../../../../following-sibling::div//div[@class='aw-policy-cell-content']") > 0)) 
					{
						break;
					}

					
				}
				UI_MPsize=get_Matching_WebElement_count(oAWBPage.Medicalpolicy_in_oppgrid);

			}*/
		}


		System.out.println("UIMPslist ==>"+ProjectVariables.UIMPslist);
		System.out.println("UIMPslist ==>"+ProjectVariables.UIMPslist.size());

	}

	//===========================================================================================================================================================//
	
		public void Capturing_the_DPKeys_from_the_oppgrid_of_RWO_page() {
			AWBPage oAWBPage=this.switchToPage(AWBPage.class);
			ProjectVariables.UIDPKeylist.clear();

			String UIDPKey=null;
			
			Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of RWO Page", clickGivenXpath(StringUtils.replace(oAWBPage.ChevronInGrid, "value", "topic")));
			
			int UI_DPKeysize=get_Matching_WebElement_count(oAWBPage.DPKey_in_Oppgrid);


			for (int i = 1; i <= UI_DPKeysize; i++)
			{
				int j=1;
				boolean elementstatus=is_WebElement_Displayed(oAWBPage.DPKey_in_Oppgrid+"["+i+"]");
				//if(elementstatus)
				{
					scrollingToGivenElement(getDriver(), oAWBPage.DPKey_in_Oppgrid+"["+i+"]");
					UIDPKey=get_TextFrom_Locator(oAWBPage.DPKey_in_Oppgrid+"["+i+"]");
					System.out.println(i+"."+UIDPKey);
					
					ProjectVariables.UIDPKeylist.add(UIDPKey);
					
					
					
				}
				/*else if(!elementstatus||is_WebElement_Displayed(oAWBPage.Verticalscrollbar_Freespace))
				{
					if(is_WebElement_Displayed("//div[@id='jqxScrollBtnDownverticalScrollBarjqxOppGrid']"))
					{
						do{
							oAWBPage.PerformTheScrollingOperation();
							i = 1;
							j = j + 1;
						} while (is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_with_text, "value", UIDPKey)) ^ j == 20);
					}
					if (is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_with_text, "value", UIDPKey))) 
					{
						if (!(get_Matching_WebElement_count("//div[text()='"+UIDPKey+"' and @class='aw-dp-content-cell']/../../../../following-sibling::div//div[@class='aw-dp-content-cell']") > 0)) 
						{
							break;
						}

						
					}
					UI_DPKeysize=get_Matching_WebElement_count(oAWBPage.DPKey_in_Oppgrid);

				}*/
			}


			System.out.println("UIDPKeylist ==>"+ProjectVariables.UIDPKeylist);
			System.out.println("UIDPKeylist ==>"+ProjectVariables.UIDPKeylist.size());

		}
	//===========================================================================================================================================================//

	public void Validate_topic_level_savings_data_in_the_Oppgrid_of_RWO_page(String client, String release,String savingsstatus) 
	{
		int j=0;
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
		int UITopicSize=0;
		String UITopicname=null;
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		
		ArrayList<String> payershorts=new ArrayList<>();
		
		//Capturing the MPS from Oppgrid of AWB Page
		Capturing_the_MPs_from_the_oppgrid_of_RWO_page();

		//Connecting to Mongo DB
		MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

		
		for (String UIMP : ProjectVariables.UIMPslist)
		{
				Serenity.setSessionVariable("Medicalpolicy").to(UIMP);
			
				System.out.println("UI MedicalPolicies size in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",MP's size==>"+ProjectVariables.UIMPslist.size());

				Assert.assertTrue("unable to enter the medicalpolicy in the search box in the Opportunity grid of RWO Page for the Medicalpolicy ==>"+UIMP, Enter_given_Text_Element(oAWBPage.sSearchField_RWOpp, UIMP));

				Assert.assertTrue("unable to click the search button in the Opportunity grid of RWO Page for the MP ==>"+UIMP, clickGivenXpath(oAWBPage.AWBgriSearchbutton));

				defaultWait(ProjectVariables.TImeout_2_Seconds);

				oOpportunityRunsPage.click_the_given_cheveron("Topic","down");
				
				UITopicSize=get_Matching_WebElement_count(oAWBPage.Topicname_in_oppgrid);

					for (int i = 1; i<=UITopicSize; i++) 
					{
						
						UITopicname=get_TextFrom_Locator(oAWBPage.Topicname_in_oppgrid+"["+i+"]");
						
						if(!UITopicname.contains("'"))
						{
						
						//String savingslocator=StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UITopicname.trim());
						
							UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UITopicname.trim())+"[3]").trim());
							UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UITopicname.trim())+"[4]").trim());
							//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UITopicname.trim())+"[5]").trim());
							UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UITopicname.trim())+"[5]").trim());

						//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
						MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(payershorts,UIMP, UITopicname, "", "", "ReviewGrid");
		
		
						Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at Topic level in the oppgrid of RWO Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
		
						Assert.assertTrue("UIAggsavings data was not matched with DB_Aggsavings at Topic level in the oppgrid of RWO Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));
		
						//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at Topic level in the oppgrid of RWO Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));
		
						Assert.assertTrue("UIEdits data was not matched with DB_Edits at Topic level in the oppgrid of RWO Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));
		
						System.out.println("All the Savings data was matching with DB_Savings at Topic level in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
						else
						{
							System.out.println("Topicname contains (')-singlequote in the oppgrid of RWO Page,which is not able to filter in mongoDB,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",Topicname==>"+UITopicname+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
				
					}
			break;
			}
		
		System.out.println("All the Topic level savings are matched with Mongo DB in RWO Grid for the Medicalpolicy ==>"+Serenity.sessionVariableCalled("Medicalpolicy"));
			
	}	
		
	//===========================================================================================================================================================//

	public void Validate_DP_level_savings_data_in_the_Oppgrid_of_RWO_page(String client, String release,String savingsstatus) 
	{
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
	DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		int j=0;
		int UIDPKeySize=0;
		
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		String UIMP=null;
		String UITopicname=null;
		
		ArrayList<String> payershorts=new ArrayList<>();
		
		//Capturing the MPS from Oppgrid of AWB Page
		Capturing_the_DPKeys_from_the_oppgrid_of_RWO_page();

		//Connecting to Mongo DB
		MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

		
		for (String UIDPKey : ProjectVariables.UIDPKeylist)
		{
			
				System.out.println("UI DPKey size in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",DPKEy size==>"+ProjectVariables.UIDPKeylist.size());

				Assert.assertTrue("unable to enter the DPKey in the search box in the Opportunity grid of RWO Page for the DPKEy ==>"+UIDPKey, Enter_given_Text_Element(oAWBPage.sSearchField_RWOpp, UIDPKey));

				Assert.assertTrue("unable to click the search button in the Opportunity grid of RWO Page for the DPKey ==>"+UIDPKey, clickGivenXpath(oAWBPage.AWBgriSearchbutton));

				defaultWait(ProjectVariables.TImeout_3_Seconds);
				Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of RWO Page", clickGivenXpath(StringUtils.replace(oAWBPage.ChevronInGrid, "value", "dp")));
				
				UIMP=get_TextFrom_Locator(oAWBPage.Medicalpolicy_in_oppgrid);
				UITopicname=get_TextFrom_Locator(oAWBPage.Topicname_in_oppgrid);
				int payersize=get_Matching_WebElement_count(StringUtils.replace(oAWBPage.Payershortssize_basedon_DPkey, "dpkey", UIDPKey));

					if(UIDPKey.length()!=1)
						{
						
						//String savingslocator=StringUtils.replace(oAWBPage.savings_in_oppgrid, "value", UIDPKey.trim());
						
						UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.DPsavings_in_oppgrid, "value", UIDPKey.trim())+"[3]").trim());
						UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.DPsavings_in_oppgrid, "value", UIDPKey.trim())+"[4]").trim());
						//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.DPsavings_in_oppgrid, "value", UIDPKey.trim())+"[5]").trim());
						UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.DPsavings_in_oppgrid, "value", UIDPKey.trim())+"[5]").trim());

						//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
						MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(payershorts,UIMP,UITopicname, UIDPKey, "", "ReviewGrid");
		
		
						Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at DP level in the oppgrid of RWO Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
		
						Assert.assertTrue("UIAggsavings data was not matched with DB_Aggsavings at DP level in the oppgrid of RWO Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));
		
						//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at DP level in the oppgrid of RWO Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));
		
						Assert.assertTrue("UIEdits data was not matched with DB_Edits at Topic DP in the oppgrid of RWO Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));
		
						System.out.println("All the Savings data was matching with DB_Savings at DP level in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
						else
						{
							System.out.println("DP key length is one number in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMP+",DPkey ==>"+UIDPKey);
						}
				
					
			}
		
		System.out.println("ALl the DPLevel Savings are matched with Mongo DB in RWO Grid ");
			
	}	
		
		//===========================================================================================================================================================//

	public void Validate_Payershort_level_savings_data_in_the_Oppgrid_of_RWO_page(String client, String release,String savingsstatus) 
	{
		int j=0;
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		String UIPayershort=null;
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		String UITopicname=null;
		String UIMPname=null;
		List<String> UI_Payershort=new ArrayList<>();
		
		//Capturing the MPS from Oppgrid of AWB Page
		Capturing_the_DPKeys_from_the_oppgrid_of_RWO_page();

		//Connecting to Mongo DB
		MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

		
		for (String UIDPKey : ProjectVariables.UIDPKeylist)
		{
			
				Serenity.setSessionVariable("DPKey").to(UIDPKey);
			
				System.out.println("UI DPKey size in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",DPKEy size==>"+ProjectVariables.UIDPKeylist.size());

				Assert.assertTrue("unable to enter the DPKey in the search box in the Opportunity grid of RWO Page for the DPKEy ==>"+UIDPKey, Enter_given_Text_Element(oAWBPage.sSearchField_RWOpp, UIDPKey));

				Assert.assertTrue("unable to click the search button in the Opportunity grid of RWO Page for the DPKey ==>"+UIDPKey, clickGivenXpath(oAWBPage.AWBgriSearchbutton));

				defaultWait(ProjectVariables.TImeout_2_Seconds);

				
				UIMPname=get_TextFrom_Locator(oAWBPage.Medicalpolicy_in_oppgrid);
				UITopicname=get_TextFrom_Locator(oAWBPage.Topicname_in_oppgrid);
				int payersize=get_Matching_WebElement_count(StringUtils.replace(oAWBPage.Payershortssize_basedon_DPkey, "dpkey", UIDPKey));


				for (int i = 1; i <= payersize; i++) {

						if(UIDPKey.length()!=1)
						{
						
							UIPayershort=get_TextFrom_Locator(StringUtils.replace(oAWBPage.Payershortssize_basedon_DPkey, "dpkey", UIDPKey)+"["+i+"]");
							UI_Payershort.add(UIPayershort);
							String savingslocator=StringUtils.replace(oAWBPage.payershortsavings_in_oppgrid, "payer", UIPayershort.trim());

							UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[3]").trim());
							UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[4]").trim());
							//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[5]").trim());
							UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(oAWBPage.payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[5]").trim());

						//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
						MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(UI_Payershort,UIMPname, UITopicname, UIDPKey, "", "ReviewGrid");
		
		
						Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at payershort level in the oppgrid of RWO Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname+",payershort"+UI_Payershort,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));
		
						Assert.assertTrue("UIAggsavings data was not matched with DB_aggsavings at payershort level in the oppgrid of RWO Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname+",payershort"+UI_Payershort,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));
		
						//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at payershort level in the oppgrid of RWO Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname+",payershort"+UI_Payershort,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));
		
						Assert.assertTrue("UIEdits data was not matched with DB_Edits at payershort level in the oppgrid of RWO Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+"DPKEy ==>"+UIDPKey+",Topic ==>"+UITopicname+",payershort"+UI_Payershort,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));
		
						System.out.println("All the Savings data was matching with DB_Savings at payershort level in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
						else
						{
							System.out.println("DP key length is one number in the oppgrid of RWO Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+UIMPname+",DPkey ==>"+UIDPKey);
						}
				
					}
			break;
			}
			
		
		System.out.println("ALl the PayershortLevel Savings are matched with Mongo DB in RWO Grid,for the DPKey ==>"+Serenity.sessionVariableCalled("DPKey"));
	}	


	//===========================================================================================================================================================//


		public void Validate_the_Data_in_Opportunity_Grid_with_Mongo_DB(String datacriteria, String filtername, String filteroption) 
		{AWBPage oAWBPage=this.switchToPage(AWBPage.class);
			boolean bstatus=false;
					
			HashSet<String> Not_DisplayedDatalist = new HashSet<>();
			HashSet<String> DBDatalist = new HashSet<>();
			/////////////////////////////////////
			
			switch(datacriteria)
			{
			case "Medical Policy":
				
				DBDatalist.addAll(ProjectVariables.DB_MPlist);
				
				break;
			case "Topic":
				
				DBDatalist.addAll(ProjectVariables.DB_Topiclist);
				
				break;
			
				default:
					Assert.assertTrue("Given selection was not found ==>"+datacriteria, false);
				break;
			}
			
			
			
			
		for (String DB_Data : DBDatalist) {
		
			if(!DB_Data.contains(":"))
			{
				Assert.assertTrue("Unable to enter the "+datacriteria+" "+DB_Data+" in the search field of RWO Grid", Enter_given_Text_Element(oAWBPage.sSearchField_RWOpp,DB_Data.trim()));

				Assert.assertTrue("Unable to click the search icon beside search box in the RWO Grid", clickGivenXpath(oAWBPage.AWBgriSearchbutton));

				AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				
				if(datacriteria.equalsIgnoreCase("Topic"))
				{
					Assert.assertTrue("unable to click the mp chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(oAWBPage.ChevronInGrid, "value", "mp")));
					AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				}
				
				
				 bstatus= is_WebElement_Visible(StringUtils.replace(oAWBPage.labelcontainstext, "svalue",DB_Data.trim()));
				
				if(!bstatus)
					{
					
					Not_DisplayedDatalist.add(String.valueOf(DB_Data.trim()));
					}
				
				
			}else
			{
				System.out.println("DB "+datacriteria+" contains ':' ,so if searched with "+datacriteria+" in RWO grid,we have to give the additional space,after colon,"+datacriteria+" is ==>"+DB_Data);
			}
			
				

			}
			

			Assert.assertTrue("Some "+datacriteria+" are not displaying in RWO Grid from Mongo DB as expected,Not available "+datacriteria+" count ==>"+Not_DisplayedDatalist.size()+",Not available "+datacriteria+" are ==>"+Not_DisplayedDatalist+",Filtername ==>"+filtername+",filteroption ==>"+filteroption+",DB "+datacriteria+" count ==>"+DBDatalist.size(),Not_DisplayedDatalist.size()==0);


		}
		
	//===========================================================================================================================================================//	

		public void Validate_the_DPs_in_RWO_Grid_with_Mongo_DB() 
		{AWBPage oAWBPage=this.switchToPage(AWBPage.class);
			boolean bstatus=false;
			
			HashSet<String> ValidDPlist = new HashSet<>();

			
		
			
			for (Long DB_DPKey : ProjectVariables.DB_DpkeyList) 
			{
				
				Assert.assertTrue("Unable to enter the DPKey "+DB_DPKey+" in the search field of AWB Grid", Enter_given_Text_Element(oAWBPage.sSearchField_RWOpp,String.valueOf(DB_DPKey)));

				System.out.println(is_WebElement_Displayed(oAWBPage.AWBgriSearchbutton));
				
				Assert.assertTrue("Unable to click the search icon beside search box in the AWB Grid", clickGivenXpath(oAWBPage.AWBgriSearchbutton));

				AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				Assert.assertTrue("unable to click the dp chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(oAWBPage.ChevronInGrid, "value", "dp")));
				AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
				
				 bstatus= is_WebElement_Visible(StringUtils.replace(oAWBPage.ButtonContainsText, "value",String.valueOf(DB_DPKey)));
				
				if(!bstatus){
					
						ValidDPlist.add(String.valueOf(DB_DPKey));
					
				}
				

			}
			
			

			Assert.assertTrue("Some DP's are not displaying in RWO Grid from Mongo DB as expected,Not available DP count ==>"+ValidDPlist.size()+",Not available DP's are ==>"+ValidDPlist+",DB DPKeylist count ==>"+ProjectVariables.DB_DpkeyList.size(),ValidDPlist.size()==0);


		}
		
		//===========================================================================================================================================================//	
		
		public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(String filtername, String FilterOptions,List<String> Payerslist) throws InterruptedException {
			boolean bstatus=false;
			boolean DBstatus=false;
			AWBPage oAWBPage=this.switchToPage(AWBPage.class);
			List<String> insurancelist = null;
			List<String> claimtypelist=null;
			List<String> filteroptionsList=Arrays.asList(FilterOptions.split(","));
			AppUtils oAppUtils=this.switchToPage(AppUtils.class);
			OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
			
			
			for (int i = 0; i < filteroptionsList.size(); i++) {
				
				Assert.assertTrue("'"+filtername+"' filterhead checkbox is unable to checked in the RWO Page", oOpportunityRunsPage.ApplyFilters(filtername, "", "CHECK", ""));
				
				Assert.assertTrue("'"+filtername+"' filterhead checkbox is unable to uncheck in the RWO Page", oOpportunityRunsPage.ApplyFilters(filtername, "", "UNCHECK", ""));
				
				Assert.assertTrue("'"+filteroptionsList.get(i)+"' filter checkbox is unable to checked in the filter '"+filtername+"' of the RWO Page", oOpportunityRunsPage.ApplyFilters(filtername,filteroptionsList.get(i).trim(),"CHECK",StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
				
				//Wait untill the loading icon is not visible
				oAppUtils.WaitUntilPageLoad();
				
				bstatus=is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", "No results found that meet the search criteria."));
				
				switch(filtername)
				{
				case "Latest Client Decision":
					
					//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
					DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB("", Payerslist,insurancelist,claimtypelist, filteroptionsList.get(i).trim(), "", "", filtername,"RWO");
					
				break;
				case "Current Disposition":
					
					//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
					DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB( "", Payerslist,insurancelist,claimtypelist, "", filteroptionsList.get(i).trim(), "", filtername,"RWO");
					
				break;
				
				
				default:
					
				Assert.assertTrue("Given selection is not found ===>"+filtername, false);	
				break;
				}
				
				if(bstatus)
				{
					if(DBstatus)
					{
						Assert.assertTrue("'No opportunities available for the selected Medical Policy and filters comination' message is displayed in the RWO Grid as not expected with Mongo DB for the client key ==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",Medical policy ==>"+Serenity.sessionVariableCalled("Medicalpolicy")+",filtername ==>"+filtername+",filter option ==>"+filteroptionsList.get(i), false);	
					}
					else
					{
						System.out.println("'No opportunities available for the selected Medical Policy and filters comination' message is displayed in the RWO Grid as expected with Mongo DB for the client key ==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",Medical policy ==>"+Serenity.sessionVariableCalled("Medicalpolicy")+",filtername ==>"+filtername+",filter option ==>"+filteroptionsList.get(i));
					}
				}
				else
				{	
					//validating the Topics displayed in the RWO grid with Mongo DB as per the filter combination 
					Validate_the_Data_in_Opportunity_Grid_with_Mongo_DB("Medical Policy",filtername,filteroptionsList.get(i));
					
					Validate_the_Data_in_Opportunity_Grid_with_Mongo_DB("Topic",filtername,filteroptionsList.get(i));
					
					//validating the DP's displayed in the RWO grid with Mongo DB as per the filter combination 
					Validate_the_DPs_in_RWO_Grid_with_Mongo_DB();
				}
				
				
				
			}
			
			
			
			
		}

		public void verify_retention_functionality_for_the_filter(String filtername, String Requiredfilteroption, String pagename) {
			
			
			switch(filtername)
			{
			case "Latest Client Decision":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.LatestClientDecisionFilterOptions,Requiredfilteroption,pagename);
			break;
			case "Prior Disposition":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.PriorDispositionFilterOptions,Requiredfilteroption,pagename);
			break;
			case "Current Disposition":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.CurrentDispositionFilterOptions,Requiredfilteroption,pagename);
				
			break;
			case "Savings Status":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.SavingStatusFilterOptions,Requiredfilteroption,pagename);
				
			break;
			case "Payer Short":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,"",Requiredfilteroption,pagename);
				
			break;
			case "Insurance":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.InsuranceFilterOptions,Requiredfilteroption,pagename);
				
			break;
			
			case "Product":
				//validate the filter option status for retention functionality
				validate_filter_retention_status(filtername,ProjectVariables.ProductFilterOptions,Requiredfilteroption,pagename);
				
			break;
			
			
			default:
				
			Assert.assertTrue("Given selection is not found ===>"+filtername, false);	
			break;
			}
			
			
		}

		private void validate_filter_retention_status(String filtername,String filteroptionlist,String Requiredfilteroption,String pagename) {
			boolean bstatus=false;
			List<String> filteroptions=null;
			OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
			
			filteroptions=Arrays.asList(filteroptionlist.split(","));
			
			if(filteroptionlist.isEmpty())
			{
				bstatus=oOpportunityRunsPage.FilterCheckbox_Status(filtername, Requiredfilteroption);
				
				Assert.assertTrue("filteroption '"+Requiredfilteroption+"' is un-checked,expected should be checked as per retention functionality in "+Requiredfilteroption+" of "+pagename+"", bstatus);
				
			}
			else
			{
				for (int i = 0; i < filteroptions.size(); i++) 
				{
					
					bstatus=oOpportunityRunsPage.FilterCheckbox_Status(filtername, filteroptions.get(i));
					
					if(filteroptions.get(i).equalsIgnoreCase(Requiredfilteroption))
					{
						Assert.assertTrue("filteroption '"+filteroptions.get(i)+"' is un-checked,expected should be checked as per retention functionality in "+filteroptions.get(i)+" of "+pagename+"", bstatus);
					}
					else
					{
						Assert.assertFalse("filteroption '"+filteroptions.get(i)+"' is checked,expected should be un-checked as per retention functionality in "+filteroptions.get(i)+" of "+pagename+"", bstatus);	
					}
					
				}
			}
			
		}



}
			

