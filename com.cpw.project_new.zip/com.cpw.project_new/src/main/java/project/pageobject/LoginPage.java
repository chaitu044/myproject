package project.pageobject;
import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.util.EnvironmentVariables;
import project.utilities.AppUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;

public class LoginPage extends PageObject {
	
	private EnvironmentVariables environmentVariables;

	//################################################################################################################################################################
	//LOCATORS
	//################################################################################################################################################################
	public static String sClientPolicy="//h1[contains(text(),'Client Policy')]";
	public static String AWBgridheader="//div[contains(text(),'Opportunities(RVA)')]";	
	public static String CPD_Login_header="//mat-card-title[text()='Client Policy Distribution']";
	public String Select_Application_Dropdown="//mat-label[text()='Select an application']";
	public String CPD_Credentials="//input[@formcontrolname='value']";
	//################################################################################################################################################################
	//INSTANCE VARIABLES
	//################################################################################################################################################################
	GenericUtils oGenericUtils;
	AppUtils oAppUtils;
	
	
	//################################################################################################################################################################

	//Login CPW Application
	public void Login_CPW(String sUser) throws Exception{
		
		AWBPage	oAWBPage=this.switchToPage(AWBPage.class);
		ReviewWorkedOpportunityPage	oReviewWorkedOpportunityPage=this.switchToPage(ReviewWorkedOpportunityPage.class);
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		SeleniumUtils oSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		//try{
			Serenity.setSessionVariable("user").to(sUser);
			
			
			String APP_URL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("webdriver.base.url");
			ProjectVariables.DB_CONNECTION_URL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("DB_CONNECTION_URL");
			ProjectVariables.BaseURI = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("restapi.baseuri");

			
			//Launch Application
			Serenity.setSessionVariable("user").to(sUser);
			System.out.println("AppUrl==========>"+APP_URL);
			getDriver().manage().deleteAllCookies();
			getDriver().get(APP_URL);
			getDriver().manage().window().maximize();
			System.out.println("Waiting to Load Login Page of CPW........");
			//Verify Application page
			Assert.assertTrue("'Client Policy Distribution' header text was not displayed in the Login page of CPD Page",oGenericUtils.isElementExist(CPD_Login_header));
			//Enter Username
			Assert.assertTrue("Unable to enter the username in the Login page of CPD Page",oGenericUtils.setValue(By.xpath(StringUtils.replace(CPD_Credentials, "value", "username")), sUser));
			//Enter Password
			
			System.out.println(oSeleniumUtils.is_WebElement_Displayed(StringUtils.replace(CPD_Credentials, "value", "password")));
			System.out.println(Get_Password_For_the_given_url(sUser));
			
			Assert.assertTrue("Unable to enter the password in the Login page of CPD Page", oSeleniumUtils.Enter_given_Text_Element(StringUtils.replace(CPD_Credentials, "value", "password"), Get_Password_For_the_given_url(sUser)));
			
			Assert.assertTrue("Unable to select an application dropdown of CPD Page", oGenericUtils.clickButton(By.xpath("//div[contains(@class,'mat-select-value')]")));
			
			Assert.assertTrue("Unable to click the 'CPW' in select adn applciation drodown of CPD Page", oGenericUtils.clickButton(By.xpath(StringUtils.replace(oAWBPage.Span_contains_text, "value", "CPW"))));
			
			Assert.assertTrue("Unable to click the Login Button of CPW Page", oGenericUtils.clickButton(By.xpath("//span[text()='Login']")));
			
			Thread.sleep(10000);
			//Loading POPUP
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
			
			//Verify HomePage
			GenericUtils.Verify("AWB Page should be displayed,after clicking on the Login Button of CPW Page", oGenericUtils.isElementExist(AWBgridheader,30));
			
			//oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "", "");
			
	}

	//################################################################################################################################################################
	
	//Logout 'CPW' Application
	public void Logout_CPW(){
		getDriver().quit();

	}

	//################################################################################################################################################################
	
	public String Get_Password_For_the_given_url(String user) throws Exception {
		
		HashMap<String, String> oHashMap=new HashMap<String,String>();
		oHashMap.put("nkumar", GenericUtils.decode(ProjectVariables.nkumarPassword));
		oHashMap.put("ulanka", GenericUtils.decode(ProjectVariables.ulankaPassword));
		oHashMap.put("iht_ittest09", GenericUtils.decode(ProjectVariables.PASSWORD));
		oHashMap.put("iht_ittest03", GenericUtils.decode(ProjectVariables.PASSWORD));
		oHashMap.put("iht_ittest04", GenericUtils.decode(ProjectVariables.PASSWORD));
		oHashMap.put("iht_ittest05", GenericUtils.decode(ProjectVariables.PASSWORD));
		return oHashMap.get(user);
	}
	
	public void navigatetoPMfromCPWapplication()
	{
		boolean bstatus=false;
		SeleniumUtils oSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		//To open PM application
		oGenericUtils.clickOnElement("a", "PM");
		SeleniumUtils.defaultWait(ProjectVariables.TImeout_3_Seconds);
		oSeleniumUtils.switchWindowUsingWindowCount(5, 2);
		SeleniumUtils.defaultWait(ProjectVariables.TImeout_5_Seconds);
		//Loading POPUP
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
		bstatus=oSeleniumUtils.is_WebElement_Displayed("//span[contains(text(),'NPP Opportunities ')]");
		if(!bstatus)
		{
			Assert.assertTrue("Available deck is not displayed,after navigating to 'PM' application", false);
		}
	}
	
	public void navigatetoCPWfromPMapplication()
	{
		boolean bstatus=false;
		SeleniumUtils oSeleniumUtils=this.switchToPage(SeleniumUtils.class);
		
		int windowsize=oSeleniumUtils.switchWindowCount(5, 2);
		
		if(windowsize==2)
		{
			oSeleniumUtils.switchWindowUsingWindowCount(5, 1);
			SeleniumUtils.defaultWait(ProjectVariables.TImeout_3_Seconds);
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
		}
		else
		{
			//To open PM application
			oGenericUtils.clickOnElement("span", "CPW");
			SeleniumUtils.defaultWait(ProjectVariables.TImeout_3_Seconds);
			oSeleniumUtils.switchWindowUsingWindowCount(5, 2);
			SeleniumUtils.defaultWait(ProjectVariables.TImeout_5_Seconds);
			//Loading POPUP
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
			bstatus=oSeleniumUtils.is_WebElement_Displayed("//a[text()='PM']");
			if(!bstatus)
			{
				Assert.assertTrue("CPW AWB Page is not displaying,after navigating to 'CPW' application", false);
			}
			
		}
		
	}
}
