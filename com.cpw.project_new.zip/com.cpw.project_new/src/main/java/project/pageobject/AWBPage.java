package project.pageobject;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import org.junit.Assert;
import org.openqa.selenium.By;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import project.utilities.AppUtils;
import project.utilities.GenericUtils;
import project.utilities.MicroServRestUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;

public class AWBPage extends SeleniumUtils {
	
	OpportunityRunsPage oOpportunityRunsPage;

	GenericUtils oGenericUtils;
	AppUtils oAppUtils;
	
	//ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage;
	//################################# PAGE OBJECTS ##############################################################################

	public String ButtonContainsText = "//button[contains(text(),'value')]";
	
	public String ButtonContainsClass = "//button[contains(@class,'value')]";

	public String ButtonWithText = "//button[text()='svalue']";

	public String Header4__with_text="//h4[text()='value']";

	public String Header6__with_text="//h6[text()='value']";

	public String Topicname_in_oppgrid="(//div[contains(@class,'topic-desc')]//label)";
	
	public String Medicalpolicy_in_oppgrid="(//div[contains(@class,'md-desc')]//label)";

	public String savings_in_oppgrid="//label[text()='value']/ancestor::td/following-sibling::td";
	
	public String DPsavings_in_oppgrid="//button[contains(text(),'value')]/ancestor::td/following-sibling::td";
	
	public String payershorts_in_AWBPage="//strong[contains(text(),'Payer Short')]/ancestor::span";

	public String Verticlescrollbtn_in_Oppgrid="//div[@id='jqxScrollBtnDownverticalScrollBarjqxOppGrid']";

	public String Verticalscrollbar_Freespace="//div[contains(@id,'AreaDownverticalScrollBarjqxOppGrid')]";

	public String DPKey_in_Oppgrid="(//div[@class='dp-number']/button)";

//	public String AWB_Searchbox="//input[@id='searchInputBox']";

	//public String AWB_Searchbtn="//div[@id='searchButtonBox']";

	public String Payershortssize_basedon_DPkey="(//button[text()='dpkey']/ancestor::tr/following-sibling::tr//div[@class='payer-desc']/button)";
	
	public String payershortsavings_in_oppgrid="//button[contains(text(),'payer')]/ancestor::td/following-sibling::td";

	public String labelcontainstext = "//label[contains(text(),'svalue')]";

	public String labelwithtext = "//label[text()='svalue']";
	
	public String NotesTextarea = "(//mat-label[text()='Note'])/..//textarea";

	public String Div_with_text = "//div[text()='value']";

	public String Div_with_ID = "//div[@id='value']";
	
	public String Div_Contains_ID = "//div[contains(@id,'value')]";

	public String Div_contains_text = "//div[contains(text(),'value')]";
	
	public String Div_contains_class = "(//div[contains(@class,'value')])";

	public String Div_with_class = "(//div[@class='value'])";
	
	public String ChevronInGrid = "//div[@class='value-box']//fa-icon";
	
	public String ApplyResetfiltersbutton = "//div[@class='reset-apply-buttons']//span[contains(text(),'value')]";

	public static String sPolicySelection="//a[contains(text(),'Policy Selection')]";
	public static String sApplyFilters_PS="//button[contains(@class,' policy-apply-filters')]";
	public static String sSearchFeild_MP="//input[@placeholder='Search'][@id='inputBox']";
	public static String sSearchField_AWB="//input[@placeholder='Search Topic, DP, or DP Description']";
	public static String sSearchField_RWOpp="//input[contains(@placeholder,'Topic, DP, or DP Description')]";

	public static String sSearchIcon="//div[@id='searchBox']/span";
	
	public String Inputwithvalue="//input[@value='text']";
	
	public String CurrentDisposition_RWOpp="(//div[contains(@onclick,'value')])";
	
	public String DPHeader_in_DPWB="//span[contains(text(),'DP')]//following-sibling::span[text()='value']";

	public String Disposition_in_DPWB="//span[text()='Disposition']/ancestor::p";
	
	public String Rules_in_DPDescpopup="(//div[contains(@class,'flexRow')]//p[contains(@class,'value')])";
	
	public String Text_with_Tag_P = "//P[contains(text(),'value')]";
	
	public String Text_with_header4 = "//h4[text()='value']";
	
	public String anchorTag_with_text = "//a[text()='value']";
	
	public String Span_with_text = "//span[text()='value']";
	
	public String Span_contains_text = "(//span[contains(text(),'value')])";
	
	public String Span_contains_value = "(//span[contains(text(),value)])";
	
	public String Span_contains_text_without_braces = "//span[contains(text(),'value')]";
	
	public String Span_contains_class = "//span[contains(@class,'value')]";
	
	public String GridChkbox_Review_worked_OPPGrid="//div[@dataid='value']";
	
	public String Payershort_chkbox_AWB="//button[contains(text(),'payer')]/ancestor::td/preceding-sibling::td[1]/input"; 
	
	public String MedicalPolicies_In_PolicySelection="(//div[contains(text(),'Medical Policy/Topic')]/ancestor::kendo-grid//kendo-grid-list//div[contains(@class,'row')]/div[not (contains(@class,'savings'))])";
	
	public String Topics_In_PolicySelection="(//div[contains(text(),'Medical Policy/Topic')]/ancestor::kendo-grid//kendo-grid-list//div[not (contains(@class,'group')) and contains(@class,'row')]/div[not (contains(@class,'savings'))]/strong)";
	
	public String Topicsavings_In_PolicySelection="(//div[contains(text(),'Medical Policy/Topic')]/ancestor::kendo-grid//kendo-grid-list//div[not (contains(@class,'group')) and contains(@class,'row')]/div[(contains(@class,'savings'))])";
	
	public String MedicalPolicyVerticalscrollbar = "//div[contains(@id,'PolicyTreeGrid')]/div[contains(@class,'arrow-down')]";
	
	public String Loadmorelink="//div[@class='mx-listview mx-listview-selectable mx-name-listView1']/button";
	
	//public String Rules_Data_in_DPDesc="//p[text()='rule']/../../..";
	
	public String latestclientDecision="//button[contains(text(),'dpkey')]/ancestor::td/following-sibling::td[6]/button";
	
	public String RWOlatestclientDecision="//button[contains(text(),'dpkey')]/ancestor::td/following-sibling::td[6]/button";
	
	//public String Prior_or_current_disposition="//div[contains(@class,'prior') and @data-id='dpkey']";
	
	public String Priordisposition="//button[contains(text(),'dpkey')]/ancestor::td/following-sibling::td[7]/button";
	
	public String current_disposition="//button[contains(text(),'dpkey')]/ancestor::td/following-sibling::td[7]/button";
	
	public String LoadingIcon = "//p[contains(text(),'Loading')]";
	
	//public String OppGrid_ClientsList="((//div[contains(@class,'mx-listview-clickable mx-name-listView_Client')])//div[contains(@class,'dataRow--bold')])";
	
	public String OppGrid_ClientsList="(//span[contains(text(),'20')][@class='mat-button-wrapper'][not (contains(text(),'$')) and not (contains(text(),','))])";
	
	public String WorkedOpportunityHeader="//span[contains(text(),'Export Dispositions')]";
	
	public String AWBgriSearchbutton="//input[contains(@placeholder,'Topic, DP, or DP Description')]/ancestor::mat-form-field/following-sibling::button";
	
	public String Text_contains_header3 = "//h3[contains(text(),'value')]";
	
	public String Tag_P_with_class="(//p[@class='value'])";
	
	public String Rules_Data_in_DPDesc="//p[contains(text(),'rule')]/../following-sibling::div/p[contains(@class,'value')]";
	
	public String text_contains_header_th="//th[contains(text(),'value')]";
	
	public String DecisionPopupsize="(//th[contains(text(),'Mid Rule')]/ancestor::table/../../following-sibling::kendo-grid-list//tbody/tr)";
	
	//########################################### PI-25 Locators #############################################################################
	public String ClientListinDropdown="(//span[@class='mat-option-text'][not (contains(text(),'client'))])";
	
	public String AWBGridHirerachy="//div[contains(text(),'Opportunities(RVA)')]/ancestor::mat-tab-group//button[@mattooltip='Hierarchy']";
	
	public String Tag_th_contains_text="//th[contains(text(),'value')]";
	
	public String labelWithCheckbox = "//label[contains(text(),'svalue')]//span[@class='checkmark']";	
	
	public String eLL_DP_Column="(//table[contains(@class,'grid-table')]//tr//td[5]/span)";
	
	public String eLL_DP_View_Checkbox="(//td[contains(@class,'payerShort')]//span[contains(@class,'checkmark')])[1]";
	
	public String PPS_Comb_Checkbox(String value1,String value2,String value3){
		String Xpath="//span[contains(text(),'"+value1+"')]/span[contains(text(),'["+value2+"]')]/../../../following-sibling::td[contains(@class,'"+value3+"')][not (contains(@class,'greyOut'))]";
		return Xpath;
	}
	
	public String PPS_Comb_status(String value1,String value2,String value3){
		String Xpath="//span[contains(text(),'"+value1+"')]/span[contains(text(),'["+value3+"]')]/../../../following-sibling::td[contains(@class,'"+value2+"')]";
		return Xpath;
	}
	
	public String RVADPrulerelationshipicon="//button[contains(text(),'dpkey')]/../../following-sibling::td[1]//fa-icon[@title='Rule Relationship Alert']";
	
	public String RVADPviewpayershort="(//div[@class='dp_view_main']//span[contains(text(),'payer')])";
	
	public String rulerelationshipval="(//mat-row[not (contains(@class,'group'))]//mat-cell[contains(@class,'value')])";
	
	public String RRCloseIcon="//fa-icon[@icon='times']";
	
	public String RRsubrulecol="(//mat-row[contains(@class,'group')])";
	//################################# PAGE METHODS ##############################################################################

	public void validate_the_capture_disposition_dropdown(String Pagename)
	{
		if(Pagename.equalsIgnoreCase("AWBPage"))
		{
			Assert.assertTrue("Capture Disposition Dropdown was unable to clicked in AWB page", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Capture Disposition")));
		}
		else if(Pagename.equalsIgnoreCase("Review Worked Opportunity"))
		{

			Assert.assertTrue("Update Disposition Dropdown was unable to clicked in Reviewed Worked OppPage", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Update Disposition")));
		}

		Assert.assertTrue("Present option was not displayed in the Capture Disposition dropdown in "+Pagename+" Page", is_WebElement_Visible("("+StringUtils.replace(ButtonContainsText, "value", "Present")+")[1]"));
		Assert.assertTrue("Invalid option was not displayed in the Capture Disposition dropdown in "+Pagename+" Page", is_WebElement_Visible(StringUtils.replace(ButtonContainsText, "value", "Invalid")));





	}


	public void validate_the_capture_disposition_window_popup_for_the_given_dispositions(String Pagename)
	{

		


		for (int i = 0; i < ProjectVariables.Dispositions.length; i++) {
			if(Pagename.equalsIgnoreCase("AWB"))
			{
				Assert.assertTrue("Capture Disposition Dropdown was unable to clicked in AWB page", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Capture Disposition")));
			}
			else if(Pagename.equalsIgnoreCase("Review Worked Opportunity"))
			{
				Assert.assertTrue("Update Disposition Dropdown was unable to clicked in Reviewed Worked OppPage", clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", "Update Disposition")));
			}

			switch(ProjectVariables.Dispositions[i])
			{

			case "Present":
				Validate_the_given_disposition_window_popup("Present","AWB",ProjectVariables.Present_Disposition_Reasons);
				break;
			case "Invalid":
				Validate_the_given_disposition_window_popup("Invalid","AWB",ProjectVariables.InvalidReasons);
				break;
		
			default:
				Assert.assertTrue("Case not found::"+ProjectVariables.Dispositions[i], false);
				break;

			}



		}


	}


	public void Validate_the_given_disposition_window_popup(String disposition, String pagename,String[] dispositionsReasons) {
		
		Assert.assertTrue("'"+disposition+"' option was uanble to clicked in the Capture Disposition dropdown in "+pagename+" Page", clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", disposition)));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		Assert.assertTrue("'"+disposition+"' header was not displayed,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", disposition)));
		if(disposition.equalsIgnoreCase("Present"))
		{
			Assert.assertTrue("'"+disposition+"' header was not displayed,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(labelcontainstext, "svalue", "Priority")));
			
			for (int i = 0; i < ProjectVariables.Present_Disposition_Priorities.length; i++) {
			
				Assert.assertTrue("'"+ProjectVariables.Present_Disposition_Priorities[i]+"' priority was not displayed,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Inputwithvalue, "text", ProjectVariables.Present_Disposition_Priorities[i])));
			}
		}
		
		Assert.assertTrue("'Reasons' header text was not displayed,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(labelcontainstext, "svalue", "Reasons")));

		Assert.assertTrue("'Choose one or more' text  was not displayed under 'Reasons',after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Choose one or more")));



		for (int i = 0; i < dispositionsReasons.length; i++) 
		{
			System.out.println(StringUtils.replace(Span_contains_value, "value","\""+dispositionsReasons[i]+"\"" ));
			Assert.assertTrue("'"+dispositionsReasons[i]+"' reason was not displayed in the '"+disposition+"' disposition window popup in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Span_contains_value, "value","\""+dispositionsReasons[i]+"\"")));

			Assert.assertTrue("'"+dispositionsReasons[i]+"' reason check box was unabled to select in the '"+disposition+"' disposition window popup in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(StringUtils.replace(Span_contains_value, "value","\""+dispositionsReasons[i]+"\"")));

			Assert.assertTrue("'"+dispositionsReasons[i]+"' reason check box was unabled to de-select in the '"+disposition+"' disposition window popup in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(StringUtils.replace(Span_contains_value, "value","\""+dispositionsReasons[i]+"\"")));

		}

		if(disposition.equalsIgnoreCase("Present"))
		{
			Assert.assertTrue("'Note' header was not displayed,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Div_with_class, "value", "notes")));

			Assert.assertTrue("Unable to enter the notes in the 'Note' section,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", Enter_given_Text_Element(StringUtils.replace(Div_with_class, "value", "notes")+"//textarea",ProjectVariables.Posted_DispositionNotes));

		}
		
		Assert.assertTrue("'Ok' button was not displayed in the window popup,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Ok")));

		Assert.assertTrue("'Cancel' button was not displayed in the window popup,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Cancel")));

		Assert.assertTrue("'Cancel' button was unable to clicked in the window popup,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Cancel")));
		defaultWait(ProjectVariables.TImeout_3_Seconds);


	}


	public void Validate_the_Topics_in_Opportunity_Grid_with_Mongo_DB(String client,String relase,String medicalpolicy) 
	{
		boolean bstatus=false;
				
		HashSet<String> Not_DisplayedTopiclist = new HashSet<>();
		/////////////////////////////////////
		int j=0;
		
	for (String DB_Topic : ProjectVariables.DB_Topiclist) {
		j=j+1;
		
		System.out.println(j+".Topic,Total Size==>"+ProjectVariables.DB_Topiclist.size());
		
	
		if(!DB_Topic.contains(":"))
		{
			Assert.assertTrue("Unable to enter the Topic "+DB_Topic+" in the search field of AWB Grid", Enter_given_Text_Element(sSearchField_AWB,DB_Topic.trim()));

			Assert.assertTrue("Unable to click the search icon beside search box in the AWB Grid", clickGivenXpath(AWBgriSearchbutton));

			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			 bstatus= is_WebElement_Visible(StringUtils.replace(labelcontainstext, "svalue",DB_Topic.trim()));
			
			if(!bstatus){
				bstatus=MongoDBUtils.Check_the_savings_for_the_given_DP(Serenity.sessionVariableCalled("clientkey"), relase, medicalpolicy,DB_Topic.trim(),"Topic");
				if(!bstatus)
				{
				
				Not_DisplayedTopiclist.add(String.valueOf(DB_Topic.trim()));
				}
			}
			
		}else
		{
			System.out.println("DB Topic contains ':' ,so if searched with topic in AWB grid,we have to give the additional space,after colon,Topic is ==>"+DB_Topic);
		}
		
			

		}
		

		Assert.assertTrue("Some Topics are not displaying in AWb Grid from Mongo DB as expected,Not available Topic count ==>"+Not_DisplayedTopiclist.size()+",Not available Topics are ==>"+Not_DisplayedTopiclist+",for the medical policy ==>"+medicalpolicy+",client ==>"+client+",release ==>"+relase+",DB Topiclist count ==>"+ProjectVariables.DB_Topiclist.size(),Not_DisplayedTopiclist.size()==0);


	}


	public void Validate_the_DPs_in_Opportunity_Grid_with_Mongo_DB(String client,String medicalpolicy,String pagename,List<Long> DB_DPKeylist) 
	{
		boolean bstatus=false;
		String xpath=null;
		HashSet<String> ValidDPlist = new HashSet<>();
		HashSet<String> UIDPlist = new HashSet<>();
		int j=0; 
		if(pagename.equalsIgnoreCase("eLL Tab"))
		{
			xpath="(//table[contains(@class,'grid-table')]//tr//td[5]/span)";
		}
		else
		{
			xpath="("+StringUtils.replace(Div_contains_class, "value", "dp-number")+"/button)";
		}
		
		
		int dpsize=get_Matching_WebElement_count(xpath);
		for (int i = 1; i <=dpsize; i++) {
			scrollingToGivenElement(getDriver(), xpath+"["+i+"]");
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			UIDPlist.add(get_TextFrom_Locator(xpath+"["+i+"]").trim());
		}
		
		for (Long DB_DPKey : DB_DPKeylist) {
			j=j+1;
			
			System.out.println(j+".DBDPkey::"+DB_DPKey+",Total Size==>"+DB_DPKeylist.size());
						
			 bstatus= UIDPlist.contains(String.valueOf(DB_DPKey));
			
				if(!bstatus)
				{
					ValidDPlist.add(String.valueOf(DB_DPKey));
				}
				else
				{
					System.out.println(j+".DPkey::"+DB_DPKey+" is displayed in "+pagename+" as expected with DB");
				}
		}
		
		

		Assert.assertTrue("Some DP's are not displaying in "+pagename+" from Mongo DB as expected,Not available DP count ==>"+ValidDPlist.size()+",Not available DP's are ==>"+ValidDPlist+",for the medical policy ==>"+medicalpolicy+",client ==>"+client+",DB DPKeylist count ==>"+DB_DPKeylist.size(),ValidDPlist.size()==0);


	}


	public void PerformTheScrollingOperation() {

		
			Doubleclick("//div[@id='jqxScrollBtnDownverticalScrollBarjqxOppGrid']");
			Doubleclick("//div[@id='jqxScrollBtnDownverticalScrollBarjqxOppGrid']");
		

	}


	public void Validate_topic_level_savings_data_in_the_Oppgrid_of_AWB_page(String client,String release,String medicalpolicy, String savingsstatus) 
	{

		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		String UITopicname=null;
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		HashSet<String> UITopiclist = new HashSet<>();


		//Connection method to Mongo DB
		MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

		int UI_topicssize=get_Matching_WebElement_count(Topicname_in_oppgrid);

		String Payershorts=get_TextFrom_Locator(payershorts_in_AWBPage);

		List<String> UIPayershortlist=Arrays.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));


		for (int i = 1; i <= UI_topicssize; i++)
		{
			System.out.println("UI Topiclist size in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topic size==>"+UI_topicssize);

			/*if(is_WebElement_Displayed(Topicname_in_oppgrid+"["+i+"]"))
			{*/
				scrollingToGivenElement(getDriver(), Topicname_in_oppgrid+"["+i+"]");
				UITopicname=get_TextFrom_Locator(Topicname_in_oppgrid+"["+i+"]");


				if(!UITopiclist.contains(UITopicname))
				{
					System.out.println(i+"."+UITopicname);
					//String savingslocator=StringUtils.replace(savings_in_oppgrid, "value", "\""+UITopicname.trim()+"\"");


					UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(savings_in_oppgrid, "value", UITopicname.trim())+"[3]").trim());
					UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(savings_in_oppgrid, "value", UITopicname.trim())+"[4]").trim());
					//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(savings_in_oppgrid, "value", UITopicname.trim())+"[5]").trim());
					UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(savings_in_oppgrid, "value", UITopicname.trim())+"[5]").trim());

					if(UITopicname.contains("'"))
					{
						UITopicname=StringUtils.substringBefore(UITopicname, "(").trim();
					}
					
					
					//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
					MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page( UIPayershortlist,medicalpolicy, UITopicname, "", savingsstatus, "AWBGrid");


					Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at topic level in the oppgrid of AWB Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));

					Assert.assertTrue("UIAggsavings data was not matched with DB_Aggsavings at topic level in the oppgrid of AWB Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));

					//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at topic level in the oppgrid of AWB Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));

					Assert.assertTrue("UIEdits data was not matched with DB_Edits at topic level in the oppgrid of AWB Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));

					System.out.println("All the Savings data was matching with DB_Savings at topic level in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",UI Topic size ==>"+UI_topicssize+",Topic number ==>"+i);

					UITopiclist.add(UITopicname);



				}

			/*}
			else
			{
				Click_Untill_Element_is_not_displayed_with_the_given_time(10,Verticlescrollbtn_in_Oppgrid,Verticalscrollbar_Freespace);
				UI_topicssize=get_Matching_WebElement_count(Topicname_in_oppgrid);
				i=1;
			}*/
		}



	}

	public void Validate_the_DPLevel_PayershortLevel_savings_data_in_Opportunity_Grid_of_AWB_Page_with_Mongo_DB(String client,String release,String medicalpolicy,String AWBGridlevel, String savingsstatus) 
	{
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		int j=0;
		boolean bstatus=false;
		List<String> UI_Payershort=new ArrayList<>();
		String UITopicname=null;
		String UIRawsavings=null;
		String UIAggsavings=null;
		String UIConsavings=null;
		String UIEdits=null;
		String UIPayershort=null;

		defaultWait(ProjectVariables.TImeout_2_Seconds);

		bstatus=Wait_Untill_Element_is_displayed(20,Topicname_in_oppgrid);
		
		if(savingsstatus.equalsIgnoreCase("Production")&&!bstatus)
		{
			System.out.println("Topic level data was not displaying in the AWB Grid for the savings status '"+savingsstatus+"'");
		}
		else
		{
			Assert.assertTrue("Topic level data was not displaying in the AWB Grid for the savings status '"+savingsstatus+"'",bstatus);	
			//Capturing the dpkeys from Oppgrid of AWB Page
			Capturing_the_DPkeys_from_the_oppgrid_of_AWB_page("");

			//Connecting to Mongo DB
			MongoDBUtils.retrieveAllDocuments("cpd", "oppty");

			String Payershorts=get_TextFrom_Locator(payershorts_in_AWBPage);

			List<String> UIPayershortlist=Arrays.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));

			switch(AWBGridlevel)
			{
			case "DPLevel":

				for (String UIDPkey : ProjectVariables.UIDPKeylist) 
				{
					j=j+1;
					
					if(UIDPkey.length()!=2)
					{
						System.out.println("UI DPKey size '"+j+"' in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",DPs size==>"+ProjectVariables.UIDPKeylist.size());

						Assert.assertTrue("unable to enter the DPKey in the search box in the Opportunity grid of AWB Page for the DPkey ==>"+UIDPkey, Enter_given_Text_Element(sSearchField_RWOpp, UIDPkey));

						Assert.assertTrue("unable to click the search button in the Opportunity grid of AWB Page for the DPkey ==>"+UIDPkey, clickGivenXpath(AWBgriSearchbutton));

						defaultWait(ProjectVariables.TImeout_2_Seconds);

						Assert.assertTrue("unable to click the Topic chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
						defaultWait(ProjectVariables.TImeout_3_Seconds);
						
						//String savingslocator=StringUtils.replace(savings_in_oppgrid, "value", UIDPkey.trim());

						UITopicname=get_TextFrom_Locator(Topicname_in_oppgrid);
						int payersize=get_Matching_WebElement_count(StringUtils.replace(Payershortssize_basedon_DPkey, "dpkey", UIDPkey));


						/*for (int i = 0; i < array.length; i++) {

						}*/
						
						if(!UITopicname.contains("'"))
						{
						
							UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(DPsavings_in_oppgrid, "value", UIDPkey.trim())+"[3]").trim());
							UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(DPsavings_in_oppgrid, "value", UIDPkey.trim())+"[4]").trim());
							//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(DPsavings_in_oppgrid, "value", UIDPkey.trim())+"[5]").trim());
							UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(DPsavings_in_oppgrid, "value", UIDPkey.trim())+"[5]").trim());

						//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
						MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(UIPayershortlist,medicalpolicy, UITopicname, UIDPkey, savingsstatus, "AWBGrid");


						Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at DP level in the oppgrid of AWB Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));

						Assert.assertTrue("UIAggsavings data was not matched with DB_Aggsavings at DP level in the oppgrid of AWB Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));

						//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at DP level in the oppgrid of AWB Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));

						Assert.assertTrue("UIEdits data was not matched with DB_Edits at DP level in the oppgrid of AWB Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));

						System.out.println("All the Savings data was matching with DB_Savings at DP level in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
						else
						{
							System.out.println("Topicname contains (')-singlequote in the oppgrid of AWB Page,which is not able to filter in mongoDB,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
						}
					}
					else
					{
						System.out.println("DP key length is two in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);
					}
				
				}

				break;
			case "Payershort Level":



				for (String UIDPkey : ProjectVariables.UIDPKeylist) 
				{
					j=j+1;
					System.out.println("UI DPKey size '"+j+"' in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",DPs size==>"+ProjectVariables.UIDPKeylist.size());


					Assert.assertTrue("unable to enter the DPKey in the search box in the Opportunity grid of AWB Page for the DPkey ==>"+UIDPkey, Enter_given_Text_Element(sSearchField_RWOpp, UIDPkey));

					Assert.assertTrue("unable to click the search button in the Opportunity grid of AWB Page for the DPkey ==>"+UIDPkey, clickGivenXpath(AWBgriSearchbutton));

					defaultWait(ProjectVariables.TImeout_2_Seconds);

					Assert.assertTrue("unable to click the Topic chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					
					UITopicname=get_TextFrom_Locator(Topicname_in_oppgrid);
					int payersize=get_Matching_WebElement_count(StringUtils.replace(Payershortssize_basedon_DPkey, "dpkey", UIDPkey));

					if(UITopicname.contains("("))
					{
						UITopicname=StringUtils.substringBefore(UITopicname, "(").trim();
					}

					

					for (int i = 1; i <= payersize; i++) {

						//UIPayershortlist.clear();
						UIPayershort=get_TextFrom_Locator(StringUtils.replace(Payershortssize_basedon_DPkey, "dpkey", UIDPkey)+"["+i+"]").trim();
						UI_Payershort.add(UIPayershort);
						//String savingslocator=StringUtils.replace(payershortsavings_in_oppgrid, "payer", UIPayershort.trim());


						UIRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[2]").trim());
						UIAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[3]").trim());
						//UIConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[4]").trim());
						UIEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(payershortsavings_in_oppgrid, "payer", UIPayershort.trim())+"[4]").trim());

						//Method to retrieve savings based on the medicalpolicy/topic/dp's in oppgrid of AWB Page
						MongoDBUtils.AggregateMethod_in_Mongo_DB_For_AWB_Page(UI_Payershort,medicalpolicy, UITopicname, UIDPkey, savingsstatus, "AWBGrid");


						Assert.assertTrue("UI_Rawsavings data was not matched with DB_Rawsavings at payershort level in the oppgrid of AWB Page,UI_Rawsavings ==> "+UIRawsavings+",DB_Rawsavings "+ProjectVariables.RawSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",Payershort ==>"+UIPayershort,UIRawsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.RawSavings.get(0))));

						Assert.assertTrue("UIAggsavings data was not matched with DB_Aggsavings at payershort level in the oppgrid of AWB Page,UIAggsavings ==> "+UIAggsavings+",DB_Aggsavings "+ProjectVariables.AggSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",Payershort ==>"+UIPayershort,UIAggsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.AggSavings.get(0))));

						//Assert.assertTrue("UIConsavings data was not matched with DB_Consavings at payershort level in the oppgrid of AWB Page,UIConsavings ==> "+UIConsavings+",DB_Consavings "+ProjectVariables.ConSavings+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",Payershort ==>"+UIPayershort,UIConsavings.equalsIgnoreCase(String.valueOf(ProjectVariables.ConSavings.get(0))));

						Assert.assertTrue("UIEdits data was not matched with DB_Edits at payershort level in the oppgrid of AWB Page,UIEdits ==> "+UIEdits+",DB_Edits "+ProjectVariables.Edits+",for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",Payershort ==>"+UIPayershort,UIEdits.equalsIgnoreCase(String.valueOf(ProjectVariables.Edits.get(0))));

						System.out.println("All the Savings data was matching with DB_Savings at payershort level in the oppgrid of AWB Page,for the Client ==>"+client+",Release ===>"+release+",medicalpolicy ==>"+medicalpolicy+",Topicname==>"+UITopicname+",DPkey ==>"+UIDPkey+",DPKey list size ==>"+ProjectVariables.UIDPKeylist.size()+",DPKey number ==>"+j);

						UI_Payershort.clear();
					}



				}

				break;
			default:
				Assert.assertTrue("Given selection was not found ==>"+AWBGridlevel, false);
			break;
			
			}

		}
		

		



	}

	public void Capturing_the_DPkeys_from_the_oppgrid_of_AWB_page(String pagename) {

		ProjectVariables.UIDPKeylist.clear();
		String xpath=null;
		
		int j=0; 
		if(pagename.equalsIgnoreCase("eLL"))
		{
			xpath="(//table[contains(@class,'grid-table')]//tr//td[3]/span)";
		}
		else
		{
			xpath="("+StringUtils.replace(Div_contains_class, "value", "dp-number")+"/button)";
		}
		
		
		int dpsize=get_Matching_WebElement_count(xpath);
		for (int i = 1; i <=dpsize; i++) {
			scrollingToGivenElement(getDriver(), xpath+"["+i+"]");
			defaultWait(ProjectVariables.TImeout_2_Seconds);
			ProjectVariables.UIDPKeylist.add(get_TextFrom_Locator(xpath+"["+i+"]").trim());
		}


		System.out.println("UIDPKeylist ==>"+ProjectVariables.UIDPKeylist);
		System.out.println("UIDPKeysize ==>"+ProjectVariables.UIDPKeylist.size());

	}

	public void ApplyFilters(String sHeadearItem,String sSelectItem,String sChbk_Operation,String sApplyFilters){
		try{

			String sChbk_HeadearChild="(//div[contains(@class,'headerRow')]/..//span[.='"+sHeadearItem+"']/..//..//div[contains(@class,'body')])[1]/..//span[.='"+sSelectItem+"']/..//input";
			boolean sItem = getDriver().findElement(By.xpath(sChbk_HeadearChild)).isSelected();	
			//Check Condition
			if((!sItem) && (sChbk_Operation=="CHECK")){
				getDriver().findElement(By.xpath(sChbk_HeadearChild)).click();
			}
			//UnCheck Condition
			if((sItem) && (sChbk_Operation=="UNCHECK")){
				getDriver().findElement(By.xpath(sChbk_HeadearChild)).click();
			}
			//Click on 'Apply Filters'
			if(!sApplyFilters.isEmpty()){
				oGenericUtils.clickButton(By.xpath(sApplyFilters));
			}


		}catch(Exception e){
			GenericUtils.Verify("Object not clicked Successfully , Failed due to :="+e.getMessage(),"FAILED");
		}
	}

	public void SelectPayer(String sRunDate,String sPayer){
		try{
			//Click 'Client/Payer'
			String sClientPayer="(//div[contains(@class,'mx-listview-clickable mx-name-listView_Client')])//label[contains(text(),'"+sPayer+"')]/../../..//label[text()='"+sRunDate+"']";
			oGenericUtils.clickOnElement(sClientPayer);

			//Loading POPUP
			//oAppUtils.WaitUntilPageLoad();
			//Verify MedicalPolicy screen
			oGenericUtils.IsElementExistWithContains("span", sPayer);
			//oAppUtils.WaitUntilPageLoad();
		}catch(Exception e){
			GenericUtils.Verify("Object not clicked Successfully , Failed due to :="+e.getMessage(),"FAILED");
		}
	}

	public void Perform_the_capture_disposition_operation(String disposition, String dispositionreasons,
			String dispositionnotes,String pagename,String sRulerelations) throws InterruptedException {

		AppUtils oAppUtils=this.switchToPage(AppUtils.class);
		String dispositionxpath=null;
		
		//validating Capture disposition window popup
		validate_the_capture_disposition_dropdown(pagename);
		if(pagename.equalsIgnoreCase("RWO"))
		{
			dispositionxpath="//button[contains(text(),'"+disposition+"')][@role='menuitem']";
		}
		else
		{
			dispositionxpath="//div[contains(@class,'disposition')]/..//button[contains(text(),'"+disposition+"')]";
		}
		
		Assert.assertTrue("'"+disposition+"' disposition is unable to clicked in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(dispositionxpath));	
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		
		if(disposition.equalsIgnoreCase("Present"))
		{
			Assert.assertTrue("Priority 'High' radio button is not selected by default,it should be selected in the Present Capture disposition window of "+pagename+"", is_WebElement_Selected("//input[@value='High']"));
			
			Assert.assertTrue("Prioriy '"+ProjectVariables.Priority+"' radio button was unable to clicked in the '"+disposition+"' disposition window popup in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(StringUtils.replace(Div_contains_text, "value", ProjectVariables.Priority)));
		}
		
		if(!disposition.equalsIgnoreCase("Not Reviewed"))
		{
			clickGivenXpath(StringUtils.replace(Span_contains_value, "value","\""+dispositionreasons+"\""));
		}
		
		if(disposition.equalsIgnoreCase("Present"))
		{
		Assert.assertTrue("Unable to enter the notes in the notes textarea of '"+disposition+"' disposition window popup in the Capture Disposition dropdown of "+pagename+" Page", Enter_given_Text_Element(StringUtils.replace(Div_with_class, "value", "notes")+"//textarea", dispositionnotes));
		}

		Assert.assertTrue("Unable to click the 'Ok' button in the window popup,after clicking on the disposition '"+disposition+"' in the Capture Disposition dropdown of "+pagename+" Page", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Ok")));
		
		if(sRulerelations!=null)
		{
			//verify rulerelation alert in awb page after capturing disposition
			//verifyRulerelationalert(sRulerelations);
		}
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
		
		//Wait untill the given time or the given xpath is not displayed
		Assert.assertFalse("Unable to capture the disposition as the disposition popup is still displaying after clicking on OK button in CPW ",is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Ok")));



	}

	private void verifyRulerelationalert(String sRulerelations) 
	{
		String sAlertmessage=null;
		boolean bstatus=false;
		int icount=0;
		switch(sRulerelations)
		{
		case "Companion":
		case "Counterpart":
		case "Out of Sequence":
			sAlertmessage=ProjectVariables.Rulerelationshipalert1;
		break;
		case "Mutually Exclusive":
			sAlertmessage=ProjectVariables.Rulerelationshipalert2;
		break;
		case "Out of Sequence+Mutually Exclusive":
		case "Counterpart+Mutually Exclusive":
		case "Companion+Mutually Exclusive":
			sAlertmessage=ProjectVariables.Rulerelationshipalert3;
		break;
		default:
			Assert.assertTrue("Case not found::"+sRulerelations, false);
		break;
		}
		do
		{
			icount=icount+1;
			bstatus=is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", sAlertmessage));
			if(icount==20)
			{
				break;
			}
		}while(!bstatus);
		
		GenericUtils.Verify("Rulerelationship alert should be displayed after capturing disposition for dpkey::"+Serenity.sessionVariableCalled("DPkey"), bstatus);
		
	}

	public void Intialaize_the_Dispositions_fields_to_post(String postedOpportunity) {

		switch(postedOpportunity)
		{
		case "Present":

			ProjectVariables.Disposition="Present";
			ProjectVariables.DispositionReasons="High Savings";


			break;
		case "Do Not Present - CPM Review":

			ProjectVariables.Disposition="Do Not Present - CPM Review";
			ProjectVariables.DispositionReasons="Adverse quality score impact";


			break;
		case "Do Not Present":

			ProjectVariables.Disposition="Do Not Present";
			ProjectVariables.DispositionReasons="Adverse quality score impact";


			break;
			
		case "Invalid":

			ProjectVariables.Disposition="Invalid";
			ProjectVariables.DispositionReasons="Mutually exclusive DP";


			break;

		case "Not Reviewed":

			ProjectVariables.Disposition="Not Reviewed";
			ProjectVariables.DispositionReasons="";


			break;

		default:
			Assert.assertTrue("Given selection '"+postedOpportunity+"' was not found in the switch case method======>Intialaize_the_Dispositions_fields_to_post", false);
			break;

		}



	}


	public void verify_the_captured_data_is_not_displayed_in_the_given(ArrayList<String> CaptureddataList,String capturedtypeofdata,String Pagename) {
		
		
		if(!is_WebElement_Displayed(StringUtils.replace(Div_contains_text, "value", "No results found that meet the search criteria.")))
		{
			//To capture All dpkeys displayed in UI
			Capturing_the_DPkeys_from_the_oppgrid_of_AWB_page(Pagename);
						
			for (String Captureddata : CaptureddataList) {
				if(ProjectVariables.UIDPKeylist.contains(Captureddata.trim()))
				{
					Assert.assertTrue("DPkey '"+Captureddata+"' is still displayed eventhough it's captured in "+Pagename, false);
				}
				else
				{
					System.out.println("DPkey '"+Captureddata+"' is not displayed as expected bcz it's captured in "+Pagename);
				}
			}

		}
		else
		{
			System.out.println("All DPs are captured in the '"+Pagename+"' Grid......................");
		}
		
		


	


	}


	public void validate_the_captured_pps_with_mongo_DB(String disposition,ArrayList<String> CaptureddataList,String capturedtypeofdata) {

		Assert.assertTrue("subrule count is not matching between the count before capturing and after capturing the disposition, for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition+",Expected ==>"+ProjectVariables.DB_Nodisposition_subRuleList+",Actual ==>"+ProjectVariables.DB_subRuleList+",Expected Rules size ==>"+ProjectVariables.DB_Nodisposition_subRuleList.size()+",Actual Rules size ==>"+ProjectVariables.DB_subRuleList.size(), ProjectVariables.DB_Nodisposition_subRuleList.size()==ProjectVariables.DB_subRuleList.size());

		Assert.assertTrue("insurances count is not matching between the count before capturing and after capturing the disposition, for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition+",Expected ==>"+ProjectVariables.DB_Nodisposition_insuranceList+",Actual ==>"+ProjectVariables.DB_insuranceList, ProjectVariables.DB_Nodisposition_insuranceList.size()==ProjectVariables.DB_insuranceList.size());

		Assert.assertTrue("claimtypes count is not matching between the count before capturing and after capturing the disposition, for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition+",Expected ==>"+ProjectVariables.DB_Nodisposition_claimtypeList+",Actual ==>"+ProjectVariables.DB_claimtypeList, ProjectVariables.DB_Nodisposition_claimtypeList.size()==ProjectVariables.DB_claimtypeList.size());

		Assert.assertTrue("Dpkeys count is not matching between the count before capturing and after capturing the disposition, for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition+",Expected ==>"+ProjectVariables.DB_Nodisposition_DpkeyList+",Actual ==>"+ProjectVariables.DB_DpkeyList, ProjectVariables.DB_Nodisposition_DpkeyList.size()==ProjectVariables.DB_DpkeyList.size());

		//Comparing the PPS lists between before and after capturing the data
		compare_the_given_list_of_data_for_capture_disposition_fucntionality(ProjectVariables.DB_Nodisposition_subRuleList,ProjectVariables.DB_subRuleList,CaptureddataList,capturedtypeofdata,disposition,"subrule");

		compare_the_given_DP_list_of_data_for_capture_disposition_fucntionality(ProjectVariables.DB_Nodisposition_DpkeyList,ProjectVariables.DB_DpkeyList,CaptureddataList,capturedtypeofdata,disposition,"DPkey");

		compare_the_given_list_of_data_for_capture_disposition_fucntionality(ProjectVariables.DB_Nodisposition_insuranceList,ProjectVariables.DB_insuranceList,CaptureddataList,capturedtypeofdata,disposition,"Insurance");

		compare_the_given_list_of_data_for_capture_disposition_fucntionality(ProjectVariables.DB_Nodisposition_claimtypeList,ProjectVariables.DB_claimtypeList,CaptureddataList,capturedtypeofdata,disposition,"Claimtype");


	}

	private void compare_the_given_list_of_data_for_capture_disposition_fucntionality(HashSet<String> ExpectedList,HashSet<String> ActualList,ArrayList<String> CaptureddataList,String capturedtypeofdata,String disposition,String PPSType) {

		for (String Expecteddata : ExpectedList) {

			if(!ActualList.contains(Expecteddata))
			{
				Assert.assertTrue(""+PPSType+" is not matching between before capturing and after capturing the disposition,Expected ==>"+Expecteddata+",Actual List==>"+ActualList+", for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition, false);	
			}


		}





	}

	private void compare_the_given_DP_list_of_data_for_capture_disposition_fucntionality(HashSet<Long> ExpectedList,HashSet<Long> ActualList,ArrayList<String> CaptureddataList,String capturedtypeofdata,String disposition,String PPSType) {

		for (Long Expecteddata : ExpectedList) {

			if(!ActualList.contains(Expecteddata))
			{
				Assert.assertTrue(""+PPSType+" is not matching between before capturing and after capturing the disposition,Expected ==>+"+Expecteddata+",Actual List==>"+ActualList+", for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+CaptureddataList+",Captured Disposition ==>"+disposition, ProjectVariables.DB_Nodisposition_subRuleList.size()==ProjectVariables.DB_subRuleList.size());	
			}


		}





	}

	public void validate_the_captured_pps_in_review_worked_opportunity_page(String disposition,ArrayList<String> CaptureddataList,String capturedtypeofdata,String Pagename) {
		
	
		ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage=this.switchToPage(ReviewWorkedOpportunityPage.class);
		
		
		if(Pagename.equalsIgnoreCase("RWO"))
		{
			//click on review worked opportunity button and check the page is opening or not
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			//Selecting the checkboxes in the RWO Page
			oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
			
		}
		for (String Captureddata : CaptureddataList) 
		{
			if(capturedtypeofdata.contains("DP")&&Captureddata.length()<4)
			{
				System.out.println("Captured DPkey length < '4',so we are not searching that to eliminate duplicate data,DPkey===>"+Captureddata);
			}
			else
			{
				//Validating the captured disposition is displaying or not in the Grid
				verify_the_given_disposition_is_displayed_in_Review_Worked_OppGrid(disposition,Captureddata,capturedtypeofdata);
			}
		}
		
		/*if(capturedtypeofdata.equalsIgnoreCase("DPkeys"))
		{
			
			Assert.assertTrue("Unable to enter the "+capturedtypeofdata+" in the search field of Reviewwoked Opportunity Page,"+capturedtypeofdata+" ===>"+CaptureddataList.get(0), Enter_given_Text_Element(sSearchField_RWOpp,CaptureddataList.get(0)));

			Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));

			defaultWait(ProjectVariables.TImeout_5_Seconds);
			
			orefOpportunityRunsPage.click_the_given_cheveron(capturedtypeofdata,"up");
			
			defaultWait(ProjectVariables.TImeout_5_Seconds);

			//verify_the_given_disposition_is_displayed_in_DPWB_Page(disposition,CaptureddataList.get(0),capturedtypeofdata);
			
		}*/
		
		
		
		
	
		
		
		
	}

	private void verify_the_given_disposition_is_displayed_in_DPWB_Page(String disposition,String Captureddata, String capturedtypeofdata) {
		
		AppUtils oAppUtils=this.switchToPage(AppUtils.class);
		
		Assert.assertTrue("Unable to click the "+capturedtypeofdata+" in the Reviewwoked Opportunity Page, "+capturedtypeofdata+" ==>"+Captureddata, clickGivenXpath(StringUtils.replace(ButtonContainsText, "value",Captureddata)));
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		Assert.assertTrue(""+capturedtypeofdata+" was not displayed in the DP WorkbenchPage,after clicking on that in Review Worked Opp Page "+capturedtypeofdata+" ==>"+Captureddata, Wait_Untill_Element_is_displayed(10, StringUtils.replace(Text_contains_header3, "value", Captureddata)));
		
		String Disp_in_DPWB=StringUtils.substringBefore(get_TextFrom_Locator(Disposition_in_DPWB), "Disposition").trim();
	
		if(!Disp_in_DPWB.equalsIgnoreCase(disposition))
		{
			if(!Disp_in_DPWB.equalsIgnoreCase("Multiple"))
			{
				Assert.assertTrue("Disposition displayed in the DPWB is not matching with captured disposition,Expected ==>"+disposition+",Actual ===>"+Disp_in_DPWB+",for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+Captureddata+",MedicalPolicy ==>"+Serenity.sessionVariableCalled("Medicalpolicy"), false);	
			}
			
		}
		
		Assert.assertTrue("Unable to click the Worked Opportunity link in the DPWBPage,"+capturedtypeofdata+" ==>"+Captureddata, clickGivenXpath(StringUtils.replace(anchorTag_with_text, "value","Worked Opportunities")));
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		
		Assert.assertTrue("Worked Opportunities header is not displaying in the Review WorkedOpp Page,after clicking on that link in DPWB Page "+capturedtypeofdata+" ==>"+Captureddata, Wait_Untill_Element_is_displayed(10, WorkedOpportunityHeader));
	
		
	}

	private void verify_the_given_disposition_is_displayed_in_Review_Worked_OppGrid(String disposition,String Captureddata, String capturedtypeofdata) {
		
		int iCaptureddataSize=0;
		OpportunityRunsPage oOpportunityRunsPage=this.switchToPage(OpportunityRunsPage.class);
		String ExpectedDisposition=null;
		ExpectedDisposition=disposition;
		
		int dispositionsize=0;
		String Dispositionlocator=null;
		
		Assert.assertTrue("Unable to enter the "+capturedtypeofdata+" in the search field of Reviewwoked Opportunity Page,"+capturedtypeofdata+" ===>"+Captureddata, Enter_given_Text_Element(sSearchField_RWOpp,Captureddata));

		Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));

		defaultWait(ProjectVariables.TImeout_5_Seconds);
		
		oOpportunityRunsPage.click_the_given_cheveron(capturedtypeofdata,"up");
		
		defaultWait(ProjectVariables.TImeout_5_Seconds);
		
		if(capturedtypeofdata.contains("DP")||capturedtypeofdata.contains("Payershort"))
		{
			iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(ButtonContainsText, "value",Captureddata));
		}
		else
		{
			iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(labelcontainstext, "svalue",Captureddata));
		}
		
		if(iCaptureddataSize>=1)
		{
			if(capturedtypeofdata.contains("DP")||capturedtypeofdata.contains("Payershort"))
			{
				Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata+",Disposition ==>"+disposition, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",Captureddata)));
			}
			else
			{
				Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata+",Disposition ==>"+disposition, is_WebElement_Displayed(StringUtils.replace(labelcontainstext, "svalue",Captureddata)));	
			}
			
			if(capturedtypeofdata.equalsIgnoreCase("Medical Policy"))
			{
				Assert.assertTrue("unable to click the Topic chevron", clickGivenXpath("//div[@class='topic-box']//fa-icon"));
			}
			
			//((//label[contains(text(),'Clinician-Administered Drugs - Infliximab (J1745, Q5103, Q5104')]/ancestor::tr/following-sibling::tr)/td[11]/button)
			
			if(capturedtypeofdata.contains("DP")||capturedtypeofdata.contains("Payershort"))
			{
				dispositionsize=get_Matching_WebElement_count("(//button[contains(text(),'"+Captureddata+"')]/ancestor::tr/following-sibling::tr/td[11]/button)");
				Dispositionlocator="(//button[contains(text(),'"+Captureddata+"')]/ancestor::tr/following-sibling::tr/td[11]/button)";
			}
			else
			{
				dispositionsize=get_Matching_WebElement_count("((//label[contains(text(),'"+Captureddata+"')]/ancestor::tr/following-sibling::tr)/td[11]/button)");
				Dispositionlocator="((//label[contains(text(),'"+Captureddata+"')]/ancestor::tr/following-sibling::tr)/td[11]/button)";
			}
				
			
			
			if(!capturedtypeofdata.equalsIgnoreCase("Payershort"))
			{
				for (int i = 1; i <= dispositionsize-1; i++) 
				{
					scrollingToGivenElement(getDriver(), Dispositionlocator+"["+i+"]");
					defaultWait(ProjectVariables.TImeout_2_Seconds);
					String currentDisposition=get_TextFrom_Locator(Dispositionlocator+"["+i+"]");
					
					if(currentDisposition.equalsIgnoreCase("Multiple"))
					{
						disposition="Multiple";
					}
					else
					{
						disposition=ExpectedDisposition;
					}
					//!Disp_in_DPWB.equalsIgnoreCase(disposition)&&!Disp_in_DPWB.equalsIgnoreCase("Multiple")
					if(!currentDisposition.equalsIgnoreCase(disposition))
					{
						Assert.assertTrue("Current Disposition column data are not matching with captured disposition in Review Worked OppPage,Expected ==>"+disposition+",Actual ===>"+currentDisposition+",for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+","+capturedtypeofdata+"===>"+Captureddata, false);
					}
					
				}
			}
			else
			{
				
				for (int i = 0; i <ProjectVariables.sGetPayershorts.size(); i++) 
				{
					String currentDisposition=get_TextFrom_Locator("(//button[contains(text(),'"+ProjectVariables.sGetPayershorts.get(i)+"')]/ancestor::td/following-sibling::td)[6]//button");
					
					//!Disp_in_DPWB.equalsIgnoreCase(disposition)&&!Disp_in_DPWB.equalsIgnoreCase("Multiple")
					if(!currentDisposition.equalsIgnoreCase(disposition))
					{
						Assert.assertTrue("Current Disposition column data are not matching with captured disposition in Review Worked OppPage,Expected ==>"+disposition+",Actual ===>"+currentDisposition+",for the client ==>"+Serenity.sessionVariableCalled("client")+",release ==>"+Serenity.sessionVariableCalled("release")+",DPKey===>"+Captureddata+",Payershorts ==>"+ProjectVariables.sGetPayershorts.get(i), false);
					}
					
				}
				
			}
		}
		else if(iCaptureddataSize==0)
		{
			Assert.assertTrue("Captured "+capturedtypeofdata+" count is showing as 'zero' in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata, false);
		}
		else
		{
			System.out.println("Captured "+capturedtypeofdata+" is  showing as 'Multiple' count in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata+",Disposition ==>"+disposition);
		}
		
		
		
		
	}


	public void validate_the_update_disposition_funtionality_for_captured_pps_in_review_worked_opportunity_page(String Updatedisposition,ArrayList<String> CaptureddataList,String capturedtypeofdata) throws InterruptedException {

		int iCaptureddataSize=0;
		String Captureddata=CaptureddataList.get(0);
		
		//for (String Captureddata : CaptureddataList) {
			Assert.assertTrue("Unable to enter the "+capturedtypeofdata+" in the search field of Reviewwoked Opportunity Page,"+capturedtypeofdata+" ===>"+Captureddata, Enter_given_Text_Element(sSearchField_RWOpp,Captureddata));

			Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));

			defaultWait(ProjectVariables.TImeout_2_Seconds);
			
			oOpportunityRunsPage.click_the_given_cheveron(capturedtypeofdata,"up");
			
			if(capturedtypeofdata.equalsIgnoreCase("DPKey")||capturedtypeofdata.contains("DPkeys"))
			{
				iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(ButtonContainsText, "value",Captureddata));
			}
			else
			{
				iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(labelcontainstext, "svalue",Captureddata));
			}
			
			if(iCaptureddataSize>=1)
			{
			
				if(capturedtypeofdata.equalsIgnoreCase("DPKey")||capturedtypeofdata.contains("DPkey"))
				{
					Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",Captureddata)));
				}
				else
				{
					Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata, is_WebElement_Displayed(StringUtils.replace(labelcontainstext, "svalue",Captureddata)));	
				}
				
				//Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata, is_WebElement_Displayed(StringUtils.replace(Div_with_text, "value",Captureddata)));
				
				
				if(capturedtypeofdata.equalsIgnoreCase("DPKey")||capturedtypeofdata.contains("DPkey"))
				{
					Assert.assertTrue("Unable to click the "+capturedtypeofdata+" ===>"+Captureddata+" checkbox in the  Review WorkedOpp Page", clickGivenXpath("//button[contains(text(),'"+Captureddata+"')]/../..//input"));	
				}
				else
				{
					Assert.assertTrue("Unable to click the "+capturedtypeofdata+" ===>"+Captureddata+" checkbox in the  Review WorkedOpp Page", clickGivenXpath("//label[contains(text(),'"+Captureddata+"')]/../..//input"));
				}
				
				
				
				//Capturing the disposition operation for the given client,release and disposition
				Perform_the_capture_disposition_operation(Updatedisposition, ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"Review Worked Opportunity","");
				
				//Validating the captured disposition is displaying or not in the Grid
				verify_the_given_disposition_is_displayed_in_Review_Worked_OppGrid(Updatedisposition,Captureddata,capturedtypeofdata);
				
				if(capturedtypeofdata.equalsIgnoreCase("DPKey")||capturedtypeofdata.contains("DPkey"))
				{
					verify_the_given_disposition_is_displayed_in_DPWB_Page(Updatedisposition,CaptureddataList.get(0),capturedtypeofdata);
					
				}
			}
			else if(iCaptureddataSize==0)
			{
				Assert.assertTrue("Captured "+capturedtypeofdata+" count is showing as 'zero' in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata, false);
			}
			else
			{
				System.out.println("Captured "+capturedtypeofdata+" count is showing as 'Multiple' in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+Captureddata);
			}
		//}
	}


	public ArrayList<String> SelectPayershortsInOpportunityGridofAWBPage(String string, int payercount) {
		boolean status=false;
		boolean payershortstatus=false;
		String DPKey=null;
		List<String> UIPayershortlist=null;
		int Payershortsize=0;
		String payershort=null;
		ArrayList<String> selectedPayershorts=new ArrayList<>();
		int z=0;
	
		System.out.println(is_WebElement_Displayed(WorkedOpportunityHeader));
		
		if(!is_WebElement_Displayed(WorkedOpportunityHeader))
		{
			String Payershorts=oOpportunityRunsPage.get_TextFrom_Locator(oOpportunityRunsPage.payershorts_in_AWBPage);
			UIPayershortlist=Arrays.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));
			Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			 DPKey=get_TextFrom_Locator(DPKey_in_Oppgrid+"[1]");
			Serenity.setSessionVariable("DPKey").to(DPKey);
			Assert.assertTrue("Unable to enter the DPKey in the search field of AWB Page,DPKEY ===>"+DPKey, Enter_given_Text_Element(sSearchField_AWB,DPKey));
			Assert.assertTrue("Unable to click the search icon beside search box in the AWB Page", clickGivenXpath(AWBgriSearchbutton));
			//defaultWait(ProjectVariables.TImeout_2_Seconds);
			//Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("DPKey '"+DPKey+"' is not displaying in the AWB Grid after searching,DPKEY ===>"+DPKey, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",DPKey)));
		
			for (int j = 0; j < UIPayershortlist.size(); j++) 
			{
				status=is_WebElement_Displayed(StringUtils.replace(Payershort_chkbox_AWB,"payer",UIPayershortlist.get(j).trim()));
				if(status)
				{
					Assert.assertTrue("Unable to click the payerhshort '"+UIPayershortlist.get(j).trim()+"' checkbox in the Oppgrid of AWB Page", clickGivenXpath(StringUtils.replace(Payershort_chkbox_AWB,"payer",UIPayershortlist.get(j).trim())));
					selectedPayershorts.add(UIPayershortlist.get(j).trim());
					z=z+1;
				}
				if(z==payercount)
				{
					payershortstatus=true;
					break;
				}
			}
			if(!payershortstatus)
			{
				Assert.assertTrue("Unable to click the given count '"+payercount+"' of payershort checkboxes in the Oppgrid of AWB Page,for the DPKEy =>"+DPKey, false);
			}
    	}	
	    else
		{
	    	Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of RWO Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
	    	defaultWait(ProjectVariables.TImeout_3_Seconds);
			 DPKey=get_TextFrom_Locator(DPKey_in_Oppgrid+"[1]");
			Serenity.setSessionVariable("DPKey").to(DPKey);
			Assert.assertTrue("Unable to enter the DPKey in the search field of RWO Page,DPKEY ===>"+DPKey, Enter_given_Text_Element(sSearchField_RWOpp,DPKey));
			Assert.assertTrue("Unable to click the search icon beside search box in the RWO Page", clickGivenXpath(AWBgriSearchbutton));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			//Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of RWO Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
	    	//defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("DPKey '"+DPKey+"' is not displaying in the RWO Grid after searching,DPKEY ===>"+DPKey, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",DPKey)));
			
			Payershortsize=get_Matching_WebElement_count("//div[@class='payer-desc']");
			for (int j = 1; j <=Payershortsize; j++) 
			{
				payershort=get_TextFrom_Locator("(//div[@class='payer-desc'])["+j+"]/button");
				Assert.assertTrue("Unable to click the payerhshort '"+payershort+"' checkbox in the Oppgrid of AWB Page", clickGivenXpath(StringUtils.replace(Payershort_chkbox_AWB,"payer",payershort)));
				selectedPayershorts.add(payershort);
				z=z+1;
				
				if(z==payercount)
				{
					payershortstatus=true;
					break;
				}
			}
			if(!payershortstatus)
			{
				Assert.assertTrue("Unable to click the given count '"+payercount+"' of payershort checkboxes in the Oppgrid of RWO Page,for the DPKEy =>"+DPKey, false);
			}
			
			
		}
		
		
		return selectedPayershorts;
	}


	public void validate_the_all_checkboxes_funtionality(String filterName, String FilterOptions) {
		
		boolean bstatus=false;
		
		//Selecting the FilterHeader checkbox in the AWB Page
		oOpportunityRunsPage.ApplyFilters(filterName, "", "CHECK", "");
		
		List<String> filteroptionsList=Arrays.asList(FilterOptions.split(","));
		
		for (int i = 0; i < filteroptionsList.size(); i++) 
		{
			
			System.out.println(i+"."+filteroptionsList.get(i));
			
			bstatus=Get_Value_By_given_attribute("class", "//app-checklist[@title='"+filterName+"']//div[contains(text(),'"+filteroptionsList.get(i)+"')]/preceding-sibling::mat-pseudo-checkbox").contains("checked");
			
			if(!bstatus)
			{
				Assert.assertTrue("'"+filteroptionsList.get(i).trim()+"' filter checkbox is not checked in the filter '"+filterName+"' of the AWB Page,even though header is checked", false);		
			}
			
		}
		
		//Selecting the FilterHeader checkbox in the AWB Page
		oOpportunityRunsPage.ApplyFilters(filterName, "", "UNCHECK", "");
		
		 
		for (int i = 0; i < filteroptionsList.size(); i++) {
			
			bstatus=Get_Value_By_given_attribute("class", "//app-checklist[@title='"+filterName+"']//div[contains(text(),'"+filteroptionsList.get(i)+"')]/preceding-sibling::mat-pseudo-checkbox").contains("checked");
			
			if(bstatus)
			{
				Assert.assertTrue("'"+filteroptionsList.get(i).trim()+"' filter checkbox is checked in the filter '"+filterName+"' of the AWB Page,even though header is un-checked", false);		
			}
			
		}
		
		
		
		
		
		
	}


	public void validate_the_applyfiler_reset_button_funtionality(String filterName, String FilterOptions,String sApplyFilter,String sReset) {
		
		boolean bstatus=false;
		String classname=null;
		String sChbk_HeadearChild=null;
		
		List<String> filteroptionsList=Arrays.asList(FilterOptions.split(","));
		
		//Selecting the FilterHeader checkbox in the AWB Page
		oOpportunityRunsPage.ApplyFilters(filterName, "", "CHECK", "");
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		bstatus=is_WebElement_Displayed(sApplyFilter);
		
		if(bstatus)
		{
			Assert.assertTrue("Apply filters button is disabled in the AWB Page beside Filter checkbox,even though all the filter headers are checked", false);
		}
	
		//Selecting the FilterHeader checkbox in the AWB Page
		oOpportunityRunsPage.ApplyFilters(filterName, "", "UNCHECK", "");
		defaultWait(ProjectVariables.TImeout_2_Seconds);
				
		bstatus=is_WebElement_Displayed(sApplyFilter);
	
		if(!bstatus)
		{
			Assert.assertTrue("Apply filters button is enabled in the AWB Page beside Filter checkbox,even though '"+filterName+"' filter header is un-checked", false);
		}
		
		//Clicking on Reset button in  Beside filter checkbox section in the AWB Page
		Assert.assertTrue("Reset button is unable to clicked in the AWB Page beside Filter checkbox", clickGivenXpath(sReset));
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		sChbk_HeadearChild="//span[contains(text(),'"+filterName+"')]/ancestor::mat-checkbox";
		
		bstatus =Get_Value_By_given_attribute("class", sChbk_HeadearChild).contains("checked");
		
		if(!bstatus)
		{
			Assert.assertTrue("'"+filterName+"' filter header checkbox is not checked  of the AWB Page,even though after clicking onthe reset button", false);
		}
		
		
		Assert.assertTrue("The filter '"+filteroptionsList.get(0)+"' is unable to uncheck in the  filter '"+filterName+"' of the AWB Page", oOpportunityRunsPage.ApplyFilters(filterName, filteroptionsList.get(0), "UNCHECK", ""));
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		sChbk_HeadearChild="//span[contains(text(),'"+filterName+"')]/ancestor::mat-checkbox";
		
		bstatus =Get_Value_By_given_attribute("class", sChbk_HeadearChild).contains("checked");
		
		if(bstatus)
		{
			Assert.assertTrue("'"+filterName+"' filter header checkbox is checked in the AWB Page,even though one of the filter option '"+filteroptionsList.get(0)+"' is unchecked", false);
		}
		
		Assert.assertTrue("The filter '"+filteroptionsList.get(0)+"' is unable to check in the  filter '"+filterName+"' of the AWB Page", oOpportunityRunsPage.ApplyFilters(filterName, filteroptionsList.get(0), "CHECK", ""));
	}


	public void validate_the_opportunitygrid_data_with_mongo_DB_in_the_AWB_page_based_on_the_filteroptions(String filtername, String FilterOptions,List<String> Payerslist) throws InterruptedException {
		boolean bstatus=false;
		boolean DBstatus=false;
		List<Long> DB_DPKeylist=null;
		List<String> insurancelist = null;
		List<String> claimtypelist=null;
		List<String> filteroptionsList=Arrays.asList(FilterOptions.split(","));
		
		
		
		for (int i = 0; i < filteroptionsList.size(); i++) {
			
			Assert.assertTrue("'"+filtername+"' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters(filtername, "", "CHECK", ""));
			
			Assert.assertTrue("'"+filtername+"' filterhead checkbox is unable to uncheck in the AWB Page", oOpportunityRunsPage.ApplyFilters(filtername, "", "UNCHECK", ""));
			
			Assert.assertTrue("'"+filteroptionsList.get(i)+"' filter checkbox is unable to checked in the filter '"+filtername+"' of the AWB Page", oOpportunityRunsPage.ApplyFilters(filtername,filteroptionsList.get(i),"CHECK",StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")));
			
			//Wait untill the loading icon is not visible
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
			
			bstatus=is_WebElement_Displayed(StringUtils.replace(Div_contains_text, "value", "No results found that meet the search criteria."));
			
			switch(filtername)
			{
			case "Latest Client Decision":
				
				//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
				DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB(Serenity.sessionVariableCalled("Medicalpolicy"), Payerslist,insurancelist,claimtypelist, filteroptionsList.get(i), "", "", filtername,"AWB");
				
			break;
			case "Prior Disposition":
				
				//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
				DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB( Serenity.sessionVariableCalled("Medicalpolicy"), Payerslist,insurancelist,claimtypelist, "", filteroptionsList.get(i), "", filtername,"AWB");
				
			break;
			case "Savings Status":
				
				//Retrieve the Topics displayed in the AWb grid from Mongo DB as per the filter combination
				DBstatus=MongoDBUtils.Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB(Serenity.sessionVariableCalled("Medicalpolicy"), Payerslist,insurancelist,claimtypelist, "", "", filteroptionsList.get(i), filtername,"AWB");
				
			break;
			
			default:
				
			Assert.assertTrue("Given selection is not found ===>"+filtername, false);	
			break;
			}
			
			if(bstatus)
			{
				if(DBstatus)
				{
					Assert.assertTrue("'No opportunities available for the selected Medical Policy and filters comination' message is displayed in the AWB Grid as not expected with Mongo DB for the client key ==>"+Serenity.sessionVariableCalled("clientkey")+",release ==>"+Serenity.sessionVariableCalled("release")+",Medical policy ==>"+Serenity.sessionVariableCalled("Medicalpolicy")+",filtername ==>"+filtername+",filter option ==>"+filteroptionsList.get(i), false);	
				}
				
			}
			else
			{	
				//validating the Topics displayed in the AWb grid with Mongo DB as per the filter combination 
				Validate_the_Topics_in_Opportunity_Grid_with_Mongo_DB(Serenity.sessionVariableCalled("client"), Serenity.sessionVariableCalled("release"), Serenity.sessionVariableCalled("Medicalpolicy"));
				DB_DPKeylist.addAll(ProjectVariables.DB_DpkeyList);
				//validating the DP's displayed in the AWb grid with Mongo DB as per the filter combination 
				Validate_the_DPs_in_Opportunity_Grid_with_Mongo_DB(Serenity.sessionVariableCalled("client"), Serenity.sessionVariableCalled("Medicalpolicy"),"AWB Grid",DB_DPKeylist);
			}
			
			
			
		}
		
		
		
		
	}


	public void validate_the_Rules_in_DPDesc_Popup_with_mongodb_for(String DPKey,String pagename) {
		String UIRule=null;
		int rulessize=0;
		int intialrulesize=0;
		boolean bstatus=false;
		ArrayList<String> Not_DisplayedRulesList=new ArrayList<>();
		int i = 1;
		HashSet<String> UIRulesList=new HashSet<>();
		
		
		 rulessize=get_Matching_WebElement_count(StringUtils.replace(Tag_P_with_class, "value", "midrule-name"));
		
		 intialrulesize=rulessize;
		for (; i <=rulessize; i++) {
			
			scrollingToGivenElement(getDriver(), StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
          	defaultWait(ProjectVariables.TImeout_3_Seconds);
			UIRule=get_TextFrom_Locator(StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
		
			//Retrieve the exact rule from UI 
			UIRule=RetrieveTheExacttheRule(UIRule);
			System.out.println(UIRule);
			
			UIRulesList.add(UIRule);
			/*if(i==rulessize)
			{
				bstatus=is_WebElement_Displayed(Loadmorelink);
				
				if(bstatus)
				{
					Assert.assertTrue("Unable to click the 'Load more' link in the DPDesc popup", clickGivenXpath(Loadmorelink));
					
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					
					rulessize=get_Matching_WebElement_count(StringUtils.replace(Rules_in_DPDescpopup, "value", "title"));
					i=rulessize-intialrulesize;
					//i=1;
					
				}
			}*/
			
			
			
		}
		
		System.out.println("UI Ruleslist ==>"+UIRulesList);
		System.out.println("UI Ruleslistsize ==>"+UIRulesList.size());
		
		List<String> DB_Ruleslist=Arrays.asList(ProjectVariables.DB_Rules.split(","));
		
		//validate the rules in the DP Desc with mongoDB rules
		for (String DB_Rule : DB_Ruleslist) {

			System.out.println("DBRule ==>"+DB_Rule);
			if(!UIRulesList.contains(DB_Rule.trim()))
				{
					Not_DisplayedRulesList.add(DB_Rule.trim());
				}
		}
		
		Assert.assertTrue("Some Rules are not displayed in the DP Desc popup in AWB Page,Not displayed Rules Count ==>"+Not_DisplayedRulesList.size()+",Not displayed rules ==>"+Not_DisplayedRulesList+",UI Rulessize ==>"+UIRulesList.size()+",UI Ruleslist"+UIRulesList, Not_DisplayedRulesList.size()==0);
		
		Assert.assertTrue("Unable to click the 'x' icon of DPDesc popup of AWB Page", clickGivenXpath("//span[contains(text(),'"+DPKey+"')]/..//button"));
		
	}
	
	
	private String RetrieveTheExacttheRule(String UIRule)
	{
		String sExactRule=null;
		
		if(UIRule.contains("Deactivated")||UIRule.contains("Retired")||UIRule.contains("Disbled"))
		{
			sExactRule=StringUtils.substringBefore(UIRule, "(").trim();
			return sExactRule;
		}
		if(UIRule.contains("Custom"))
		{
			sExactRule=StringUtils.substringBefore(UIRule, "Custom").trim();
			return sExactRule;
		}
		else if(UIRule.contains("Library"))
		{
			sExactRule=StringUtils.substringBefore(UIRule, "Library").trim();
			return sExactRule;
		}
		else 
		{
			sExactRule=UIRule.trim();
			
		}
		
		
		return sExactRule;
	}


	public void validate_the_Rule_information_in_DPDesc_Popup_with_mongodb_for(String DPKey,List<String> payershortList,String pagename,String ExpectedSavingsstatus) {
		String UIRule=null;
		String ReferenceDetails=null;
		int rulessize=0;
		int intialrulesize=0;
		String ruleinBaseLine=null;
		boolean bstatus=false;
		if(ExpectedSavingsstatus.equalsIgnoreCase("Opportunity"))
		{
			ruleinBaseLine="0";
		}
		else if(ExpectedSavingsstatus.equalsIgnoreCase("Production"))
		{
			ruleinBaseLine="-1";
		}
		int i = 1;
		
		//CLick the DPDesc link for the given DPKey
		Click_the_DPDesc_for_the_given_DPKey(pagename);
		
		 rulessize=get_Matching_WebElement_count(StringUtils.replace(Tag_P_with_class, "value", "midrule-name"));
		
		 intialrulesize=rulessize;
		for (; i <=rulessize; i++) {
			
			scrollingToGivenElement(getDriver(), StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
			
			UIRule=get_TextFrom_Locator(StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
			
			//Retrieve the exact rule from UI 
			UIRule=RetrieveTheExacttheRule(UIRule);
			
		
			
			String ruletype=get_TextFrom_Locator(StringUtils.replace(Text_with_Tag_P, "value", UIRule)+"/span");
			
			String Savingsstatus=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(StringUtils.replace(Rules_Data_in_DPDesc, "rule", UIRule),"value","saving-status")),":").trim();
			
			String PrimaryReferncetype=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(StringUtils.replace(Rules_Data_in_DPDesc, "rule", UIRule),"value","reference-source")+"/span"),":").trim();
			
			String PrimaryRefernceData=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(StringUtils.replace(Rules_Data_in_DPDesc, "rule", UIRule),"value","reference-source")),PrimaryReferncetype).trim();
			
			ReferenceDetails=StringUtils.substringAfter(get_TextFrom_Locator(StringUtils.replace(StringUtils.replace(Rules_Data_in_DPDesc, "rule", UIRule),"value","reference-detail")),"Reference Detail").trim();
		
			//Get the rule information from the mongo DB for th given data 
			MongoDBUtils.Get_the_Rule_information_for_the_given(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), payershortList,ruleinBaseLine,DPKey,UIRule);
			
			Assert.assertTrue("Rule type is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+",Expected ==>"+ProjectVariables.DB_CoreenhancedDesc+",Actual ==>"+ruletype, ruletype.equalsIgnoreCase(ruletype));
			
			Assert.assertTrue("Primary reference source type is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+",Expected ==>"+ProjectVariables.DB_CoreenhancedDesc+",Actual ==>"+PrimaryReferncetype, PrimaryReferncetype.equalsIgnoreCase(ProjectVariables.DB_CoreenhancedDesc));
			
			Assert.assertTrue("Primary reference source data is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+",Expected ==>"+ProjectVariables.DB_PrimaryRefsource+",Actual ==>"+PrimaryRefernceData, PrimaryRefernceData.equalsIgnoreCase(ProjectVariables.DB_PrimaryRefsource));
			
			
			if(Savingsstatus.equalsIgnoreCase("Multiple"))
			{
				Assert.assertTrue("Savingstatus is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+",Expected ==>"+ProjectVariables.DB_Savingsstatus+",Actual ==>"+Savingsstatus, ProjectVariables.DB_Savingsstatus.contains("0")&&ProjectVariables.DB_Savingsstatus.contains("-1"));
			}
			else
			{
				Assert.assertTrue("Savingstatus is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+",Expected ==>"+ProjectVariables.DB_Savingsstatus+",Actual ==>"+Savingsstatus, Savingsstatus.equalsIgnoreCase(ProjectVariables.DB_Savingsstatus));
			}
			
			if(ReferenceDetails.equalsIgnoreCase(" "))
			{
				Assert.assertTrue("Reference Details is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+"Expected ==>"+ProjectVariables.DB_refdetails+",Actual ==>"+ReferenceDetails, ProjectVariables.DB_refdetails.isEmpty());
			}
			else
			{
				Assert.assertTrue("Reference Details is not matching with DB in DPDesc popup of AWB Page for the rule ==>"+UIRule+",DPKey ==>"+DPKey+"Expected ==>"+ProjectVariables.DB_refdetails+",Actual ==>"+ReferenceDetails, ReferenceDetails.equalsIgnoreCase(ProjectVariables.DB_refdetails));	
			}
			
			
			/*if(i==rulessize)
			{
				bstatus=is_WebElement_Displayed(Loadmorelink);
				
				if(bstatus)
				{
					Assert.assertTrue("Unable to click the 'Load more' link in the DPDesc popup", clickGivenXpath(Loadmorelink));
					
					defaultWait(ProjectVariables.TImeout_10_Seconds);
					
					rulessize=get_Matching_WebElement_count(StringUtils.replace(Rules_in_DPDescpopup, "value", "title"));
					i=rulessize-intialrulesize;
					//i=1;
					
				}
			}*/
			
			
			
		}
		
		
	}


	public void Click_the_DPDesc_for_the_given_DPKey(String pagename) {
		
		Assert.assertTrue("DPKey is not displayed in the "+pagename+" Grid,after searching,DPKey==>"+ProjectVariables.DB_DPKey, is_WebElement_Visible(StringUtils.replace(ButtonContainsText, "value",ProjectVariables.DB_DPKey)));
		
		Assert.assertTrue("Unable to click the DPDesc link in the "+pagename+" Grid for DPKEy ==>"+ProjectVariables.DB_DPKey, clickGivenXpath(StringUtils.replace(Div_with_class, "value","dp-desc")));

		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		Assert.assertTrue("DPKey Header is not displayed in the DPDesc POPup as ==>DP "+ProjectVariables.DB_DPKey+" Details in the "+pagename+" page", is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "DP "+ProjectVariables.DB_DPKey+" Details")));
		
		String UI_DPDesc=get_TextFrom_Locator(StringUtils.replace(Tag_P_with_class, "value", "dp-description")).trim();
		
		Assert.assertTrue("DP desc is not matching with DB in the DP Desc popup of '"+pagename+"' for the DP Key ==>"+ProjectVariables.DB_DPKey+",Expected ==>"+ProjectVariables.DB_DPDesc+",Actual ==>"+UI_DPDesc, UI_DPDesc.equalsIgnoreCase(ProjectVariables.DB_DPDesc));
		
		
		
	}


	public void validate_the_Rules_sorting_functionality_in_DPDesc_Popup(String dB_DPKey, String pagename) {
		
		String UIRule=null;
		String PreviousRule=null;
		int rulessize=0;
		int intialrulesize=0;
		boolean bstatus=false;
		
		int i = 1;
		HashSet<String> UIRulesList=new HashSet<>();
		rulessize=get_Matching_WebElement_count(StringUtils.replace(Tag_P_with_class, "value", "midrule-name"));
		 intialrulesize=rulessize;
		for (; i <=rulessize; i++) {
			
			scrollingToGivenElement(getDriver(), StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
			UIRule=get_TextFrom_Locator(StringUtils.replace(Tag_P_with_class, "value", "midrule-name")+"["+i+"]");
			//Retrieve the exact rule from UI 
			UIRule=RetrieveTheExacttheRule(UIRule);
			
			if(!(PreviousRule==null))
			{
				int compare = PreviousRule.replaceAll(".", "").trim().compareToIgnoreCase(UIRule.replaceAll(".", "").trim());
				
				if (compare == 0 || compare < 0) {
					System.out.println( "Rules are displayed in 'Ascending Order' as expected in DPDesc popup for the DPkey==>"+dB_DPKey+",Medicalpolicy ==>"+ProjectVariables.DB_Medicalpolicylist.get(0)+",RulesData:"+PreviousRule.trim() + "," + UIRule.trim());
				} else {
					Assert.assertTrue( "Rules are not displayed in 'Ascending Order' in DPDesc popup for the DPkey==>"+dB_DPKey+",Medicalpolicy ==>"+ProjectVariables.DB_Medicalpolicylist.get(0)+",RulesData:"+PreviousRule.trim() + "," + UIRule.trim(), false);
				}
			}
			
			
			
			PreviousRule=UIRule;
			UIRulesList.add(UIRule);
			/*if(i==rulessize)
			{
				bstatus=is_WebElement_Displayed(Loadmorelink);
				if(bstatus)
				{
					Assert.assertTrue("Unable to click the 'Load more' link in the DPDesc popup", clickGivenXpath(Loadmorelink));
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					rulessize=get_Matching_WebElement_count(StringUtils.replace(Rules_in_DPDescpopup, "value", "title"));
					i=rulessize-intialrulesize;
					//i=1;
				}
			}*/
		}
		
		
		
		
		
	}


	public void Select_the_DPDesc_in_the_grid_from_DB(String Pagename,String Savingsstatus,List<String> UIPayershortlist) throws InterruptedException {

		ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage = this.switchToPage(ReviewWorkedOpportunityPage.class);
		String ruleinBaseLine="";
		
		
		if(Savingsstatus.equalsIgnoreCase("Opportunity"))
		{
			ruleinBaseLine="0";
		}
		else if(Savingsstatus.equalsIgnoreCase("Production"))
		{
			ruleinBaseLine="-1";
		}
	
		//Retrieve the DPKeys with multiple rules for the given criteria
		MongoDBUtils.Get_the_DPKey_with_multiplerules_based_on_client_release_and_savingstatus(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), UIPayershortlist,ruleinBaseLine,Pagename);
		//
		//ProjectVariables.DB_Medicalpolicylist.add("Add-on Code Policy");
		//ProjectVariables.DB_DPKeylist.add("5758");
		
		Serenity.setSessionVariable("Medicalpolicy").to(ProjectVariables.DB_Medicalpolicylist.get(0));
		
		
		switch(Pagename)
		{
		case "AWB":
			//Select the medicalpolicy from policy selection 
			oOpportunityRunsPage.SelectPolicySelectionAndApplyFilters(ProjectVariables.DB_Medicalpolicylist.get(0));
			
			if(Savingsstatus.equalsIgnoreCase("Opportunity")||Savingsstatus.equalsIgnoreCase("Production"))
			{
				Assert.assertTrue("'"+Savingsstatus+"' filter checkbox is unable to un-checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","","UNCHECK",""));	
				Assert.assertTrue("'"+Savingsstatus+"' filter checkbox is unable to checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status",Savingsstatus,"CHECK",StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")));
			}
			
			
			Assert.assertTrue("Unable to enter the DPKey "+ProjectVariables.DB_DPKey+" in the search field of "+Pagename, Enter_given_Text_Element(sSearchField_AWB,ProjectVariables.DB_DPKey));

			Assert.assertTrue("Unable to click the search icon beside search box in the "+Pagename+"", clickGivenXpath(AWBgriSearchbutton));

			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
			
			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("DPKey is not displayed in the "+Pagename+" Grid,after searching,DPKey==>"+ProjectVariables.DB_DPKey, is_WebElement_Visible(StringUtils.replace(ButtonContainsText, "value",ProjectVariables.DB_DPKey)));
			
			break;
		case "Review Worked Opportunity":
		
			Assert.assertTrue("Reviewed Worked Opportunity button was unable to clicked in AWB page", clickGivenXpath(StringUtils.replace(Span_contains_text, "value", "Review Worked Opportunities")));
			
			defaultWait(ProjectVariables.TImeout_2_Seconds);
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
			defaultWait(ProjectVariables.TImeout_2_Seconds);
			
			Assert.assertTrue("Worked Opportunities header is not displaying in the Review WorkedOpp Page,after clicking on that link in AWB Page ", Wait_Untill_Element_is_displayed(10, WorkedOpportunityHeader));
			
			//Selecting the checkboxes in the RWO Page
			oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");

			if(Savingsstatus.equalsIgnoreCase("Opportunity")||Savingsstatus.equalsIgnoreCase("Production"))
			{
				Assert.assertTrue("'"+Savingsstatus+"' filter checkbox is unable to un-checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","","UNCHECK",""));	
				Assert.assertTrue("'"+Savingsstatus+"' filter checkbox is unable to checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status",Savingsstatus,"CHECK",StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")));
			}

				
			Assert.assertTrue("Unable to enter the "+ProjectVariables.DB_DPKey+" in the search field of Reviewwoked Opportunity Page,DPKey===>"+ProjectVariables.DB_DPKey, Enter_given_Text_Element(sSearchField_RWOpp,ProjectVariables.DB_DPKey));

			Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));

			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
			
			AWBPage.defaultWait(ProjectVariables.TImeout_3_Seconds);
			
			
			
			break;
		default:
			Assert.assertTrue("Given selection was not found ===>"+Pagename, false);
			break;
			
		}
		
	}


	public void verify_the_given_data_is_displayed_in_the_page(String data,String capturedtypeofdata,String Pagename) {	
		if(capturedtypeofdata.equalsIgnoreCase("DPkey")&&data.length()==2)
		{
			System.out.println("Captured DPkey length is '2' only,if we search with that,Grid will display contains values,Captured DPKEy==>"+data);
		}
		else
		{
			if(Pagename.equalsIgnoreCase("AWB"))
			{
					defaultWait(ProjectVariables.TImeout_2_Seconds);
					Assert.assertTrue(""+capturedtypeofdata+" "+data+" is not displayed in the "+Pagename+" grid,after searching", is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",data)));
			}	
			else if(Pagename.equalsIgnoreCase("eLL"))
			{
				Assert.assertTrue(""+capturedtypeofdata+" "+data+" is not displayed in the "+Pagename+" grid,after searching", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value",data)));	
			}
			else
			{
				Assert.assertTrue("Unable to enter the "+capturedtypeofdata+" in the search field of Reviewwoked Opportunity Page,"+capturedtypeofdata+" ===>"+data, Enter_given_Text_Element(sSearchField_RWOpp,data));

				Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));

				defaultWait(ProjectVariables.TImeout_5_Seconds);
				
				if(capturedtypeofdata.equalsIgnoreCase("DPkey"))
				{
					Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+data, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",data)));
				}
				else
				{
					Assert.assertTrue("unable to click the DP chevron in the Opportunity grid of AWB Page", clickGivenXpath(StringUtils.replace(ChevronInGrid, "value", "dp")));
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					Assert.assertTrue("Captured "+capturedtypeofdata+" is not displaying in the Review Worked Opp Grid,Captured "+capturedtypeofdata+" ===>"+data, is_WebElement_Displayed(StringUtils.replace(labelcontainstext, "svalue",data)));	
				}
				
				
			}
		}
		
		}


	public void validate_the_popup_data_with_MongoDB_in_the_Page(String popup, String dB_DPKey, String pagename) throws InterruptedException {int popupsize=0;
	String reason=null;
	String notes=null;
	String CDMmodifications=null;
	
	ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage=this.switchToPage(ReviewWorkedOpportunityPage.class);
	switch(popup){
	case "latest Client Decision":
		
		if(pagename.equalsIgnoreCase("AWB"))
		{
			//Select the given medicalpolicy from policy selection drawer
			oOpportunityRunsPage.applygiventopictoawbgrid(ProjectVariables.DB_UniqueTopic,"","","","");	
			//To select 'Production' checkbox
			oOpportunityRunsPage.ApplyFilters("Savings Status", "Production", "CHECK", "");
			clickGivenXpath(StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters"));
			AWBPage.defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
			DynamicWaitfortheLoadingIconWithCount(LoadingIcon, 20);
			
			
		}
		else
		{
			oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
			
			oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
			
			Assert.assertTrue("'Latest Client Decision' filterhead checkbox is unable to un-checked in the AWB Page", oOpportunityRunsPage.ApplyFilters("Latest Client Decision", "", "UNCHECK", ""));
			
			Assert.assertTrue("'Latest Client Decision' filterhead checkbox is unable to checked in the AWB Page", oOpportunityRunsPage.ApplyFilters("Latest Client Decision", ProjectVariables.DB_Requireddecision, "CHECK", StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")));
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		}
		
		//verify the DpKey is displayed in the AWb Grid
		verify_the_given_data_is_displayed_in_the_page(ProjectVariables.DB_DPKey,"DPkey",pagename);
		
		if(pagename.equalsIgnoreCase("AWB"))
		{
		Assert.assertTrue("unable to click the '"+popup+"' link in the "+pagename+" page for the Dpkey ==>"+dB_DPKey, clickGivenXpath(StringUtils.replace(latestclientDecision, "dpkey", dB_DPKey)));
		}
		else
		{
			Assert.assertTrue("unable to click the '"+popup+"' link in the "+pagename+" page for the Dpkey ==>"+dB_DPKey, clickGivenXpath(StringUtils.replace(RWOlatestclientDecision, "dpkey", dB_DPKey)));
		}
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		Assert.assertTrue("'"+popup+"' popup header is not displayed as expected,expected ===>Latest Client Decision DP "+dB_DPKey+",after clicking on that link in "+pagename+"", is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "Latest Client Decision DP "+dB_DPKey+"")));
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		for (int i = 0; i < ProjectVariables.latesetClientDecisionColumns.length; i++) 
		{

			Assert.assertTrue("'"+ProjectVariables.latesetClientDecisionColumns[i]+"' column is not displaying in the "+popup+"' popup of "+pagename+"", is_WebElement_Displayed(StringUtils.replace(text_contains_header_th,"value",ProjectVariables.latesetClientDecisionColumns[i])));
			
		}
		
		 popupsize=get_Matching_WebElement_count(DecisionPopupsize);
		 
		 for (int i = 1; i <=popupsize; i++) {
			
			 String midrule=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[1]").trim();
			 String payer=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[2]").trim();
			 String insurance=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[3]").trim();
			 String claimtype=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[4]").trim();
			 String CDMDecision=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[5]").trim();
			 
			// if(is_WebElement_Displayed("("+StringUtils.replace(Div_contains_class, "value", "bodyRow")+"["+i+"]//label)[5]"))
			 {
				 CDMmodifications=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[6]").trim();	 
			 }
			// else
			 {
			//	 CDMmodifications="";
			 }
			 
			 String release=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[7]").trim();
			 
			 List<String> midrulesList=Arrays.asList(midrule.split(","));
			 List<String> payerList=Arrays.asList(payer.split(","));
			 
			 System.out.println("Payer ==>"+payer);
			 System.out.println("midrule ==>"+midrule);
			 System.out.println("insurance ==>"+insurance);
			 System.out.println("claimtype ==>"+claimtype);
			 System.out.println("CDMDecision ==>"+CDMDecision);
			 System.out.println("CDMmodifications ==>"+CDMmodifications);
			 System.out.println("release ==>"+release);
			 
			 
			 if(midrule.contains(","))
			 {
				 for (int j = 0; j < midrulesList.size(); j++) 
				 {
					 //To retrive the CDM Decisions data based on the client,release and PPS combination
					 MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrulesList.get(j).trim(), payer, insurance,claimtype, popup);
					 if(ProjectVariables.DB_CDMDecision==null)
					 {
						 System.out.println(CDMDecision);
						 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.isEmpty());
						 
						 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype,CDMmodifications.isEmpty());
						 
						 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.isEmpty());
						 	 
					 }
					 else
					 {
						 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.equalsIgnoreCase(ProjectVariables.DB_CDMDecision));
						 
						 if(ProjectVariables.DB_CDMModifications==null)
						 {
							 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMmodifications.isEmpty());
						 }
						 else
						 {
							 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, StringUtils.substringAfterLast(ProjectVariables.DB_CDMModifications.trim(), "**").trim().replaceAll(" ", "").equalsIgnoreCase(StringUtils.substringAfterLast(CDMmodifications.trim(),"**").trim().replaceAll(" ", "")));	 
						 }
						 
						 
						 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrulesList.get(j)+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.trim().equalsIgnoreCase(ProjectVariables.DB_CDMDecisionRelease.trim()));
						
					 }
			      }
		   }
			 else
			 {
				//To retrive the CDM Decisions data based on the client,release and PPS combination
				 MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrule.trim(), payer, insurance,claimtype, popup);
				 
				 if(ProjectVariables.DB_CDMDecision==null)
				 {
					 System.out.println(CDMDecision);
					 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.isEmpty());
					 
					 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype,CDMmodifications.isEmpty());
					 
					 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.isEmpty());
					 	 
				 }
				 else
				 {
					 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.equalsIgnoreCase(ProjectVariables.DB_CDMDecision));
					 
					 if(ProjectVariables.DB_CDMModifications==null)
					 {
						 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMmodifications.isEmpty());
					 }
					 else
					 {
						 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, StringUtils.substringAfterLast(ProjectVariables.DB_CDMModifications.trim(), "**").trim().replaceAll(" ", "").equalsIgnoreCase(StringUtils.substringAfterLast(CDMmodifications.trim(),"**").trim().replaceAll(" ", "")));	 
					 }
					 
					 
					 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.trim().equalsIgnoreCase(ProjectVariables.DB_CDMDecisionRelease.trim()));
					 	 
				 }
			 }
			
			/* if(payer.contains(","))
			 {
				 for (int j = 0; j < payerList.size(); j++) {
					 //To retrive the CDM Decisions data based on the client,release and PPS combination
					 MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrule.trim(), payerList.get(j).trim(), insurance,claimtype, popup);
				}
			 }
			 else
			 {
				//To retrive the CDM Decisions data based on the client,release and PPS combination
				 MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrule.trim(), payer, insurance,claimtype, popup);
				 
			 }*/
			 
			 /*if(ProjectVariables.DB_CDMDecision==null)
			 {
				 System.out.println(CDMDecision);
				 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.isEmpty());
				 
				 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype,CDMmodifications.isEmpty());
				 
				 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.isEmpty());
				 	 
			 }
			 else
			 {
				 Assert.assertTrue("CDM Decision is not matching with DB,expected ==>"+ProjectVariables.DB_CDMDecision+",Actual ==>"+CDMDecision+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMDecision.equalsIgnoreCase(ProjectVariables.DB_CDMDecision));
				 
				 if(ProjectVariables.DB_CDMModifications==null)
				 {
					 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, CDMmodifications.isEmpty());
				 }
				 else
				 {
					 Assert.assertTrue("CDM modifications is not matching with DB,expected ==>"+ProjectVariables.DB_CDMModifications+",Actual ==>"+CDMmodifications+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, StringUtils.substringAfterLast(ProjectVariables.DB_CDMModifications.trim(), "**").trim().replaceAll(" ", "").equalsIgnoreCase(StringUtils.substringAfterLast(CDMmodifications.trim(),"**").trim().replaceAll(" ", "")));	 
				 }
				 
				 
				 Assert.assertTrue("Release is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_CDMDecisionRelease+",Actual ==>"+release+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, release.trim().equalsIgnoreCase(ProjectVariables.DB_CDMDecisionRelease.trim()));
				 	 
			 }
			
			 */
		}
		
		
		
	break;
	
	case "Current Disposition":
		
		oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
		
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
		
		
		//verify the DpKey is displayed in the AWb Grid
		verify_the_given_data_is_displayed_in_the_page(ProjectVariables.DB_DPKey,"DPkey","Review Worked Opportunity");
		
		Assert.assertTrue("unable to click the '"+popup+"' link in the "+pagename+" page for the Dpkey ==>"+dB_DPKey, clickGivenXpath(StringUtils.replace(current_disposition, "dpkey", dB_DPKey)));
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		Assert.assertTrue("'"+popup+"' popup header is not displayed as expected,expected ===>Current Disposition "+dB_DPKey+",after clicking on that link in "+pagename+"", is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "Current Disposition "+dB_DPKey+"")));
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		for (int i = 0; i < ProjectVariables.CurrentDispositionColumns.length; i++) 
		{
			
			Assert.assertTrue("'"+ProjectVariables.CurrentDispositionColumns[i]+"' column is not displaying in the "+popup+"' popup of "+pagename+"", is_WebElement_Displayed(StringUtils.replace(text_contains_header_th, "value", ProjectVariables.CurrentDispositionColumns[i])));
			
		}
		
		 popupsize=get_Matching_WebElement_count(DecisionPopupsize);
		 
		 for (int i = 1; i <=popupsize; i++) {
			
			 String midrule=StringUtils.substringBefore(get_TextFrom_Locator(DecisionPopupsize+"[1]/td[1]").trim(), ".");
			 String payer=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[2]").trim();
			 String insurance=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[3]").trim();
			 String claimtype=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[4]").trim();
			 String currentdisposition=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[6]").trim();
			 
			//To retrive the CDM Decisions data based on the client,release and PPS combination
			 MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrule.trim(), payer, insurance,claimtype, popup);
			
			 Assert.assertTrue("Current Disposition is not matching with DB,expected ==>"+ProjectVariables.DB_Disposition+",Actual ==>"+currentdisposition+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, currentdisposition.equalsIgnoreCase(ProjectVariables.DB_Disposition));
			 
			 reason=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[7]").trim();
			 if(!reason.isEmpty())
			 {
				  
				 Assert.assertTrue("Disposition reasons is not matching with DB,expected ==>"+ProjectVariables.DB_DispositionReasonslist+",Actual ==>"+reason+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, ProjectVariables.DB_DispositionReasonslist.contains(reason));
				 
					
			 }
			 else
			 {
				 Assert.assertTrue("Disposition reasons is not matching with DB,expected ==>"+ProjectVariables.DB_DispositionReasonslist+",Actual ==>"+reason+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, ProjectVariables.DB_DispositionReasonslist.isEmpty());
			 }
			 
			 notes=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[8]").trim();
			 if(!notes.isEmpty())
			 {
				  
				 Assert.assertTrue("Dispositionnotes is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_Dispositionnotes+",Actual ==>"+notes+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, notes.equalsIgnoreCase(ProjectVariables.DB_Dispositionnotes));
			 }
			 else
			 {
				 Assert.assertTrue("Dispositionnotes is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_Dispositionnotes+",Actual ==>"+notes+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, ProjectVariables.DB_Dispositionnotes==null);
			 }
			
		}
		
		
		
	break;
	
	case "Prior Disposition":
		
		
		//Select the given medicalpolicy from policy selection drawer
		oOpportunityRunsPage.applygiventopictoawbgrid(ProjectVariables.DB_UniqueTopic,"","","","");
		
		//verify the DpKey is displayed in the AWb Grid
		verify_the_given_data_is_displayed_in_the_page(ProjectVariables.DB_DPKey,"DPkey",pagename);
		
		scrollingToGivenElement(getDriver(),StringUtils.replace(Priordisposition, "dpkey", dB_DPKey));
		
		Assert.assertTrue("unable to click the '"+popup+"' link in the "+pagename+" page for the Dpkey ==>"+dB_DPKey, clickGivenXpath(StringUtils.replace(Priordisposition, "dpkey", dB_DPKey)));
		
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		
		defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		Assert.assertTrue("'"+popup+"' popup header is not displayed as expected,expected ===>Prior Disposition "+dB_DPKey+",after clicking on that link in "+pagename+"", is_WebElement_Displayed(StringUtils.replace(Span_with_text, "value", "Prior Disposition "+dB_DPKey+"")));
		
		
		for (int i = 0; i < ProjectVariables.PriorDispositionColumns.length; i++) {
			
			Assert.assertTrue("'"+ProjectVariables.PriorDispositionColumns[i]+"' column is not displaying in the "+popup+"' popup of "+pagename+"", is_WebElement_Displayed(StringUtils.replace(text_contains_header_th, "value", ProjectVariables.PriorDispositionColumns[i])));
			
		}
		
		 popupsize=get_Matching_WebElement_count(DecisionPopupsize);
		 
		 for (int i = 1; i <=popupsize; i++) {
			 String midrule=StringUtils.substringBefore(get_TextFrom_Locator(DecisionPopupsize+"[1]/td[1]").trim(), ".");
			 String payer=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[2]").trim();
			 String insurance=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[3]").trim();
			 String claimtype=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[4]").trim();
			 String priordisposition=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[5]").trim();
			reason=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[6]").trim();
			 //if(is_WebElement_Displayed(StringUtils.replace(Div_contains_class, "value", "Table__bodyRow")+"[1]//div[@data-dojo-attach-point='textNode']"))
			 {
				  notes=get_TextFrom_Locator(DecisionPopupsize+"["+i+"]/td[7]").trim();	 
			 }
			
			 
			
			//To retrive the CDM Decisions data based on the client,release and PPS combination
			MongoDBUtils.Get_the_popup_data_based_on_client_release_and_PPS(Serenity.sessionVariableCalled("clientkey"), Serenity.sessionVariableCalled("release"), dB_DPKey, midrule.trim(), payer, insurance,claimtype, popup);
				 
			
			
			 Assert.assertTrue("Prior Disposition is not matching with DB,expected ==>"+ProjectVariables.DB_Disposition+",Actual ==>"+priordisposition+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, priordisposition.equalsIgnoreCase(ProjectVariables.DB_Disposition));
			 
			//Assert.assertTrue("Prior Disposition reasons is not matching with DB,expected ==>"+ProjectVariables.DB_DispositionReasonslist+",Actual ==>"+reason+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, reason.equalsIgnoreCase(ProjectVariables.DB_DispositionReasonslist.get(0)));
			 
			 //Assert.assertTrue("Prior Disposition notes is not matching with DB in latest client decision popup,expected ==>"+ProjectVariables.DB_Dispositionnotes+",Actual ==>"+notes+",for the DP=>"+dB_DPKey+"payershort ==>"+payer+",midrule ==>"+midrule+",insurance ==>"+insurance+",claimtype ==>"+claimtype, notes.equalsIgnoreCase(ProjectVariables.DB_Dispositionnotes));
			 
		}
		
		
		
	break;
	
	
	default:
		
		Assert.assertTrue("Given selection is not found ===>"+popup, false);
		
	break;
	
}
}


	public void capture_the_data_at_Topic_level(String criteriatype, String disposition, String updateddisposition) throws InterruptedException {
		
		
		
		ArrayList<String> sGetTopicItems=new ArrayList<>();
		ArrayList<String> sGetDPItems=new ArrayList<>();
		
		String Payershorts=oOpportunityRunsPage.get_TextFrom_Locator(oOpportunityRunsPage.payershorts_in_AWBPage);
		
		List<String> UIPayershortlist=Arrays.asList(StringUtils.substringAfter(Payershorts, "Payer Short: ").split(","));
		
		
		
		if(criteriatype.equalsIgnoreCase("Single Topic"))
		{
			sGetTopicItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage("TOPIC",1);
    		System.out.println("Topic name ===>"+sGetTopicItems);
    		System.out.println("Selected the single topic successfully");
		}
		else if(criteriatype.equalsIgnoreCase("Multiple Topics"))
		{
			sGetTopicItems = oOpportunityRunsPage.SelectDPKeysInOpportunityGridofAWBPage("TOPIC",4);
    		System.out.println("Topic name ===>"+sGetTopicItems);
    		System.out.println("Selected the multiples topic successfully");
		}
    		
		
		
		
    		//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
    		//MongoDBUtils.Disposition_Records_in_Mongo_DB_For_the_given_PPS_in_AWB_Page(Serenity.sessionVariableCalled("Medicalpolicy"), sGetTopicItems, sGetDPItems, "Opportunity", "No Disposition", "AWBGrid");
    		
    		//System.out.println("Successsfully retrieved the No disposition PPS count from mongo DB for the selected topic ==>"+sGetTopicItems);
    		
    		//To Initialize the disposition fields
    		Intialaize_the_Dispositions_fields_to_post(disposition);
    		
    		//Capturing the disposition operation for the given client,release and disposition
    		Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage","");
    		
    		
    		System.out.println("Successsfully captured the Disposition '"+disposition+"' for the selected topic ==>"+sGetTopicItems);
    		
    		//Verify the captured data is displaying in AWB Grid or not
    		verify_the_captured_data_is_not_displayed_in_the_given(sGetTopicItems,"Topic","AWB Page");
    		
    		System.out.println("Verified the captured topic is not visible in the AWB Grid as expected,Disposition '"+disposition+"'for the selected topic ==>"+sGetTopicItems);
    		
    		
    		//To Retrieve the Captured PPS Count from Mongo DB 
    		//MongoDBUtils.Disposition_Records_in_Mongo_DB_For_the_given_PPS_in_AWB_Page(Serenity.sessionVariableCalled("clientkey"), UIPayershortlist, Serenity.sessionVariableCalled("release"), Serenity.sessionVariableCalled("Medicalpolicy"), sGetTopicItems, sGetDPItems, "opportunity", disposition, "ReviewGrid");
    		
    		//System.out.println("Successsfully retrieved the PPS count from mongo DB for the captured topic ==>"+sGetTopicItems);
    		
    		//validate the captured PPS disposition with MongoDB
    		//validate_the_captured_pps_with_mongo_DB(disposition,sGetTopicItems,"Topic");
    		    		
    		//System.out.println("Validation was done between the PPS before captured captured and after captured with Mongo DB for the captured topic ==>"+sGetTopicItems+" ,Disposition '"+disposition);
    		
    		//validate the captured PPS disposition in Review worked Opportunity Page 
    		validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetTopicItems,"Topic","RWO");
    		
    		System.out.println("Captured Topic is displayed in RWO Grid as expected, captured topic ==>"+sGetTopicItems+" ,Disposition '"+disposition);
    		
    		//To Initialize the disposition fields
    		Intialaize_the_Dispositions_fields_to_post(updateddisposition);
    		
    		
    		//validate the update disposition functionality for captured PPS in Review worked Opportunity Page 
    		validate_the_update_disposition_funtionality_for_captured_pps_in_review_worked_opportunity_page(updateddisposition,sGetTopicItems,"Topic");
    		
    		System.out.println("Captured Topic is updated in RWO Grid as expected, captured topic ==>"+sGetTopicItems+" ,UpdatedDisposition '"+updateddisposition);
		
		
	}


	public void capture_the_data_at_DP_level(ArrayList<String> sGetDPItems,String disposition, String tabname,
			String payershort,String insurance,String claimtype,String LCD) throws InterruptedException {
		String sRulerelations=null;
		Long ppscountBefore=0l;
		Long ppscountAfter=0l;
		ArrayList<Long> dpkeysList=new ArrayList<>();
		boolean bstatus=false;
		for (int i = 0; i < sGetDPItems.size(); i++) 
		{
			dpkeysList.add(Long.valueOf(sGetDPItems.get(i)));
		}
		
		if(tabname.contains("-"))
		{
			sRulerelations=StringUtils.substringAfter(tabname, "-");
			tabname=StringUtils.substringBefore(tabname, "-");
			
		}
		
		if(tabname.equalsIgnoreCase("RVA"))
		{
			//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
			ppscountBefore=MongoDBUtils.NoDisposition_Records_in_Mongo_DB_For_the_given_PPS_in_AWB_Page(disposition,dpkeysList, tabname,payershort, insurance, claimtype,LCD);
		}
		else if(tabname.equalsIgnoreCase("eLL"))
		{
			//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
			ppscountBefore=MongoDBUtils.NoDispositionPPSforeLLDPkey(dpkeysList,payershort, insurance, claimtype,LCD);
		}
		System.out.println("Successsfully retrieved the No disposition PPS count from mongo DB for the selected DPKey ==>"+sGetDPItems);
		
		//To Initialize the disposition fields
		Intialaize_the_Dispositions_fields_to_post(disposition);
		
		//Capturing the disposition operation for the given client,release and disposition
		Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage",sRulerelations);
		
		
		System.out.println("Successsfully captured the Disposition '"+disposition+"' for the selected DPKey ==>"+sGetDPItems);
		
		//Verify the captured data is displaying in AWB Grid or not
		verify_the_captured_data_is_not_displayed_in_the_given(sGetDPItems,"DPKey",tabname);
		
		System.out.println("Verified the captured DPKEY is not visible in the AWB Grid as expected,Disposition '"+disposition+"'for the selected DPkeys ==>"+sGetDPItems);
		//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
		ppscountAfter=MongoDBUtils.NoDisposition_Records_in_Mongo_DB_For_the_given_PPS_in_AWB_Page(disposition,dpkeysList, "RWO", "", "", "", "");
		
		bstatus=ppscountAfter==ppscountBefore;
		
		//GenericUtils.Verify("Before PPScount::"+ppscountBefore+",After PPScount::"+ppscountAfter+",after performing capture disposition for the dpkey::"+sGetDPItems, bstatus);
		
		//validate the captured PPS disposition in Review worked Opportunity Page 
		validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetDPItems,"DPkeys","RWO");
		
		System.out.println("Captured DPKeys are displayed in RWO Grid as expected, captured DPKEys ==>"+sGetDPItems+" ,Disposition '"+disposition);
		
		
	}


	public void capture_the_data_at_payershort_level(String disposition, String tabname,
			String payershort,String insurance,String claimtype,String LCD) throws InterruptedException {
		
		String sRulerelations=null;
		Long ppscountBefore=0l;
		Long ppscountAfter=0l;
		boolean bstatus=false;
		ArrayList<String> sGetDPItems=new ArrayList<>();
		sGetDPItems.add(Serenity.sessionVariableCalled("DPkey"));
		if(tabname.contains("-"))
		{
			sRulerelations=StringUtils.substringAfter(tabname, "-");
			tabname=StringUtils.substringBefore(tabname, "-");
		}
		
		for (String pps : ProjectVariables.PPSList)
		{
			String sPayershort=StringUtils.substringBefore(pps, ":");
			ProjectVariables.payerShortList.add(sPayershort);
			ProjectVariables.ClaimtypeList.add(StringUtils.substringAfter(pps, ":"));
			ProjectVariables.payerKeys.add(Long.valueOf(MongoDBUtils.Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(sPayershort,"Payershort")));
			ProjectVariables.sGetPayershorts.addAll(ProjectVariables.payerShortList);
		}
		
		if(tabname.equalsIgnoreCase("RVA"))
		{
			//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
			ppscountBefore=MongoDBUtils.DispositionRecordsinMongoDBForgivenPayerLOBinAWBPage(disposition, tabname);
		}
		else if(tabname.equalsIgnoreCase("eLL"))
		{
			//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
			ppscountBefore=MongoDBUtils.NoDispositionPayerLOBforeLLDPkey();
		}
		System.out.println("Successsfully retrieved the No disposition PPS count from mongo DB for the selected DPKey ==>"+sGetDPItems);
		
		//To Initialize the disposition fields
		Intialaize_the_Dispositions_fields_to_post(disposition);
		
		//Capturing the disposition operation for the given client,release and disposition
		Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage",sRulerelations);
		
		
		System.out.println("Successsfully captured the Disposition '"+disposition+"' for the selected DPKey ==>"+sGetDPItems);
		
		//Verify the captured data is displaying in AWB Grid or not
		verify_the_captured_data_is_not_displayed_in_the_given(sGetDPItems,"DPKey",tabname);
		
		System.out.println("Verified the captured DPKEY is not visible in the AWB Grid as expected,Disposition '"+disposition+"'for the selected DPkeys ==>"+sGetDPItems);
		//To Retrieve the 'No Disposition' PPS Count from Mongo DB 
		ppscountAfter=MongoDBUtils.DispositionRecordsinMongoDBForgivenPayerLOBinAWBPage(disposition,"RWO");
		
		bstatus=ppscountAfter==ppscountBefore;
		
		GenericUtils.Verify("Before PPScount::"+ppscountBefore+"After PPScount::"+ppscountAfter+",after performing capture disposition for the dpkey::"+sGetDPItems, bstatus);
		
		//validate the captured PPS disposition in Review worked Opportunity Page 
		validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetDPItems,"Payershort","RWO");
		
		System.out.println("Captured DPKeys are displayed in RWO Grid as expected, captured DPKEys ==>"+sGetDPItems+" ,Disposition '"+disposition);
		
		
	}

	//=============================================================================================================================================================================== //
	
	public static boolean RetrievetheClientdatafromtheResponse(String username, String serviceurl) throws IOException {
		
	
		boolean bstatus=false;
		
		String ServiceRequestBody= "{\r\n" +"	\"userName\": \""+username+"\"\r\n" +"}\r\n";
		
		//method to post the given data in the given service
		MicroServRestUtils.Post_the_Data_with_Rest_Assured_And_Fetch_Clients(ServiceRequestBody, serviceurl);
		
		//System.out.println("Total Assigned CLients ==>"+j);
		System.out.println("Total Clientskeys ==>"+ProjectVariables.clientKeysList);
		System.out.println("Total Clients ==>"+ProjectVariables.clientNamesList);
		return bstatus;
	}
	
	//=============================================================================================================================================================================== //
	
	public static String RetrieveTheClientkeyfromgivenClientthroughservice(String client) throws IOException
	{
		String sClientkey=null;
		String user=Serenity.sessionVariableCalled("user");
		System.out.println("########################## Clientkey service was intiated ######################");
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();       
		String restURI=EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("restapi.baseuri");
		System.out.println(restURI);
		RetrievetheClientdatafromtheResponse(user, restURI+ProjectVariables.CLIENT_TEAM_DATA_ENDPOINT);
		
		for (int i = 0; i < ProjectVariables.clientNamesList.size(); i++) 
		{
			if(ProjectVariables.clientNamesList.get(i).contains(client))
			{
				sClientkey=StringUtils.substringAfter(ProjectVariables.clientNamesList.get(i), "=").trim();
				break;
			}
		}
		
		if(sClientkey==null)
		{
			Assert.assertTrue("Unable to retrive the clientkey through service for the given client=>"+client, false);
		}
		
		
		System.out.println("Clientkey for the client '"+client+"' ==>"+sClientkey);
		return sClientkey;
	}

	//########################################### PI-25 Steps #############################################################################
			
	public ArrayList<String> RetrieveAlltheClientsfromDropdown() 
	{
		int iClientssize=0;
		String Clientname=null;
		ArrayList<String> Clientlist=new ArrayList<>();
		
		clickGivenXpath(StringUtils.replace(Div_with_class, "value", "selectionHolder"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		iClientssize=get_Matching_WebElement_count(ClientListinDropdown);
		
		for (int i = 1; i <= iClientssize; i++) 
		{
			Clientname=get_TextFrom_Locator(ClientListinDropdown+"["+i+"]").trim();
			Clientlist.add(Clientname);
			System.out.println(i+"."+Clientname);
		}
		System.out.println(Clientlist);
		return Clientlist;
		
	}

	public void validate_the_filters_checkboxes_funcitonality(String checkboxesnames,String Pagename) {
		
		String sApplyFiltersbutton=null;
		String sResetbutton=null;
		if(Pagename.equalsIgnoreCase("Filter Panel"))
		{
			sApplyFiltersbutton="//h3[text()='Filters']/..//span[contains(text(),'Apply Filters')]/ancestor::div[@class='filter-buttons']//button[@disabled='true']";
			sResetbutton="//h3[text()='Filters']/..//span[contains(text(),'Reset')]";
		}
		else
		{
			sApplyFiltersbutton=StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")+"/ancestor::button[@disabled]";
			sResetbutton=StringUtils.replace(ApplyResetfiltersbutton, "value", "Reset");
			
		}
		List<String> checkboxexList=Arrays.asList(checkboxesnames.split(","));
				
		for (int i = 0; i < checkboxexList.size(); i++) {
			switch(checkboxexList.get(i))
			{
			case "Payer Short":
				//validate the default all checkboxes functionality
				validate_the_all_checkboxes_funtionality(checkboxexList.get(i),Serenity.sessionVariableCalled("Payershorts"));
				
				//Validate the applyfilter and reset button functionality for the filterchecbox in the RWO Page
				validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),Serenity.sessionVariableCalled("Payershorts"),sApplyFiltersbutton,sResetbutton);
				
			break;
			case "Insurance":
				//validate the default all checkboxes functionality
				validate_the_all_checkboxes_funtionality(checkboxexList.get(i),ProjectVariables.InsuranceFilterOptions);
				
				//Validate the applyfilter and reset button functionality for the filterchecbox in the RWO Page
				validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),ProjectVariables.InsuranceFilterOptions,sApplyFiltersbutton,sResetbutton);
				
			break;
			case "Product":
				//validate the default all checkboxes functionality
				//validate_the_all_checkboxes_funtionality(checkboxexList.get(i),ProjectVariables.ProductFilterOptions);
				
				//Validate the applyfilter and reset button functionality for the filterchecbox in the RWO Page
				//validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),ProjectVariables.ProductFilterOptions);
				
			break;
			
			case "Latest Client Decision":
				//validate the default all checkboxes functionality
				validate_the_all_checkboxes_funtionality(checkboxexList.get(i),ProjectVariables.LatestClientDecisionFilterOptions);
				
				//Validate the applyfilter and reset button functionality for the filterchecbox in the RWO Page
				validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),ProjectVariables.LatestClientDecisionFilterOptions,sApplyFiltersbutton,sResetbutton);
				
			break;
			
			case "Current Disposition":
				
				//validate the default all checkboxes functionality
				validate_the_all_checkboxes_funtionality(checkboxexList.get(i),ProjectVariables.CurrentDispositionFilterOptions);
				
				//Validate the applyfilter and reset button functionality for the filterchecbox in the RWO Page
				validate_the_applyfiler_reset_button_funtionality(checkboxexList.get(i),ProjectVariables.CurrentDispositionFilterOptions,sApplyFiltersbutton,sResetbutton);
				
			break;
			
		
			
			default:
				Assert.assertTrue("Given selection was not found ===>"+checkboxexList.get(i), false);
				break;
			
			}
			
			
		}
		
	}

	public void verifyThecolumnnamesinthegrid(String gridname,String gridcolnames) 
	{
		// TODO Auto-generated method stub
		List<String> ColnamesList=Arrays.asList(gridcolnames.split(","));
		
		for (int i = 0; i < ColnamesList.size(); i++) 
		{
			switch(ColnamesList.get(i))
			{
			case "DP":
			case "Raw Savings":
			case "Aggressive Savings":
			case "Edits":
				GenericUtils.Verify("'"+ColnamesList.get(i)+"' colname should be displayed under '"+gridname+"' of AWB page", is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", ColnamesList.get(i))));
			break;
			default:
				GenericUtils.Verify("'"+ColnamesList.get(i)+"' colname should be displayed under '"+gridname+"' of AWB page", is_WebElement_Displayed(StringUtils.replace(Tag_th_contains_text, "value", ColnamesList.get(i))));
			break;
			}
		}
	}

	public void verifyTheAWBGiddatabasedOnDP(String sDPKey, String sMP,String criteria) throws ParseException 
	{
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		String sRawsavings=null;
		String sAggsavings=null;
		String sEdits=null;
		String sSavingsstatus=null;
		String sLCD=null;
		String sPD=null;
		String DBSaivngsstatus=null;
		
		
		if(Serenity.sessionVariableCalled("Savingsstatus").toString().equalsIgnoreCase("0"))
		{
			DBSaivngsstatus="Opportunity";	
		}
		else if(Serenity.sessionVariableCalled("Savingsstatus").toString().equalsIgnoreCase("-1"))
		{
			DBSaivngsstatus="Production";
		}
		else
		{
			DBSaivngsstatus="Multiple";
		}
			
		String DBLCD=ReturntheValue(Serenity.sessionVariableCalled("LCD"));
		String DBPriorDis=ReturntheValue(Serenity.sessionVariableCalled("PD"));
		
		scrollingToGivenElement(getDriver(), StringUtils.replace(ButtonContainsText, "value", sDPKey));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		sRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[2]"));
		sAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[3]"));
		sEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[4]"));
		sSavingsstatus=get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[5]");
		if(is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[6]/button"))
		{
			sLCD=get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[6]/button").trim();	
		}
		else
		{
			sLCD=get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[6]/span").trim();
		}
		
		GenericUtils.Verify("AWBGrid UIRawsavings::"+sRawsavings+",DBRawsavings::"+Serenity.sessionVariableCalled("Rawsavings")+",for DP::"+sDPKey+","+criteria+"::"+sMP, Serenity.sessionVariableCalled("Rawsavings").toString().equalsIgnoreCase(sRawsavings));
		GenericUtils.Verify("AWBGrid UIAggsavings::"+sAggsavings+",DBAggsavings::"+Serenity.sessionVariableCalled("Aggsavings")+",for DP::"+sDPKey+","+criteria+"::"+sMP, Serenity.sessionVariableCalled("Aggsavings").toString().equalsIgnoreCase(sAggsavings));
		GenericUtils.Verify("AWBGrid UIEdits::"+sEdits+",DBEdits::"+Serenity.sessionVariableCalled("Edits")+",for DP::"+sDPKey+","+criteria+"::"+sMP, Serenity.sessionVariableCalled("Edits").toString().equalsIgnoreCase(sEdits));
		
		if(!DBSaivngsstatus.equalsIgnoreCase(sSavingsstatus))
		{
			String status=MongoDBUtils.getLatestDecisionforgiveneLLDPkeyPPS(sDPKey, "", "", "", "");
			DBSaivngsstatus=StringUtils.substringAfter(status, "::");
			DBLCD=StringUtils.substringBefore(status, "::");
		}
		
		//getLatestDecisionforgiveneLLDPkeyPPS
		
		GenericUtils.Verify("AWBGrid UISavingsStatus::"+sSavingsstatus+",DBSaivngsstatus::"+DBSaivngsstatus+",for DP::"+sDPKey+","+criteria+"::"+sMP, DBSaivngsstatus.equalsIgnoreCase(sSavingsstatus));
		if(DBLCD.isEmpty())
		{
			GenericUtils.Verify("AWBGrid UILatestClineDecision::"+sLCD+",DBLatestClineDecision::"+DBLCD+",for DP::"+sDPKey+","+criteria+"::"+sMP, sLCD.equalsIgnoreCase("-"));	
		}
		else
		{
			GenericUtils.Verify("AWBGrid UILatestClineDecision::"+sLCD+",DBLatestClineDecision::"+DBLCD+",for DP::"+sDPKey+","+criteria+"::"+sMP, sLCD.equalsIgnoreCase(DBLCD));
		}
		
		if(DBPriorDis.equalsIgnoreCase("No Disposition"))
		{
			GenericUtils.Verify("AWBGrid PriorDis::' ',DBPriorDis::"+DBPriorDis+",for DP::"+sDPKey+","+criteria+"::"+sMP, !is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[7]/button"));
		}
		else
		{
			sPD=get_TextFrom_Locator(StringUtils.replace(ButtonContainsText, "value", sDPKey)+"/../../following-sibling::td[7]/button").trim();
			GenericUtils.Verify("AWBGrid PriorDis::"+sPD+",DBPriorDis::"+DBPriorDis+",for DP::"+sDPKey+","+criteria+"::"+sMP, sPD.equalsIgnoreCase(DBPriorDis));
		}

	}

	public String ReturntheValue(String sData)
	{
		String svalue=null;
		List<String> sDatalist=null;

		sDatalist=Arrays.asList(sData.split(","));
		
		if(sDatalist.size()>1)
		{
			svalue="Multiple";
		}
		else
		{
			svalue=sData;
		}
		return svalue;
	}

	public void verifyDispositionPopup(String tabName) throws InterruptedException
	{
		boolean bstatus=false;
		int DPkeyssize=0;
		Assert.assertFalse("'Capture Disposition' dropdown should be disabled by default in "+tabName, is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Capture Disposition")+"/ancestor::button[@disabled]"));
		//To validate the capture disposition dropdown
		//validate_the_capture_disposition_dropdown("AWBPage");
		//To validate the capture disposition window
		validate_the_capture_disposition_window_popup_for_the_given_dispositions("AWB");
	
		//To select MP with savings status as 'Production'
		selectTheMPforProduction(tabName);
		
		Assert.assertTrue("'Savings Status' filter checkbox is unable to un-check in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","","UNCHECK",""));
		Assert.assertTrue("'Production' filter checkbox is unable to checked in the filter 'Savings Status' of the AWB Page", oOpportunityRunsPage.ApplyFilters("Savings Status","Production","CHECK",StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters")));
		defaultWait(ProjectVariables.TImeout_10_Seconds);
		if(tabName.equalsIgnoreCase("eLL"))
		{
			DPkeyssize=get_Matching_WebElement_count("(//table[contains(@class,'grid-table')]//tr//td[5]/span)");
		}
		else
		{
			DPkeyssize=get_Matching_WebElement_count(StringUtils.replace(Div_contains_class, "value", "dp-number"));
		}
		
		 
		if(DPkeyssize==0)
		{
			Assert.assertTrue(tabName+":: No DPkeys are available for production for selected Topic::"+Serenity.sessionVariableCalled("Topic"),false);
		}
		else
		{
			for (int i = 1; i <=DPkeyssize; i++) 
			{
				if(tabName.equalsIgnoreCase("eLL"))
				{
					bstatus=is_WebElement_Displayed("(//table[contains(@class,'grid-table')]//tr//td[2]/mat-checkbox)["+i+"]");
				}
				else
				{
					bstatus=is_WebElement_Displayed(StringUtils.replace(Div_contains_class, "value", "dp-number")+"["+i+"]/../../td[2]//input[@aria-checked='false']");
				}
				Assert.assertFalse(i+".DPKey is having checkbox in "+tabName+",even though it's production one", bstatus);
			}
		}
		
	}

	private void selectTheMPforProduction(String tabName) throws InterruptedException {
		
		//oOpportunityRunsPage.OpenFilterPanel();
		
		String dbTopic = null;
		if (tabName.equalsIgnoreCase("eLL")) 
		{
			dbTopic = MongoDBUtils.geteLLTopicswithNodisposition("", 
					"", "","","");
		} else {
			dbTopic = MongoDBUtils.getRVATopicswithNoDisposition(
			"", "", "","","");
			
		}
		
		Serenity.setSessionVariable("Topic").to(dbTopic);
		
		oOpportunityRunsPage.applygiventopictoawbgrid(dbTopic,"", "", "", "");
		
		
		//###############################################################
		/*if(tabName.equalsIgnoreCase("RVA Tab"))
		{
			Assert.assertTrue("Unable to un-check the 'Latest Client Decision' header checkbox and apply filter button in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Latest Client Decision","None","UNCHECK",oOpportunityRunsPage.sApplyFilters_PS));
		}
		else
		{
			Assert.assertTrue("Unable to un-check the 'Latest Client Decision' header checkbox and apply filter button in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Latest Client Decision","","UNCHECK",""));
			Assert.assertTrue("Unable to check the 'Approve Library' header checkbox and apply filter button in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Latest Client Decision","Approve Library","CHECK",""));
			Assert.assertTrue("Unable to check the 'Approve With Modifications' header checkbox and apply filter button in the policy selection drawer",oOpportunityRunsPage.ApplyFilters("Latest Client Decision","Approve With Modifications","CHECK",oOpportunityRunsPage.sApplyFilters_PS));
			
		}
		String sMP=get_TextFrom_Locator("(//div[contains(text(),'$0')]/../div)[1]");
		Assert.assertTrue("Unable to click the MP::"+sMP+" in filterpanel", clickGivenXpath("(//div[contains(text(),'$0')]/../div)[1]"));
		Serenity.setSessionVariable("Medicalpolicy").to(sMP);
		//Click on 'Apply to Opportunity Grid'
		Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",oGenericUtils.clickOnElement(StringUtils.replace(Span_contains_text, "value", "Apply To Opportunity Grid")));
		//Loading POPUP	
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		DynamicWaitfortheLoadingIconWithCount(LoadingIcon, 20);
		defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);*/
        if(tabName.equalsIgnoreCase("eLL Tab"))
		{
        Assert.assertTrue("Unable to click the '"+tabName+"' tab in AWBGrid",clickGivenXpath(StringUtils.replace(Div_contains_text, "value", "Opportunities(eLL)")));
		OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
		}
	}

	public void verifyeLLGridbasedOnDPKey(String sDPKey, String sMP, String status_CDMDecision) 
	{
		String DBLatestDecision=StringUtils.substringBefore(status_CDMDecision, "::");
		String DBStatus=StringUtils.substringAfter(status_CDMDecision, "::");
		
		String UIStatus=get_TextFrom_Locator(StringUtils.replace(Span_contains_text, "value", sDPKey)+"/../following-sibling::td[2]").trim();
		String UIDecision=get_TextFrom_Locator(StringUtils.replace(Span_contains_text, "value", sDPKey)+"/../following-sibling::td[3]/button").trim();
		
		GenericUtils.Verify("eLL Grid UIStatus::"+UIStatus+",DBStatus::"+DBStatus+",for DPKEY::"+sDPKey, UIStatus.equalsIgnoreCase(DBStatus));
		GenericUtils.Verify("eLL Grid UIDecision::"+UIDecision+",DBLatestDecision::"+DBLatestDecision+",for DPKEY::"+sDPKey, UIDecision.equalsIgnoreCase(DBLatestDecision));
		
	}
	
	public void verifyRetainfunctionalityofRVADPView(String tabname)
	{
		boolean bstatus=false;
		int idpSize=get_Matching_WebElement_count(StringUtils.replace(Div_contains_class, "value", "dp-number"));
		if(idpSize<2)
		{
			Assert.assertTrue("DPs are not avilabe to retain functionality in DPview in "+tabname, false);
		}
		String dpkey1=get_TextFrom_Locator(StringUtils.replace(Div_contains_class, "value", "dp-number")+"[1]//button").trim();
		String dpkey2=get_TextFrom_Locator(StringUtils.replace(Div_contains_class, "value", "dp-number")+"[2]//button").trim();
		
		//To open dpview of dpkey1
		clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", dpkey1)+"/../../preceding-sibling::td[4]/a");
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		System.out.println(is_WebElement_Selected(StringUtils.replace(labelcontainstext, "svalue", "ALL")+"/span"));
		clickGivenXpath(StringUtils.replace(labelcontainstext, "svalue", "ALL"));
		
		//To open dpview of dpkey2
		System.out.println(is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value", dpkey2)+"/../../preceding-sibling::td[4]/a"));
		scrollingToGivenElement(getDriver(), StringUtils.replace(ButtonContainsText, "value", dpkey2)+"/../../preceding-sibling::td[4]/a");
		clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", dpkey2)+"/../../preceding-sibling::td[4]/a");
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		bstatus=is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value", dpkey1)+"/../../preceding-sibling::td[4]/a[contains(@title,'Collapse')]");
		GenericUtils.Verify("DPview of dpkey::"+dpkey1+" should not be visible as another DPkey::"+dpkey2+" is opened", !bstatus);
		
		//To Again open dpview of dpkey1
		clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", dpkey1)+"/../../preceding-sibling::td[4]/a");
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		System.out.println(is_WebElement_Selected(StringUtils.replace(labelcontainstext, "svalue", "ALL")+"/span"));
		bstatus=is_WebElement_Selected(StringUtils.replace(labelcontainstext, "svalue", "ALL"));
		GenericUtils.Verify("PPS should not be selected for DPkey::"+dpkey1+",as per the retain functionality of DPview", !bstatus);
		
	}

	public void verifythePPSinDPviewwithDB(String dpkey,String tabName
			,String UIpayershort,String UIinsurance,String UIclaimtype,String UILCD,String Savingsstatus) throws Exception
	{
		String payershort=null;
		String insurance=null;
		String claimtype=null;
		String PPS=null;
		String ppsxpath=null;
		String DBsavingsstatus=null;
		boolean bstatus=false;
		HashSet<String> validppsList=new HashSet<>();
		ArrayList<String> ppsList=new ArrayList<>();
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		String MP=Serenity.sessionVariableCalled("Medicalpolicy");
		
		//To retrieve the PPS from service for DPview with out None decision
		oServicesPage.getUniquePPSfromClientconfigService();
		
		//To retrieve the PPS for the given dpkey as per config service
		ppsList.addAll(MongoDBUtils.retrieveThePPSforDPkey(dpkey,UIpayershort,UIinsurance,UIclaimtype,UILCD,Savingsstatus));
		
		//Method to get valid pps from eLLhierarchy collection and mdm service
		validppsList.addAll(getValidPPSbasedoneLLmidRuleClaimType(dpkey, ppsList));
		
		if(validppsList.size()==0)
		{
			int ppssize=get_Matching_WebElement_count("//div[@class='dp_view_main']//tbody//tr");
			GenericUtils.Verify("PPS size should be '0' in dpview as per RVAconfigservice and DB,DPkey::"+dpkey, ppssize==0);
			
		}
		else
		{
		for (String validpps:validppsList) 
		{
			PPS=StringUtils.substringBeforeLast(validpps, ":");
			payershort=StringUtils.substringBefore(StringUtils.substringBeforeLast(PPS, ":"),":");
			insurance=StringUtils.substringBetween(PPS, ":",":");
			claimtype=StringUtils.substringAfterLast(PPS, ":");
			DBsavingsstatus=StringUtils.substringAfterLast(validpps, ":");
			if(insurance.equalsIgnoreCase("Dual Eligible"))
			{
				insurance="dualEligible";
			}
			else
			{
				insurance=insurance.toLowerCase();
			}
			ppsxpath=PPS_Comb_status(payershort, insurance, claimtype);
			//To verify for the opportunity is displayed or not
			if(DBsavingsstatus.equalsIgnoreCase("Opportunity"))
			{
				bstatus=is_WebElement_Displayed(ppsxpath+"[not (contains(@class,'greyOut'))]");
			}
			else
			{
				bstatus=is_WebElement_Displayed(ppsxpath+"[contains(@class,'greyOut')]");
			}
			//need to add oppty db method to verifypps is captured
			/*if(!bstatus)
			{
				bstatus=MongoDBUtils.verifygivenPPSiscapturedOrNot(dpkey, UIpayershort, UIinsurance, UIclaimtype, UILCD);
			}*/
			GenericUtils.Verify("PPS '"+validpps+"' should be displayed in the DPview of dpkey::"+dpkey+" in "+tabName+" Tab for MP::"+MP, bstatus);
		}
		
		}
	}

	public void verifySavningsstatusandLCDinAWBgridbasedonfilter(String Savingssttaus,String LCD, String tabname) throws ParseException {
		String sdpKey=null;
		String UISavingsStatus=null;
		String UILCD=null;
		
		boolean bstatus=false;
		int idpSize=0;
		String sMP = Serenity.sessionVariableCalled("Medicalpolicy");
		switch (tabname) {
		case "eLL":
			idpSize = get_Matching_WebElement_count(eLL_DP_Column);
			for (int i = 1; i <= idpSize; i++) 
			{
				scrollingToGivenElement(getDriver(), eLL_DP_Column+"["+i+"]");
				defaultWait(ProjectVariables.TImeout_3_Seconds);
				sdpKey = get_TextFrom_Locator(eLL_DP_Column+"["+i+"]");
				UISavingsStatus=get_TextFrom_Locator(StringUtils.replace(Span_contains_text, "value", sdpKey)+"/../following-sibling::td[2]");
				UILCD=get_TextFrom_Locator(StringUtils.replace(Span_contains_text, "value", sdpKey)+"/../following-sibling::td[3]/button");
				
				//DB Method to retrieve the ellGrid data based on DPkey
				//String status_CDMDecision=MongoDBUtils.getLatestDecisionforgiveneLLDPkeyPPS(sdpKey, "", "", "", "");
				//DBLCD=StringUtils.substringBefore(status_CDMDecision, "::");
				// To verify savingsstatus in UI
				bstatus=UISavingsStatus.equalsIgnoreCase(Savingssttaus);
				GenericUtils.Verify("UISavingsstatus::"+UISavingsStatus+",DBSavingstatus::"+Savingssttaus+",for DPkey::"+sdpKey, bstatus);
				// To verify LCD in UI
				bstatus=LCD.equalsIgnoreCase(UILCD);
				GenericUtils.Verify("UILCD::"+UILCD+",DBLCD::"+LCD+",for DPkey::"+sdpKey, bstatus);
			
			}
			break;
		case "RVA":
			verifyLCDandsavingsstatusasperselectioninRVA(Savingssttaus, LCD, tabname);
			break;
		default:
			Assert.assertTrue("case not found==>"+tabname, false);
			break;
		}
		
		
		
	}

	public void selectGivensavingsstatus(String savingsstatus) {
		
		if(savingsstatus.equalsIgnoreCase("0"))
		{
			savingsstatus="Opportunity";
		}
		else if(savingsstatus.equalsIgnoreCase("-1"))
		{
			savingsstatus="Production";
		}
			
			
		//To select given savingsstatus 
		oOpportunityRunsPage.ApplyFilters("Savings Status", "", "UNCHECK", "");
		oOpportunityRunsPage.ApplyFilters("Savings Status", savingsstatus, "CHECK", StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters"));
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);
		
	}

	public void verifyLCDandsavingsstatusasperselectioninRVA(String savingsstatus, String LCD, String tabname) {
		boolean bstatus=false;
		int idpSize=get_Matching_WebElement_count(StringUtils.replace(Div_contains_class, "value", "dp-number"));
		if(savingsstatus.equalsIgnoreCase("0"))
		{
			savingsstatus="Opportunity";
		}
		else if(savingsstatus.equalsIgnoreCase("-1"))
		{
			savingsstatus="Production";
		}
		for (int i = 1; i <=idpSize; i++) 
		{
			scrollingToGivenElement(getDriver(), StringUtils.replace(Div_contains_class, "value", "dp-number")+"["+i+"]/../following-sibling::td[6]/button");
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			String UILCD=get_TextFrom_Locator(StringUtils.replace(Div_contains_class, "value", "dp-number")+"["+i+"]/../following-sibling::td[6]/button").trim();
			String UIsavingsstatus=get_TextFrom_Locator(StringUtils.replace(Div_contains_class, "value", "dp-number")+"["+i+"]/../following-sibling::td[5]").trim();
			
			bstatus=UIsavingsstatus.equalsIgnoreCase(savingsstatus);
			GenericUtils.Verify("Expected Savingsstaus::"+savingsstatus+",UI savingsstatus::"+UIsavingsstatus+" as per selection", bstatus);
			
			bstatus=UILCD.equalsIgnoreCase(LCD);
			GenericUtils.Verify("Expected LCD::"+LCD+",UI LCD::"+UILCD+" as per selection in RVA", bstatus);

		}
		
		
	}

	public void verifygridcolumnsinAWBPae(String gridname) {
		switch (gridname) {
		case "eLL":
			Assert.assertTrue("Unable to click the '" + gridname + "' tab in AWBGrid", 
					clickGivenXpath(StringUtils.replace(Div_contains_text, "value", "Opportunities(eLL)")));
			OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
			// To validate the coloumns in eLL Tab in awbgrid
			verifyThecolumnnamesinthegrid(gridname, ProjectVariables.eLLtabcolnames);
			break;
		case "RVA":
			// To validate the coloumns in RVA Tab in awbgrid
			verifyThecolumnnamesinthegrid(gridname, ProjectVariables.RVAtabcolnames);
			GenericUtils.Verify("'Capture Dispositions' button should be displayed in " + gridname + " in AWBGrid",
					is_WebElement_Displayed(
							StringUtils.replace(Span_contains_text, "value", "Capture Dispositions")));
			break;
		default:
			Assert.assertTrue("case not found==>" + gridname, false);
			break;
		}
		
	}

	//############################# Rule Relationship methods ########################################################//
	
	public String retrieveTheDPswithgivenrulerelationship(String rulerelationship, String payershort, String insurance,
			String claimtype, String LCD) {
		String sTopic=null;
		String sDPkey=null;
		String UIRRcol=null;
		boolean bstatus=false;
		String sPayershort=null;
		String DBruleralationship=null;
		List<String> UIrulerelationList=Arrays.asList(rulerelationship.split(","));
		ArrayList<String> TopicwithDPs=new ArrayList<>();
		//DB method to retrieve the topic with dps,which have rulerelations
		TopicwithDPs.addAll(MongoDBUtils.retrieveRulerelationsTopicswithDPkeysinRVA(payershort, insurance, claimtype, LCD));
		
		for (int i = 0; i < TopicwithDPs.size(); i++) 
		{
			String topicwithDps=StringUtils.substringBeforeLast(TopicwithDPs.get(i), "::");
			sTopic=StringUtils.substringBefore(topicwithDps,"::").trim();
			sDPkey=StringUtils.substringBetween(topicwithDps, "::","::").trim();
			DBruleralationship=StringUtils.substringAfterLast(topicwithDps, "::").trim();
			sPayershort=StringUtils.substringAfterLast(TopicwithDPs.get(i), "::");
			for (int j = 0; j < UIrulerelationList.size(); j++) 
			{
				if(UIrulerelationList.get(j).contains(":"))
				{
					UIRRcol=StringUtils.substringBefore(UIrulerelationList.get(j), ":").toUpperCase()+" : "+StringUtils.substringAfter(UIrulerelationList.get(j), ":");	
				}
				else
				{
					UIRRcol=UIrulerelationList.get(j).toUpperCase();
				}
				
				
				if(DBruleralationship.contains(UIRRcol))
				{
					bstatus=true;
				}
				else
				{
					bstatus=false;
				}
			}
			
			if(bstatus)
			{
				break;
			}
		}
		if(!bstatus)
		{
		Assert.assertTrue("No DPkey & Topic is available in DB for the given rulerelationship::"+rulerelationship, false);	
		}
		Serenity.setSessionVariable("Topic").to(sTopic);
		System.out.println(sTopic+"::"+sDPkey+"::"+sPayershort);
		return sTopic+"::"+sDPkey+"::"+sPayershort;	
	}

	public String selectDPKeyforgivenRulerelationship(String rulerelationship,String tabname,
			String payershort, String insurance, String claimtype, String LCD) throws InterruptedException 
	{
		
		boolean bstatus=false;
		String dpkeyxpath=null;
		
		//To retrieve the topics with DPs,which have rulerelationship
		String sTopicDPpayershort=retrieveTheDPswithgivenrulerelationship(rulerelationship,payershort, insurance, claimtype, LCD);
		String sTopic=StringUtils.substringBefore(StringUtils.substringBeforeLast(sTopicDPpayershort, "::"),"::");
		String sDPkey=StringUtils.substringBetween(sTopicDPpayershort, "::","::");
		String spayershort=StringUtils.substringAfterLast(sTopicDPpayershort, "::");
				
		//Apply given topic to awb grid without none decision
		oOpportunityRunsPage.applygiventopictoawbgrid(sTopic,payershort, insurance, claimtype, LCD);
		
		//To select DB rulerelationships flags filters 
		selctgivenRRinflagfilter(rulerelationship, "CHECK");
		//To select the RVA/eLL grid
		verifygridcolumnsinAWBPae(tabname);
		//To select savingstatus as 'Opportunity'
		selectGivensavingsstatus("Opportunity");
		if(tabname.equalsIgnoreCase("RVA"))
		{
			dpkeyxpath=StringUtils.replace(ButtonContainsText, "value", sDPkey);
		}
		else
		{
			dpkeyxpath=StringUtils.replace(Span_contains_text, "value", sDPkey);
		}
		bstatus=is_WebElement_Displayed(dpkeyxpath);
		GenericUtils.Verify("Rulerelationship DPkey::"+sDPkey+" should be displayed in "+tabname+",Topic::"+sTopic, bstatus);
		
		return sDPkey+"::"+spayershort;
	}

	public void verifyFlagfilterfunctionalityinRVA(String rulerelationship,String sDPkey, String sPayershort) throws Exception 
	{
		boolean bstatus=false;
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		List<String> rulerelationshipList=Arrays.asList(rulerelationship.split(","));
		//To retrieve the PPS from rva config service
		//oServicesPage.getUniquePPSfromClientconfigService();
		
		//verify RR popup for the given dpkey and payershorts
		verifygivenRRinDPviewforDPkey(sDPkey,rulerelationship,sPayershort,"Displayed");
		
		//To un-check flag filter,in order to remove
		selctgivenRRinflagfilter(rulerelationship,"UNCHECK");
		
		//verify flag icon should not be displayed for dpkey
		bstatus=is_WebElement_Displayed(StringUtils.replace(RVADPrulerelationshipicon, "dpkey", sDPkey));
		if(bstatus)
		{
			//verify RR popup for the given dpkey,flag should not displayed
			verifygivenRRinDPviewforDPkey(sDPkey,rulerelationship,sPayershort,"Not Displayed");
			
		}
		else
		{
			GenericUtils.Verify("Rulerelationship icon shouldn't be displayed as flags were unchecked for RVADPkey::"+sDPkey+",RRFlag::"+rulerelationship, true);
		}
		
		
		
		
		
	}

	private void verifygivenRRinDPviewforDPkey(String sDPkey, String rulerelationship, String sPayershort,
			String criteria) {
		int dpviewpayersize=0;
		boolean bstatus=false;
		
		List<String> payerShortsList=Arrays.asList(sPayershort.split(","));
		bstatus=is_WebElement_Displayed(StringUtils.replace(RVADPrulerelationshipicon, "dpkey", sDPkey));
		GenericUtils.Verify("Rulerelationship icon should be displayed for RVADPkey::"+sDPkey, bstatus);
		
		//To open DPview
		clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", sDPkey)+"/../../preceding-sibling::td[4]//a");
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		//To open rulerelationship popup at payershort level
		for (int i = 0; i < payerShortsList.size(); i++) 
		{
			dpviewpayersize=get_Matching_WebElement_count(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim()));
			if(dpviewpayersize==0)
			{
				Assert.assertTrue("Payershort::"+payerShortsList.get(i).trim()+" is not displayed in dpview of RVA dpkey::"+sDPkey, false);
			}
			for (int j = 1; j <= dpviewpayersize; j++) 
			{
				scrollingToGivenElement(getDriver(), StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]");
				defaultWait(ProjectVariables.TImeout_3_Seconds);
				//verify flag icon is displayed at payershort level
				bstatus=is_WebElement_Displayed(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]/..//fa-icon");
				GenericUtils.Verify("Flag icon should be displayed at payer level,payerhsort::"+payerShortsList.get(i)+",DPkey::"+sDPkey, bstatus);
			
				//To open RR popup at payershort level
				clickGivenXpath(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]/..//fa-icon");
				defaultWait(ProjectVariables.TImeout_5_Seconds);
				//
				bstatus=is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Rule Relationship ("+payerShortsList.get(i).trim()+" : DP "+sDPkey+")"));
				GenericUtils.Verify("RRPopup header should be displayed,Header::Rule Relationship ("+payerShortsList.get(i).trim()+" : DP "+sDPkey+")", bstatus);
				//verify given rulerelationship in popup
				verifygivenRulerelationshipinpopup(rulerelationship,sDPkey,payerShortsList.get(i),criteria);
			}
		}
		
	}

	private void selctgivenRRinflagfilter(String rulerelationship,String operation) {
		
		String rulerelationshipcol=null;
		String rulerelationshipvalue=null;
		List<String> rulerelationshipList=Arrays.asList(rulerelationship.split(","));
		if(operation.equalsIgnoreCase("UNCHECK"))
		{
			oOpportunityRunsPage.ApplyFilters("Flag", "", "CHECK", "");
		}
		else if(operation.equalsIgnoreCase("CHECK"))
		{
			oOpportunityRunsPage.ApplyFilters("Flag", "", "UNCHECK", "");
		}
		
		for (int i = 0; i < rulerelationshipList.size(); i++) 
		{
			rulerelationshipcol=StringUtils.substringBefore(rulerelationshipList.get(i).trim(), ":").trim();
			rulerelationshipvalue=StringUtils.substringAfter(rulerelationshipList.get(i).trim(), ":").trim();
			switch(rulerelationshipcol.toUpperCase())
			{
				case "COMPANION":
					rulerelationshipcol="Companion";
				break;
				case "MUTUALLY EXCLUSIVE":
					rulerelationshipcol=rulerelationshipvalue;
				break;
				case "OUT OF SEQUENCE":
					rulerelationshipcol="Out of Sequence";
				break;
				case "COUNTERPART":
					rulerelationshipcol="Counterpart";
				break;
				default:
					Assert.assertTrue("case not found::"+rulerelationshipcol, false);
				break;
			}
			//To check flag filter
			oOpportunityRunsPage.ApplyFilters("Flag", rulerelationshipcol, operation, "");
		}
		//To click on applyfilters button
		clickGivenXpath(StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
	}

	private void verifygivenRulerelationshipinpopup(String rulerelationship,String dpkey,String payershort,
			String criteria) 
	{
		boolean bstatus=false;
		String UIRRval=null;
		String rulerelationshipcol=null;
		String rulerelationshipvalue=null;
		List<String> rulerelationshipList=Arrays.asList(rulerelationship.split(","));
		int RRsize=0;
		for (int i = 0; i < rulerelationshipList.size(); i++) 
		{
			rulerelationshipcol=StringUtils.substringBefore(rulerelationshipList.get(i).trim(), ":").trim();
			rulerelationshipvalue=StringUtils.substringAfter(rulerelationshipList.get(i).trim(), ":").trim();
			switch(rulerelationshipcol.toUpperCase())
			{
			case "COMPANION":
				rulerelationshipcol="Companion";
				if(rulerelationshipvalue.equalsIgnoreCase("NA"))
				{
					rulerelationshipvalue="Companion";
				}
			break;
			case "MUTUALLY EXCLUSIVE":
				rulerelationshipcol="Mutually-Exclusive";
			break;
			case "OUT OF SEQUENCE":
				rulerelationshipcol="Out-of-Sequence";
			break;
			case "COUNTERPART":
				rulerelationshipcol="Counterpart";
				if(rulerelationshipvalue.equalsIgnoreCase("NA"))
				{
					rulerelationshipvalue="Counterpart";
				}
			break;
			
			default:
				Assert.assertTrue("case not found::"+rulerelationshipcol, false);
			break;
			}
			
			RRsize=get_Matching_WebElement_count(StringUtils.replace(rulerelationshipval, "value", rulerelationshipcol));
			if(criteria.equalsIgnoreCase("Not Displayed"))
			{
				if(RRsize>0)
				{
					for (int j = 1; j <= RRsize; j++) 
					{
						UIRRval=get_TextFrom_Locator(StringUtils.replace(rulerelationshipval, "value", rulerelationshipcol)+"["+j+"]");
						System.out.println(UIRRval.isEmpty());
						bstatus=UIRRval.isEmpty();
						GenericUtils.Verify("Midrulekeys shouldn't be availble in RRpouup as user un-checked flag::"+rulerelationship+",for payer::"+payershort+",DPkey::"+dpkey, bstatus);
					}
				}
				else
				{
					GenericUtils.Verify("Midrulekey shouldn't be availble in RRpouup as user un-checked flag::"+rulerelationship+",for payer::"+payershort+",DPkey::"+dpkey, true);	
				}
				
				
			}
			else
			{
				if(RRsize==0)
				{
					Assert.assertTrue("No Midrulekey is available in RRpouup at payerhsortlevel for payer::"+payershort+",DPkey::"+dpkey, false);
				}
				for (int j = 1; j <= RRsize; j++) 
				{
					 UIRRval=get_TextFrom_Locator(StringUtils.replace(rulerelationshipval, "value", rulerelationshipcol)+"["+j+"]").trim();
					bstatus=UIRRval.equalsIgnoreCase(rulerelationshipvalue);
					GenericUtils.Verify("UI RulerealtionValue::"+UIRRval+",Expected Rulerelationval::"+rulerelationshipvalue+",for DPkey::"+dpkey+",payershort::"+payershort, bstatus);
				}
			}
			
			
			
			
		}
		//To close RRpopup
		clickGivenXpath(RRCloseIcon);
		defaultWait(ProjectVariables.TImeout_3_Seconds);
	}

	public void verifyRRpopupwithDB(String rulerelationship,String sDPkey, String sPayershort)
	{
		int dpviewpayersize=0;
		boolean bstatus=false;
		
		List<String> payerShortsList=Arrays.asList(sPayershort.split(","));
		bstatus=is_WebElement_Displayed(StringUtils.replace(RVADPrulerelationshipicon, "dpkey", sDPkey));
		GenericUtils.Verify("Rulerelationship icon should be displayed for RVADPkey::"+sDPkey, bstatus);
		
		//To open DPview
		scrollingToGivenElement(getDriver(), StringUtils.replace(RVADPrulerelationshipicon, "dpkey", sDPkey));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		clickGivenXpath(StringUtils.replace(ButtonContainsText, "value", sDPkey)+"/../../preceding-sibling::td[4]//a");
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		//To open rulerelationship popup at payershort level
		for (int i = 0; i < payerShortsList.size(); i++) 
		{
			dpviewpayersize=get_Matching_WebElement_count(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim()));
			if(dpviewpayersize==0)
			{
				Assert.assertTrue("Payershort::"+payerShortsList.get(i).trim()+" is not displayed in dpview of RVA dpkey::"+sDPkey, false);
			}
			for (int j = 1; j <= dpviewpayersize; j++) 
			{
				scrollingToGivenElement(getDriver(), StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]");
				defaultWait(ProjectVariables.TImeout_3_Seconds);
				//To verify flag icon beside given payershort in dpview
				bstatus=is_WebElement_Displayed(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]/..//fa-icon");
				GenericUtils.Verify("Flag icon should be displayed at payer level,payerhsort::"+payerShortsList.get(i)+",DPkey::"+sDPkey, bstatus);
				//To retrieve claimtype for the corresponding payershort
				String sClaimtype=StringUtils.substringBetween(get_TextFrom_Locator(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i))+"["+j+"]/span").trim(),"[","]").trim();
				Serenity.setSessionVariable("Claimtype").to(sClaimtype);
				//To open RR popup at payershort level
				clickGivenXpath(StringUtils.replace(RVADPviewpayershort, "payer", payerShortsList.get(i).trim())+"["+j+"]/..//fa-icon");
				defaultWait(ProjectVariables.TImeout_5_Seconds);
				//
				bstatus=is_WebElement_Displayed(StringUtils.replace(Span_contains_text, "value", "Rule Relationship ("+payerShortsList.get(i).trim()+" : DP "+sDPkey+")"));
				GenericUtils.Verify("RRPopup header should be displayed,Header::Rule Relationship ("+payerShortsList.get(i).trim()+" : DP "+sDPkey+")", bstatus);
				
				//verify subrules in RR popup with DB
				verifysubRulesinRRpopupwithDB(rulerelationship,sDPkey,sPayershort,sClaimtype);
				
				//verify activerules in RR popup with DB
				verifyActiveRulesinRRpopupwithDB(rulerelationship,sDPkey,sPayershort,sClaimtype);
				
			
			}
		}
	
	}

	private void verifyActiveRulesinRRpopupwithDB(String rulerelationship, String sDPkey, String sPayershort,String sClaimtype) 
	{
		int subrulessize=0;
		int activerulessize=0;
		int activerulescount=0;
		boolean bstatus=false;
		String UIsubrule=null;
		String UIActiverule=null;
		String UIActiveruleDP=null;
		String UIActiveruleStatus=null;
		String UIActiveruleSavings=null;
		String UIActiveruleRR=null;
		String DBActiverule=null;
		String DBActiveruleDP=null;
		String DBActiveruleStatus=null;
		String DBActiveruleSavings=null;
		String DBActiveruleRR=null;
		String RRcolname=null;
		String DBRRval=null;
		
		ArrayList<String> dbactiveruledata=new ArrayList<>();
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		
		subrulessize=get_Matching_WebElement_count(RRsubrulecol);
				
		for (int i = 1; i <= subrulessize; i++) 
		{
			UIsubrule=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[1]").trim();
			activerulessize=get_Matching_WebElement_count(RRsubrulecol+"["+i+"]/following-sibling::mat-row");
			activerulescount=activerulessize;
			//To find exact active rules count
			for (int j = 1; j <= activerulessize; j++) 
			{
				String classname=Get_Value_By_given_attribute("class", RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]");
				if(classname.contains("group"))
				{
					activerulescount=j-1;
					break;
				}
			}
			
			//DBmethod to retrieve active rules for the RR dpkey and payershort
			dbactiveruledata.addAll(MongoDBUtils.retrieveActiverulesforRRinRVAtab(sDPkey, sPayershort,UIsubrule,sClaimtype));
			
			bstatus=activerulescount==dbactiveruledata.size();
			GenericUtils.Verify("RRpopup DBactiverules count::"+dbactiveruledata.size()+",UIactiverules count::"+activerulescount+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort, bstatus);
			
			for (int j = 1; j <= activerulescount; j++) 
			{
				UIActiverule=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]/mat-cell[1]").trim();
				UIActiveruleDP=StringUtils.substringAfter(get_TextFrom_Locator(RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]/mat-cell[2]"),"DP").trim();
				UIActiveruleStatus=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]/mat-cell[3]").trim();
				UIActiveruleSavings=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]/mat-cell[4]").trim();
				if(UIActiveruleSavings.equalsIgnoreCase("$ ---"))
				{
					UIActiveruleSavings="0";
				}
				else
				{
					UIActiveruleSavings=oDPWBPage.ReturnValue(UIActiveruleSavings);
				}
				
				
				for (String activeRuledata : dbactiveruledata) 
				{
					DBActiverule=StringUtils.substringBetween(activeRuledata, "Rule-", ";Dpkey");
					DBActiveruleDP=StringUtils.substringBetween(activeRuledata, "Dpkey-", ";svgstatus");
					DBActiveruleStatus=StringUtils.substringBetween(activeRuledata, "svgstatus-", ";rawsvgs");
					DBActiveruleSavings=StringUtils.substringBetween(activeRuledata, "rawsvgs-", ";RR");
					DBActiveruleRR=StringUtils.substringAfter(activeRuledata, "RR-");
					
					//To retrieve exact RR coloumn
					RRcolname=retrieveExactRRfromgivenDBvalue(DBActiveruleRR, "coloumn");
					DBRRval=retrieveExactRRfromgivenDBvalue(DBActiveruleRR, "value");
					if(DBActiverule.equalsIgnoreCase(UIActiverule))
					{
						GenericUtils.Verify("RRpopup UIactiverule::"+UIActiverule+",DBActiverule::"+DBActiverule+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, true);
						bstatus=UIActiveruleSavings.equalsIgnoreCase(DBActiveruleSavings);
						if(!bstatus)
						{
							System.out.println("failed.......");
						}
						GenericUtils.Verify("RRpopup UIActiveruleSavings::"+UIActiveruleSavings+",DBActiveruleSavings::"+DBActiveruleSavings+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, bstatus);
						break;
					}
					else
					{
						bstatus=false;
					}
				}
				
				if(!bstatus)
				{
					GenericUtils.Verify("RRpopup UIactiverule::"+UIActiverule+" is not avaialble in DB,for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, false);
				}
				UIActiveruleRR=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/following-sibling::mat-row["+j+"]/mat-cell[contains(@class,'"+RRcolname+"')]");
				
				bstatus=UIActiveruleDP.equalsIgnoreCase(DBActiveruleDP);
				GenericUtils.Verify("RRpopup UIActiveruleDP::"+UIActiveruleDP+",DBActiveruleDP::"+DBActiveruleDP+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, bstatus);
				
				bstatus=UIActiveruleStatus.equalsIgnoreCase(DBActiveruleStatus);
				GenericUtils.Verify("RRpopup UIActiveruleStatus::"+UIActiveruleStatus+",DBActiveruleStatus::"+DBActiveruleStatus+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, bstatus);
				
				bstatus=UIActiveruleRR.equalsIgnoreCase(DBRRval);
				GenericUtils.Verify("RRpopup UIActiveruleRR::"+UIActiveruleRR+",DBRRval::"+DBRRval+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort+",Subruleid::"+UIsubrule, bstatus);
				
				
			}
			
			
			dbactiveruledata.clear();
			
			
		
		
		}
		
		
		
	}

	private void verifysubRulesinRRpopupwithDB(String rulerelationship, String sDPkey, String sPayershort,String sClaimtype) 
	{
		int subrulessize=0;
		boolean bstatus=false;
		String UIsubrule=null;
		String UIDPkey=null;
		String UIStatus=null;
		String UIsavings=null;
		String DBsubrule=null;
		String DBSavings=null;
		String DBSvgstatus=null;
		HashSet<String> uiSubrules=new HashSet<>();
		ArrayList<String> dbsubrulewithsavings=new ArrayList<>();
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		
		//DBmethod to retrieve subrules for the RR dpkey and payershort
		dbsubrulewithsavings.addAll(MongoDBUtils.retrieveSubrulesforRRinRVAtab(sDPkey, sPayershort,sClaimtype));;
		
		subrulessize=get_Matching_WebElement_count(RRsubrulecol);
		
		
		for (int i = 1; i <= subrulessize; i++) 
		{
			UIsubrule=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[1]").trim();
			UIDPkey=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[2]").trim();
			UIStatus=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[3]").trim();
			UIsavings=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[4]").trim();
			String UImutuallyexeclusive=get_TextFrom_Locator(RRsubrulecol+"["+i+"]/mat-cell[5]").trim();
			uiSubrules.add(UIsubrule);
			if(UIsavings.equalsIgnoreCase("$ ---"))
			{
				UIsavings="0";
			}
			else
			{
				UIsavings=oDPWBPage.ReturnValue(UIsavings);
			}
			
			for (int j = 0; j < dbsubrulewithsavings.size(); j++) 
			{
				//15052.11::0::Opportunity
				DBSvgstatus=StringUtils.substringAfterLast(dbsubrulewithsavings.get(j).trim(), "::").trim();
				DBSavings=StringUtils.substringBetween(dbsubrulewithsavings.get(j).trim(), "::","::").trim();
				DBsubrule=StringUtils.substringBefore(StringUtils.substringBefore(dbsubrulewithsavings.get(j).trim(), "::"+DBSvgstatus),"::").trim();
				
				if(UIsubrule.equalsIgnoreCase(DBsubrule))
				{
					GenericUtils.Verify("RRpopup UIsubrule::"+UIsubrule+",DBsubrule::"+DBsubrule+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort, true);
					bstatus=UIsavings.equalsIgnoreCase(DBSavings);
					GenericUtils.Verify("RRpopup UIsavings::"+UIsavings+",DBSavings::"+DBSavings+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort, bstatus);
					if(DBSvgstatus.equalsIgnoreCase("Multiple"))
					{
						UIStatus="Multiple";
					}
					bstatus=UIStatus.equalsIgnoreCase(DBSvgstatus);
					GenericUtils.Verify("RRpopup UIStatus::"+UIStatus+",DBStatus::Opportunity,for dpkey::"+sDPkey+",payerhsort::"+sPayershort, bstatus);
					
					break;
				}
				else
				{
					bstatus=false;
				}
			}
			
			if(!bstatus)
			{
				GenericUtils.Verify("RRpopup UIsubrule::"+UIsubrule+" is not avaialble in DB,for dpkey::"+sDPkey+",payerhsort::"+sPayershort, false);
			}
		
			bstatus=UIDPkey.equalsIgnoreCase("DP "+sDPkey);
			GenericUtils.Verify("RRpopup UIDPkey::"+UIDPkey+",DBDPkey::DP "+sDPkey+",payerhsort::"+sPayershort, bstatus);
			
			
		
		
		}
		
		bstatus=dbsubrulewithsavings.size()==uiSubrules.size();
		GenericUtils.Verify("RRpopup DBSubrules count::"+dbsubrulewithsavings.size()+",UIsubrule count::"+uiSubrules.size()+",for dpkey::"+sDPkey+",payerhsort::"+sPayershort, bstatus);
		
		
	}

	public String retrieveExactRRfromgivenDBvalue(String rulerelationship,String criteria)
	{
		String rulerelationshipcol=null;
		String rulerelationshipvalue=null;
		List<String> rulerelationshipList=Arrays.asList(rulerelationship.split(","));
		
		for (int i = 0; i < rulerelationshipList.size(); i++) 
		{
			rulerelationshipcol=StringUtils.substringBefore(rulerelationshipList.get(i).trim(), ":").trim();
			rulerelationshipvalue=StringUtils.substringAfter(rulerelationshipList.get(i).trim(), ":").trim();
			switch(rulerelationshipcol)
			{
			case "COMPANION":
				rulerelationshipcol="Companion";
				if(rulerelationshipvalue.equalsIgnoreCase("NA"))
				{
					rulerelationshipvalue="Companion";
				}
			break;
			case "MUTUALLY EXCLUSIVE":
				rulerelationshipcol="Mutually-Exclusive";
			break;
			case "OUT OF SEQUENCE":
				rulerelationshipcol="Out-of-Sequence";
			break;
			case "COUNTERPART":
				rulerelationshipcol="Counterpart";
				if(rulerelationshipvalue.equalsIgnoreCase("NA"))
				{
					rulerelationshipvalue="Counterpart";
				}
			break;
			
			default:
				Assert.assertTrue("case not found::"+rulerelationshipcol, false);
			break;
			}
		}
		if(criteria.equalsIgnoreCase("coloumn"))
		{
			return rulerelationshipcol;
		}
		else
		{
			return rulerelationshipvalue;
		}
		
	}
	
	//*********************************** Rule Relationship DPkeys and PPS ******************************************//
	
	public HashSet<String> getDPkeyandPPSforthegivenRRDPkey(String dpKey,String payershort,String rulerelation,String claimtype) throws Exception
	{
		String subrule=null;
		String activeRule=null;
		String activeDPkey=null;
		String svgstatus=null;
		String activeRR=null;
		//String claimtype=null;
		HashSet<String> validppsList=new HashSet<>();
		ArrayList<String> PPSList=new ArrayList<>();
		ArrayList<String> subRuleList=new ArrayList<>();
		ArrayList<String> ActiveRulelist=new ArrayList<>();
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		
		//To retrieve the PPS from service for DPview with out None decision
		oServicesPage.getUniquePPSfromClientconfigService();
				
		
		//DB method to retrieve the RR subrules for the given dpkey and payershort
		subRuleList.addAll(MongoDBUtils.retrieveSubrulesforRRinRVAtab(dpKey, payershort,claimtype));
		
		for (int i = 0; i < subRuleList.size(); i++) 
		{
			subrule=StringUtils.substringBefore(subRuleList.get(i).trim(), "::");
			
			//DB method to retrieve RR activerules and corresponding dpkeys and PPS from given dpkey and payershort
			ActiveRulelist.addAll(MongoDBUtils.retrieveActiverulesforRRinRVAtab(dpKey, payershort, subrule,claimtype));
			
			for (String activeRuledata : ActiveRulelist) 
			{
				activeRule=StringUtils.substringBetween(activeRuledata, "Rule-", ";Dpkey");
				if(activeRule.contains("."))
				{
					activeDPkey=StringUtils.substringBetween(activeRuledata, "Dpkey-", ";svgstatus");
					svgstatus=StringUtils.substringBetween(activeRuledata, "svgstatus-", ";rawsvgs");
					activeRR=StringUtils.substringAfterLast(activeRuledata, "RR-");
					
					if(svgstatus.equalsIgnoreCase("Opportunity"))
					{
						//To retreive the pps for the given RR DPkey
						PPSList.addAll(MongoDBUtils.getPPSforRRDPkey(activeDPkey,payershort,activeRule,activeRR,claimtype));
					}
				}
				
			}
			
		}
		
		//To retrieve the valid PPS List based on mdm service and eLLhierarchy midruleclaimtypes
		validppsList.addAll(retrieveValidPPSfromRRDPkey(PPSList));
				
		return validppsList;
		
	}
	
	private HashSet<String> retrieveValidPPSfromRRDPkey(ArrayList<String> PPSList)
	{
		String claimtype=null;
		String activeDPkey=null;
		HashSet<String> validppsList=new HashSet<>();
				
		for (String pps : PPSList)
		{
			activeDPkey=StringUtils.substringBetween(pps,"Dpkey-",";Payershort");
			claimtype=StringUtils.substringBetween(pps,"Claimtype-",";Subrule").trim();
			//Db method to get midruleclaimtypes from eLLhierachy collection
			String midRuleclaimtypes=MongoDBUtils.getmidRuleClaimtypeineLLhierarchy(activeDPkey);
			
			List<String> eLLclaimtypeList=Arrays.asList(midRuleclaimtypes.split(","));
			
			for (int i = 0; i < eLLclaimtypeList.size(); i++) 
			{
				if(eLLclaimtypeList.get(i).trim().equalsIgnoreCase(claimtype))
				{
					System.out.println(pps);
					validppsList.add(pps);
				}
			}
			
		}
		System.out.println("Valid PPSList size::"+validppsList.size());
		
		return validppsList;
	}
	
	//********************************** Capture RR DPkey at PPS Level and verify related RR DPkeys *******************************************//
	
	public void captureDispositionatPPSLevelforRRDpkey(String dpkey,String Payershort,String rulerelationship,String disposition) throws Exception
	{
		String subrule=null;
		HashSet<String> ActualRRPPSList=new HashSet<>();
		//HashSet<String> RRRelatedPPSList=new HashSet<>();
		ArrayList<String> PPSList=new ArrayList<>();
		ArrayList<String> subRuleList=new ArrayList<>();
		ArrayList<String> sGetDPItems=new ArrayList<>();
			
		ServicesPage oServicesPage=this.switchToPage(ServicesPage.class);
		
		sGetDPItems.add(dpkey);
		ProjectVariables.sGetPayershorts.add(Payershort);
		
		//To retrieve the PPS from service for DPview with out None decision
		oServicesPage.getUniquePPSfromClientconfigService();
				
		
		//Method to select given payershort from dpkey
		oOpportunityRunsPage.selectgivenPayershortfromDPkey(dpkey, Payershort);
		String claimtype=Serenity.sessionVariableCalled("Claimtype");
		
		//DB method to retrieve the RR subrules for the given dpkey and payershort
		subRuleList.addAll(MongoDBUtils.retrieveSubrulesforRRinRVAtab(dpkey, Payershort,claimtype));
		
		for (int i = 0; i < subRuleList.size(); i++) 
		{
			subrule=StringUtils.substringBefore(subRuleList.get(i).trim(), "::");
			//To retrieve the pps for the given RR DPkey
			PPSList.addAll(MongoDBUtils.getPPSforRRDPkey(dpkey,Payershort,subrule,rulerelationship,claimtype));
			
		}
		
		//To retrieve the actual valid PPS List based on mdm service and eLLhierarchy midruleclaimtypes
		ActualRRPPSList.addAll(retrieveValidPPSfromRRDPkey(PPSList));
		if(ActualRRPPSList.size()==0)
		{
			GenericUtils.Verify("Valid Actual PPS count is zero from the given PPS::"+PPSList, false);
		}
		
		//To retrieve the RR related valid PPS List for the captured dpkey and Payershort based on mdm service and eLLhierarchy midruleclaimtypes
		ProjectVariables.RRRelatedPPSList.addAll(getDPkeyandPPSforthegivenRRDPkey(dpkey, Payershort, rulerelationship,claimtype));
		
		//To Initialize the disposition fields
		Intialaize_the_Dispositions_fields_to_post(disposition);
		
		//Capturing the disposition operation for the given client,release and disposition
		Perform_the_capture_disposition_operation(disposition,ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"AWBPage",rulerelationship);
				
		System.out.println("Successsfully captured the Disposition '"+disposition+"' for the selected DPKey::"+dpkey+",Payerhsort::"+Payershort);
		GenericUtils.Verify("Successsfully captured the Disposition '"+disposition+"' for the selected DPKey::"+dpkey+",Payerhsort::"+Payershort, true);
		
		//verify captured RR DPkey and PPS in DB
		MongoDBUtils.verifygivenRRPPSiscapturedOrNot(ActualRRPPSList, disposition);
		
		//verify  RR related DPkey and PPS in DB as updated or not
		MongoDBUtils.verifygivenRRPPSiscapturedOrNot(ProjectVariables.RRRelatedPPSList, disposition);
		
		System.out.println("Captured DPsize::"+Serenity.sessionVariableCalled("payerlobsize"));
		if(!Serenity.sessionVariableCalled("payerlobsize").toString().equalsIgnoreCase("1"))
		{
			//Verify the dpkey is still displayed as we have captured at payershort level
			verify_the_captured_data_is_displayed_in_the_given(dpkey, "AWB");
			
		}
		
		//validate the captured PPS disposition in Review worked Opportunity Page 
		validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetDPItems,"Payershort","RWO");
		
		//verify RR related DPkeys and Payershorts are displayed in RWO or not
		verifyRRRelatedDPkeysandPPSinRWO(disposition);
		
		
	}
	
	//######################################################################################################################
		
	
	public void verifyRRRelatedDPkeysandPPSinRWO(String disposition) 
	{
		ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage=this.switchToPage(ReviewWorkedOpportunityPage.class);
		String dpkey=null;
		String Payershort=null;
		ArrayList<String> sGetDPItems=new ArrayList<>();
		ProjectVariables.sGetPayershorts.clear();
		if(ProjectVariables.RRRelatedPPSList.isEmpty())
		{
			System.out.println("No DP&PPS are available in for the captured RR DP+PPS");
		}
		else
		{
			for (String pps : ProjectVariables.RRRelatedPPSList) 
			{
				String RR=StringUtils.substringAfterLast(pps, "RR-");
				dpkey=StringUtils.substringBetween(pps, "Dpkey-", ";Payershort");
				Payershort=StringUtils.substringBetween(pps, "Payershort-", ";Insurance");
				sGetDPItems.add(dpkey);
				ProjectVariables.sGetPayershorts.add(Payershort);
				
				//Refresh the browser
				refreshBrowser();
				defaultWait(ProjectVariables.TImeout_3_Seconds);
				oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
				defaultWait(ProjectVariables.TImeout_5_Seconds);
				oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
				
				if(RR.contains("MUTUALLY EXCLUSIVE"))
				{
					//click on review worked opportunity button and check the page is opening or not
					oReviewWorkedOpportunityPage.Open_the_Review_Worked_Opportunity_Page();
					//Selecting the checkboxes in the RWO Page
					oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("", "","");
					//verify Mutual Exclusive rule relation dpkeys and pps are not displayed
					verifyGivenDPkeyisnotDisplayedinRWO(dpkey,disposition);
				}
				else
				{
					//validate the captured PPS disposition in Review worked Opportunity Page 
					validate_the_captured_pps_in_review_worked_opportunity_page(disposition,sGetDPItems,"Payershort","RWO");
				}
				sGetDPItems.clear();
				ProjectVariables.sGetPayershorts.clear();
			}
		}
		
		
	}

	//Method to get valid pps from eLLhierarchy collection and mdm service
	public HashSet<String> getValidPPSbasedoneLLmidRuleClaimType(String dpkey,ArrayList<String> ppsList)
	{
		HashSet<String> validppsList=new HashSet<>();
		
		//Db method to get midruleclaimtypes from eLLhierachy collection
		String midRuleclaimtypes=MongoDBUtils.getmidRuleClaimtypeineLLhierarchy(dpkey);
		
		List<String> eLLclaimtypeList=Arrays.asList(midRuleclaimtypes.split(","));
		
		for (int i = 0; i < eLLclaimtypeList.size(); i++) 
		{
			for (int j = 0; j < ppsList.size(); j++) 
			{
				String PPS=StringUtils.substringBeforeLast(ppsList.get(j), ":");
				if(PPS.contains(eLLclaimtypeList.get(i).trim()))
				{
					validppsList.add(ppsList.get(j));
				}
			}
		}
		
		System.out.println("DPKey::"+dpkey+",valid PPSList size::"+validppsList.size());
		System.out.println("DPKey::"+dpkey+",valid PPSList::"+validppsList);
				
		return validppsList;
		
	}

	public void verify_the_captured_data_is_displayed_in_the_given(String dpkey,String Pagename) {
			
			
		//To capture All dpkeys displayed in UI
			Capturing_the_DPkeys_from_the_oppgrid_of_AWB_page(Pagename);
			
				if(ProjectVariables.UIDPKeylist.contains(dpkey.trim()))
				{
					System.out.println("DPkey '"+dpkey+"' is displayed as expected bcz it's captured at payershort level in "+Pagename);
				}
				else
				{
					Assert.assertTrue("DPkey '"+dpkey+"' is not displayed eventhough it's captured at payershort level in "+Pagename, false);
					
				}
			
	}
	
	public void verifyGivenDPkeyisnotDisplayedinRWO(String Dpkey,String disposition)
	{
		int iCaptureddataSize=0;
		//To verify DPkey in RWO
		boolean bstatus=verifycapturedDPkeysinRWO(Dpkey,"DP Level",disposition);
		
		if(!bstatus)
		{
			System.out.println("DPkey::"+Dpkey+", is not displayed as expected in RWO Page");
		}
		else
		{
			for (int i = 0; i <ProjectVariables.sGetPayershorts.size(); i++) 
			{
				iCaptureddataSize=get_Matching_WebElement_count("(//button[contains(text(),'"+ProjectVariables.sGetPayershorts.get(i)+"')]/ancestor::td/following-sibling::td)[7]//button");
				
				//!Disp_in_DPWB.equalsIgnoreCase(disposition)&&!Disp_in_DPWB.equalsIgnoreCase("Multiple")
				if(iCaptureddataSize==0)
				{
					System.out.println("DPkey::"+Dpkey+",Payershort::"+ProjectVariables.sGetPayershorts+" is not displayed as expected in RWO Page");
				}
				else
				{
					GenericUtils.Verify("DPkey::"+Dpkey+",Payershort::"+ProjectVariables.sGetPayershorts+" is  displayed in RWO Page,it shouldn't display", false);
				}
				
			}
		}
	}

	public String selectDPKeywithAllPPSforgivenRulerelationship(String rulerelationship,String tabname,
			String payershort, String insurance, String claimtype, String LCD) throws InterruptedException 
	{
		
		boolean bstatus=false;
		String dpkeyxpath=null;
		
		//To retrieve the topics with DPs,which have rulerelationship
		String sTopicDPpayershort=retrieveTheDPswithgivenrulerelationship(rulerelationship,payershort, insurance, claimtype, LCD);
		String sTopic=StringUtils.substringBefore(StringUtils.substringBeforeLast(sTopicDPpayershort, "::"),"::");
		String sDPkey=StringUtils.substringBetween(sTopicDPpayershort, "::","::");
		String spayershort=StringUtils.substringAfterLast(sTopicDPpayershort, "::");
				
		//Apply given topic to awb grid without none decision
		oOpportunityRunsPage.applyAllPPSandgiventopictoawbgrid(sTopic,payershort, insurance, claimtype, LCD);
		
		//To select DB rulerelationships flags filters 
		selctgivenRRinflagfilter(rulerelationship, "CHECK");
		//To select the RVA/eLL grid
		verifygridcolumnsinAWBPae(tabname);
		//To select savingstatus as 'Opportunity'
		//selectGivensavingsstatus("Opportunity");
		if(tabname.equalsIgnoreCase("RVA"))
		{
			dpkeyxpath=StringUtils.replace(ButtonContainsText, "value", sDPkey);
		}
		else
		{
			dpkeyxpath=StringUtils.replace(Span_contains_text, "value", sDPkey);
		}
		bstatus=is_WebElement_Displayed(dpkeyxpath);
		GenericUtils.Verify("Rulerelationship DPkey::"+sDPkey+" should be displayed in "+tabname+",Topic::"+sTopic, bstatus);
		
		return sDPkey+"::"+spayershort;
	}
	
	public boolean verifycapturedDPkeysinRWO(String Dpkey,String criteria,String Disposition)
	{
		boolean bstatus=false;
			
		
		Assert.assertTrue("Unable to enter the DPkey in the search field of Reviewwoked Opportunity Page,DPkey ===>"+Dpkey, Enter_given_Text_Element(sSearchField_RWOpp,Dpkey));
		Assert.assertTrue("Unable to click the search icon beside search box in the Reviewwoked Opportunity Page", clickGivenXpath(AWBgriSearchbutton));
		defaultWait(ProjectVariables.TImeout_5_Seconds);
		oOpportunityRunsPage.click_the_given_cheveron("DPKEYS","up");
		defaultWait(ProjectVariables.TImeout_5_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		int iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(ButtonContainsText, "value",Dpkey));
		if(iCaptureddataSize==0)
		{
			return bstatus;
		}
		else
		{
			String currentDisposition=get_TextFrom_Locator("(//button[contains(text(),'"+Dpkey+"')]/ancestor::td/following-sibling::td)[7]//button").trim();
			bstatus=currentDisposition.equalsIgnoreCase(Disposition.trim());
			System.out.println("ActualDis::"+currentDisposition+",ExpDis::"+Disposition.trim());
			System.out.println(bstatus);
			return bstatus;
		}
		
	}
	
	public void verifyUpdateDispositionatPayerLOBLevel(
			String Updatedisposition,String sdpKey,String sPayershort) throws InterruptedException
	{
		boolean bstatus=false;
		int iCaptureddataSize=0;
		
		
			
			Enter_given_Text_Element(sSearchField_RWOpp,sdpKey);
			clickGivenXpath(AWBgriSearchbutton);
			defaultWait(ProjectVariables.TImeout_5_Seconds);
			oOpportunityRunsPage.click_the_given_cheveron("DPKEYS","up");
			defaultWait(ProjectVariables.TImeout_5_Seconds);
			iCaptureddataSize=get_Matching_WebElement_count(StringUtils.replace(ButtonContainsText, "value",sdpKey));
			if(iCaptureddataSize>=1)
			{
				Assert.assertTrue("Captured DPkey is not displaying in the Review Worked Opp Grid,DPKey"+sdpKey, is_WebElement_Displayed(StringUtils.replace(ButtonContainsText, "value",sdpKey)));
				/*bstatus=is_WebElement_Displayed("//button[contains(text(),'"+sPayershort+"')]/../../../preceding-sibling::td[1]//input");
				if(!bstatus)
				{*/
					scrollingToGivenElement(getDriver(), "//button[contains(text(),'"+sPayershort+"')]");
					defaultWait(ProjectVariables.TImeout_3_Seconds);
					clickGivenXpath("//button[contains(text(),'"+sPayershort+"')]/../../../preceding-sibling::td[1]//input");	
				/*}
				else
				{
					clickGivenXpath("//button[contains(text(),'"+sPayershort+"')]/../../../preceding-sibling::td[1]//input");	
				}*/
				
				//To Initialize the disposition fields
				Intialaize_the_Dispositions_fields_to_post(Updatedisposition);
				//Capturing the disposition operation for the given client,release and disposition
				Perform_the_capture_disposition_operation(Updatedisposition, ProjectVariables.DispositionReasons,ProjectVariables.DispositionNotes,"Review Worked Opportunity","");
			
				String currentDisposition=get_TextFrom_Locator("(//button[contains(text(),'"+sPayershort+"')]/ancestor::td/following-sibling::td)[6]//button").trim();
				bstatus=currentDisposition.equalsIgnoreCase(Updatedisposition.trim());
				GenericUtils.Verify("CurrentDisposition at Payer/LOB Level,DPkey::"+sdpKey+",Payerhsort::"+sPayershort+",expected::"+Updatedisposition+",Actual::"+currentDisposition+",after updating dispostion in RWO", bstatus);
			
			}
			else if(iCaptureddataSize==0)
			{
				Assert.assertTrue("Captured Dpkey count is showing as 'zero' in the Review Worked Opp Grids,dpKey::"+sdpKey, false);
			}
			else
			{
				Assert.assertTrue("Captured DPkey count is showing as 'Multiple' in the Review Worked Opp Grid,dpKey::"+sdpKey,false);
			}
		
	}

	public void selectgivenPPSinRWO(List<String> PPSList)
	{
		ReviewWorkedOpportunityPage oReviewWorkedOpportunityPage=this.switchToPage(ReviewWorkedOpportunityPage.class);
		String payershort=null;
		String Insurance=null;
		String claimtype=null;
		String pps=null;
		HashSet<String> payershortList=new HashSet<>();
		HashSet<String> insuranceList=new HashSet<>();
		HashSet<String> claimTypeList=new HashSet<>();
		for (int i = 0; i < PPSList.size(); i++)
		{
		    pps=StringUtils.substringBeforeLast(PPSList.get(i), "-");
			payershort=StringUtils.substringBefore(StringUtils.substringBeforeLast(pps, "-"),"-");
			Insurance=StringUtils.substringBetween(pps, "-","-");
			claimtype=StringUtils.substringAfterLast(pps, "-");
			payershortList.add(payershort);
			insuranceList.add(Insurance);
			claimTypeList.add(claimtype);
		}
		payershort=String.join(",", payershortList);
		Insurance=String.join(",", insuranceList);
		claimtype=String.join(",", claimTypeList);
		clickGivenXpath(StringUtils.replace(ApplyResetfiltersbutton, "value", "Reset"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("Payer Short", payershort, "");
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("Insurance", Insurance, "");
		oReviewWorkedOpportunityPage.select_the_filters_in_RWO_Page("Product", claimtype, "");
		clickGivenXpath(StringUtils.replace(ApplyResetfiltersbutton, "value", "Apply Filters"));
		//combination of Static and dynamic wait 
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
	}
}

