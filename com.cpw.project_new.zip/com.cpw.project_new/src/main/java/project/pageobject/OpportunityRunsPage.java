package project.pageobject;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;

import org.openqa.selenium.WebElement;

import net.serenitybdd.core.Serenity;


import project.utilities.AppUtils;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;



public class OpportunityRunsPage extends SeleniumUtils {

	//Instance Creation
	GenericUtils oGenericUtils=new GenericUtils();
	AppUtils oAppUtils=new AppUtils();
	
	//Locators for Opportunity Runs page

	public static String sPolicySelection="//button[@mattooltip='Policy Drawer']";
	public  String sApplyFilters_PS="//h3[text()='Filters']/..//span[contains(text(),'Apply Filters')]";
	public static String sSearchFeild_MP="//div[@class='grid-search']//input";
	public static String sSearchIcon="//div[@class='grid-search']//fa-icon";
	public static String sDPArrow="//i[contains(@id,'dpAngle')]";
	public static String sTopicArrow="//i[contains(@id,'topicAngle')]";
	public static String sTopicCheckbox="//div[@class='aw-checkbox-cell']";
	public static String sHeadearItem=null;
	public static String sSelectItem=null;
	public String payershorts_in_AWBPage="//strong[contains(text(),'Payer Short')]/ancestor::span";
	public String ClientHeaders_in_OpportunityDashboard="((//div[contains(@class,'mx-listview-clickable mx-name-listView_Client')])//div[contains(@class,'dataRow--bold')])";
	public String ClientswithRelease="(((//div[contains(@class,'mx-listview-clickable mx-name-listView_Client')])//div[contains(@class,'dataRow--bold')])//label[contains(text(),'release')]/../../following-sibling::div//div[contains(@class,'weight-bold')]/label)";
	
	public String ClientwithPolicyRelease="(//span[contains(text(),'client')]/ancestor::td/preceding-sibling::td//span[contains(text(),'release')]/ancestor::tr//following-sibling::tr)";
	
	public String Text_Contains_tag_b="//b[contains(text(),'value')]";

	//############################################# PI-25 Locators #############################################
	public String ClientInAWBDropdown="//span[contains(text(),'client')][@class='mat-option-text']";
	
	public String RVADPExpandicon="//button[contains(text(),'dpkey')]/../../preceding-sibling::td[4]/a";
	

	//****************************************SelectPayer************************************************************************************	
	public void SelectPayer(String sClient){
		AWBPage oAWBPage = this.switchToPage(AWBPage.class);
		clickGivenXpath(StringUtils.replace(oAWBPage.Div_with_class, "value", "selectionHolder"));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		clickGivenXpath(StringUtils.replace(ClientInAWBDropdown, "client", sClient));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 10);
		GenericUtils.Verify("Client '"+sClient+"' should be displayed,after selcting in the dropdown", is_WebElement_Displayed(StringUtils.replace(oAWBPage.Span_contains_text, "value", sClient)));
		
	}
	//*****************************************PolicySelection**********************************************************************************
	public void SelectPolicySelectionAndApplyFilters(String sMedicalPolicy) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		
		//select the policy selection drawer and apply all checkboxes in that section
		SelectthePolicySelectionDrawerandApplyAllFilters();
		
		//To Selcet Display MPs/Topic toggle selection
		oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
		
		
		//To select the given MP in filterPanel and applytoopportunity grid
		SelectGivenMPinFilterPanel(sMedicalPolicy,"MP");
		
			
	}
	
	public void SelectMPwithoutNoneDecisoin(String sMedicalPolicy) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		
		//select the policy selection drawer and apply all checkboxes in that section
		ApplyAllPPSFilterswithoutNoneDecision();
		
		//To Selcet Display MPs/Topic toggle selection
		oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
		
		
		//To select the given MP in filterPanel and applytoopportunity grid
		SelectGivenMPinFilterPanel(sMedicalPolicy,"MP");
		
			
	}
	
	public void SelectPolicySelectionAndApplyFilters(String sMedicalPolicy,String payershort,String Insurance,String product,String latestclientdecision) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		
		//select the policy selection drawer and apply all checkboxes in that section
		SelectthePolicySelectionDrawerandApplyAllFilters(payershort,Insurance,product,latestclientdecision);
		
		//To Selcet Display MPs/Topic toggle selection
		oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("MP");
		
		
		//To select the given MP in filterPanel and applytoopportunity grid
		SelectGivenMPinFilterPanel(sMedicalPolicy,"MP");
		
			
	}
	
	public void SelectGivenMPinFilterPanel(String sMedicalPolicy,String criteria) throws InterruptedException {
		AWBPage oAWBPage = this.switchToPage(AWBPage.class);
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		List<String> checkboxexList=Arrays.asList(project.utilities.ProjectVariables.filters.split(","));
		
		if(is_WebElement_Enabled(StringUtils.replace(oAWBPage.Div_contains_class, "value", "selectall-reset-buttons")+"/button[2]"))
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Div_contains_class, "value", "selectall-reset-buttons")+"/button[2]");
			defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
				
		}
		//Enter Medical Policy in 'Search'feild
		Thread.sleep(2000);
		Assert.assertTrue("Unable to enter the medicalpolicy in the search box of policy selection drawer in AWB Page,medicalpolicy ==>"+sMedicalPolicy,Enter_given_Text_Element(sSearchFeild_MP, sMedicalPolicy));
		Thread.sleep(2000);
		//Click 'Search' icon
		Assert.assertTrue("Unable to click the search icon in the policy selection drawer in AWB Page",oGenericUtils.clickButton(By.xpath(sSearchIcon)));
		
		if(criteria.equalsIgnoreCase("Topic"))
		{
			int itopisize=get_Matching_WebElement_count(StringUtils.replace(oPolicySelectionFiltersection.StrongtagContainstext, "value", "\""+sMedicalPolicy+"\""));
			for (int i = 1; i <=itopisize; i++) 
			{
				String sTopic=get_TextFrom_Locator(StringUtils.replace(oPolicySelectionFiltersection.StrongtagContainstext, "value", "\""+sMedicalPolicy+"\"")+"["+i+"]").trim();
				if(sTopic.equalsIgnoreCase(sMedicalPolicy))
				{
					//Select 'Medical Policy/Topic'
					Assert.assertTrue("Unable to click the Topic '"+sMedicalPolicy+"' in the policy selection drawer in AWB Page",oGenericUtils.clickOnElement(StringUtils.replace(oPolicySelectionFiltersection.StrongtagContainstext, "value", "\""+sMedicalPolicy+"\"")+"["+i+"]"));
					break;
				}
			}
					
		}
		else
		{
			//Select 'Medical Policy/Topic'
			Assert.assertTrue("Unable to click the medicalpolicy '"+sMedicalPolicy+"' in the policy selection drawer in AWB Page",oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Div_contains_text, "value", sMedicalPolicy)));
			
		}
		//Click on 'Apply to Opportunity Grid'
		Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
		//Loading POPUP	
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);
 
		
		/*for (int i = 0; i < checkboxexList.size(); i++) 
		{
			Assert.assertTrue("'"+checkboxexList.get(i)+"' filterhead checkbox is unable to checked in the AWB Page", ApplyFilters(checkboxexList.get(i), "", "CHECK", ""));
		}*/
		
		clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Reset"));
		defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
		clickGivenXpath(StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters"));
		defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		
		
	}
	
	public void SelectthePolicySelectionDrawerandApplyAllFilters() throws InterruptedException {
		
		//To open filter panel
		OpenFilterPanel();
		
		
        //Select All Filters like ''Payer Short,Insurance,Product
        if (Serenity.sessionVariableCalled("sPayershort")==null)
        {
            Assert.assertTrue("Unable to check the 'Payershort' header checkbox in the policy selection drawer", ApplyFilters("Payer Short","","CHECK",""));
        }
        else
        {
            ApplyFilters("Payer Short", "", "UNCHECK", "");
            ApplyFilters("Payer Short", Serenity.sessionVariableCalled("sPayershort").toString(), "CHECK", "");
                            
        }
       Assert.assertTrue("Unable to check the 'Insurance' header checkbox in the policy selection drawer",ApplyFilters("Insurance","","CHECK",""));
       Assert.assertTrue("Unable to check the 'Product' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Product","","CHECK",""));
       Assert.assertTrue("Unable to check the 'latest Client Decision' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Latest Client Decision","","CHECK",sApplyFilters_PS));
       
                                        
        //Loading POPUP
        //oAppUtils.WaitUntilPageLoad();
        
        defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
        //Loading POPUP
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);
                                               
}
	
	public void ApplyAllPPSFilterswithoutNoneDecision() throws InterruptedException {
		
		//To open filter panel
		OpenFilterPanel();
		
		
        //Select All Filters like ''Payer Short,Insurance,Product
        if (Serenity.sessionVariableCalled("sPayershort")==null)
        {
            Assert.assertTrue("Unable to check the 'Payershort' header checkbox in the policy selection drawer", ApplyFilters("Payer Short","","CHECK",""));
        }
        else
        {
            ApplyFilters("Payer Short", "", "UNCHECK", "");
            ApplyFilters("Payer Short", Serenity.sessionVariableCalled("sPayershort").toString(), "CHECK", "");
                            
        }
       Assert.assertTrue("Unable to check the 'Insurance' header checkbox in the policy selection drawer",ApplyFilters("Insurance","","CHECK",""));
       Assert.assertTrue("Unable to check the 'Product' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Product","","CHECK",""));
       Assert.assertTrue("Unable to check the 'latest Client Decision' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Latest Client Decision","","CHECK",""));
       Assert.assertTrue("Unable to UN-check 'none' in 'latest Client Decision' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Latest Client Decision","None","UNCHECK",sApplyFilters_PS));
                                        
        //Loading POPUP
        //oAppUtils.WaitUntilPageLoad();
        
        defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
        //Loading POPUP
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);
                                               
	}

    public void OpenFilterPanel() {
    	//Click 'PolicySelection
        Assert.assertTrue("Unable to click the policy selection drawer link in the AWB Page", oGenericUtils.clickButton(By.xpath(sPolicySelection)));
        //Loading POPUP
        defaultWait(ProjectVariables.TImeout_5_Seconds);
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
        //Verify 'Choose a Medical PolicyTopic' screen

        boolean sGetMedicalPolicy=oGenericUtils.isElementExist("//h3[.='Choose a Medical Policy/Topic']", project.utilities.ProjectVariables.TImeout_5_Seconds);
        if(!sGetMedicalPolicy)
        {
             Assert.assertTrue("Unable to click the policy selection drawer link in the AWB Page", oGenericUtils.clickButton(By.xpath(sPolicySelection)));
        }
        defaultWait(ProjectVariables.TImeout_5_Seconds);
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
		
	}
    
	public void SelectthePolicySelectionDrawerandApplyAllFilters(String payershort,String Insurance,String product,String latestclientdecision) throws InterruptedException {
	PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
	
	List<String> Payershortlist=Arrays.asList(payershort.split(","));
	List<String> InsuranceList=Arrays.asList(Insurance.split(","));
	List<String> ClaimtypeList=Arrays.asList(product.split(","));
	List<String> LatestClientDecisionList=Arrays.asList(latestclientdecision.split(","));
	
	//To Open the filter panel
	OpenFilterPanel();
	
	//To click on 'Reset' button
	clickGivenXpath(StringUtils.replace(sApplyFilters_PS, "Apply Filters", "Reset"));
	AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
	
	//Select All Filters like 'Payer Short,Insurance,Product
	Assert.assertTrue("Unable to UN-check the 'Payershort' header checkbox in the policy selection drawer", ApplyFilters("Payer Short","","UNCHECK",""));
	Assert.assertTrue("Unable to un-check the 'Insurance' header checkbox in the policy selection drawer",ApplyFilters("Insurance","","UNCHECK",""));
	Assert.assertTrue("Unable to un-check the 'Product' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Product","","UNCHECK",""));
	Assert.assertTrue("Unable to un-check the 'Latest Client Decision' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Latest Client Decision","","UNCHECK",""));
	
	oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Payer Short",Payershortlist,"CHECK","");
	
	oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Insurance",InsuranceList,"CHECK","");
	
	oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Product",ClaimtypeList,"CHECK","");
	
	oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Latest Client Decision",LatestClientDecisionList,"CHECK",sApplyFilters_PS);
	
	AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
	//Loading POPUP
	oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
	AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
	
	
	}

  //*********************************************APPLY_FILETRS************************************************************************************
  	public boolean FilterCheckbox_Status(String sHeadearItem,String sSelectItem){
  		String sChbk_HeadearChild=null;
	  		
  		  if(sSelectItem.isEmpty())
			{
				
				 sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::mat-checkbox";
			}
	  		else if(sHeadearItem.equalsIgnoreCase("Product"))
			{
				sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::mat-tree-node//following-sibling::mat-tree-node//span[contains(text(),'"+sSelectItem+"')][not (contains(text(),'Professional'))]/ancestor::mat-checkbox";
			}
			else
			{
				sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::div[@class='select-all']//following-sibling::div//div[contains(text(),'"+sSelectItem+"')]/preceding-sibling::mat-pseudo-checkbox";
				//sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::div[@class='select-all']//following-sibling::mat-selection-list//div[contains(text(),'"+sSelectItem+"')]/preceding-sibling::mat-pseudo-checkbox";
			}
		 
  			//boolean sItem = getDriver().findElement(By.xpath(sChbk_HeadearChild)).isSelected();	
  			boolean sItem = Get_Value_By_given_attribute("class", sChbk_HeadearChild).contains("checked");
  			


  		return sItem;
  		
  	}
   
	//*********************************************APPLY_FILETRS************************************************************************************
	public boolean ApplyFilters(String sHeadearItem,String sSelectItem,String sChbk_Operation,String sApplyFilters){
		boolean bstatus=false;
		String sChbk_HeadearChild=null;
		//try{
			if(sSelectItem.isEmpty())
			{
				
				 sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::mat-checkbox";
			}
			else if(sHeadearItem.equalsIgnoreCase("Product"))
			{
				sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::mat-tree-node//following-sibling::mat-tree-node//span[contains(text(),'"+sSelectItem+"')][not (contains(text(),'Professional'))][not (contains(text(),'Outpatient'))]/ancestor::mat-checkbox";
			}
			else
			{
				sChbk_HeadearChild="//span[contains(text(),'"+sHeadearItem+"')]/ancestor::div[@class='select-all']//following-sibling::div//div[contains(text(),'"+sSelectItem+"')]/preceding-sibling::mat-pseudo-checkbox";
			}
			if(sHeadearItem.equalsIgnoreCase("Latest Client Decision")&&Serenity.sessionVariableCalled("Pagename")!="RWO")
			{
				scrollingToGivenElement(getDriver(), sChbk_HeadearChild);
				defaultWait(ProjectVariables.TImeout_2_Seconds);
			}
			
			clickGivenXpath(sChbk_HeadearChild);
			oAppUtils.DynamicWaitfortheLoadingIconWithCount(50);
			
			//boolean sItem = getDriver().findElement(By.xpath(sChbk_HeadearChild)).isSelected();||sClass.contains("indeterminate")
			String sClass=Get_Value_By_given_attribute("class", sChbk_HeadearChild);
			boolean sItem =sClass.contains("checked");
			//Check Condition
			if((!sItem) && (sChbk_Operation=="CHECK")){
				bstatus=clickGivenXpath(sChbk_HeadearChild);
				oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
				Assert.assertTrue("unable to click the '"+sHeadearItem+"' header checkbox for filteroption '"+sSelectItem+"'", bstatus);
			}
			else
			{
				bstatus=true;	
			}
			//UnCheck Condition
			if((sItem) && (sChbk_Operation=="UNCHECK")){
				bstatus= clickGivenXpath(sChbk_HeadearChild);
				oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
				Assert.assertTrue("unable to un-click the '"+sHeadearItem+"' header checkbox for filteroption '"+sSelectItem+"'", bstatus);
			}
			else
			{
				bstatus=true;
			}
			//Click on 'Apply Filters'
			if(!sApplyFilters.isEmpty()){
				bstatus=clickGivenXpath(sApplyFilters);
				oAppUtils.DynamicWaitfortheLoadingIconWithCount(20);
				Assert.assertTrue("unable to click Applyfilter button", bstatus);
			}
			else
			{
				bstatus=true;
			}


		//}catch(Exception e){
			//GenericUtils.Verify("Object not clicked Successfully , Failed due to :="+e.getMessage(),"FAILED");
		//}
		return bstatus;
		
	}
	//**********************************************SelectDPKeysInOpportunityGridofAWBPage()****************************************************************
	public ArrayList<String> SelectDPKeysInOpportunityGridofAWBPage(String sFunctionality,int sCount){
		
		ArrayList<String> sArr = new ArrayList<String>();
		String sRows=null;
		String sCheckbox=null;
		String sGetDPKey=null;
		String sDPkey=null;
		String criteria=null;
		String data=null;
		
		if(Serenity.sessionVariableCalled("Medicalpolicy")==null)
		{
			criteria="Topic";
			data=Serenity.sessionVariableCalled("Topic");
		}
		else
		{
			criteria="Medicalpolicy";
			data=Serenity.sessionVariableCalled("Medicalpolicy");
		}
			if(Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("eLL"))
			{
				sRows="(//table[contains(@class,'grid-table')]//tr//td[2]/mat-checkbox[not (@hidden)])";
			}
			else
			{
				sRows="((//div[contains(@class,'dp-number')])/../..//mat-checkbox[not (@hidden)])";	
			}
			
			int i = 0;
			
			//============================================================================>

			//Retrieving Total rows
			if(sCount>0){
				List<WebElement> sRowCount=getDriver().findElements(By.xpath(sRows));
				if(sRowCount.size()==0)
				{
				Assert.assertTrue("DPkey not available for Selected "+criteria+"::'"+data+"'", false);	
				}
				int iRequiredcount=0;
				
				if(sRowCount.size()>sCount)
				{
					iRequiredcount=sCount;
				}
				else if(sRowCount.size()<sCount)
				{
					iRequiredcount=sRowCount.size();
				}
				else
				{
					iRequiredcount=sRowCount.size();
				}
				switch(sFunctionality)
				{
				case "PAYER_CHKBOX":
					for(i=1;i<=sRowCount.size();i++)
					{						
						if(Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("eLL"))
						{
						sGetDPKey="(//table[contains(@class,'grid-table')]//tr//td[5]/span)["+i+"]";
						}
						else
						{
							sGetDPKey="(//div[contains(@class,'dp-number')]/button)["+i+"]";
						}
						sCheckbox="(//table[contains(@class,'grid-table')]//tr//td[1]/a)["+i+"]";
						Assert.assertTrue("Unable to expand the "+i+".'Dpkey' in the Grid", clickGivenXpath(sCheckbox));
						defaultWait(ProjectVariables.TImeout_5_Seconds);
						int iPayersize=get_Matching_WebElement_count("(//div[@class='dp_view_main']//td[contains(@class,'payer')])");
						if(iPayersize>=sCount)
						{
							for (int j = 1; j <= sCount; j++) 
							{
								String sPayershort=StringUtils.substringBefore(get_TextFrom_Locator("(//div[@class='dp_view_main']//td[contains(@class,'payer')])["+j+"]//span[contains(@class,'font')]"),"[").trim();
								String sClaimtype=StringUtils.substringBetween(get_TextFrom_Locator("(//div[@class='dp_view_main']//td[contains(@class,'payer')])["+j+"]//span[contains(@class,'font')]/span"),"[","]").trim();
								System.out.println(sPayershort+":"+sClaimtype);
								clickGivenXpath("(//div[@class='dp_view_main']//td[contains(@class,'payer')])["+j+"]//span[contains(@class,'check')]");
								ProjectVariables.PPSList.add(sPayershort+":"+sClaimtype);
							}
							//sCount
							sDPkey=getDriver().findElement(By.xpath(sGetDPKey)).getText().trim();
							sArr.add(sDPkey);
							System.out.println("DPkey:=="+sDPkey);
							break;
						}
						
						Assert.assertTrue("Unable to de-expand the "+i+".'Dpkey' in the Grid", clickGivenXpath(sCheckbox));
						defaultWait(ProjectVariables.TImeout_5_Seconds);
					}
					
					if(ProjectVariables.PPSList.isEmpty())
					{
						Assert.assertTrue("Given payer/lobs are not available in the dpview for topic::"+Serenity.sessionVariableCalled("Topic"), false);
					}
					break;
				case "DPKEY_CHKBOX":
					for(i=1;i<=iRequiredcount;i++)
					{						
						if(Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("eLL"))
						{
						sGetDPKey="(//table[contains(@class,'grid-table')]//tr//td[5]/span)["+i+"]";
						}
						else
						{
							sGetDPKey="(//div[contains(@class,'dp-number')]/button)["+i+"]";
						}
						sCheckbox=sRows+"["+i+"]";
						Assert.assertTrue("Unable to select the "+i+".'Dpkey' checkbox in the Grid", clickGivenXpath(sCheckbox));
						sDPkey=get_TextFrom_Locator(sGetDPKey).trim();
						
						sArr.add(sDPkey);
						System.out.println("Get Data:=="+sDPkey);
					}
					break;
				case "DPKEY_EXPAND":
					for(i=1;i<=iRequiredcount;i++)
					{	
						if(Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("eLL"))
						{
						sGetDPKey="(//table[contains(@class,'grid-table')]//tr//td[5]/span)["+i+"]";
						}
						else
						{
							sGetDPKey="(//div[contains(@class,'dp-number')]/button)["+i+"]";
						}
						sCheckbox="(//table[contains(@class,'grid-table')]//tr//td[1]/a)["+i+"]";
						Assert.assertTrue("Unable to select the "+i+".'Dpkey' checkbox in the Grid", clickGivenXpath(sRows+"["+i+"]"));
						Assert.assertTrue("Unable to expand the "+i+".'Dpkey' in the Grid", clickGivenXpath(sCheckbox));
						defaultWait(ProjectVariables.TImeout_5_Seconds);
						sDPkey=getDriver().findElement(By.xpath(sGetDPKey)).getText().trim();
						sArr.add(sDPkey);
						System.out.println("Get Data:=="+sDPkey);
						
						
					}
					break;
				case "DPKEY_CLICK":					
					sRows="(//div[contains(@class,'dp-number')]/button)";
					sDPkey=getDriver().findElement(By.xpath("(//div[contains(@class,'dp-number')]/button)[1]")).getText();
                    sArr.add(sDPkey);
                    getDriver().findElement(By.xpath("(//div[contains(@class,'dp-number')]/button)[1]")).click();
                    //Verifying DP screen displayed
                    oGenericUtils.isElementExist("//h3[contains(text(),'"+sDPkey+"')]");
                    break;
				default:
					Assert.assertTrue("Case not found::"+sFunctionality, false);
				break;
				}
					
				
			}
			else
			{
				System.out.println("Given checkboxes count for '"+sFunctionality+"' was zero from the gherkin ==>"+sCount);
			}
			Serenity.setSessionVariable("DPkey").to(sDPkey);

		return sArr;


	

	}
	
	//**********************************************Clicking Chevron****************************************************************
	
	public void click_the_given_cheveron(String chevronname, String condition) {
		String sArrow=null;
		String sChevron=null;
		boolean sArrowstatus=false;
		
		switch(chevronname.toUpperCase())
		{
		case "TOPIC":
			sChevron="//div[@class='topic-box']//fa-icon";
			Assert.assertTrue("unable to click the "+chevronname+" chevron", clickGivenXpath(sChevron));
			
			sArrow="//div[@class='topic-box']//fa-icon/*[@data-icon='angle-double-"+condition+"']";
		break;
		case "PAYERSHORT":
		case "DPKEYS":
			sChevron="//div[@class='dp-box']//fa-icon";
			Assert.assertTrue("unable to click the "+chevronname+" chevron", clickGivenXpath(sChevron));
			sArrow="//div[@class='dp-box']//fa-icon/*[@data-icon='angle-double-"+condition+"']";
		break;
		case "MEDICAL POLICY":
			sChevron="//div[@class='mp-box']//fa-icon";
			Assert.assertTrue("unable to click the "+chevronname+" chevron", clickGivenXpath(sChevron));
			sArrow="//div[@class='mp-box']//fa-icon/*[@data-icon='angle-double-"+condition+"']";
		break;
		default:
			Assert.assertTrue("given selection was not found ==>"+chevronname, false);
		break;
		}
		
		sArrowstatus=is_WebElement_Displayed(sArrow);
		if(!sArrowstatus){
			Assert.assertTrue("unable to click the "+chevronname+" chevron", clickGivenXpath(sChevron));
		}
		
		
	}
	
	//**********************************************Sorting Functionality****************************************************************
	
	public void valdiate_the_sorting_funtionality_of_clients_and_releases_in_Opportunity_dashboard() 
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		
		String PolicyReleaseyear=null;
		String PolicyReleaseyearwithmonth=null;
		ArrayList<String> Policyreleaselist=new ArrayList<>();
		HashSet<String> Yearlist=new HashSet<>();
		HashSet<String> MonthYearlist=new HashSet<>();
		
		int Policyreleasesize=get_Matching_WebElement_count(oAWBPage.OppGrid_ClientsList);
		
		for (int i = 1; i<=Policyreleasesize; i++) 
		{
			
			PolicyReleaseyearwithmonth=get_TextFrom_Locator(oAWBPage.OppGrid_ClientsList+"["+i+"]");
			
			PolicyReleaseyear=StringUtils.substringAfter(get_TextFrom_Locator(oAWBPage.OppGrid_ClientsList+"["+i+"]")," ");
			
			Policyreleaselist.add(PolicyReleaseyear);
			
			Yearlist.add(PolicyReleaseyear);
			
			MonthYearlist.add(PolicyReleaseyearwithmonth);
		}
		
		//Validating Sortng functionality for Policy release years
		oPolicySelectionFiltersection.validate_the_sorting_funtionality(Policyreleaselist,"Descending Order","Policy release year in Opportunity Dashboard");
		
		//Validating Sortng functionality for Policy release months,Clients
		PolicyReleaseMonth_Client_Sorting_Funtionality(Yearlist,MonthYearlist);
		
		//Validating Sortng functionality for Payershorts
		OpportunityDashboard_Payershorts_Sorting_Funtionality();
		
		
		
		
		
	}
	
	public void OpportunityDashboard_Payershorts_Sorting_Funtionality() {
		
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		
		String PolicyRelease=null;
		String clientname=null;
		String Payershort=null;
		ArrayList<String> PayershortList=new ArrayList<>();
		
		int client_payershortsize=get_Matching_WebElement_count(oAWBPage.OppGrid_ClientsList);
		
		for (int i = 1; i <= client_payershortsize; i++) 
		{
		
			 PolicyRelease=oAWBPage.get_TextFrom_Locator(oAWBPage.OppGrid_ClientsList+"["+i+"]").trim();
			 clientname=oAWBPage.get_TextFrom_Locator("("+oAWBPage.OppGrid_ClientsList+"["+i+"]/ancestor::td//following-sibling::td)[1]//span").trim();
			
			 int Payershortsize=RetrievePayershortsizeforthegivernclientandPolicyrelease(clientname,PolicyRelease);
			 
				
			
			if(Payershortsize==1)
			{
				System.out.println("Only one Payershort is available in the Opportunitydashboard for the release ==>"+PolicyRelease+",Client ==>"+clientname);
			}
			else
			{
				String Locator=StringUtils.replace(ClientwithPolicyRelease, "client", clientname);
				for (int j = 1; j <= Payershortsize; j++) 
				{
					Payershort=get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", PolicyRelease)+"["+j+"]//td[@aria-selected])[2]").trim();
					PayershortList.add(Payershort);
					
				}
				
				GenericUtils.validate_the_sorting_funtionality(PayershortList, "Ascending order", "Payershorts in Opportunity Dashboard for the policyrelease ==>"+PolicyRelease+",Client ==>"+clientname);
				
				PayershortList.clear();
			}
			
			
		}
		
		
	}
	
	public void PolicyReleaseMonth_Client_Sorting_Funtionality(HashSet<String> PolicyreleaseYears,HashSet<String> PolicyreleaseYearswithMonth) 
	{
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		System.out.println("Policy release years size ==>"+PolicyreleaseYears.size());
		ArrayList<String> Monthlist=new ArrayList<>();
		ArrayList<String> Clientlist=new ArrayList<>();
		String monthname=null;
		String clientname=null;
		
		for (String year : PolicyreleaseYears) 
		{
		
			int Policyreleasesize=get_Matching_WebElement_count(StringUtils.replace(oAWBPage.OppGrid_ClientsList, "20", year));
			
			for (int i = 1; i <= Policyreleasesize; i++) 
			{
				monthname=StringUtils.substringBefore(get_TextFrom_Locator(StringUtils.replace(oAWBPage.OppGrid_ClientsList, "20", year)+"["+i+"]")," ");
				Monthlist.add(monthname);
				
			}
			
			for (int k = 0; k < (Monthlist.size()- 1); k++) 
			{
				
				System.out.println("Month 1 ==>"+Monthlist.get(k));
				System.out.println("Month 2 ==>"+Monthlist.get(k+1));
				
				if(GenericUtils.Months_Sorting_funcitonality(Monthlist.get(k), Monthlist.get(k+1)).contains("Ascending"))
					{
					Assert.assertTrue("Monthnames are not in ascending order for the policy release year ==>"+year+", in Opportunity Dashboard", false);
					};

				
			}
			
			Monthlist.clear();
			
		}
		
		
		for (String yearwithmonth : PolicyreleaseYearswithMonth) {
			
			int clientsize=get_Matching_WebElement_count(StringUtils.replace(oAWBPage.OppGrid_ClientsList, "20", yearwithmonth));
			
			if(clientsize>1)
			{
				for (int i = 1; i <=clientsize; i++) 
				{
					
					clientname=get_TextFrom_Locator("("+StringUtils.replace(oAWBPage.OppGrid_ClientsList, "20", yearwithmonth)+"["+i+"]/ancestor::td//following-sibling::td)[1]//span");
					Clientlist.add(clientname);
				}
				
				GenericUtils.validate_the_sorting_funtionality(Clientlist, "Ascending order", "Clients in Opportunity Dashboard for the policyrelease ==>"+yearwithmonth);
			}
			else
			{
				System.out.println("Only one client is available for the policy release ==>"+yearwithmonth);
			}
			
			Clientlist.clear();
			
		}
		
		
		
		
		
		
	}
	
	
	public void ValidateThepayershortsandSavingswithMongoDb(String clientName, String policyRelease) throws Exception 
	{
		DPWBPage oDPWBPage=this.switchToPage(DPWBPage.class);
		String sPayershort=null;
		String sPayershortTotalEdits=null;
		String sPayershortRawsavings=null;
		String sPayershortAggsavings=null;
		String sPayershortConsavings=null;
		long iClientTotalEdits=0l;
		long iClientRawsavings=0l;
		long iClientAggsavings=0l;
		long iClientConsavings=0l;
		
		//To retrieve the client key from the given client
		String sClientkey=AWBPage.RetrieveTheClientkeyfromgivenClientthroughservice(clientName);
		String ExactRelease=StringUtils.substringAfterLast(policyRelease, " ")+GenericUtils.RetrivetheexactMonth(policyRelease);
         
					
		String Locator=StringUtils.replace(ClientwithPolicyRelease, "client", clientName);
		
		int iPayershortsize=RetrievePayershortsizeforthegivernclientandPolicyrelease(clientName,policyRelease);
		
		for (int i = 1; i <=iPayershortsize; i++) 
		{
			sPayershort=get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]//td[@aria-selected])[2]").trim();
			sPayershortTotalEdits=oDPWBPage.ReturnValue(get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]//td[@aria-selected])[3]").trim());
			sPayershortRawsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]//td[@aria-selected])[4]").trim());
			sPayershortAggsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]//td[@aria-selected])[5]").trim());
			sPayershortConsavings=oDPWBPage.ReturnValue(get_TextFrom_Locator("("+StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]//td[@aria-selected])[6]").trim());
			
			MongoDBUtils.Retrieve_the_mongodb_data_to_validate_the_CPW_oppotunityDashboard(sClientkey, sPayershort, ExactRelease);
			
			GenericUtils.Verify("Opportunity Dashboard DBTotalEdits=>"+ProjectVariables.Edits+",PayershortTotalEdits=>"+sPayershortTotalEdits+", for payershort=>"+sPayershort+",Client=>"+clientName+",Policyrelease=>"+policyRelease, ProjectVariables.Edits.get(0).equals(Long.valueOf(sPayershortTotalEdits)));
			GenericUtils.Verify("Opportunity Dashboard DBRawsavings=>"+ProjectVariables.RawSavings+",PayershortRawsavings=>"+sPayershortRawsavings+", for payershort=>"+sPayershort+",Client=>"+clientName+",Policyrelease=>"+policyRelease, ProjectVariables.RawSavings.get(0).equals(Long.valueOf(sPayershortRawsavings)));
			GenericUtils.Verify("Opportunity Dashboard DBAggsavings=>"+ProjectVariables.AggSavings+",PayershortAggsavings=>"+sPayershortAggsavings+", for payershort=>"+sPayershort+",Client=>"+clientName+",Policyrelease=>"+policyRelease, ProjectVariables.AggSavings.get(0).equals(Long.valueOf(sPayershortAggsavings)));
			GenericUtils.Verify("Opportunity Dashboard DBConsavings=>"+ProjectVariables.ConSavings+",PayershortConsavings=>"+sPayershortConsavings+", for payershort=>"+sPayershort+",Client=>"+clientName+",Policyrelease=>"+policyRelease, ProjectVariables.ConSavings.get(0).equals(Long.valueOf(sPayershortConsavings)));
			
			iClientTotalEdits=iClientTotalEdits+Long.valueOf(sPayershortTotalEdits);
			iClientRawsavings=iClientRawsavings+Long.valueOf(sPayershortRawsavings);
			iClientAggsavings=iClientAggsavings+Long.valueOf(sPayershortAggsavings);
			iClientConsavings=iClientConsavings+Long.valueOf(sPayershortConsavings);
		}
		
		Serenity.setSessionVariable("ClientTotalEdits").to(iClientTotalEdits);
		Serenity.setSessionVariable("ClientRawsavings").to(iClientRawsavings);
		Serenity.setSessionVariable("ClientAggsavings").to(iClientAggsavings);
		Serenity.setSessionVariable("ClientConsavings").to(iClientConsavings);
		
		
	}
	
	
	private int RetrievePayershortsizeforthegivernclientandPolicyrelease(String clientName, String policyRelease) 
	{
		
		int iPayershortsize=0;
		String Locator=StringUtils.replace(ClientwithPolicyRelease, "client", clientName);
		
		int Policyreleasedatasize=get_Matching_WebElement_count(StringUtils.replace(Locator, "release", policyRelease));
		
		for (int i = 1; i <=Policyreleasedatasize; i++) 
		{
			String classname=Get_Value_By_given_attribute("class", StringUtils.replace(Locator, "release", policyRelease)+"["+i+"]");
			
			if(classname.contains("group"))
			{
				iPayershortsize=i-1;
				break;
			}
		}
		
		
		
		return iPayershortsize;
	}
	
	//**********************************************SelectDPKeysInOpportunityGridofAWBPage()****************************************************************
		public ArrayList<String> SelectDPKeysInRWOPage(String sFunctionality,int sCount){
			
			AWBPage oAWBPage = this.switchToPage(AWBPage.class);
			ArrayList<String> sArr = new ArrayList<String>();
			String sArrowup=null;
			String sArrowdown=null;
			String sRows=null;
			String sCheckbox=null;
			String sGetDPKey=null;
			boolean sTopicArrow=false;
			/*if(!Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("Review Worked Opportunities"))
	        {
				Assert.assertTrue("Unable to click the 'AWBGrid Hirerarchy' icon",clickGivenXpath(oAWBPage.AWBGridHirerachy));
				
				OpportunityRunsPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
					
			}
			*/
			
			
			try{

				int i = 0;
				//============================================================================>
				switch(sFunctionality.toUpperCase()){
				case "MEDICAL POLICY":
					sArrowdown="//div[@class='mp-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-down']";
					sArrowup="//div[@class='mp-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-up']";
					sRows="//div[contains(@class,'md-desc')]//label";

					sTopicArrow=is_WebElement_Displayed(sArrowdown);
					//sTopicArrow=oGenericUtils.isElementExist(sArrowdown,ProjectVariables.MIN_COUNT);
					if(!sTopicArrow){
						clickGivenXpath(sArrowup);
					}
					break;
				case "TOPIC":
					
					if(is_WebElement_Displayed(oAWBPage.WorkedOpportunityHeader))
					{
						Assert.assertTrue("unable to click the Medicalpolicy chevron in the RWO Grid", clickGivenXpath("//div[@class='mp-box']//fa-icon"));
					}
					
					sArrowdown="//div[@class='topic-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-down']";
					sArrowup="//div[@class='topic-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-up']";
					sRows="//div[contains(@class,'topic-desc')]//label";

					sTopicArrow=is_WebElement_Displayed(sArrowdown);
					//sTopicArrow=oGenericUtils.isElementExist(sArrowdown,ProjectVariables.MIN_COUNT);
					if(!sTopicArrow){
						clickGivenXpath(sArrowup);
					}
					break;
				case "DPKEY_CLICK":	
				case "DPKEYS":
				case "TOPIC_DPKEY_CHECKBOX":
				//case "DPKEY_CLICK":	
					sArrowdown="//div[@class='dp-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-down']";
					sArrowup="//div[@class='dp-box']//fa-icon/*[name()='svg'][@data-icon='angle-double-up']";
					sRows="//div[contains(@class,'dp-desc')]//span";
					
					

					sTopicArrow=is_WebElement_Displayed(sArrowup);
					//sTopicArrow=oGenericUtils.isElementExist(sArrowup,ProjectVariables.MIN_COUNT);

					if(!sTopicArrow){
						clickGivenXpath(sArrowdown);
						defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
						
					}							

					break;
				default:
					
					Assert.assertTrue("Given selection was not found ==>"+sFunctionality, false);
				break;
					
				}
				//============================================================================>

				//Retrieving Total rows
				if(sCount>0){
					List<WebElement> sRowCount=getDriver().findElements(By.xpath(sRows));
					if(sRowCount.size()==0)
					{
					Assert.assertTrue("'"+sFunctionality+"' Records not available for Selected MedicalPolicy '"+Serenity.sessionVariableCalled("Medicalpolicy")+"'", false);	
					}
					int iRequiredcount=0;
					
					if(sRowCount.size()>sCount)
					{
						iRequiredcount=sCount;
					}
					else if(sRowCount.size()<sCount)
					{
						iRequiredcount=sRowCount.size();
					}
					else
					{
						iRequiredcount=sRowCount.size();
					}
						if(!sFunctionality.equalsIgnoreCase("DPKEY_CLICK")){
							for(i=1;i<=iRequiredcount;i++){						
								
								if(sFunctionality.equalsIgnoreCase("MEDICAL POLICY")){
									sGetDPKey="(//div[contains(@class,'md-desc')]//label)["+i+"]";
									sCheckbox="(//div[contains(@class,'md-desc')]//label)["+i+"]/..//input";
								}
								else if(sFunctionality.equalsIgnoreCase("TOPIC")){
									sGetDPKey="(//div[contains(@class,'topic-desc')]//label)["+i+"]";
									sCheckbox="(//div[contains(@class,'topic-desc')]//label)["+i+"]/..//input";
								}else{
									sGetDPKey="(//div[contains(@class,'dp-number')]/button)["+i+"]";
									sCheckbox="(//div[contains(@class,'dp-desc')]//span)["+i+"]/../../..//input";
								}
								
								sTopicArrow=is_WebElement_Displayed(sCheckbox);
								
								Assert.assertTrue(sFunctionality+" checkbox was not displayed in the grid", sTopicArrow);
								
								Assert.assertTrue("Unable to select the '"+sFunctionality+"' checkbox in the Grid", clickGivenXpath(sCheckbox));
								sArr.add(getDriver().findElement(By.xpath(sGetDPKey)).getText());
								System.out.println("Get Data:=="+getDriver().findElement(By.xpath(sGetDPKey)).getText());
							}
						}else{ 
							

							//Get Current Disposition
	                       //Serenity.setSessionVariable("sCurrentDP").to(oGenericUtils.GetElementText("(//div[contains(@class,'dp-number')]/button/ancestor::tr)[1]//td[11]/button"));
	                        Serenity.setSessionVariable("sTopic").to(oGenericUtils.GetElementText("(//div[contains(@class,'topic-desc')]//label)[1]"));
	                        
	                        if(Serenity.sessionVariableCalled("Pagename")!=null&&Serenity.sessionVariableCalled("Pagename").toString().equalsIgnoreCase("Review Worked Opportunities"))
	                        {
	                        	Serenity.setSessionVariable("sCurrentDP").to(oGenericUtils.GetElementText("(//div[contains(@class,'dp-number')]/button/ancestor::tr)[1]//td[10]/button"));
	                        	Serenity.setSessionVariable("Medicalpolicy").to(oGenericUtils.GetElementText("(//div[contains(@class,'md-desc')]//label)[1]"));	
	                        }
	                        
	                        //=====================================================================>
	                        String sGetDPVal=getDriver().findElement(By.xpath("(//div[contains(@class,'dp-number')]/button)[1]")).getText();
	                        sArr.add(sGetDPVal);
	                        getDriver().findElement(By.xpath("(//div[@class='dp-number']//button)[1]")).click();
	                        defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
	                        oAppUtils.DynamicWaitfortheLoadingIconWithCount(5);
	                        //Verifying DP screen displayed
	                        oGenericUtils.isElementExist("//h3[contains(text(),'"+sGetDPVal+"')]");
	                        //oGenericUtils.isElementExist("span", sGetDPVal);
	                        }

					//}else{
						//GenericUtils.Verify("These many '"+sFunctionality+"' Records not available for Selected MedicalPolicy '"+Serenity.sessionVariableCalled("Medicalpolicy")+"',reuquired count===>"+sCount,"FAILED");
					//}
				}
				else
				{
					System.out.println("Given checkboxes count for '"+sFunctionality+"' was zero from the gherkin ==>"+sCount);
				}


			}catch(Exception e){
				GenericUtils.Verify("Object not clicked Successfully , Failed due to :="+e.getMessage(),"FAILED");

			}

			return sArr;


		

		}
	
	public void selectGivenMulipleMPs(HashSet<String> MPs,String criteria) throws InterruptedException {
		AWBPage oAWBPage = this.switchToPage(AWBPage.class);
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		List<String> checkboxexList=Arrays.asList(project.utilities.ProjectVariables.filters.split(","));
		String MP_Topic=null;
		String mptopicXpath=null;
		if(criteria.equalsIgnoreCase("Topic")){
			mptopicXpath=oPolicySelectionFiltersection.StrongtagContainstext;
		}
		else
		{
			mptopicXpath="("+oAWBPage.Div_contains_text+")";
		}
		//To click refresh button
		if(is_WebElement_Enabled(StringUtils.replace(oAWBPage.Div_contains_class, "value", "selectall-reset-buttons")+"/button[2]"))
		{
			oAWBPage.clickGivenXpath(StringUtils.replace(oAWBPage.Div_contains_class, "value", "selectall-reset-buttons")+"/button[2]");
			defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		}
		
		for (String medicalpolicy : MPs) {
		
			int mptopicsize=get_Matching_WebElement_count(StringUtils.replace(mptopicXpath, "value", medicalpolicy.trim()));
			if(mptopicsize>1)
			{
				for (int j = 1; j <=mptopicsize; j++) {
					MP_Topic=get_TextFrom_Locator(StringUtils.replace(mptopicXpath, "value", medicalpolicy.trim())+"["+j+"]").trim();
					if(MP_Topic.equalsIgnoreCase(medicalpolicy.trim()))
					{
						clickGivenXpath(StringUtils.replace(mptopicXpath, "value", medicalpolicy.trim())+"["+j+"]");
					}
				}
			}
			else
			{
				clickGivenXpath(StringUtils.replace(mptopicXpath, "value", medicalpolicy.trim()));
			}
		}
		//Click on 'Apply to Opportunity Grid'
		Assert.assertTrue("Unable to click the 'ApplyToOpportunityGrid' button in the policy selection drawer in AWB Page",oGenericUtils.clickOnElement(StringUtils.replace(oAWBPage.Span_contains_text, "value", "Apply To Opportunity Grid")));
		//Loading POPUP	
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
		defaultWait(project.utilities.ProjectVariables.TImeout_3_Seconds);
        oAppUtils.DynamicWaitfortheLoadingIconWithCount(30);
		
		for (int i = 0; i < checkboxexList.size(); i++) 
		{
			Assert.assertTrue("'"+checkboxexList.get(i)+"' filterhead checkbox is unable to checked in the AWB Page", ApplyFilters(checkboxexList.get(i), "", "CHECK", ""));
		}
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		Assert.assertTrue("'Saving Status' filterhead checkbox is unable to checked in the AWB Page", ApplyFilters("Savings Status", "", "CHECK", StringUtils.replace(oAWBPage.ApplyResetfiltersbutton, "value", "Apply Filters")));
		defaultWait(project.utilities.ProjectVariables.TImeout_5_Seconds);
		Assert.assertFalse("'No results found that meet the search criteria.' message is displayed in the AWB Grid for the Medical policy ==>"+MPs,is_WebElement_Displayed(StringUtils.replace(oAWBPage.Div_contains_text, "value", "No results found that meet the search criteria.")));

		
	}

	public void applygiventopictoawbgrid(String sTopic,
			String payershort, String insurance, String claimtype, String LCD) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		if(payershort.isEmpty())
	{
		// To open filter panel
		ApplyAllPPSFilterswithoutNoneDecision();
	}
	else
	{
		// To open filter panel
		SelectthePolicySelectionDrawerandApplyAllFilters(payershort, insurance, claimtype, LCD);
	}
	// To Selcet Display MPs/Topic toggle selection
	oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
	// Select the policy selection drawer and apply all checkboxes
	SelectGivenMPinFilterPanel(sTopic, "Topic");
		
	}
	
	public void selectgivennoofPPSandLCDCombination(String payercount,String inscount,String productcount,String lcdcount)
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		List<String> payerShortlist=new ArrayList<>();
		List<String> insurancelist=new ArrayList<>();
		List<String> claimTypelist=new ArrayList<>();
		List<String> LCDlist=new ArrayList<>();
		int iPayercount=0;
		
		payerShortlist.addAll(MongoDBUtils.getTheDistinctdataBasedOnClient("_id.payerShort", "Payershort"));
		insurancelist=Arrays.asList(ProjectVariables.InsuranceFilterOptions.split(","));
		claimTypelist=Arrays.asList(ProjectVariables.ProductFilterOptions.split(","));
		LCDlist=Arrays.asList(ProjectVariables.LatestClientDecisionFilterOptions.split(","));
		
		if(Integer.valueOf(payercount)>payerShortlist.size())
		{
			System.out.println("Given payercount is greaterthan availble payercount for the client,so putting payercount as available payer count");
			iPayercount=payerShortlist.size();
		}
		else
		{
			iPayercount=Integer.valueOf(payercount);
		}
		//To retrieve the dynamic combinations
		ProjectVariables.payerShortList.addAll(GenericUtils.generateRandomCombinations(payerShortlist, iPayercount));
		ProjectVariables.insuranceList.addAll(GenericUtils.generateRandomCombinations(insurancelist, Integer.valueOf(inscount)));
		ProjectVariables.ClaimtypeList.addAll(GenericUtils.generateRandomCombinations(claimTypelist, Integer.valueOf(productcount)));
		ProjectVariables.lCDlist.addAll(GenericUtils.generateRandomCombinations(LCDlist, Integer.valueOf(lcdcount)));
		
		//To Open the filter panel
		OpenFilterPanel();
		
		//To click on 'Reset' button
		clickGivenXpath(StringUtils.replace(sApplyFilters_PS, "Apply Filters", "Reset"));
		AWBPage.defaultWait(ProjectVariables.TImeout_5_Seconds);
		
		//Select All Filters like 'Payer Short,Insurance,Product
		Assert.assertTrue("Unable to UN-check the 'Payershort' header checkbox in the policy selection drawer", ApplyFilters("Payer Short","","UNCHECK",""));
		Assert.assertTrue("Unable to un-check the 'Insurance' header checkbox in the policy selection drawer",ApplyFilters("Insurance","","UNCHECK",""));
		Assert.assertTrue("Unable to un-check the 'Product' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Product","","UNCHECK",""));
		Assert.assertTrue("Unable to un-check the 'Latest Client Decision' header checkbox and apply filter button in the policy selection drawer",ApplyFilters("Latest Client Decision","","UNCHECK",""));
		
		if(iPayercount==payerShortlist.size())
		{
			ApplyFilters("Payer Short","","CHECK","");
		}
		else
		{
			oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Payer Short",ProjectVariables.payerShortList,"CHECK","");	
		}
		
		
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Insurance",ProjectVariables.insuranceList,"CHECK","");
		
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Product",ProjectVariables.ClaimtypeList,"CHECK","");
		
		oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection("Latest Client Decision",ProjectVariables.lCDlist,"CHECK",sApplyFilters_PS);
		
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		//Loading POPUP
		oAppUtils.DynamicWaitfortheLoadingIconWithCount(10);
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		System.out.println("Payershorts::"+ProjectVariables.payerShortList);
		System.out.println("Insurances::"+ProjectVariables.insuranceList);
		System.out.println("ClaimtypeList::"+ProjectVariables.ClaimtypeList);
		System.out.println("lCDlist::"+ProjectVariables.lCDlist);
		GenericUtils.Verify("Dynamic PPS Combo,payershort::"+ProjectVariables.payerShortList+",Insurance::"+ProjectVariables.insuranceList+","
				+ "Claimtype::"+ProjectVariables.ClaimtypeList+",LCD::"+ProjectVariables.lCDlist, true);
		
	}
	
	public void userSelectsgivenPPSinFilterpanel(String data,String colname) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		List<String> datalist=Arrays.asList(data.split(","));
		//Select All Filters like 'Payer Short,Insurance,Product
		Assert.assertTrue("Unable to UN-check the '"+colname+"' header checkbox in the policy selection drawer", ApplyFilters(colname,"","UNCHECK",""));
		if(data.isEmpty())
		{
			Assert.assertTrue("Unable to check the '"+colname+"' header checkbox in the policy selection drawer",ApplyFilters(colname,"","CHECK",""));
		}
		else
		{
			oPolicySelectionFiltersection.SelelctthegivenfilterscheckboxesInPolicySelection(colname,datalist,"CHECK","");	
		}
		
		AWBPage.defaultWait(ProjectVariables.TImeout_2_Seconds);
		
		
		}
	
	//############################################# Select given Payershort from given dpkey in grid ###################################################//
	
	public void selectgivenPayershortfromDPkey(String dpkey,String payershort)
	{
		int dpviewpayersize=0;
		String sClaimtype=null;
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
	
		scrollingToGivenElement(getDriver(), StringUtils.replace(oAWBPage.ButtonContainsText, "value", dpkey));
		defaultWait(ProjectVariables.TImeout_3_Seconds);
		clickGivenXpath(StringUtils.replace(RVADPExpandicon, "dpkey", dpkey));
		defaultWait(ProjectVariables.TImeout_5_Seconds);
		dpviewpayersize=get_Matching_WebElement_count(StringUtils.replace(oAWBPage.RVADPviewpayershort, "payer", payershort));
		if(dpviewpayersize==0)
		{
			Assert.assertTrue("Payershort::"+payershort+" is not displayed in dpview of RVA dpkey::"+dpkey, false);
		}
		for (int j = 1; j <= dpviewpayersize; j++) 
		{
			scrollingToGivenElement(getDriver(), StringUtils.replace(oAWBPage.RVADPviewpayershort, "payer", payershort)+"["+j+"]");
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			clickGivenXpath(StringUtils.replace(oAWBPage.RVADPviewpayershort, "payer", payershort)+"["+j+"]");
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			sClaimtype=StringUtils.substringBetween(get_TextFrom_Locator(StringUtils.replace(oAWBPage.RVADPviewpayershort, "payer", payershort)+"["+j+"]/span").trim(),"[","]").trim();
			Serenity.setSessionVariable("Claimtype").to(sClaimtype);
			Serenity.setSessionVariable("payerlobsize").to(String.valueOf(dpviewpayersize));
			break;
		}
	}
	
	public void applyAllPPSandgiventopictoawbgrid(String sTopic,
			String payershort, String insurance, String claimtype, String LCD) throws InterruptedException
	{
		PolicySelectionFiltersection oPolicySelectionFiltersection=this.switchToPage(PolicySelectionFiltersection.class);
		AWBPage oAWBPage=this.switchToPage(AWBPage.class);
		if(payershort.isEmpty())
	{
			//To open filter panel
			OpenFilterPanel();
			clickGivenXpath(StringUtils.replace(sApplyFilters_PS, "Apply Filters", "Reset"));
			defaultWait(ProjectVariables.TImeout_3_Seconds);
			clickGivenXpath(sApplyFilters_PS);
			DynamicWaitfortheLoadingIconWithCount(oAWBPage.LoadingIcon, 20);
	}
	else
	{
		// To open filter panel
		SelectthePolicySelectionDrawerandApplyAllFilters(payershort, insurance, claimtype, LCD);
	}
	// To Selcet Display MPs/Topic toggle selection
	oPolicySelectionFiltersection.SelectTheDisplayMPTopicToggleinFilterPanel("Topic");
	// Select the policy selection drawer and apply all checkboxes
	SelectGivenMPinFilterPanel(sTopic, "Topic");
		
	}
	
}
