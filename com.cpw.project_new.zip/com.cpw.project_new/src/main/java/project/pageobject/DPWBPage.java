package project.pageobject;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.pages.PageObject;
import project.utilities.GenericUtils;
import project.utilities.MongoDBUtils;
import project.utilities.ProjectVariables;
import project.utilities.SeleniumUtils;


public class DPWBPage extends SeleniumUtils{
                
                GenericUtils oGenericUtils=new GenericUtils();
                //Locators
                
                //Retrieving DPWB Insurance data
                
                public void RetreiveDPWBInsuranceSectionData(String sInsuranceName,String sSectionDta,String sDisposition){
                    //public String sDPWBInsuranceSection="//p[.='Dual Eligible']/..//p[.='Edits']/..//div/div";
                    ArrayList<String> sArr = null;
                    String sGetEdits=null;
                    String sGetRawSavings=null;
                    String sGetAggSavings=null;
                    String sGetConSavings=null;
                    String sDPDescription=null;
                        try{
                                        
                                        
                        switch(sSectionDta.trim().toUpperCase()){
                        
                        case "INSURANCE_SECTION":
           
                                        sGetEdits=ReturnValue(oGenericUtils.GetElementText("//p[.='"+sInsuranceName+"']/..//p/..//small[.='Edits']/..//span"));
                                        sGetRawSavings=ReturnValue(oGenericUtils.GetElementText("//p[.='"+sInsuranceName+"']/..//p/..//small[.='Raw Savings']/..//span"));
                                        sGetAggSavings=ReturnValue(oGenericUtils.GetElementText("//p[.='"+sInsuranceName+"']/..//p/..//small[.='Agg Savings']/..//span"));
                                        //sGetConSavings=ReturnValue(oGenericUtils.GetElementText("//p[.='"+sInsuranceName+"']/..//p/..//small[.='Con Savings']/..//span"));
                                        boolean sResult=oGenericUtils.isElementExist("//*[.='DP Description']/..//button[contains(text(),'More')]", 5);
                                                        if(sResult==true){
                                                                        oGenericUtils.clickOnElement("//*[.='DP Description']/..//button[contains(text(),'More')]");                                                                                           
                                                        }
                                         sDPDescription= oGenericUtils.GetElementText("//*[.='DP Description']/..//span");
                                        
                                         //Retrieve data from MongoDB
                                        MongoDBUtils.Savings_summary_for_DPWB_based_on_insurance(sDisposition, sInsuranceName,"",Serenity.sessionVariableCalled("savingsstatus"));
                                        
                                        if(!sGetEdits.equalsIgnoreCase("-"))
                                        {
                                        	 //Verify DP Description output
                                            oGenericUtils.CompareTwoValues("DP Description Under "+sSectionDta+" section of '"+sInsuranceName+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sDPDescription.trim(), ProjectVariables.DB_DPDesc.trim());
                                           
                                        }
                                        
                                       
                                        oGenericUtils.CompareTwoValues("Edits Under "+sSectionDta+" section of '"+sInsuranceName+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sGetEdits, ProjectVariables.Edits.get(0));
                                        oGenericUtils.CompareTwoValues("Raw Savings "+sSectionDta+" section of '"+sInsuranceName+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sGetRawSavings, ProjectVariables.RawSavings.get(0));
                                        oGenericUtils.CompareTwoValues("Agg Savings "+sSectionDta+" section of '"+sInsuranceName+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sGetAggSavings, ProjectVariables.AggSavings.get(0));
                                        //oGenericUtils.CompareTwoValues("Con Savings "+sSectionDta+" section of '"+sInsuranceName+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sGetConSavings, ProjectVariables.ConSavings.get(0));
                        
                                        break;
                        case "DP_SUMMARY_SAVINGS":
                         	
                                        sGetEdits=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("//span[contains(text(),'Edits')]/../..//p")), "Edits").trim();
                                        sGetRawSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("//span[contains(text(),'Raw Savings')]/../..//p")), "Raw Savings").trim();
                                        sGetAggSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("//span[contains(text(),'Agg Savings')]/../..//p")), "Agg Savings").trim();
                                        //sGetConSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("//span[contains(text(),'Con Savings')]/../..//p")), "Con Savings").trim();
                                        //Retrieve data from MongoDB
                                        MongoDBUtils.Savings_summary_for_DPWB_based_on_insurance(sDisposition, "","",Serenity.sessionVariableCalled("savingsstatus"));
                                        
                                        oGenericUtils.CompareTwoValues("Edits Under "+sSectionDta+" section",sGetEdits, ProjectVariables.Edits.get(0));
                                        oGenericUtils.CompareTwoValues("Raw Savings "+sSectionDta+" section",sGetRawSavings, ProjectVariables.RawSavings.get(0));
                                        oGenericUtils.CompareTwoValues("Agg Savings "+sSectionDta+" section",sGetAggSavings, ProjectVariables.AggSavings.get(0));
                                        //oGenericUtils.CompareTwoValues("Con Savings "+sSectionDta+" section",sGetConSavings, ProjectVariables.ConSavings.get(0));
                        
                                        break;   
                          default:
                        	Assert.assertTrue("Given selection was not found ==>"+sSectionDta, false);  
                          break;
                        }
                        
                        
                                                        
                        }catch(Exception e){
                                                GenericUtils.Verify("Object not found , Failed due to :="+e.getMessage(),"FAILED");
                                }
                                
                                
                }
                //==================================================
                public String ReturnValue(String sInput){
                                
                                String sval=sInput;
                                // TODO Auto-generated method stub
                                                                String sfinalval=null;
                                                                
                                                                int sintval=sval.indexOf("$");
                                                                if(sintval==-1)  {
                                                                                sfinalval=sval.replace(",", "");
                                                                }else{
                                                                                sfinalval=sval.replace("$", "").replace(",", "");
                                                                }
                                                                
                                                                //System.out.println(sfinalval);
                                                return   sfinalval;
                                
                }
                //=========================================Summary Data=============================================================>
public void sRetrieveSummaryData(String sDisposition){
               
                String sGetMDPolicy=null;
                                
                try{
	                                            
                                //Ex;- //p[.='Disposition']/..//div/div                                                        
                            //Retrieve Text for Disposition
				
                String sGetDisposition= StringUtils.substringBefore(oGenericUtils.GetElementText("//span[.='Disposition']/../..//p"), "Disposition").trim();
                if(sDisposition.equalsIgnoreCase("No Disposition")){
                            oGenericUtils.CompareTwoValues("Disposition Summary data",sGetDisposition, "-");
                            sGetMDPolicy= Serenity.sessionVariableCalled("Medicalpolicy");
                }else{
                	if(sGetDisposition.equalsIgnoreCase("Multiple"))
                	{
                		sDisposition="Multiple";
                	}
                            oGenericUtils.CompareTwoValues("Disposition Summary data",sGetDisposition, sDisposition);
                            sGetMDPolicy= Serenity.sessionVariableCalled("Medicalpolicy");
                }
                
                //Medical Policy
                String sMedicalPolicy= oGenericUtils.GetElementText("(//p[.='Medical Policy']/..//p)[2]");
                
                oGenericUtils.CompareTwoValues("Medical Policy Summary data",sMedicalPolicy, sGetMDPolicy);
               //Topic
                
                boolean sResult=oGenericUtils.isElementExist("//*[.='Topic']/..//button[contains(text(),'More')]", 5);
                if(sResult==true){
                                oGenericUtils.clickOnElement("//*[.='Topic']/..//button[contains(text(),'More')]");                                                                                           
                }
                String sTopic= oGenericUtils.GetElementText("(//p[.='Topic']/..//p)[2]");
                String sGetTopic=Serenity.sessionVariableCalled("sTopic");
                //oGenericUtils.CompareTwoValues("Topic Summary data",sTopic, sGetTopic);
                    
		}catch(Exception e){
		                GenericUtils.Verify("Object not found , Failed due to :="+e.getMessage(),"FAILED");
		}
		
		
		
		}
//=============================================RetrieveRuleHeadearSavingsinDPWB==============================================>
                public void RetrieveRuleHeadearSavingsinDPWB(String sDisposition){
                    int sRuleinBaseline=0;
                    boolean bstatus=false;
                    try{
                        //click Down Arrow
                        List<WebElement> sList=getDriver().findElements(By.xpath("//button[@id='expandCollapseBtn']"));
                        
                        if(sList.size()>0){
                                for(int i=0;i<=sList.size();i++)
                                {
                                	
                                	String sGetMidRule=ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[1]"));
                                	String sGetStatus=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[2]")),"Status").trim();
                                	
	                                sList.get(i).click();                                                                                             
	                                Thread.sleep(5000);
	                                bstatus= oGenericUtils.isElementExist("//*[.='Rule Description']/..//div",50);
	                                Assert.assertTrue("Taking more time to open RuleData section,after clicking on the Rule dropdown icon,Rule ==>"+sGetMidRule, bstatus);
	                                //==================================================================>
	                                
	                                if(sGetStatus.equalsIgnoreCase("Opportunity")){
	                                                sRuleinBaseline=0;
	                                }
	                                else if(sGetStatus.equalsIgnoreCase("Production"))
	                                {
	                                                sRuleinBaseline=-1;
	                                }
	                                else
	                                {
	                                				sRuleinBaseline=-0;
	                                }
	                                String sGetEdits=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[3]")),"Edits").trim();
	                                String sGetRawSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[4]")),"Raw Savings").trim();
	                                String sGetAggSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[5]")),"Agg Savings").trim();
	                               // String sGetConSavings=StringUtils.substringBefore(ReturnValue(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[6]")),"Con Savings").trim();
	                                //==================================================================>
	                                                //Validate UI data with MongoDB data
	                                Serenity.setSessionVariable("Rule").to(sGetMidRule);
	                                Serenity.setSessionVariable("Opportunity").to(sRuleinBaseline);
	                                MongoDBUtils.Savings_summary_for_DPWB_based_on_insurance(sDisposition, "",sGetMidRule,sRuleinBaseline);
	                                //Verifying UI Data with MongoDB
	                                oGenericUtils.CompareTwoValues("Edits Under Rule Headear section",sGetEdits, ProjectVariables.Edits.get(0));
	                                oGenericUtils.CompareTwoValues("Raw Savings Rule Headear section",sGetRawSavings, ProjectVariables.RawSavings.get(0));
	                                oGenericUtils.CompareTwoValues("Agg Savings Rule Headear section",sGetAggSavings, ProjectVariables.AggSavings.get(0));
	                                //oGenericUtils.CompareTwoValues("Con Savings Rule Headear section",sGetConSavings, ProjectVariables.ConSavings.get(0));
	                                break;
                                }
                                        
                                        
                        }else{
                                        GenericUtils.Verify("Records not found:="+sList.size(),"FAILED");
                        }
				        }catch(Exception e){
				                        GenericUtils.Verify("Object not found , Failed due to :="+e.getMessage(),"FAILED");
				        }
                                
                }
//===========================================RetrieveRuleDatainDPWB=============================================================>
                public void RetrieveRuleDatainDPWB(String sDisposition){
                    int sRuleinBaseline=0;
                    String sGetRuleDesc=null;
                    //try{
                    
                        boolean sResult=oGenericUtils.isElementExist("//*[.='Rule Description']/..//button[contains(text(),'More')]", 10);
                        if(sResult==true)
                        {
                            oGenericUtils.clickOnElement("//*[.='Rule Description']/..//button[contains(text(),'More')]");
                                        
                        }
                        sGetRuleDesc= StringUtils.substringBefore(oGenericUtils.GetElementText("//*[contains(text(),'Rule Description')]/..//div"),"Less");
                        String sSubRuleNotes=oGenericUtils.GetElementText("//*[contains(text(),'Sub Rule Notes')]/..//div");
                        String sCoreEnhanced=oGenericUtils.GetElementText("//*[contains(text(),'Primary Reference Source')]/..//span");
                        String[] sCoreVal = sCoreEnhanced.split("Primary Reference Source:");
                        String sCoreRefrence=oGenericUtils.GetElementText("//*[contains(text(),'Primary Reference Source')]/..//div");
                        if(!is_WebElement_Displayed("//*[contains(text(),'Reference Detail')]/..//div"))
                        {
                        	scrollingToGivenElement(getDriver(), "//*[contains(text(),'Reference Detail')]/..//div");
                        }
                        String sRefrenceDetail=oGenericUtils.GetElementText("//*[contains(text(),'Reference Detail')]/..//div");
                        //String sMidRuleClaimType=oGenericUtils.GetElementText("//*[.='Mid Rule Claim Type(s): ']/..//p");
                        //Compare DB Output
                        String sGetMidRule=oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[1]");
                        String sGetStatus=StringUtils.substringBefore(oGenericUtils.GetElementText("(//div[@class='header-savings']//span)[2]"),"Status");
                        if(sGetStatus.trim().equalsIgnoreCase("Opportunity")){
                                        sRuleinBaseline=0;
                        }else{
                                        sRuleinBaseline=-1;
                        }
                        
                        MongoDBUtils.RuleDatainDPWBWorkbench(sDisposition, sGetMidRule, sRuleinBaseline);
                        //Verifying UI Data with MongoDB
                        oGenericUtils.CompareTwoValues("Rule Description Under Rule Data section",sGetRuleDesc.trim(), ProjectVariables.DB_RuleDesc.trim());
                        oGenericUtils.CompareTwoValues("Sub Rule Notes Under Rule Data section",sSubRuleNotes.trim().replaceAll(" ", ""), ProjectVariables.DB_Subrulenotes.trim().replaceAll(" ", ""));
                        //check with chaitanya
                        oGenericUtils.CompareTwoValues("Core Enhanced Desc Under Rule Data section",sCoreVal[1].trim(), ProjectVariables.DB_CoreenhancedDesc.trim());
                        oGenericUtils.CompareTwoValues("Primary Refrence Source Under Rule Data section",sCoreRefrence.trim(), ProjectVariables.DB_PrimaryRefsource.trim());
                        oGenericUtils.CompareTwoValues("Rule Description Under Rule Data section",sRefrenceDetail.trim(), ProjectVariables.DB_refdetails.trim());
                        
                                    
                        // }catch(Exception e){
//                                    GenericUtils.Verify("Object not found , Failed due to :="+e.getMessage(),"FAILED");
//                    }
                }
//=============================================RetrievePayerGridData=====================================================================>
                public void RetrievePayerGridData(String ssDisposition){
	                try{
	                	
	                	scrollingToGivenElement(getDriver(), "//tr[@class='k-grouping-row ng-star-inserted']");
	                	
                        //Retrieve total rows
                        List<WebElement> sList=getDriver().findElements(By.xpath("//tr[contains(@class,'ng-star-inserted')]"));
                        for(int i=1;i<=sList.size();i++)
                        {
                            //Retrieve Column values
                            String sAll=oGenericUtils.GetElementText("(//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]//div");
                            String sPiriorDisposition=oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[2]");
                            String sCurrentDisposition=oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[3]");
                            String sClientDescision=oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[4]");
                            String sEdits=ReturnValue(oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[5]"));
                            String sRawSavings=ReturnValue(oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[6]"));
                            String sAggSavings=ReturnValue(oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[7]"));
                           // String sConSavings=ReturnValue(oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[8]"));
                           // String sUnconfirmed=oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[9]");
                            //String sFlags=oGenericUtils.GetElementText("((//tr[contains(@class,'ng-star-inserted')])["+(i+1)+"]/td)[10]");
                            
                            //mongo Method to retrieve the payer-insurance grid data
                            
                            if(i==1)
                            {
                            	System.out.println("payershort ==>"+sAll);
                            	Serenity.setSessionVariable("sPayershort").to(sAll);
                            	MongoDBUtils.Savings_summary_for_DPWB_based_on_insurance(ssDisposition, "",Serenity.sessionVariableCalled("Rule"),Integer.valueOf(Serenity.sessionVariableCalled("Opportunity").toString()));	
                            }
                            else
                            {
                            	System.out.println("Insurance ==>"+sAll);
                            	MongoDBUtils.Savings_summary_for_DPWB_based_on_insurance(ssDisposition, sAll,Serenity.sessionVariableCalled("Rule"),Integer.valueOf(Serenity.sessionVariableCalled("Opportunity").toString()));
                            }
                            
                            if(sPiriorDisposition.equalsIgnoreCase("-"))
                            {
                            	sPiriorDisposition="No Disposition";
                            }
                            
                            if(sCurrentDisposition.equalsIgnoreCase("-"))
                            {
                            	sCurrentDisposition="No Disposition";
                            }
                            if(sClientDescision.equalsIgnoreCase("-"))
                            {
                            	sClientDescision="";
                            }
                            
                            
                            //Validating the Payer_Insurance Grid data with mongo DB
                            oGenericUtils.CompareTwoValues("PiriorDisposition of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sPiriorDisposition, ProjectVariables.DB_Priordisposition);
                            oGenericUtils.CompareTwoValues("CurrentDisposition of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sCurrentDisposition, ProjectVariables.Disposition);
                            oGenericUtils.CompareTwoValues("latestClientDescision of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sClientDescision, ProjectVariables.DB_CDMDecision);
                            
                            
                            oGenericUtils.CompareTwoValues("Edits of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sEdits, ProjectVariables.Edits.get(0));
                            oGenericUtils.CompareTwoValues("Raw Savings of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sRawSavings, ProjectVariables.RawSavings.get(0));
                            oGenericUtils.CompareTwoValues("Agg Savings of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sAggSavings, ProjectVariables.AggSavings.get(0));
                            //oGenericUtils.CompareTwoValues("Con Savings of Payer_Insurance grid of '"+sAll+"',for the dpkey ==>"+Serenity.sessionVariableCalled("dpkey"),sConSavings, ProjectVariables.ConSavings.get(0));
            
                            break;
	                     }
	                                
	                }catch(Exception e)
	                {
                                                GenericUtils.Verify("Object not found , Failed due to :="+e.getMessage(),"FAILED");
                                }
                }
                
                
              
}

