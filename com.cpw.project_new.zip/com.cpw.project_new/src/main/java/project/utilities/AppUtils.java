package project.utilities;

import java.util.List;

import org.openqa.selenium.WebElement;
import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;

public class AppUtils extends SeleniumUtils {
	
	
	public String LoadingIcon ="//p[contains(text(),'Presentation Loading') or contains(text(),'Please wait. Content loading') or contains(text(),'Loading')]";
	
	//Loading POPUP

		public void WaitUntilPageLoad() throws InterruptedException{
			
			int iTimer=0;
			boolean blnResult=false;
			do{
				//List<WebElement> sList=getDriver().findElements(By.xpath("//div[@class='mx-page navlayout-topbar navlayout-topbar page-dashboard page-dashboard-actions']"));
				List<WebElement> sList=getDriver().findElements(By.xpath("//p[contains(text(),'Loading')]"));
				//System.out.println("Loop 1:=="+sList.size());
				if(sList.size()>0){				
					//======================================================================================================>
						do{
							//List<WebElement> sList=getDriver().findElements(By.xpath("//div[@class='mx-page navlayout-topbar navlayout-topbar page-dashboard page-dashboard-actions']"));
							List<WebElement> sList1=getDriver().findElements(By.xpath("//p[contains(text(),'Loading')]"));
							//System.out.println("Loop 2:=="+sList1.size());
							if(sList1.size()>0){								
								System.out.println("POPUP closed");
								blnResult=true;
							}
							
							iTimer=iTimer+1;
						}while((iTimer!=50) && (blnResult!=true));
					//======================================================================================================>
				}
				
				iTimer=iTimer+1;
			}while((iTimer!=10) && (blnResult!=true));
			
			
		}
		
		

		public boolean DynamicWaitfortheLoadingIconWithCount(int count) {
			boolean bstatus=false;
			int j = 1;
			System.out.println("Loading is in progress");
			
			do {
				
				defaultWait(ProjectVariables.TImeout_2_Seconds);
				j = j + 1;
				
				if (j == count) {
					break;
				}
				
				bstatus=is_WebElement_Visible(LoadingIcon);
				
			} while (bstatus);
			
			
			

			return bstatus;
			
		}
		
}
