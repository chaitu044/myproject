package project.utilities;

public class OracleDBQueries {
	
	public static String DistinctPPS = "SELECT PL.CLIENT_KEY\r\n" +
			", PS.PAYER_KEY\r\n" +
			", PL.PAYER_SHORT\r\n" +
			", PS.POLICY_SET_KEY\r\n" +
			", PS.INSURANCE_KEY\r\n" +
			", PS.CLAIM_TYPE\r\n" +
			", PSC.POLICY_SET_CONFIG_KEY\r\n" +
			", PSC.PROD_NOT_TEST_10\r\n" +
			"FROM MICRO_ETL_APP.POLICY_SETS PS\r\n" +
			", MICRO_ETL_APP.POLICY_SET_CONFIG PSC\r\n" +
			", MICRO_ETL_APP.PAYER_LKP PL\r\n" +
			"WHERE PS.PAYER_KEY = PL.PAYER_KEY\r\n" +
			"AND PL.PAYER_STATUS_KEY IN (3,5)\r\n" +
			"AND PS.POLICY_SET_KEY = PSC.POLICY_SET_KEY (+)\r\n" +
			"AND PL.CLIENT_KEY = clientkey\r\n";


}
