package project.utilities;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;



import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class ExcelUtils {

	public static int GetSheetCount(String sTestDataFilePath) throws Exception {
		int sheetcount;
		try {
			File src = new File(sTestDataFilePath);
			FileInputStream finput = new FileInputStream(src);
			XSSFWorkbook workbook = new XSSFWorkbook(finput);
			sheetcount = workbook.getNumberOfSheets();
		} catch (Exception e) {
			throw (e);
		}

		System.out.println("sheet Count:=" + sheetcount);
		return sheetcount;

	}



	//###############################################################################################################

	public static int GetRowCount(String sTestDataFilePath,int sheet_No) throws Exception {

		int rowcount;
		try {

			// Open the Excel file
			File src = new File(sTestDataFilePath);
			FileInputStream finput = new FileInputStream(src);
			HSSFWorkbook workbook = new HSSFWorkbook(finput);

			HSSFSheet ExcelWSheet = workbook.getSheetAt(sheet_No);

			rowcount = ExcelWSheet.getLastRowNum();

		} catch (Exception e) {

			throw (e);

		}

		System.out.println("Row Count:=" + rowcount);
		return rowcount;
	}

	//###############################################################################################################

	public static int GetColumnCount(String sTestDataFilePath,int sheet_No) throws Exception {

		int columncount;
		try {

			// Open the Excel file

			File src = new File(sTestDataFilePath);
			FileInputStream finput = new FileInputStream(src);
			XSSFWorkbook workbook = new XSSFWorkbook(finput);

			XSSFSheet ExcelWSheet = workbook.getSheetAt(sheet_No);
			XSSFRow row = ExcelWSheet.getRow(0);
			columncount = row.getLastCellNum();

		} catch (Exception e) {

			throw (e);

		}

		System.out.println("Column Count:=" + columncount);
		return columncount;
	}

	//###############################################################################################################

	public static String getCellData(String FilePath,String FileName, int sheet_No,int RowNum, int ColNum) throws Exception {
		String cellText = null;

		try {
			//Creating object for File class 
			File ofile=new File(FilePath+"\\"+FileName);
			//Creating object for Fileinputstream to read excel data
			//System.out.println(ofile.getName());
			FileInputStream inputstream=new FileInputStream(ofile);

			//Find the File Extension type
			String GetFileExtension = FileName.substring(FileName.indexOf("."));
			Workbook oWorkbook=null;
			//If File Type is Xls
			if(GetFileExtension.equalsIgnoreCase(".xls")){
				oWorkbook=new HSSFWorkbook(inputstream);
			}else{
				oWorkbook=new XSSFWorkbook(inputstream);
			}

			//Creating object for Worksheet
			Sheet sheet=oWorkbook.getSheetAt(sheet_No);

			Cell cell = sheet.getRow(RowNum).getCell(ColNum);
			cellText = cell.getStringCellValue();
			//System.out.println(cellText);
			if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
				cellText = cell.getStringCellValue();
			} else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC || cell.getCellType() == Cell.CELL_TYPE_FORMULA) {
				cellText = String.valueOf(cell.getDateCellValue());
			} else if (cell.getCellType() == Cell.CELL_TYPE_BLANK)
				cellText = null;
			else
				cellText = null;
		}

		catch (Exception e) {
			// e.printStackTrace();
			System.out.println("row " + RowNum + " or column " + ColNum + " does not exist  in xlsx");
			cellText = null;
		}

		return cellText;
	}

	//###############################################################################################################
	// This method is to write in the Excel cell, Row num and Col num are the
	// parameters

	/*     public static boolean SetCellData(int rowNum, int colName, String data, int sheet_No) {

                                try {

                                                String path = WITLocalVariables.sTestDataFilePath;
                                                FileInputStream fis = new FileInputStream(path);
                                                XSSFWorkbook workbook = new XSSFWorkbook(fis);
                                                if (rowNum <= 0)
                                                                return false;
                                                XSSFSheet sheet = workbook.getSheetAt(sheet_No);
                                                XSSFRow row = sheet.getRow(0);
                                                int colNum = colName;
                                                sheet.autoSizeColumn(colNum);
                                                row = sheet.getRow(rowNum - 1);
                                                if (row == null)
                                                                row = sheet.createRow(rowNum - 1);
                                                XSSFCell cell = row.getCell(colNum);
                                                if (cell == null)
                                                                cell = row.createCell(colNum);
                                                cell.setCellValue(data);
                                                FileOutputStream fileOut = new FileOutputStream(path);
                                                workbook.write(fileOut);
                                                fileOut.close();

                                } catch (Exception e) {
                                                e.printStackTrace();
                                                return false;
                                }
                                return true;
                }*/

	//###############################################################################################################

	public static int SetCellDataXlsm(String sFeaturename , String sTcName, String sTcStatus, String sPath) throws Exception {

		int rowcount;
		int rowNum = 0;
		try {

			int iTcNum = 0;
			int iFeatureName = 1;
			int iTcName = 2;
			int iTcStatus = 3;
			int iTcTime = 4;                                                                                                                                  
			String path = sPath;

			DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
			Date date = new Date();
			String sDate = dateFormat.format(date).toString();

			File src = new File(path);
			FileInputStream finput = new FileInputStream(src);
			XSSFWorkbook workbook = new XSSFWorkbook(finput);
			XSSFSheet sheet = workbook.getSheetAt(0);                                       
			rowcount = sheet.getPhysicalNumberOfRows();

			int iRowCount = rowcount;
			rowNum = iRowCount+1;
			String sTcNo = "TC_"+(iRowCount-9);

			XSSFRow row = sheet.getRow(0);                             
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);

			sheet.autoSizeColumn(iTcNum);
			XSSFCell sTcNumCell = row.getCell(iTcNum);
			if (sTcNumCell == null)
				sTcNumCell = row.createCell(iTcNum);
			sTcNumCell.setCellValue(sTcNo);

			sheet.autoSizeColumn(iFeatureName);
			XSSFCell sFeatureCell = row.getCell(iFeatureName);
			if (sFeatureCell == null)
				sFeatureCell = row.createCell(iFeatureName);
			sFeatureCell.setCellValue(sFeaturename);

			sheet.autoSizeColumn(iTcName);
			XSSFCell sTsNamecell = row.getCell(iTcName);
			if (sTsNamecell == null)
				sTsNamecell = row.createCell(iTcName);
			sTsNamecell.setCellValue(sTcName);

			sheet.autoSizeColumn(iTcStatus);
			XSSFCell sTcStatusCell = row.getCell(iTcStatus);
			if (sTcStatusCell == null)
				sTcStatusCell = row.createCell(iTcStatus);
			sTcStatusCell.setCellValue(sTcStatus);

			sheet.autoSizeColumn(iTcTime);
			XSSFCell sTcDateCell = row.getCell(iTcTime);
			if (sTcDateCell == null)
				sTcDateCell = row.createCell(iTcTime);
			sTcDateCell.setCellValue(sDate);

			FileOutputStream fileOut = new FileOutputStream(path);
			workbook.write(fileOut);

			fileOut.close();

		} catch (Exception e) {
			e.getMessage();
		}

		return rowNum;

	}

	//###############################################################################################################

	public static boolean SetPath(int rowNum, int colName, String data, String sPath) {

		try {

			String path = sPath;
			FileInputStream fis = new FileInputStream(path);
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			if (rowNum <= 0)
				return false;
			XSSFSheet sheet = workbook.getSheetAt(0);
			XSSFRow row = sheet.getRow(0);
			int colNum = colName;
			sheet.autoSizeColumn(colNum);
			row = sheet.getRow(rowNum - 1);
			if (row == null)
				row = sheet.createRow(rowNum - 1);
			XSSFCell cell = row.getCell(colNum);
			if (cell == null)
				cell = row.createCell(colNum);
			cell.setCellValue(data);
			FileOutputStream fileOut = new FileOutputStream(path);
			workbook.write(fileOut);
			fileOut.close();

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}

	//###############################################################################################################
	//###############################################################################################################

	public static String get_MailPath(){

		String sDirectory = System.getProperty("user.dir");
		String sDriverPath = sDirectory+"\\src\\test\\resources\\Data";
		String sExcelPath = sDirectory+"\\src\\test\\resources\\Data\\Mail.xlsm";

		return sExcelPath;

	}

	//=============================================================================================================>

	public static boolean GetExcelData(String FilePath,String FileName,String SheetName,int RowNo,int ColNo,String sExpData){
		boolean blnResult=false;

		try{

			//Creating object for File class 
			File ofile=new File(FilePath+"\\"+FileName);
			//Creating object for Fileinputstream to read excel data
			FileInputStream inputstream=new FileInputStream(ofile);

			//Find the File Extension type
			String GetFileExtension = FileName.substring(FileName.indexOf("."));
			Workbook oWorkbook=null;
			//If File Type is Xls
			if(GetFileExtension.equalsIgnoreCase(".xls")){
				oWorkbook=new HSSFWorkbook(inputstream);
			}else{
				oWorkbook=new XSSFWorkbook(inputstream);
			}

			//Creating object for Worksheet
			Sheet oWsheet=oWorkbook.getSheet(SheetName);
			int rowCount = oWsheet.getLastRowNum()-oWsheet.getFirstRowNum();
			for (int i=1;i<RowNo+1;i++){

				System.out.println("Get Data:="+oWsheet.getRow(i).getCell(3).getStringCellValue());
			}
			// return oWsheet;

		}catch(Exception e){

		}
		return blnResult;


	}

	public static String getSheetName(String FilePath,String FileName) throws IOException{
		String SheetName=null;
		File ofile=new File(FilePath+"\\"+FileName);
		//String FileName="AutoTestInstance470_AmeriHealth Mercy.xls";
		//Creating object for File inputstream to read excel data
		FileInputStream inputstream=new FileInputStream(ofile);

		//Find the File Extension type
		String GetFileExtension = FileName.substring(FileName.indexOf("."));
		Workbook oWorkbook=null;
		//If File Type is Xls
		if(GetFileExtension.equalsIgnoreCase(".xls")){
			oWorkbook=new HSSFWorkbook(inputstream);
		}else{
			oWorkbook=new XSSFWorkbook(inputstream);
		}            
		// for each sheet in the workbook
		for (int i = 0; i < oWorkbook.getNumberOfSheets(); i++) {
			SheetName=oWorkbook.getSheetName(i);
			System.out.println("Sheet name: " + oWorkbook.getSheetName(i));
		}
		return SheetName;
	}
	
	// ###############################################################################################################

		public static int SetCellDataXlsm(String sFeaturename, String sTcName, String sTcStatus, String sReasonCode,
				String sReason, String sPath) throws Exception {

			int rowcount;
			int rowNum = 0;
			try {

				int iTcNum = 0;
				int iFeatureName = 1;
				int iTcName = 2;
				int iTcStatus = 3;
				int iTcTime = 4;
				int iTcReasonCode = 5;
				int iTcReason = 6;
				String path = sPath;

				DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
				Date date = new Date();
				String sDate = dateFormat.format(date).toString();

				File src = new File(path);
				FileInputStream finput = new FileInputStream(src);
				XSSFWorkbook workbook = new XSSFWorkbook(finput);
				XSSFSheet sheet = workbook.getSheetAt(0);
				rowcount = sheet.getPhysicalNumberOfRows();

				int iRowCount = rowcount;
				rowNum = iRowCount + 1;
				String sTcNo = "TC_" + (iRowCount - 9);

				XSSFRow row = sheet.getRow(0);
				row = sheet.getRow(rowNum - 1);
				if (row == null)
					row = sheet.createRow(rowNum - 1);

				sheet.autoSizeColumn(iTcNum);
				XSSFCell sTcNumCell = row.getCell(iTcNum);
				if (sTcNumCell == null)
					sTcNumCell = row.createCell(iTcNum);
				sTcNumCell.setCellValue(sTcNo);

				sheet.autoSizeColumn(iFeatureName);
				XSSFCell sFeatureCell = row.getCell(iFeatureName);
				if (sFeatureCell == null)
					sFeatureCell = row.createCell(iFeatureName);
				sFeatureCell.setCellValue(sFeaturename);

				sheet.autoSizeColumn(iTcName);
				XSSFCell sTsNamecell = row.getCell(iTcName);
				if (sTsNamecell == null)
					sTsNamecell = row.createCell(iTcName);
				sTsNamecell.setCellValue(sTcName);

				sheet.autoSizeColumn(iTcStatus);
				XSSFCell sTcStatusCell = row.getCell(iTcStatus);
				if (sTcStatusCell == null)
					sTcStatusCell = row.createCell(iTcStatus);
				sTcStatusCell.setCellValue(sTcStatus);

				sheet.autoSizeColumn(iTcTime);
				XSSFCell sTcDateCell = row.getCell(iTcTime);
				if (sTcDateCell == null)
					sTcDateCell = row.createCell(iTcTime);
				sTcDateCell.setCellValue(sDate);

				sheet.autoSizeColumn(iTcReasonCode);
				XSSFCell sTcReasonCodeCell = row.getCell(iTcReasonCode);
				if (sTcReasonCodeCell == null)
					sTcReasonCodeCell = row.createCell(iTcReasonCode);
				sTcReasonCodeCell.setCellValue(sReasonCode);

				sheet.autoSizeColumn(iTcReason);
				XSSFCell sTcReasonCell = row.getCell(iTcReason);
				if (sTcReasonCell == null)
					sTcReasonCell = row.createCell(iTcReason);
				sTcReasonCell.setCellValue(sReason);

				FileOutputStream fileOut = new FileOutputStream(path);
				workbook.write(fileOut);

				fileOut.close();

			} catch (Exception e) {
				e.getMessage();
				if (e.toString().contains("The //System cannot find the file specified")) {
					GenericUtils.logMessage("Error Message ===>" + e);
					Assert.assertTrue("The specified file was not found in the given path ===>" + sPath, false);
				}

			}

			return rowNum;

		}
		
		public static void loadServices() throws IOException{

			File src = new File("src//test//resources//RestServices.xlsx");
			FileInputStream finput = new FileInputStream(src);
			XSSFWorkbook workbook = new XSSFWorkbook(finput);

			XSSFSheet ExcelWSheet = workbook.getSheetAt(0);

			int rowcount = ExcelWSheet.getLastRowNum();

			for (int i = 1 ;i<=rowcount;i++){
				XSSFRow iRow = ExcelWSheet.getRow(i);

				String sEndPointName = iRow.getCell(0).getStringCellValue();
				String sEndPointURI = iRow.getCell(1).getStringCellValue();
				String sEndPointBody = iRow.getCell(2).getStringCellValue();
				HashMap<String,String> sURI = new HashMap<String,String>();

				sURI.put("EndpointURL", sEndPointURI);
				sURI.put("RequestBody", sEndPointBody);
				ProjectVariables.sServices.put(sEndPointName, sURI);

			}

		}
}