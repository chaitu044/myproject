
package project.utilities;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.HashSet;

import junit.framework.Assert;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;



public  class DBUtils {	

	
	public static String executeSQLQuery(String sqlQuery)
	{
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String DBConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("ORACLE_DB_CONNECTION_URL");
		
		String queryResultValue= "";
		Connection con=null;

		try {

			Class.forName(ProjectVariables.DB_DRIVER_NAME);
			con = DriverManager.getConnection(DBConURL,ProjectVariables.DB_USERNAME,ProjectVariables.DB_PASSWORD);

			if(con!=null) {
				System.out.println("Connected to the Database...");
			}else {
				System.out.println("Database connection failed ");
			}

			Statement st = con.createStatement();
			st.setQueryTimeout(30);
			ResultSet rs =st.executeQuery(sqlQuery);        	

			while(rs.next())
			{
				queryResultValue = rs.getString(1).toString();               	break;
			} 

			System.out.println("DB Result: "+queryResultValue);

			con.close();

		}catch (SQLException e) {
			e.printStackTrace();}

		catch (NullPointerException err) {
			System.out.println("No Records obtained for this specific query");
			err.getMessage();              }        

		catch (ClassNotFoundException e1) {     		  		
			e1.getMessage();	}

		finally{
			try {
				if(con != null)
					con.close();

			}catch(SQLException e)  {           
				e.getMessage();         
			} 
		}

		return queryResultValue;

	}   

	// ####################################################################################################

	public static ArrayList<String> db_GetAllFirstColumnValues(String sqlQuery){
		
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String DBConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("ORACLE_DB_CONNECTION_URL");
		
		Connection con=null;
		String result;
		ArrayList<String> resultList = new ArrayList<String>();

		try {

			Class.forName(ProjectVariables.DB_DRIVER_NAME);
			con = DriverManager.getConnection(DBConURL,ProjectVariables.DB_USERNAME,ProjectVariables.DB_PASSWORD);

			if(con!=null) {
				System.out.println("Connected to the Database...");
			}else {
				System.out.println("Database connection failed ");
			}  

			Statement st = con.createStatement();	        		
			ResultSet rs =st.executeQuery(sqlQuery);  

			while (rs.next()) {
				result = rs.getString(1).toString();
				resultList.add(result);

			}

			con.close();

		}catch (SQLException e) {
			e.printStackTrace();}

		catch (NullPointerException err) {
			System.out.println("No Records obtained for this specific query");
			err.getMessage();              }        

		catch (ClassNotFoundException e1) {     		  		
			e1.getMessage();	}

		finally{
			try {
				if(con != null)
					con.close();

			}catch(SQLException e)  {           
				e.getMessage();         
			} 
		}

		return resultList;

	}   

	//####################################################################################################

	public static ArrayList<String> db_GetAllColumnValues(String sqlQuery, String sColumn) {

		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String DBConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("ORACLE_DB_CONNECTION_URL");
		
		
		Connection con=null;
		ArrayList<String> resultList = new ArrayList<String>();
		String result;

		try {

			Class.forName(ProjectVariables.DB_DRIVER_NAME);
			con = DriverManager.getConnection(DBConURL,
					ProjectVariables.DB_USERNAME, ProjectVariables.DB_PASSWORD);

			if (con != null) {
				System.out.println("Connected to the Database...");
			} else {
				System.out.println("Database connection failed ");
			}

			Statement st = con.createStatement();
			st.setQueryTimeout(10);
			ResultSet rs = st.executeQuery(sqlQuery);
			ResultSetMetaData rsmd = rs.getMetaData();

			int iColCount = rsmd.getColumnCount();
			System.out.println("Column"+iColCount);

			while (rs.next()) {
				try{
					result = rs.getString(sColumn).toString();
					System.out.println("Column data "+result);
					resultList.add(result);		
				}catch(NullPointerException err){
					resultList.add("");
				}
			}

			con.close();

		} catch (SQLException e) {
			e.getMessage();
			System.out.println(e.getMessage());
		}

		catch (NullPointerException err) {
			System.out.println("No Records obtained for this specific query");
			err.getMessage();
		}

		catch (ClassNotFoundException e1) {
			e1.getMessage();
		}

		finally{
			try {
				if(con != null)
					con.close();

			}catch(SQLException e)  {           
				e.getMessage();         
			} 
		}

		return resultList;

	}

	//####################################################################################################

	public static String db_GetFirstValueforColumn(String sQuery,String dbColumn) throws Exception{

		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String DBConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("ORACLE_DB_CONNECTION_URL");
		
		Connection conn=null;      
		String sVal="";

		try {    	   

			Class.forName("oracle.jdbc.OracleDriver");

			conn = DriverManager.getConnection(DBConURL,
					ProjectVariables.DB_USERNAME, ProjectVariables.DB_PASSWORD);

			Statement stmt=conn.createStatement();     
			stmt.setQueryTimeout(10);
			ResultSet rs=stmt.executeQuery(sQuery);

			while (rs.next()) {
				sVal=rs.getString(dbColumn);

			}

			System.out.println("Stored Data in DB:" +" " +sVal);

			if (conn != null) {
				conn.close();}

		}catch(Exception e) {       
			System.out.println("Exception "+e.getMessage());
		}

		finally{
			try {
				if(conn != null)
					conn.close();

			}catch(SQLException e)  {           
				e.printStackTrace();         
			} 
		}

		return sVal;

	}

	//####################################################################################################
	public static String executeSQLQuery(String sqlQuery,String UserName,String Password,String Commit)
	{
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String DBConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("ORACLE_DB_CONNECTION_URL");
		
		String queryResultValue= "";
		Connection con=null;

		try {

			Class.forName(ProjectVariables.DB_DRIVER_NAME);
			con = DriverManager.getConnection(DBConURL,UserName,Password);

			if(con!=null) {
				System.out.println("Connected to the Database...");
			}else {
				System.out.println("Database connection failed ");
			}

			Statement st = con.createStatement();
			st.setQueryTimeout(30);
			ResultSet rs =st.executeQuery(sqlQuery); 
			if(Commit.equalsIgnoreCase("Yes")){
				st.executeUpdate(sqlQuery);
			}   	  
			while(rs.next())
			{
				queryResultValue = rs.getString(1).toString();   
				break;
			} 

			System.out.println("DB Result: "+queryResultValue);

			con.close();

		}catch (SQLException e) {
			e.printStackTrace();}

		catch (NullPointerException err) {
			System.out.println("No Records obtained for this specific query");
			err.getMessage();              }        

		catch (ClassNotFoundException e1) {     		  		
			e1.getMessage();	}

		finally{
			try {
				if(con != null)
					con.close();

			}catch(SQLException e)  {           
				e.getMessage();         
			} 
		}

		return queryResultValue;

	}  

	@SuppressWarnings("deprecation")
	public static  ArrayList<String> executeSQLQuery_for_the_given_DBname(String sqlQuery,String dbname)
	{
		ProjectVariables.Oracel_results_list.clear();
		Connection con = null;
		ArrayList<String> resultList = new ArrayList<String>();
	
	try {
        		
        	Class.forName(ProjectVariables.DB_DRIVER_NAME);
        	con = connectToDB(dbname);

        	  if(con!=null) {
                  System.out.println("Connected to the Database...");
              }else {
                  Assert.assertTrue("Failed to connect to oracel database ===>"+dbname, false);
              }
        	
        	  
        	 String result;
        	  
        	  Statement st = con.createStatement();	        		
        	  ResultSet rs =st.executeQuery(sqlQuery);  
        	  
        	  ResultSetMetaData rsmd = rs.getMetaData();
				int columnsNumber = rsmd.getColumnCount();

        	
        	  while (rs.next()) {
					List<String> row = new ArrayList<>(columnsNumber);
					for (int i = 1; i <= columnsNumber; i++) {
						String columnValue = rs.getString(i);
						if (columnValue == null) {
							columnValue = "0";
							
							
							row.add(columnValue);
						} else {
							
							
							
							row.add(GenericUtils.Check_the_savings_with_decimal_value_or_not(columnValue));
							
							
							
						}						
					}
					if (row.size() == columnsNumber) {
						//GenericUtils.logMessage("Row retrieved from sql query is: " + row);
						/*
							if(row.contains("48")&&row.contains("1171")&&row.contains("P")&&row.contains("2")&&row.contains("8079")&&row.contains("Medicaid"))
							{
								System.out.println(row);
								//ProjectVariables.Oracel_results_list.add(row);
								//break;
							}*/
							
							ProjectVariables.Oracel_results_list.add(row);
						//ProjectVariables.Oracel_results_list.add(row);
						/*if (queryResultInList.size() == 20) {
							break;
						}*/
						//break;
						
					}				
				}
        	           
            //System.out.println("DB Result: "+queryResultValue);
            
            con.close();
            
        }catch (SQLException e) {
            e.printStackTrace();}
        
        catch (NullPointerException err) {
            System.out.println("No Records obtained for this specific query");
            err.printStackTrace();              }        
		
	     catch (ClassNotFoundException e1) {     		  		
				e1.printStackTrace();	}
       
	 
	  return resultList;
          
	}

	public static Connection connectToDB(String dbName) {
		Connection con = null;

		try {
			Class.forName(ProjectVariables.DB_DRIVER_NAME);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {

			switch (dbName) {
			case "RLSMSG01":
				con = DriverManager.getConnection(ProjectVariables.DB_CONNECTION_URL_RLSMSG,
						ProjectVariables.ORACLE_DB_PROD_USERNAME, ProjectVariables.ORACLE_DB_PROD_PASSWORD);
				break;
			case "RVAPRD1":
				con = DriverManager.getConnection(ProjectVariables.DB_CONNECTION_URL_RVAPRD1,
						ProjectVariables.ORACLE_DB_PROD_USERNAME, ProjectVariables.ORACLE_DB_PROD_PASSWORD);
				break;
			case "VPMTST1":
				con = DriverManager.getConnection(ProjectVariables.DB_CONNECTION_URL_VPMTST1,
						ProjectVariables.ORACLE_DB_USER_MASTER_SELECT, ProjectVariables.ORACLE_DB_USER_MASTER_SELECT);
				break;
			case "PMPRD1":
				con = DriverManager.getConnection(ProjectVariables.DB_CONNECTION_URL_PMPRD1,
						ProjectVariables.ORACLE_DB_PROD_USERNAME, ProjectVariables.ORACLE_DB_PROD_PASSWORD);
				break;
			case "MICRO_ETL":
				con = DriverManager.getConnection(ProjectVariables.DB_CONNECTION_URL_VPMTST1,
						ProjectVariables.ORACLE_DB_ETL_USERNAME, ProjectVariables.ORACLE_DB_ETL_PASSWORD);
				break;
			default:
				Assert.assertTrue("Case not found::"+dbName,false);
				break;
			}

			if (con != null) {
				System.out.println("Connected to the Database...");
			} else {
				System.out.println("Database connection failed ");
			}

		} catch (SQLException e) {
			System.out.println("connection failed due to ==>"+e);
		}

		return con;
	}

	@SuppressWarnings({ "deprecation", "null" })
	public static HashSet<String> getDistinctPPSfromDB(String sqlQuery,String dbname)
	{
		int i=0;
		Connection con = null;
		HashSet<String> resultList =new HashSet<>();
		System.out.println(sqlQuery);
	
	try {
        	Class.forName(ProjectVariables.DB_DRIVER_NAME);
        	con = connectToDB(dbname);
        	if(con!=null) {
                  System.out.println("Connected to the Database...");
              }else {
                  Assert.assertTrue("Failed to connect to oracel database ===>"+dbname, false);
              }
        	  Statement st = con.createStatement();	        		
        	  ResultSet rs =st.executeQuery(sqlQuery);  
         	  while (rs.next()) 
        	  {
         		  String sPayershort=rs.getString(3).toString();
         		  String sInsurance=GenericUtils.Retrieve_the_insuranceDesc_from_insuranceKey(rs.getString(5).toString()).trim();;
         		  String sClaimtype=rs.getString(6).toString();
         		  
         		//System.out.println(sPayershort+"::"+sInsurance+"::"+sClaimtype);
         		 if(!sClaimtype.equalsIgnoreCase("D")&&!sClaimtype.equalsIgnoreCase("H"))
     			{
         		resultList.add(sPayershort+":"+sInsurance+":"+sClaimtype);
        		  i=i+1;
     			}
        		  //break;
        	  }
         	  
         	 System.out.println("####################### Oracle PPS ###############################");
         	 for (String pps : resultList) 
         	 {
			System.out.println(pps);	
			}
        	 System.out.println("Rowsize::"+i);
         	 System.out.println("Oracle DistinctPPSsize::"+resultList.size());
            
            
            con.close();
            
        }catch (SQLException e) {
            e.printStackTrace();
            }
        
        catch (NullPointerException err) {
            System.out.println("No Records obtained for this specific query");
            err.printStackTrace();              }        
		
	     catch (ClassNotFoundException e1) {     		  		
				e1.printStackTrace();	}
       
	 
	  return resultList;
          
	}
}
