package project.utilities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import org.bson.Document;
import org.bson.conversions.Bson;

import com.mongodb.BasicDBObject;
import com.mongodb.client.FindIterable;

import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;


public class ProjectVariables {

	
	//####################################### URLS ######################################################################//
	
		public static String CPQ_QA_URL = "http://10.170.32.20:10347/cpqui/#/Login";
		
		//public static String CPQ_QA_URL = "http://10.170.32.20:10040/cpqui/#/Main";
		
		public static String CPQ_DEV_URL = "http://10.170.32.20:10296/cpqui/#/Login";
		
		public static String CPQ_CI_URL ="http://10.170.32.20:10398/cpqui/#/Login";
		
		//http://10.170.32.20:10034/index3.html
		public static String CPW_QA_URL="https://cpw-qa.cotiviti.com/index3.html";
		
		public static String CPD_QA_URL="https://cpd-qa.cotiviti.com/index3.html";
		
		public static String CPW_UAT_URL="http://10.170.32.20:12034/index3.html";
			
		public static String DB_CONNECTION_URL = "jdbc:Oracle:thin:@vpmtst1.ihtech.com:1521/VPMTST1.iht.com";

		public static String PostgresSQLDB_CONNECTION_URL = "jdbc:postgresql://10.170.32.32:7433/Cotiviti_DB";
		
		public static String MONGO_SERVER_URL = "pl-0-us-east-1-6oxiw.mongodb.net";
		
		public static String MONGO_SERVER_UAT_URL = "10.171.0.35";
		
		public static String MONGO_SERVER_PROD_URL = "10.171.0.20";
		
		public static String Zero_Touch_MONGO_SERVER_URL = "10.32.16.168";
		
		public static String MONGO_SERVER_URL_For_Zero_Touch_Automation = "10.170.32.20";

		public static String MONGO_SERVER_CI_URL = "10.170.32.35";
		
		public static String sRunDate="APR 2019";
		
	    public static String sClient="Fidelis Care, Inc.";
	    
	    public static String MongoDB_CONNECTION_URL;
		//####################################### CREDENTIALS #################################################################//
		
		public static String PASSWORD = "SWhlYWx0aDEyMw==";
		
		//public static String PASSWORD = "Moto@123";

		public static String DB_USERNAME = "USER_MASTER_SELECT";

		public static String DB_PASSWORD = "USER_MASTER_SELECT";

		public static String PostgresUsername = "cotiviti";

		public static String PostgresPassword = "temp123$";

		public static String DB_DRIVER_NAME = "oracle.jdbc.OracleDriver";

		public static String PostgreSQLDB_DRIVER_NAME = "org.postgresql.Driver";

		public static String USER_IHT_09 = "iht_ittest09";

		public static String Password_IHT_09 = "Ihealth123";
		
		public static int MONGO_SERVER_OLD_QA_PORT = 10235;
		
		public static int MONGO_SERVER_QA_PORT = 10050;
		
		public static int MONGO_SERVER_UAT_PORT = 27017;
		
		//public static int MONGO_SERVER_DEVPORT = 10070;
		
		public static int MONGO_SERVER_DEVPORT = 15;
		
		public static int Zero_Touch_MONGO_SERVER_PORT = 27017;

		public static String MONGODB_USER = "cotiviti-readonly";

		public static String MONGODB_PWD = "UQgMW8LP";

		public static String MONGODB = "admin";
				
		public static String nkumarPassword = "RG9nMTAwNUA=";
		
		//########################################## BROWSER SYNC TIME VARIABLES ###########################################################################//
		 
		public static final int MAX_TIME_OUT = 20;

		public static final int MID_TIME_OUT = 5;

		public static final int MID_MIN_TIME_OUT = 3;

		public static final int MIN_TIME_OUT = 6;
		
		public static final int MIN_COUNT = 1000;

		public static final int MAX_MAX_TIME_OUT = 10;

		public static final int HIGHLIGHT_COUNT = 8;

		public static final int MIN_THREAD_WAIT = 2000;

		public static final int GRID_WAIT = 4000;

		public static final int LEAST_THREAD_WAIT = 500;

		public static final int MIN_LOOP_COUNT = 3;

		public static final int MAX_PROFILE_WAIT = 3600000;

		public static final int LEAST_CLICK_WAIT = 600;

		public static final long TImeout_1_Seconds = 1;
		
		public static final int TImeout_2_Seconds = 2;

		public static final int TImeout_5_Seconds = 5;

		public static final String sPPSColumnIndex = "7";

		public static final String sRuleDescriptionColumnIndex = "3";
		
		public static final int TImeout_3_Seconds = 3;

		public static final int TImeout_10_Seconds = 10;

		public static final int TImeout_15_Seconds = 15;

		public static final int TImeout_7_Seconds = 7;
		
		public static int High_MIN_SLEEP = 1000;
		//=====================> Rewrite Variables ============================//
		
		public static String filters="Flag,Prior Disposition,Savings Status";
		
		public static String filtersWithoutFlag="Latest Client Decision,Prior Disposition,Savings Status";
		
		public static String RWO_filters="Payer Short,Insurance,Product,Flag,Latest Client Decision,Current Disposition";
		
		public static String Polciysectionfilters="Payer Short,Insurance,Product";
		
		public static String LatestClientDecisionFilterOptions="Absence of Decision,Approve Library,Approve With Modifications,No Decision,None,Reject,Suppress";
		
		public static String LCDWithOpportunity="Absence of Decision,No Decision,Reject,Suppress";
		public static String LCDWithProduction="Approve Library,Approve With Modifications";
				
		public static String PriorDispositionFilterOptions="Present,No Disposition,Client Defer,Internal Defer,Invalid";
		
		public static String CurrentDispositionFilterOptions="Present,Client Defer,Internal Defer,Invalid";
		
		public static String InsuranceFilterOptions="Medicare,Medicaid,Commercial,Dual Eligible,BlueCard,Federal Employee Program";
		
		public static String ProductFilterOptions="A,F,P,I,O,S";
		
		public static String SavingStatusFilterOptions="Opportunity,Production";
		
		public static String[] latesetClientDecisionColumns={"Mid Rule","Payer","Insurance","Claim Type","CDM Decision","CDM Modifications","Release"};
		
		public static String[] PriorDispositionColumns={"Mid Rule","Payer","Insurance","Claim Type","Prior Disposition","Reason","Notes"};
		
		public static String[] CurrentDispositionColumns={"Mid Rule","Payer","Insurance","Claim Type","Current Disposition","Reason","Notes"};
		
		public static String[] Dispositions={"Present","Invalid"};
		
//		public static String[] Present_Disposition_Reasons={"High savings","No savings for a certain DP but another similar DP in same topic has high savings, so present both","Completeness of Payer Policy","Payer Policy Consistency"};
		
		public static String[] Present_Disposition_Reasons={"High Savings","Business Reasons","Client Requested"};
		
		public static String[] Present_Disposition_Priorities={"High","Medium","Low"};
		
		public static String[] Do_Not_Present_Disposition_Reasons={"Adverse quality score impact","Already a client program in place that addresses the issue","Bad past experience with similar policy","Client cannot accept percentages","Client cannot accept recodes","Client's contracts do not support this","Clinical concerns","Expert panel rule and client does not take these","Issue not a concern for the client","Lots of provider noise risk","Medical necessity","Member liability issues","Mutually exclusive DP (CMS vs. CMS+Cotiviti)","No LCD for client's region","No other client in region using the policy","No savings","Out of sequence claim or claim timing concerns","Prior authorization","Regulatory concerns for client"};

		public static String[] InvalidReasons={"Mutually exclusive DP","Claims system limitations/other technical issues","Performed by another vendor","Primary reference is not accepted by the Client","Not consistent with Client's medical/business policy","Prior authorization","Compliance conflict","Not consistent with line of business","Medical Necessity / diagnosis driven policy not accepted by Client"};
		
		public static String Posted_DispositionNotes="Testing by chaitanya";
		
		public static Bson Payerorquery = new BasicDBObject();
		public static Bson Insuranceorquery = new BasicDBObject();
		public static Bson Claimtypeorquery = new BasicDBObject();
		public static Bson LatestCLientDecisionOrquery = new BasicDBObject();
		public static Bson PriorDispositionOrquery = new BasicDBObject();
		public static Bson CurrentDispositionOrquery = new BasicDBObject();
		
		public static HashSet<String> DB_NoneMPlist=new HashSet<>();
		public static HashSet<String> DB_MPlist=new HashSet<>();
		public static HashSet<String> DB_Topiclist=new HashSet<>();
		public static HashSet<String> UIDPKeylist = new HashSet<>();
		public static HashSet<String> UIMPslist = new HashSet<>();
		
		public static List<String> DB_Medicalpolicylist=new ArrayList<>();
		
		public static HashSet<Long> Lines=new HashSet<>();
		public static ArrayList<Long> RawSavings=new ArrayList<>();
		public static ArrayList<Long> AggSavings=new ArrayList<>();
		public static ArrayList<Long> ConSavings=new ArrayList<>();
		public static ArrayList<Long> Edits=new ArrayList<>();
		
		public static ArrayList<Long> InvalidEdits=new ArrayList<>();
		public static ArrayList<String> InvalidDipositions=new ArrayList<>();
		public static ArrayList<String> cdmdecisionlist=new ArrayList<>();
		public static ArrayList<String> cdmmodificationlist=new ArrayList<>();
		
		public static ArrayList<String> PayershortList = new ArrayList<>();
		public static ArrayList<String> MEDICALPOLICYList = new ArrayList<>();
		public static ArrayList<Long> TopicKeyList = new ArrayList<>();
		public static ArrayList<Long> DPKeyList = new ArrayList<>();
		public static ArrayList<Long> SubrulekeyList = new ArrayList<>();

		public static String DB_Claimtypes;
		public static String DB_DPKey;
		public static String DB_DPDesc;
		public static String DB_RuleDesc;
		public static String DB_Subrulenotes;
		public static String DB_Rules;
		public static String DB_CoreenhancedDesc;
		public static String DB_refdetails;
		public static String DB_PrimaryRefsource;
		public static String DB_Savingsstatus;
		public static String DB_UniqueTopic;
		//public static String DB_UniqueMedicalPolicy;
		public static String DB_Requireddecision;
		public static String DB_CDMDecision;
		public static String DB_CDMModifications;
		public static String DB_CDMDecisionRelease;
		public static String DB_Disposition;
		public static String DB_Priordisposition;
		public static String DB_Dispositionnotes;
		public static ArrayList<String> DB_DispositionReasonslist=new ArrayList<>();
		public static ArrayList<String> DB_Requireddecisionlist=new ArrayList<>();
		public static HashSet<String> DB_UNIQUEMedicalpolicylist=new HashSet<>();
		
		public static HashSet<String> DB_Nodisposition_insuranceList = new HashSet<>();
		public static HashSet<String> DB_Nodisposition_claimtypeList = new HashSet<>();
		public static HashSet<String> DB_Nodisposition_subRuleList = new HashSet<>();
		public static HashSet<Long> DB_Nodisposition_DpkeyList = new HashSet<>();
		
		public static HashSet<String> DB_DispositionList = new HashSet<>();
		public static HashSet<String> DB_DispositionReasonList = new HashSet<>();
		public static HashSet<String> DB_DispositionNotesList = new HashSet<>();
		public static HashSet<String> DB_insuranceList = new HashSet<>();
		public static HashSet<String> DB_claimtypeList = new HashSet<>();
		public static HashSet<String> DB_subRuleList = new HashSet<>();
		public static HashSet<Long> DB_DpkeyList = new HashSet<>();
		
		public static ArrayList<Long> Clientkeylist=new ArrayList<>();

		public static ArrayList<String> UATClientList=new ArrayList<>();
		
		public static ArrayList<String> PRODClientList=new ArrayList<>();
		
		public static ArrayList<Long> UATClientKeysList=new ArrayList<>();
		
		public static ArrayList<Long> PRODClientKeysList=new ArrayList<>();
		
		public static String Disposition;

		public static String DispositionReasons;
		
		public static String DispositionNotes="Testing by chaitanya";

		public static String Priority="High";
		
		public static ArrayList<String> sGetPayershorts=new ArrayList<>();
		
		public static ArrayList<String> Topicwithsavings_PolicySelectiondrawer=new ArrayList<>();
		
		public static ArrayList<String> Medicalpolicywithsavings_PolicySelectiondrawer=new ArrayList<>();
		public static HashSet<String> Medicalpolicy_PolicySelectiondrawer=new HashSet();

		public static ArrayList<String> sGetDPItems;

		public static String ResponseOutput;
		

		public static List<List<String>> Oracel_results_list =new ArrayList<List<String>>();
		
		public static List<List<String>> Opportunity_oracle_collection_data=new ArrayList<List<String>>();

		public static List<List<String>> rvaunified_oracle_collection_data=new ArrayList<List<String>>();
		
		public static ArrayList<String> rva_unified_collection_data=new ArrayList<>();
		
		public static ArrayList<String> Opportunity_collection_data=new ArrayList<>();
		
		public static ArrayList<String> UAT_Opportunity_collection_data=new ArrayList<>();
		
		public static ArrayList<String> PROD_Opportunity_collection_data=new ArrayList<>();
		
		public static FindIterable<Document> results;
		
		public static String Oracle_query_basedon_client_release = "SELECT RVA_KEY,\r\n" +
				"    CLIENT_KEY,\r\n" +
				"    PAYER_KEY,\r\n" +
				"    LINES_PROCESSED,\r\n" +
				"    SUB_RULE_KEY,\r\n" +
				"    MID_RULE_KEY,\r\n" +
				"    RULE_VERSION,\r\n" +
				"    MED_POLICY_KEY,\r\n" +
				"    TOPIC_KEY,\r\n" +
				"    DP_KEY,\r\n" +
				"    CLAIM_TYPE,\r\n" +
				"    INSURANCE_KEY,\r\n" +
				"    INSURANCE_DESC,\r\n" +
				"    PAID,\r\n" +
				"    RAW_SAVINGS,\r\n" +
				"    AGG_SAVINGS,\r\n" +
				"    CON_SAVINGS,\r\n" +
				"    TOTAL_EDITS,\r\n" +
				"    ANNL_PAID,\r\n" +
				"    ANNL_RAW_SAVINGS,\r\n" +
				"    ANNL_AGG_SAVINGS,\r\n" +
				"    ANNL_CON_SAVINGS,\r\n" +
				"    ANNL_TOTAL_EDITS,\r\n" +
				"    DATA_VERSION,RULE_IN_BASELINE_10 FROM RVA_IA.VW_RVA_CPD WHERE CLIENT_NAME like '%clientname%' and DATA_VERSION like '%release%'\r\n" +
				"\r\n";
		
		public static String Oracle_query_basedon_client_release_for_rvaunified = "SELECT RVA_KEY,\r\n" +
				"    CLIENT_KEY,\r\n" +
				"    PAYER_KEY,\r\n" +
				//"    LINES_PROCESSED,\r\n" +
				"    SUB_RULE_KEY,\r\n" +
				"    MID_RULE_KEY,\r\n" +
				"    RULE_VERSION,\r\n" +
				"    MED_POLICY_KEY,\r\n" +
				"    TOPIC_KEY,\r\n" +
				"    DP_KEY,\r\n" +
				"    CLAIM_TYPE,\r\n" +
				"    INSURANCE_KEY,\r\n" +
				"    PAID,\r\n" +
				"    RAW_SAVINGS,\r\n" +
				"    AGG_SAVINGS,\r\n" +
				"    CON_SAVINGS,\r\n" +
				"    TOTAL_EDITS,\r\n" +
				"    ANNL_PAID,\r\n" +
				"    ANNL_RAW_SAVINGS,\r\n" +
				"    ANNL_AGG_SAVINGS,\r\n" +
				"    ANNL_CON_SAVINGS,\r\n" +
				"    ANNL_TOTAL_EDITS,\r\n" +
				"    DATA_VERSION FROM RVA_IA.VW_RVA_CPD WHERE CLIENT_NAME like '%clientname%' and DATA_VERSION like '%release%'\r\n" +
				"\r\n";
		


		public static String DB_CONNECTION_URL_VPMTST1 = "jdbc:Oracle:thin:@vpmtst1.ihtech.com:1521/VPMTST1.iht.com";

		//public static String DB_DRIVER_NAME = "oracle.jdbc.OracleDriver";
		
		public static String DB_CONNECTION_URL_RLSMSG = "jdbc:Oracle:thin:@usdpaj06.ihtech.com:1521/RLSMSG01.iht.com";
		
		public static String DB_CONNECTION_URL_RVAPRD1 = "jdbc:Oracle:thin:@usaprvaprd01.ihtech.com:1521/RVAPRD1.iht.com";
		
		public static String DB_CONNECTION_URL_PMPRD1 = "jdbc:Oracle:thin:@usappmprd01.ihtech.com:1521/PMPRD1.iht.com";
			
		public static String ORACLE_DB_USERNAME= "RVA_SVC";	
		
		public  static String ORACLE_DB_PASSWORD = "RVA_SVC";
		
		public static String ORACLE_DB_PROD_USERNAME= "USER_MASTER_SELECT";	
		
		public  static String ORACLE_DB_PROD_PASSWORD = "USER_MASTER_SELECT";
		
		public static String ORACLE_DB_TST_USERNAME= "APP_MDM";	
		
		public static String ORACLE_DB_USER_MASTER_SELECT= "USER_MASTER_SELECT";
		
		public static String ORACLE_DB_ETL_USERNAME= "MICRO_ETL_APP";	
		
		public  static String ORACLE_DB_ETL_PASSWORD = "MICRO_ETL_APP";
		
		public static String  sDirectory = System.getProperty("user.dir");
		
		public static final String CLIENT_TEAM_DATA_ENDPOINT ="/user-assignments/v1/clients";
		public static ArrayList<String> clientNamesList=new ArrayList<>();
		public static ArrayList<String> clientKeysList=new ArrayList<>();

		public static String eLLtabcolnames="DP,Flags,Status,Latest Client Decision,Prior Disposition";
		public static String RVAtabcolnames="DP,Flag,Raw Savings,Aggressive Savings,Edits,Savings Status,Latest Client Decision,Prior Disposition";
      
		public static ArrayList<String> TopicswithMultipleDPs=new ArrayList<>();
		public static HashMap<String,HashMap<String,String>> sServices= new HashMap<String,HashMap<String,String>>();
		
		public static HashSet<String> PPSList=new HashSet<>();

		public static String BaseURI;

		public static String ulankaPassword="S2FyaXptYTExQA==";
		
		public static String eLL_DP_View_Headers="ALL,Medicare,Medicaid,Commercial,Dual Eligible";
		
		public static String DPPPSMessage="*Selection at DP level captures a disposition for all PPS combinations by default.";
		
		public static List<String> lCDlist = new ArrayList<String>();
		public static List<String> ClaimtypeList = new ArrayList<>();
		public static List<String> insuranceList=new ArrayList<>();
		public static List<Long> insuranceKeyslist = new ArrayList<>();
		public static ArrayList<Long> payerKeys=new ArrayList<>();
		public static List<String> payerShortList=new ArrayList<>();

		public static String Rulerelationshipalert1="Opportunity DPs with a Companion, Counterpart, and Out of Sequence relationship have been included in your disposition and are available for review in Presentation and Decision";
		
		public static String Rulerelationshipalert2="Opportunity DPs with a Mutually Exclusive relationship have been included in your disposition. If performed in error, you may update the disposition in the Review Worked Opportunities view";
		
		public static String Rulerelationshipalert3="Opportunity DPs with multiple rule relationships have been included in your disposition. You may review the rule relationships in the Review Worked Opportunities view";

		public static Long CapturedDPkey;
		
		public static ArrayList<String> CapturedPayershortList=new ArrayList<>();
		public static ArrayList<String> CapturedDPkeyList = new ArrayList<>();
		public static ArrayList<String> CapturedClaimtypesList=new ArrayList<>();
		public static ArrayList<String> CapturedInsuranceList=new ArrayList<>();
		public static ArrayList<String> CapturedPayerLOBList=new ArrayList<>();
		
		public static String CaptureDispositionServiceUrl="cpd-opportunities/v1/capturedisposition";
		
		public static String StaticInsurnaces="1,2,3,7,8,9";
		
		public static HashSet<String> RRRelatedPPSList=new HashSet<>();
		
		
		
}
