package project.utilities;


import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

import javax.print.Doc;

import org.apache.commons.lang3.StringUtils;


import org.bson.BsonDocument;

import org.bson.Document;
import org.bson.conversions.Bson;

import org.junit.Assert;


import com.mongodb.BasicDBObject;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.AggregateIterable;
import com.mongodb.client.DistinctIterable;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Accumulators;
import com.mongodb.client.model.Aggregates;
import com.mongodb.client.model.Filters;



import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;


import com.mongodb.MongoClientURI;
import static com.mongodb.client.model.Sorts.descending;

public class MongoDBUtils {
	static MongoClient mongoClient;
	static MongoDatabase db;
	static MongoCollection<Document> mColl;
	static FindIterable<Document> results;
	static DistinctIterable<String> Distinctresults;
	static DistinctIterable<Long> Distinctresults_with_long;
	static MongoCursor<Document> cursor;
	static MongoCursor<Document> Querycursor;
	static long recordsCount;

	private static MongoDBUtils instance = null;
		

	private MongoDBUtils() {
		// Exists only to defeat instantiation.
	}

	/**
	 * @return WebControlUtils instance
	 */
	public static MongoDBUtils getInstance() {
		if (instance == null) {
			instance = new MongoDBUtils();
		}
		return instance;
	}

	// ########################CONNECTION RELATED
	// METHODS###############################################################

	public static void connectWithCredentials(int port) {
		//String DBConectionString = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("DB_CONNECTION_URL");
		
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();    
		
		String MongoConURL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("DB_CONNECTION_URL");
		
		mongoClient = new MongoClient(new MongoClientURI(MongoConURL));

		System.out.println(MongoConURL);
		System.out.println("Mongo DB Connection is estabished.....");
	}

	public static void ConnectTogivenDBandCollection(String dbname,String collectionname) 
	{
		connectWithCredentials(0);
		db = mongoClient.getDatabase(dbname);
		mColl = db.getCollection(collectionname);
	}
	
	public static void connectWithCredentials(int port,String host) {

		/*MongoClientOptions.Builder builder = new MongoClientOptions.Builder();
		// build the connection options
		builder.maxConnectionIdleTime(1200000);// set the max wait time in (ms)
		MongoClientOptions opts = builder.build();

		MongoCredential credential = MongoCredential.createCredential(ProjectVariables.MONGODB_USER,
				ProjectVariables.MONGODB, ProjectVariables.MONGODB_PWD.toCharArray());
		mongoClient = new MongoClient(new ServerAddress(host, port),
				Arrays.asList(credential), opts);*/
		
		mongoClient = new MongoClient(new MongoClientURI("mongodb+srv://cotiviti:MNE93Mh6@cpd-qa-pl-0-6oxiw.mongodb.net/admin?authSource=admin&readPreference=primary") ); 
		 
		
		
		System.out.println("Mongo DB Connection is estabished.....");
		
	}

	
	// ######################## QUERY RELATED METHODS ######################################################################

	@SuppressWarnings("deprecation")
	public static long retrieveAllDocuments(String dbname, String collectionname) {
		connectWithCredentials(ProjectVariables.MONGO_SERVER_DEVPORT);
		db = mongoClient.getDatabase(dbname);
		mColl = db.getCollection(collectionname);
		// cursor = mColl.find().iterator();
		results = mColl.find();
		recordsCount = mColl.count();

		System.out.println("Connected to Mongo DB successfully");

		System.out.println("cpd_opportunity_Collection_Count =======>" + recordsCount);
		// printResultsDocument();

		return recordsCount;
	}
	
	public static void retrieveFirstDocument(String dbname, String collectionname, Bson sFilter) {
		
		connectWithCredentials(0);

		db = mongoClient.getDatabase(dbname);
		mColl = db.getCollection(collectionname);
		// cursor = mColl.find().iterator();
		results = mColl.find(sFilter).limit(1); 
		
		//System.out.println("Connected to Mongo DB successfully.....");
		//System.out.println("Connected to Mongo DB,Time==>" + GenericUtils.getDateGivenFormat("dd/MM/yyyy h:mm:ss a"));
	}

	public static void retrieveAllDocumentsFromDB(String dbName, String collectionName, int port) {
		connectWithCredentials(port);
		db = mongoClient.getDatabase(dbName);
		mColl = db.getCollection(collectionName);
		cursor = mColl.find().iterator();
		results = mColl.find();
		recordsCount = mColl.count();

		System.out.println("cpd_opportunity_Count:" + recordsCount);

	}
	
	public static long retrieveAllDocuments(String dbname, String collectionname,String hostname,int port) {
		connectWithCredentials(port,hostname);
		db = mongoClient.getDatabase(dbname);
		mColl = db.getCollection(collectionname);
		// cursor = mColl.find().iterator();
		results = mColl.find();
		recordsCount = mColl.count();

		System.out.println("Connected to Mongo DB successfully");

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);
		// printResultsDocument();

		return recordsCount;
	}


	// ######################## Service Specific Methods ################################################################### //

	public static void AggregateMethod_in_Mongo_DB(String client, Long payerkey, String Dataversion, long insurancekey,
			long topickey, long medicalpolicykey, String claimtype, String status, String DPkey,
			String currentdisposition, String priordiposition) {

		// retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();

		if (status.isEmpty()) {
			MatchFilter = Filters.and(Filters.eq("ruleInBaseLine", 0), Filters.eq("_id.insuranceKey", insurancekey),
					Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("_id.payerKey", payerkey), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("subRule.hierarchy.topicKey", topickey),
					Filters.eq("subRule.hierarchy.medPolicyKey", medicalpolicykey),
					Filters.eq("_id.claimType", claimtype));
		} else {
			if (priordiposition.equalsIgnoreCase("null")) {
				MatchFilter = Filters.and(Filters.ne("disposition.priorDisposition", "Prior Approval"),
						Filters.eq("disposition.desc", currentdisposition),
						Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPkey)),
						Filters.eq("ruleInBaseLine", Long.valueOf(status)),
						Filters.eq("_id.insuranceKey", insurancekey),
						Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.eq("_id.payerKey", payerkey), Filters.ne("disposition.desc", "Prior Approval"),
						Filters.eq("subRule.hierarchy.topicKey", topickey),
						Filters.eq("subRule.hierarchy.medPolicyKey", medicalpolicykey),
						Filters.eq("_id.claimType", claimtype));
			} else {
				MatchFilter = Filters.and(Filters.eq("disposition.priorDisposition", priordiposition),
						Filters.eq("disposition.desc", currentdisposition),
						Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPkey)),
						Filters.eq("ruleInBaseLine", Long.valueOf(status)),
						Filters.eq("_id.insuranceKey", insurancekey),
						Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.eq("_id.payerKey", payerkey), Filters.ne("disposition.desc", "Prior Approval"),
						Filters.eq("subRule.hierarchy.topicKey", topickey),
						Filters.eq("subRule.hierarchy.medPolicyKey", medicalpolicykey),
						Filters.eq("_id.claimType", claimtype));
			}

		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static String Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(String fieldata,
			String fieldname) {BasicDBObject fields = new BasicDBObject();
			String outputresponse = null;

			Bson MatchFilter = new BsonDocument();

			if (fieldname.equalsIgnoreCase("Payershort")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("payerShort", fieldata));

			} else if (fieldname.equalsIgnoreCase("Client")) {
				MatchFilter = Filters.eq("clientDesc", java.util.regex.Pattern.compile(fieldata));
			} else if (fieldname.equalsIgnoreCase("Insurance")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("insuranceDesc", fieldata));
				// fields = new BasicDBObject("insuranceDesc", fieldata);
			} else if (fieldname.equalsIgnoreCase("PayerKey")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("_id.payerKey", Long.valueOf(fieldata)));
				// fields = new
				// BasicDBObject("_id.payerKey",Long.valueOf(fieldata));
			} else if (fieldname.equalsIgnoreCase("Topic")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.topicDesc", fieldata));
				// fields = new BasicDBObject("subRule.hierarchy.topicDesc",
				// fieldata);
			} else if (fieldname.equalsIgnoreCase("ClientKey")) {
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(fieldata)));
				// fields = new BasicDBObject("subRule.hierarchy.topicDesc",
				// fieldata);
				
			}else if (fieldname.equalsIgnoreCase("Topic Based on DP")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.topicDesc", fieldata),Filters.eq("subRule.hierarchy.dpKey", ProjectVariables.CapturedDPkey));
				// fields = new BasicDBObject("subRule.hierarchy.topicDesc",
				// fieldata);
			}
			else if (fieldname.equalsIgnoreCase("MP")) {
				MatchFilter = Filters.and(
						Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.medPolicyDesc", fieldata));
				// fields = new BasicDBObject("subRule.hierarchy.topicDesc",
				// fieldata);
			}
			else {
				Assert.assertTrue("Given Field name was not availble in the method ===>" + fieldname, false);
			}

			retrieveFirstDocument("cpd", "oppty", MatchFilter);

			
			for (Document doc : results) {

				Document IDDoccument = doc.get("_id", Document.class);

				if (fieldname.equalsIgnoreCase("Payershort")) {

					outputresponse = String.valueOf(IDDoccument.get("payerKey"));
				} else if (fieldname.equalsIgnoreCase("Client")) {

					outputresponse = String.valueOf(IDDoccument.get("clientKey"));
				} else if (fieldname.equalsIgnoreCase("Insurance")) {

					outputresponse = String.valueOf(IDDoccument.get("insuranceKey"));

				} else if (fieldname.equalsIgnoreCase("PayerKey")) {

					outputresponse = String.valueOf(IDDoccument.get("payerShort"));

				} else if (fieldname.equalsIgnoreCase("ClientKey")) {

					outputresponse = String.valueOf(doc.get("clientDesc"));

				} else if (fieldname.equalsIgnoreCase("Topic")||fieldname.equalsIgnoreCase("Topic Based on DP")) {
					Document Ioccument = doc.get("subRule", Document.class);
					Document Iccument = Ioccument.get("hierarchy", Document.class);
					outputresponse = String.valueOf(Iccument.getLong("topicKey"));
				}
				else if (fieldname.equalsIgnoreCase("MP")) {
					Document Ioccument = doc.get("subRule", Document.class);
					Document Iccument = Ioccument.get("hierarchy", Document.class);
					outputresponse = String.valueOf(Iccument.getLong("medPolicyKey"));
				}
				break;

			}

			System.out.println("'" + fieldname + "' Key ===>" + outputresponse);

			if (outputresponse == null) 
			{
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given MatchFilter ====>" + MatchFilter,false);
			}
		return 	outputresponse;
	}

	public static void Retrieve_the_mongodb_data_to_validate_the_CPW_oppotunityRun_from_Service_reponse(String ResponseRecord) throws Exception {

		
		//System.out.println("Reponse Record ==>" + ResponseRecord);
		
		String clientkey = StringUtils.substringBetween(ResponseRecord, "client_id:", ",client_name");
		String client = StringUtils.substringBetween(ResponseRecord, "client_name:", ",payer_id");
		String Dataversion = StringUtils.substringBetween(ResponseRecord, "data_version:", ",lines");
		String Payershort = StringUtils.substringBetween(ResponseRecord, "payer_short:", ",product");
		String claimtype = StringUtils.substringBetween(ResponseRecord, "product:", ",policy_release");

		Bson MatchFilter;

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
				Filters.ne("disposition.desc", "Prior Approval"), Filters.eq("_id.dataVersion", Dataversion),
				Filters.eq("payerShort", Payershort), Filters.eq("_id.claimType", claimtype));

		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		//System.out.println("Record Count from DB ==>" + recordsCount);

		long DBRawSavings = 0l;
		long DBAggSavings = 0l;
		long DBConSavings = 0l;
		long DBEdits = 0l;

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data Client ==>" + client
					+ ",DataVersion ====>" + Dataversion + ",Payershort ==>" + Payershort + ",Claimtype ===>"
					+ claimtype, false);
		}

		for (Document doc : results) {

			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);

			long LinesTotal = doc.getLong("linesTotal");
			DBRawSavings = AnnualSavingsDoccument.getLong("raw");
			DBAggSavings = AnnualSavingsDoccument.getLong("agg");
			DBConSavings = AnnualSavingsDoccument.getLong("con");
			DBEdits = AnnualSavingsDoccument.getLong("lines");

			ProjectVariables.Lines.add(LinesTotal);
			ProjectVariables.RawSavings.add(DBRawSavings);
			ProjectVariables.AggSavings.add(DBAggSavings);
			ProjectVariables.ConSavings.add(DBConSavings);
			ProjectVariables.Edits.add(DBEdits);

		}
		//System.out.println(ProjectVariables.Lines);
	}

	public static void Retrieve_the_mongodb_data_to_validate_the_CPW_oppotunityRun(String client, String Payershort,
			String Dataversion, long clientkey, long payerkey, long insurancekey, long topickey, long medicalpolicykey,
			String claimtype) throws Exception {

		long RuleInbaseLine = 0l;
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter;

		if (!(topickey == 0l)) {
			MatchFilter = Filters.and(Filters.eq("_id.insuranceKey", insurancekey),
					Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("_id.payerKey", payerkey), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("subRule.hierarchy.topicKey", topickey),
					Filters.eq("subRule.hierarchy.medPolicyKey", medicalpolicykey),
					Filters.eq("_id.claimType", claimtype));
		} else {
			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("payerShort", Payershort), Filters.ne("disposition.desc", "Prior Approval"));
		}

		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Record Count from DB ==>" + recordsCount);

		long DBRawSavings = 0l;
		long DBAggSavings = 0l;
		long DBConSavings = 0l;
		long DBEdits = 0l;

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data Client ==>" + client
					+ ",DataVersion ====>" + Dataversion + ",Payershort ==>" + Payershort, false);
		}

		for (Document doc : results) {

			// System.out.println(doc);

			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);

			if (!(topickey == 0l)) {
				RuleInbaseLine = doc.getLong("ruleInBaseLine");
			}

			long LinesTotal = doc.getLong("linesTotal");
			DBRawSavings = AnnualSavingsDoccument.getLong("raw");
			DBAggSavings = AnnualSavingsDoccument.getLong("agg");
			DBConSavings = AnnualSavingsDoccument.getLong("con");
			DBEdits = AnnualSavingsDoccument.getLong("lines");

			if (!(topickey == 0l)) {
				if (RuleInbaseLine == 0) {
					ProjectVariables.Lines.add(LinesTotal);
					ProjectVariables.RawSavings.add(DBRawSavings);
					ProjectVariables.AggSavings.add(DBAggSavings);
					ProjectVariables.ConSavings.add(DBConSavings);
					ProjectVariables.Edits.add(DBEdits);
				} else if (RuleInbaseLine == -1) {
					ProjectVariables.Lines.add(0l);
					ProjectVariables.RawSavings.add(0l);
					ProjectVariables.AggSavings.add(0l);
					ProjectVariables.ConSavings.add(0l);
					ProjectVariables.Edits.add(0l);
				}
			} else {

				ProjectVariables.Lines.add(LinesTotal);
				ProjectVariables.RawSavings.add(DBRawSavings);
				ProjectVariables.AggSavings.add(DBAggSavings);
				ProjectVariables.ConSavings.add(DBConSavings);
				ProjectVariables.Edits.add(DBEdits);

			}
		}

		DBRawSavings = 0l;
		DBAggSavings = 0l;
		DBConSavings = 0l;
		DBEdits = 0l;
		System.out.println("Raw Savings size ===>" + ProjectVariables.RawSavings.size());

		for (int j = 0; j < ProjectVariables.RawSavings.size(); j++) {

			DBRawSavings = DBRawSavings + ProjectVariables.RawSavings.get(j);

		}

		for (int j = 0; j < ProjectVariables.AggSavings.size(); j++) {
			DBAggSavings = DBAggSavings + ProjectVariables.AggSavings.get(j);

		}

		for (int j = 0; j < ProjectVariables.ConSavings.size(); j++) {
			DBConSavings = DBConSavings + ProjectVariables.ConSavings.get(j);

		}

		for (int j = 0; j < ProjectVariables.Edits.size(); j++) {
			DBEdits = DBEdits + ProjectVariables.Edits.get(j);

		}

		System.out.println("DB Raw Savings ===>" + DBRawSavings);
		System.out.println("DB AggSavings ===>" + DBAggSavings);
		System.out.println("DB ConSavings ===>" + DBConSavings);
		System.out.println("DB Edits ===>" + DBEdits);

		System.out.println("Lines ===>" + ProjectVariables.Lines);

	}

	public static void Retrieve_the_medicalpolicy_topic_for_the_given_client(String clientkey, String medicalpolicydesc,
			String fieldname) {

		ProjectVariables.TopicKeyList.clear();
		ProjectVariables.DPKeyList.clear();
		// , Long payerkey, String Dataversion,ArrayList<Long>
		// insurancekey,ArrayList<String> claimtype
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		if (fieldname.equalsIgnoreCase("Medicalpolicy")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.ne("disposition.desc", "Prior Approval"));

			Distinctresults = mColl.distinct("subRule.hierarchy.medPolicyDesc", MatchFilter, String.class);

			for (String Medicalpolicy : Distinctresults) {

				i = i + 1;

				ProjectVariables.MEDICALPOLICYList.add(Medicalpolicy);
				System.out.println(Medicalpolicy);

			}

		} else if (fieldname.equalsIgnoreCase("Topic")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicydesc),
					Filters.ne("disposition.desc", "Prior Approval"));
			Distinctresults_with_long = mColl.distinct("subRule.hierarchy.topicKey", MatchFilter, Long.class);
			for (Long TopicKey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.TopicKeyList.add(TopicKey);
				// System.out.println(TopicKey);

			}

		}

		else if (fieldname.equalsIgnoreCase("DPKey-No Disposition")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(medicalpolicydesc)));
			Distinctresults_with_long = mColl.distinct("subRule.hierarchy.dpKey", MatchFilter, Long.class);
			for (Long TopicKey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.DPKeyList.add(TopicKey);
				// System.out.println(TopicKey);

			}

		} else if (fieldname.equalsIgnoreCase("DPKey")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.ne("disposition.desc", "No Disposition"), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(medicalpolicydesc)));
			Distinctresults_with_long = mColl.distinct("subRule.hierarchy.dpKey", MatchFilter, Long.class);
			for (Long TopicKey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.DPKeyList.add(TopicKey);
				// System.out.println(TopicKey);

			}

		} else if (fieldname.equalsIgnoreCase("Subrulekey-No Disposition")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(medicalpolicydesc)));
			Distinctresults_with_long = mColl.distinct("subRule.subRuleKey", MatchFilter, Long.class);
			for (Long subrulekey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.SubrulekeyList.add(subrulekey);
				// System.out.println(TopicKey);

			}

		} else if (fieldname.equalsIgnoreCase("Subrulekey")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.ne("disposition.desc", "No Disposition"), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(medicalpolicydesc)));
			Distinctresults_with_long = mColl.distinct("subRule.subRuleKey", MatchFilter, Long.class);
			for (Long subrulekey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.SubrulekeyList.add(subrulekey);
				// System.out.println(TopicKey);

			}

		}

		else if (fieldname.equalsIgnoreCase("CDM Decision")) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(medicalpolicydesc)));
			Distinctresults_with_long = mColl.distinct("subRule.hierarchy.dpKey", MatchFilter, Long.class);
			for (Long dpkey : Distinctresults_with_long) {

				i = i + 1;

				ProjectVariables.DPKeyList.add(dpkey);
				// System.out.println(TopicKey);

			}

		}

		else {

			Assert.assertTrue(
					"fieldname was not matched/not available with the existing method ,field name ==>" + fieldname,
					false);

		}

		if (i == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data  ====>" + fieldname
					+ "," + clientkey + "," + medicalpolicydesc, false);
		}

		System.out.println("Record Count from DB ==>" + i);

		// System.out.println(ProjectVariables.TopicKeyList);

	}

	public static void AggregateMethod_in_Mongo_DB_rva_unified_collection(String client, Long payerkey,
			String Dataversion, long insurancekey, long topickey, long medicalpolicykey, String claimtype,
			String status, String DPkey, Long currentdisposition) {

		retrieveAllDocumentsFromDB("rva_data", "rva_unified ", 10235);

		Bson MatchFilter = new BsonDocument();

		MatchFilter = Filters.and(Filters.eq("value.dispositions.currentRaw", currentdisposition),
				Filters.eq("value.hierarchy.decisionPoint", Long.valueOf(DPkey)),
				Filters.eq("_id.identity.lobRaw", insurancekey),
				Filters.eq("value.clientName", java.util.regex.Pattern.compile(client)),
				Filters.eq("value.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
				Filters.eq("value.payerId", payerkey), Filters.eq("value.hierarchy.topic", topickey),
				Filters.eq("value.hierarchy.medicalPolicy", medicalpolicykey),
				Filters.eq("_id.identity.claimTypeRaw", claimtype));

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static boolean Check_the_given_record_was_exist_or_not(String client, ArrayList<String> Payerkeys,
			String dataversion, String medicalpolicy, String requestcriteria) throws Exception {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		ProjectVariables.InvalidEdits.clear();
		ProjectVariables.InvalidDipositions.clear();

		retrieveAllDocuments("cpd", "oppty");

		boolean bstatus = false;
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : Payerkeys) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter;

		MatchFilter = Filters.and(Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
				Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(dataversion)), Payerorquery,
				Insuranceorquery, Claimtypeorquery);

		// ,Filters.ne("disposition.desc", "Prior Approval")

		Long DBEdits = 0l;

		String DBDisposition = null;

		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Record Count from DB ==>" + recordsCount);

		for (Document doc : results) {

			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			Document dispositionDoccument = doc.get("disposition", Document.class);

			DBDisposition = dispositionDoccument.getString("desc");

			DBEdits = AnnualSavingsDoccument.getLong("lines");

			ProjectVariables.InvalidEdits.add(DBEdits);
			ProjectVariables.InvalidDipositions.add(DBDisposition);

		}

		if (requestcriteria.equalsIgnoreCase("Review OppGrid-Topickey")
				|| requestcriteria.equalsIgnoreCase("Review OppGrid-Medicalpolicy")) {

			for (String Diposition : ProjectVariables.InvalidDipositions) {

				if (Diposition.equalsIgnoreCase("No Disposition") || Diposition.equalsIgnoreCase("Prior Approval")) {
					bstatus = true;
				} else {
					bstatus = false;
					break;
				}

			}
		} else {

			for (String Diposition : ProjectVariables.InvalidDipositions) {

				if (Diposition.equalsIgnoreCase("Prior Approval")) {
					bstatus = true;
				} else {
					bstatus = false;
					break;
				}

			}

			if (bstatus == false) {
				for (Long Edits : ProjectVariables.InvalidEdits) {

					if (Edits == 0) {
						bstatus = true;
					} else {
						bstatus = false;
						break;
					}

				}

			}
		}

		System.out.println("Invalid Check Status ==>" + bstatus);

		return bstatus;
	}

	public static void AggregateMethod_in_Mongo_DB_For_DPWB(String client, ArrayList<String> payerkeyList,
			String Dataversion, long subrulekey, long midrule, String savingstatus, String requestcriteria) {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		retrieveAllDocuments("cpd", "oppty");

		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : payerkeyList) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter = new BsonDocument();

		long ruleInBaseLine = 0;

		if (savingstatus.equalsIgnoreCase("Prod")) {
			ruleInBaseLine = -1;
		} else if (savingstatus.equalsIgnoreCase("Opp")) {
			ruleInBaseLine = 0;
		}

		if (requestcriteria.equalsIgnoreCase("AWBGrid")) {
			if (savingstatus.equalsIgnoreCase("Multiple")) {
				MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.eq("disposition.desc", "No Disposition"), Filters.eq("_id.subRuleKey", subrulekey),
						Filters.eq("subRule.hierarchy.midRuleKey", midrule), Payerorquery, Insuranceorquery,
						Claimtypeorquery);
			} else {
				MatchFilter = Filters.and(Filters.eq("ruleInBaseLine", ruleInBaseLine),
						Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.eq("disposition.desc", "No Disposition"), Filters.eq("_id.subRuleKey", subrulekey),
						Filters.eq("subRule.hierarchy.midRuleKey", midrule), Payerorquery, Insuranceorquery,
						Claimtypeorquery);
			}

		} else if (requestcriteria.equalsIgnoreCase("ReviewGrid")) {

			if (savingstatus.equalsIgnoreCase("Multiple")) {
				MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.ne("disposition.desc", "No Disposition"), Filters.eq("_id.subRuleKey", subrulekey),
						Filters.eq("subRule.hierarchy.midRuleKey", midrule), Payerorquery, Insuranceorquery,
						Claimtypeorquery);
			} else {
				MatchFilter = Filters.and(Filters.eq("ruleInBaseLine", ruleInBaseLine),
						Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
						Filters.ne("disposition.desc", "No Disposition"), Filters.eq("_id.subRuleKey", subrulekey),
						Filters.eq("subRule.hierarchy.midRuleKey", midrule), Payerorquery, Insuranceorquery,
						Claimtypeorquery);
			}

		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static boolean Check_the_given_record_was_exist_or_not_in_DPWB(String client, ArrayList<String> Payerkeys,
			String dataversion, String dpkey, String requestcriteria) throws Exception {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		ProjectVariables.InvalidEdits.clear();
		ProjectVariables.InvalidDipositions.clear();

		retrieveAllDocuments("cpd", "oppty");

		boolean bstatus = false;
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : Payerkeys) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter;

		MatchFilter = Filters.and(Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
				Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(dataversion)),
				Filters.eq("disposition.desc", "No Disposition"), Payerorquery, Insuranceorquery, Claimtypeorquery);

		// ,Filters.ne("disposition.desc", "Prior Approval")

		Long DBEdits = 0l;

		String DBDisposition = null;

		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering dataFor client ==>"
					+ client + ",Dataversion ==>" + dataversion + ",PayerKeys ==>" + dataversion, false);
		}

		for (Document doc : results) {

			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			Document dispositionDoccument = doc.get("disposition", Document.class);

			DBDisposition = dispositionDoccument.getString("desc");

			DBEdits = AnnualSavingsDoccument.getLong("lines");

			ProjectVariables.InvalidEdits.add(DBEdits);
			ProjectVariables.InvalidDipositions.add(DBDisposition);

		}

		for (String diposition : ProjectVariables.InvalidDipositions) {

			if (diposition.equalsIgnoreCase("No Disposition") || diposition.equalsIgnoreCase("Prior Approval")) {
				bstatus = true;
			} else {
				bstatus = false;
				break;
			}

		}

		System.out.println("Invalid Check Status ==>" + bstatus);
		System.out.println("Invalid Dispositions ==>" + ProjectVariables.InvalidDipositions);
		return bstatus;
	}

	public static void AggregateMethod_in_Mongo_DB_For_DPWB_For_DP_Summary_Service(String client,
			List<String> payerkeyList, String Dataversion, String dpdesc, String dpkey, String topicname,
			String medicalpolicyname, String requestcriteria) {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		retrieveAllDocuments("cpd", "oppty");

		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : payerkeyList) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter = new BsonDocument();

		if (requestcriteria.equalsIgnoreCase("AWBGrid")) {
			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("disposition.desc", "No Disposition"), Filters.eq("subRule.hierarchy.dpDesc", dpdesc),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
					Filters.eq("subRule.hierarchy.topicDesc", topicname),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname), Payerorquery, Insuranceorquery,
					Claimtypeorquery);

		} else if (requestcriteria.equalsIgnoreCase("ReviewGrid")) {

			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.ne("disposition.desc", "No Disposition"), Filters.eq("subRule.hierarchy.dpDesc", dpdesc),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
					Filters.eq("subRule.hierarchy.topicDesc", topicname),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname), Payerorquery, Insuranceorquery,
					Claimtypeorquery);

		}

		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,For client ==>"
					+ client + ",Dataversion ==>" + Dataversion + ",DPKey ==>" + dpkey + ",Medicalpolicy Desc ==>"
					+ medicalpolicyname + ",TopicDesc ==>" + topicname + ",DPdesc ==>" + dpdesc, false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static void AggregateMethod_in_Mongo_DB_For_DPWB_For_Rule_Summary_Service(String client,
			ArrayList<String> payerkeyList, String Dataversion, String ruledesc, String primaryrefsource,
			String subrulenotes, String primaryrefsourcecode, String requestcriteria) {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		retrieveAllDocuments("cpd", "oppty");

		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : payerkeyList) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter = new BsonDocument();

		if (requestcriteria.equalsIgnoreCase("AWBGrid")) {
			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("disposition.desc", "No Disposition"), Filters.eq("subRule.desc", ruledesc),
					Filters.eq("subRule.refSource.desc", primaryrefsource),
					Filters.eq("subRule.coreEnhancedDesc", primaryrefsourcecode), Payerorquery, Insuranceorquery,
					Claimtypeorquery);
			// Filters.eq("subRule.notes", subrulenotes)

		} else if (requestcriteria.equalsIgnoreCase("ReviewGrid")) {

			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.ne("disposition.desc", "No Disposition"), Filters.eq("subRule.desc", ruledesc),
					Filters.eq("subRule.refSource.desc", primaryrefsource),
					Filters.eq("subRule.coreEnhancedDesc", primaryrefsourcecode), Payerorquery, Insuranceorquery,
					Claimtypeorquery);
			// Filters.eq("subRule.notes", subrulenotes)

		}

		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,client ===>"
					+ client + ",payerkeyList ===>" + payerkeyList + ",Dataversion" + Dataversion + ",ruledesc===>"
					+ ruledesc + ",primaryrefsource ===>" + primaryrefsource + ",subrulenotes ==>" + subrulenotes
					+ ",primaryrefsourcecode==>" + primaryrefsourcecode, false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static void AggregateMethod_in_Mongo_DB_For_DPWB_For_Insurance_Summary_Service(String client,
			ArrayList<String> payerkeyList, String Dataversion, String insurancekey, Long dpkey,
			String requestcriteria) {

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		retrieveAllDocuments("cpd", "oppty");

		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : payerkeyList) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter = new BsonDocument();

		if (requestcriteria.equalsIgnoreCase("AWBGrid")) {
			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.eq("disposition.desc", "No Disposition"), Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("_id.insuranceKey", Long.valueOf(insurancekey)),
					Filters.eq("subRule.hierarchy.dpKey", dpkey), Payerorquery, Claimtypeorquery);

		} else if (requestcriteria.equalsIgnoreCase("ReviewGrid")) {

			MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
					Filters.ne("disposition.desc", "No Disposition"),
					Filters.eq("_id.insuranceKey", Long.valueOf(insurancekey)),
					Filters.eq("subRule.hierarchy.dpKey", dpkey), Payerorquery, Claimtypeorquery);

		}

		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data", false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static void CDM_Decisions_in_Mongo_DB_based_on(String clientname, String payerkey, String insurancekey,
			String claimtype, String Dataversion, String subrule) {

		Bson MatchFilter = new BsonDocument();

		MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(clientname)),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
				Filters.eq("_id.insuranceKey", Long.valueOf(insurancekey)), Filters.eq("_id.claimType", claimtype),
				Filters.eq("_id.payerKey", Long.valueOf(payerkey)), Filters.eq("_id.subRuleId", subrule));
		retrieveAllDocuments("cpd", "oppty");
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data", false);
		}

		int i = 0;

		for (Document document : results) {

			i = i + 1;

			Document CDMDecisionDoc = document.get("latestClientDecision", Document.class);

			String cdmdecision = CDMDecisionDoc.getString("cdmDecision");
			String cdmmodification = CDMDecisionDoc.getString("cdmModifications");

			ProjectVariables.cdmdecisionlist.add(cdmdecision);
			ProjectVariables.cdmmodificationlist.add(cdmmodification);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("cdmdescionlist ==>" + ProjectVariables.cdmdecisionlist);
		System.out.println("cdmmodificationlist ==>" + ProjectVariables.cdmmodificationlist);

	}

	public static void AggregateMethod_in_Mongo_DB_For_DPWB_For_Rule_Grid_Service(String client, String payerkey,
			String Dataversion, String midrule, Long subrulekey, String insurancekey, String currentdisposition,
			String priordisposition, String requestcriteria) {

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		retrieveAllDocuments("cpd", "oppty");

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter = new BsonDocument();

		MatchFilter = Filters.and(Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),
				Filters.eq("_id.payerKey", Long.valueOf(payerkey)), Filters.eq("_id.subRuleKey", subrulekey),
				Filters.eq("subRule.hierarchy.midRuleKey", Long.valueOf(midrule)),
				Filters.eq("_id.insuranceKey", Long.valueOf(insurancekey)),
				Filters.eq("disposition.desc", currentdisposition),
				Filters.eq("disposition.priorDisposition", priordisposition), Claimtypeorquery);

		// Claimtypeorquery
		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue(
					"Record count was 'zero' in the Mongo DB for the given filtering data,For client ==>" + client
							+ ",Dataversion ==>" + Dataversion + ",PayerKey ==>" + payerkey + ",subRuleKey ==>"
							+ subrulekey + ",midRuleKey ==>" + midrule + ",insuranceKey ==>" + insurancekey
							+ ",Diposition ==>" + currentdisposition + ",Prior Disposition ==>" + priordisposition,
					false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;

			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	public static boolean Check_the_given_record_was_exist_or_not_for_cdm_service(String client,
			ArrayList<String> Payerkeys, String dataversion, String dpkey, String requestcriteria) throws Exception {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();
		ArrayList<String> CDMDecisionsList = new ArrayList<>();

		ArrayList<String> ClaimtypeList = new ArrayList<>();

		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");

		ProjectVariables.InvalidEdits.clear();
		ProjectVariables.InvalidDipositions.clear();

		retrieveAllDocuments("cpd", "oppty");

		boolean bstatus = false;
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson Payerorquery = new BasicDBObject();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		Bson Insuranceorquery = new BasicDBObject();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		Bson Claimtypeorquery = new BasicDBObject();

		for (String payer : Payerkeys) {

			Filters.eq("_id.payerKey", Long.valueOf(payer));

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("_id.payerKey", Long.valueOf(payer)));

		}

		Payerorquery = Filters.or(payerORqueryList);

		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

		Bson MatchFilter;

		MatchFilter = Filters.and(Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
				Filters.eq("clientDesc", java.util.regex.Pattern.compile(client)),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(dataversion)),
				Filters.eq("disposition.desc", "No Disposition"), Payerorquery, Insuranceorquery, Claimtypeorquery);

		// ,Filters.ne("disposition.desc", "Prior Approval")

		String cdmdecision = null;

		String DBDisposition = null;

		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data", false);
		}

		for (Document doc : results) {

			Document CDMDecisionsDoc = doc.get("latestClientDecision", Document.class);
			Document dispositionDoccument = doc.get("disposition", Document.class);

			DBDisposition = dispositionDoccument.getString("desc");

			if (CDMDecisionsDoc == null) {
				cdmdecision = "";

			} else {
				cdmdecision = CDMDecisionsDoc.getString("cdmDecision");
			}

			CDMDecisionsList.add(cdmdecision);
			ProjectVariables.InvalidDipositions.add(DBDisposition);

		}

		for (String cdmdecisiondata : CDMDecisionsList) {

			if (cdmdecisiondata.equalsIgnoreCase("")) {
				bstatus = true;
			} else {
				bstatus = false;
				break;
			}

		}

		System.out.println("Invalid Check Status ==>" + bstatus);
		System.out.println("CDMDecisionsList ==>" + CDMDecisionsList);
		return bstatus;
	}

	public static String Retrieve_the_medicalpolicy_based_on_client_and_release(String clientkey, String release,
			String payershort) {
		
		List<String> topicslist=null;
		Bson MatchFilter_2=null;
		AggregateIterable<Document> output2 = null;
		ProjectVariables.Medicalpolicy_PolicySelectiondrawer.clear();

		HashSet<String> MecdicalpoliciesList = new HashSet<>();
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		String DBMedicalpolicy = null;

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		if (payershort.isEmpty()) {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"),
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
					Filters.eq("ruleInBaseLine", 0));
			 //Filters.ne("annualSavings.lines", 0)

		} else {
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"),
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
					Filters.eq("payerShort", payershort));
					//Filters.ne("annualSavings.lines", 0));
		}
		//
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record Count ===>" + recordsCount);

		//////////////
		
		
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		
			 output2 = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group("$subRule.hierarchy.medPolicyDesc",
								Accumulators.addToSet("Topics", "$subRule.hierarchy.topicDesc"))));
	

		for (Document document : output2) {

			
			
			String Topics= StringUtils.substringBetween(document.toString(), "Topics=[", "]}}");
			
			topicslist=Arrays.asList(Topics.split(","));
			
			DBMedicalpolicy = StringUtils.substringBetween(document.toString(), "_id=", ", Topics");
			
			
			
			if(topicslist.size()>=4)
			{
				
				ProjectVariables.Medicalpolicy_PolicySelectiondrawer.add(DBMedicalpolicy);
			}
			
			
		}

	

		if (recordsCount == 0) 
		{
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,Matchfilter==>"+MatchFilter, false);
		}

		if (ProjectVariables.Medicalpolicy_PolicySelectiondrawer.isEmpty()) {
			Assert.assertTrue("Mecial policies is 'null' in the Mongo DB for the given filtering data,client key==>"
					+ clientkey + ",Release ==>" + release
					+ ",Disposition ==>No Disposition,for the topic count > 4", false);
		}

		System.out.println(ProjectVariables.Medicalpolicy_PolicySelectiondrawer);
		System.out.println("Medical Policies size ==>" + ProjectVariables.Medicalpolicy_PolicySelectiondrawer.size());

		for (String DBmedicalpolicy : ProjectVariables.Medicalpolicy_PolicySelectiondrawer) {
			return DBmedicalpolicy;
		}

		return null;

	}

	public static void AggregateMethod_in_Mongo_DB_For_AWB_Page(List<String> payerkeyList,String medicalpolicyname, String topicname, String dpkey, String savingsstatus,
			String requestcriteria) {

		ProjectVariables.RawSavings.clear();
		ProjectVariables.AggSavings.clear();
		ProjectVariables.ConSavings.clear();
		ProjectVariables.Edits.clear();
		ArrayList<String> Dispositionlist=new ArrayList<>();
		Dispositionlist.add("No Disposition");
		Dispositionlist.add("Prior Approval");
		if(!payerkeyList.isEmpty())
		{
			Intialaize_the_insurance_claimtype_queries(payerkeyList);	
		}
		

		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		Bson MatchFilter_with_savingsstatus = new BsonDocument();

		// Filters.eq("ruleInBaseLine", ruleInBaseLine)

		switch (requestcriteria) {
		case "AWBGrid":
			if (topicname.isEmpty()) {
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
						Filters.eq("disposition.desc", "No Disposition"),
						Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname), ProjectVariables.Payerorquery,
						ProjectVariables.Insuranceorquery, ProjectVariables.Claimtypeorquery);
			} else {
				/*if (topicname.equalsIgnoreCase("Smoking and Tobacco Use Cessation Counseling")) {
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.eq("disposition.desc", "No Disposition"),
							Filters.eq("subRule.hierarchy.topicKey", 2832),
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname),
							ProjectVariables.Payerorquery, ProjectVariables.Insuranceorquery,
							ProjectVariables.Claimtypeorquery);
				} else*/ 
				if (dpkey.isEmpty()) {
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.eq("disposition.desc", "No Disposition"),
							Filters.eq("subRule.hierarchy.topicDesc", topicname),
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname),
							ProjectVariables.Payerorquery, ProjectVariables.Insuranceorquery,
							ProjectVariables.Claimtypeorquery);
				} else {
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.eq("disposition.desc", "No Disposition"),
							//Filters.eq("subRule.hierarchy.topicDesc", topicname),
							Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname),
							ProjectVariables.Payerorquery, ProjectVariables.Insuranceorquery,
							ProjectVariables.Claimtypeorquery);
				}
			}

			break;

		case "ReviewGrid":
			if (topicname.isEmpty()) 
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null),
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
						Filters.nin("disposition.desc", Dispositionlist),
						//Filters.ne("disposition.desc", "Prior Approval"),
						Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));
			}
			else {
				if (dpkey.isEmpty()) {
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.nin("disposition.desc", Dispositionlist),
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname),
							Filters.eq("subRule.hierarchy.topicDesc", topicname));
				} else if(!payerkeyList.isEmpty()){
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.nin("disposition.desc", Dispositionlist),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null),
							Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
							Filters.eq("subRule.hierarchy.topicDesc", topicname),ProjectVariables.Payerorquery,
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));
				}
				else
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
							Filters.nin("disposition.desc", Dispositionlist),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null),
							Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
							Filters.eq("subRule.hierarchy.topicDesc", topicname),
							Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));
				}

			}

			break;

		}

		if (savingsstatus.equalsIgnoreCase("Opportunity")) {
			MatchFilter_with_savingsstatus = Filters.and(MatchFilter, Filters.eq("ruleInBaseLine", 0));
		} else if (savingsstatus.equalsIgnoreCase("Production")) {
			MatchFilter_with_savingsstatus = Filters.and(MatchFilter, Filters.eq("ruleInBaseLine", -1),Filters.eq("disposition.priorDisposition", "No Disposition"));
		} else {
			MatchFilter_with_savingsstatus = Filters.and(MatchFilter);
		}

		recordsCount = mColl.count(MatchFilter_with_savingsstatus);

		System.out.println("cpd_opportunity_Collection_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,For clientkey ==>"
					+ Serenity.sessionVariableCalled("clientkey") + ",MatchFilter ==>" + MatchFilter_with_savingsstatus, false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter_with_savingsstatus));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.addToSet("Topicname", "$subRule.hierarchy.topicDesc"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.sum("Edits", "$annualSavings.lines"))));

		int i = 0;

		for (Document document : output2) {

			i = i + 1;
			System.out.println(MatchFilter_with_savingsstatus);
			System.out.println(document);
			ProjectVariables.RawSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
			ProjectVariables.AggSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
			ProjectVariables.ConSavings
					.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
			ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", "}")));

		}

		if (i == 0) {
			ProjectVariables.RawSavings.add(0l);
			ProjectVariables.AggSavings.add(0l);
			ProjectVariables.ConSavings.add(0l);
			ProjectVariables.Edits.add(0l);

		}

		System.out.println("Record Count from DB ==>" + i);
		System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
		System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
		System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
		System.out.println("DBEdits ==>" + ProjectVariables.Edits);

	}

	private static void Intialaize_the_insurance_claimtype_queries(List<String> payerkeyList) {

		ArrayList<Long> InsuranceKeyList = new ArrayList<>();
		ArrayList<String> ClaimtypeList = new ArrayList<>();
		ArrayList<String> LatestClientDecisionList = new ArrayList<>();
		ArrayList<String> PriorDispositionList = new ArrayList<>();
		ArrayList<String> CurrentDispositionList = new ArrayList<>();
		
		//Intialaizing the default values in the correponding arraylists
		InsuranceKeyList.add(1l);
		InsuranceKeyList.add(2l);
		InsuranceKeyList.add(3l);
		InsuranceKeyList.add(7l);
		InsuranceKeyList.add(8l);
		InsuranceKeyList.add(9l);

		ClaimtypeList.add("A");
		ClaimtypeList.add("F");
		ClaimtypeList.add("P");
		ClaimtypeList.add("I");
		ClaimtypeList.add("O");
		ClaimtypeList.add("S");
		
		LatestClientDecisionList.add("Absence of Decision");
		LatestClientDecisionList.add("Approve Library");
		LatestClientDecisionList.add("Approve with Modification");
		LatestClientDecisionList.add("No Decision");
		LatestClientDecisionList.add("Reject");
		LatestClientDecisionList.add("Suppress");
		
		CurrentDispositionList.add("Present");
		CurrentDispositionList.add("Do Not Present - CPM Review");
		CurrentDispositionList.add("Do Not Present");
		CurrentDispositionList.add("Not Reviewed");
		
		PriorDispositionList.add("Present");
		PriorDispositionList.add("Do Not Present - CPM Review");
		PriorDispositionList.add("Do Not Present");
		PriorDispositionList.add("Not Reviewed");
		
		
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();
		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		ArrayList<Bson> LatesCDMDecisionORqueryList = new ArrayList<>();
		ArrayList<Bson> CurrentDispositionORqueryList = new ArrayList<>();
		ArrayList<Bson> PriorDispositionORqueryList = new ArrayList<>();

		
		//Payershort Or filter
		for (String payer : payerkeyList) {

			Filters.eq("payerShort", payer.trim());

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("payerShort", payer.trim()));

		}

		ProjectVariables.Payerorquery = Filters.or(payerORqueryList);

		//Insurance Or filter
		for (Long INSurance : InsuranceKeyList) {

			Filters.eq("_id.insuranceKey", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("_id.insuranceKey", INSurance));

		}

		ProjectVariables.Insuranceorquery = Filters.or(InsuranceORqueryList);

		
		//Claimtype Or filter
		for (String claimtype : ClaimtypeList) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		ProjectVariables.Claimtypeorquery = Filters.or(ClaimtypeORqueryList);
		
		//LatestClientDecisoin Or filter
				for (String latestCDMDecision : LatestClientDecisionList) {

					Filters.eq("latestClientDecision.cdmDecision", latestCDMDecision);

					// orquery=Filters.or(Filters.eq("payerShort", payer));
					LatesCDMDecisionORqueryList.add(Filters.eq("latestClientDecision.cdmDecision", latestCDMDecision));

				}

				ProjectVariables.LatestCLientDecisionOrquery = Filters.or(LatesCDMDecisionORqueryList);
			
		//CurrentDisposition Or filter
		for (String currentdisposition : CurrentDispositionList) {

					Filters.eq("disposition.desc", currentdisposition);

					// orquery=Filters.or(Filters.eq("payerShort", payer));
					CurrentDispositionORqueryList.add(Filters.eq("disposition.desc", currentdisposition));

				}

				ProjectVariables.CurrentDispositionOrquery = Filters.or(CurrentDispositionORqueryList);
							
				//PriorDisposition Or filter
				for (String priordisposition : PriorDispositionList) {

							
							PriorDispositionORqueryList.add(Filters.eq("disposition.priorDisposition", priordisposition));

						}

						ProjectVariables.PriorDispositionOrquery = Filters.or(PriorDispositionORqueryList);
								

	}

	public static void Retrieve_the_Topics_DPs_based_on_client_in_AWB(String clientkey,
			String medicalpolicyname) {
		ProjectVariables.DB_Topiclist.clear();
		ProjectVariables.DB_DpkeyList.clear();

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		String DBTopic = null;
		Long DPkey = 0l;

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
				Filters.eq("disposition.desc", "No Disposition"),
				//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
				Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));

		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		for (Document doc : results) {

			Document SubRuleDocumment = doc.get("subRule", Document.class);
			Document HierarchyDoc = SubRuleDocumment.get("hierarchy", Document.class);
			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			i = i + 1;

			Long Edits = AnnualSavingsDoccument.getLong("lines");

			DPkey = HierarchyDoc.getLong("dpKey");
			DBTopic = HierarchyDoc.getString("topicDesc");

			//if (!(Edits == 0)) {
				ProjectVariables.DB_Topiclist.add(DBTopic);

			//}

			ProjectVariables.DB_DpkeyList.add(DPkey);

		}

		if (recordsCount == 0) {
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>" + clientkey
					 + ",Disposition ==>No Disposition", false);
		}

		if (ProjectVariables.DB_Topiclist.isEmpty()) {
			Assert.assertTrue("Topic keys  is 'null' in the Mongo DB for the given filtering data,client ==>" + clientkey
					+ ",Disposition ==>No Disposition", false);
		}

		System.out.println("Topics ==>" + ProjectVariables.DB_Topiclist);
		System.out.println("DP's ==>" + ProjectVariables.DB_DpkeyList);
		System.out.println("Topics size==>" + ProjectVariables.DB_Topiclist.size());
		System.out.println("DP'size ==>" + ProjectVariables.DB_DpkeyList.size());

		// System.out.println("Documments ==>"+Doclist);

	}

	public static boolean Check_the_savings_for_the_given_DP(String clientkey, String release, String medicalpolicy,
			String griddata,String griddatacriteria) {

		boolean bstatus = false;
		HashSet<Long> DB_EditsList = new HashSet<>();
		// Connection method for Mongo DB
		 retrieveAllDocuments("cpd", "oppty");
		String DBTopic = null;
		Long DPkey = 0l;

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		if(griddatacriteria.equalsIgnoreCase("DPKey")){
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(griddata)));

		}
		else
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
					Filters.eq("subRule.hierarchy.topicDesc",griddata));

		}
		
		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		for (Document doc : results) {
			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			i = i + 1;

			Long Edits = AnnualSavingsDoccument.getLong("lines");

			DB_EditsList.add(Edits);

		}

		for (Long DB_Edits : DB_EditsList) {

			if (DB_Edits == 0) {
				bstatus = true;
			} else {
				bstatus = false;
				break;
			}

		}
		System.out.println("Record status ==>"+bstatus);
		
		return bstatus;

	}

	public static Long NoDisposition_Records_in_Mongo_DB_For_the_given_PPS_in_AWB_Page(
			String disposition,ArrayList<Long> dpKeys,String pagename,String payershort,String insurance,String claimtype,String LCD) {
		
		//To load the pps and LCD in arraylist
		loadThePPSandOpportunityLCDinList(payershort,insurance,claimtype,LCD);
		
		//To connecto to database
		//retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		
		switch (pagename) {
		case "RVA":
			ConnectTogivenDBandCollection("cdm", "latestDecision");
			//ConnectTogivenDBandCollection("cpd", "oppty");
			MatchFilter = Filters.and(
						Filters.in("_id.dpKey", dpKeys),
					  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("decStatusDesc", ProjectVariables.lCDlist)
					);
		/*	MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("disposition.desc", "No Disposition"),
					//Filters.eq("disposition.notes", ProjectVariables.DispositionNotes),
					Filters.in("subRule.hierarchy.dpKey", dpKeys),
					Filters.eq("ruleInBaseLine", 0),
				  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
				  );*/
			
		break;

		case "RWO":
			ConnectTogivenDBandCollection("cpd", "oppty");
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("disposition.desc", disposition.trim()),
					//Filters.eq("disposition.notes", ProjectVariables.DispositionNotes),
					Filters.in("subRule.hierarchy.dpKey", dpKeys),
					Filters.eq("ruleInBaseLine", 0),
				  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
				  );

			
		
			break;
			
			
			default:
				Assert.assertTrue("Given selection was not found ==>"+pagename, false);
				
			break;

		}
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Disposition_Count for the given PPS combination:" + recordsCount);
		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,Matchfilter:;"+MatchFilter, false);
		}
		return recordsCount;
		
		
	}

	public static void Get_Rule_insurance_claimtype_based_on_given(List<String> payerkeyList,
			List<Long> DPKeyList,String criteria) {
		
		ProjectVariables.DB_DispositionList.clear();				
		ProjectVariables.DB_DispositionReasonList.clear();
		ProjectVariables.DB_DispositionNotesList.clear();
		ProjectVariables.DB_insuranceList.clear();
		ProjectVariables.DB_claimtypeList.clear();
		ProjectVariables.DB_subRuleList.clear();
		
		List<String> DispositionreasonsList=null;

	
		//Mongo Connection method
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))), Filters.in("subRule.hierarchy.dpKey", DPKeyList)
				);
		//Filters.in("payerShort", payerkeyList)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Disposition_Count for the given PPS combination:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,For clientkey ==>"
					+ Serenity.sessionVariableCalled("clientkey") + ",Dataversion ==>" + Serenity.sessionVariableCalled("release") + ",DPKeys ==>" + DPKeyList + ",PayersList ==>"
					+ payerkeyList, false);
		}

		for (Document document : results) {
			Document ID_Doccument = document.get("_id", Document.class);
			Document Disposition_Doccument = document.get("disposition", Document.class);
			Document Subrule_Doccument = document.get("subRule", Document.class);
			Document hierarchy_Doccument = Subrule_Doccument.get("hierarchy", Document.class);

			if(!criteria.isEmpty())
			{
				String disposition=Disposition_Doccument.getString("desc");
				String dispositionnotes=Disposition_Doccument.getString("notes");
				DispositionreasonsList = (List<String>) Disposition_Doccument.get("reasons");
				ProjectVariables.DB_DispositionList.add(disposition);		
				if(DispositionreasonsList!=null)
					{
					ProjectVariables.DB_DispositionReasonList.addAll(DispositionreasonsList);	
					}
				
				ProjectVariables.DB_DispositionNotesList.add(dispositionnotes);
			}
			
			String claimtype = ID_Doccument.getString("claimType");
			String insurance = document.getString("insuranceDesc");
			String subrule = ID_Doccument.getString("subRuleId");
			Long DPkey = hierarchy_Doccument.getLong("dpKey");

			ProjectVariables.DB_insuranceList.add(insurance);
			ProjectVariables.DB_claimtypeList.add(claimtype);
			ProjectVariables.DB_subRuleList.add(subrule);
			// DpkeyList.add(DPkey);

		}

		System.out.println("insuranceList for the given PPS combination:" + ProjectVariables.DB_insuranceList);
		System.out.println("claimtypeList for the given PPS combination:" + ProjectVariables.DB_claimtypeList);
		System.out.println("subRuleList for the given PPS combination:" + ProjectVariables.DB_subRuleList);
		System.out.println("Dispositions for the given PPS combination:" + ProjectVariables.DB_DispositionList);
		System.out.println("DispositionReasons for the given PPS combination:" + ProjectVariables.DB_DispositionReasonList);
		System.out.println("Dispositionnotes for the given PPS combination:" + ProjectVariables.DB_DispositionNotesList);

	}

	public static String Get_the_DPKey_with_multiplerules_based_on_client_release_and_savingstatus(String clientkey, String release,
			List<String> payerkeyList,String savingsstatus,String Pagename) {
		ProjectVariables.DB_Medicalpolicylist.clear();
		
		
		String DBDPKey = null;
		String DBDPDesc = null;
		String DBRules = null;
		String DBMedicalpolicy = null;
		Bson MatchFilter = new BsonDocument();
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		List<String> sRulesList=null;
		int i = 0;
		
		

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		
		if(payerkeyList!=null)
		{
			for (String payer : payerkeyList) {

				Filters.eq("payerShort", payer.trim());

				// orquery=Filters.or(Filters.eq("payerShort", payer));
				payerORqueryList.add(Filters.eq("payerShort", payer.trim()));

			}

			ProjectVariables.Payerorquery = Filters.or(payerORqueryList);
			
		}
		
		//Filters.ne("annualSavings.lines", 0)
		switch(Pagename)
		{
		case "AWB":
			if(savingsstatus.isEmpty())
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.eq("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0),
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
						ProjectVariables.Payerorquery
						 );
				//
			}
			else
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.eq("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0),
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
						Filters.eq("ruleInBaseLine", Long.valueOf(savingsstatus)), ProjectVariables.Payerorquery);
				//,Filters.ne("annualSavings.lines", 0)
			}
		break;
		case "Review Worked Opportunity":
			if(savingsstatus.isEmpty())
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0)
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)
								);

			}
			else
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0),
						//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
						Filters.eq("ruleInBaseLine", Long.valueOf(savingsstatus)));

			}
			break;
			default:
				
				Assert.assertTrue("Given selection was not found ==>"+Pagename, false);
				
				break;
		
		}
		
		
		
		//
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record Count ===>" + recordsCount);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		//////////////

		Bson MatchFilter_2 = Filters.nor(Filters.size("Rules", 0), Filters.size("Rules", 1));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$subRule.hierarchy.dpKey", Accumulators.addToSet("Rules", "$_id.subRuleId"),
						Accumulators.addToSet("MedicalPolicy", "$subRule.hierarchy.medPolicyDesc"),Accumulators.addToSet("DPDesc", "$subRule.hierarchy.dpDesc")),
				Aggregates.match(MatchFilter_2)));

		// Accumulators.sum("count", MatchFilter_2)

		for (Document document : output2) {

			//System.out.println("DPKey Record ===>" + document.toString());

			DBDPKey = StringUtils.substringBetween(document.toString(), "_id=", ", Rules");
			DBDPDesc = StringUtils.substringBetween(document.toString(), "DPDesc=[", "]}");
			DBRules = StringUtils.substringBetween(document.toString(), "Rules=[", "], MedicalPolicy");
			DBMedicalpolicy = StringUtils.substringBetween(document.toString(), "MedicalPolicy=[", "]");
			
			sRulesList=Arrays.asList(DBRules.split(","));
			
			if(sRulesList.size()>4)
			{
				ProjectVariables.DB_DPKey=DBDPKey.trim();
				ProjectVariables.DB_DPDesc=DBDPDesc.trim();
				ProjectVariables.DB_Rules=DBRules.trim();
				ProjectVariables.DB_Medicalpolicylist.add(DBMedicalpolicy);
				
				break;
			}
				
			
		
		}

		if (recordsCount == 0) {
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>" + clientkey
					+ ",Release ==>" + release + ",Disposition ==>No Disposition,payershortlist ==>"+payerkeyList+",savingsstatus ==>"+savingsstatus, false);
		}

		if (ProjectVariables.DB_DPKey.isEmpty()) {
			Assert.assertTrue("DPKey is 'null' in the Mongo DB for the given filtering data,clientkey ==>" + clientkey
					+ ",Release ==>" + release + ",Disposition ==>No Disposition", false);
		}

		System.out.println(ProjectVariables.DB_DPKey);
		

		System.out.println("Medicalpolicy with multiple rules ==>" + ProjectVariables.DB_Medicalpolicylist);
		System.out.println("DPKey with multiple rules ==>" + ProjectVariables.DB_DPKey);
		System.out.println("DPDesc with multiple rules ==>" + ProjectVariables.DB_DPDesc);
		System.out.println("Rules ==>" + ProjectVariables.DB_Rules);
		System.out.println("RulesSize ==>" + sRulesList.size());
	
		return null;

	}

	public static boolean Retrieve_the_Topics_DPs_based_on_client_release_and_filters_in_AWB(String medicalpolicyname, List<String> payerkeyList,List<String> Insurancekelist,List<String> ClaimtypeList, String latestclientdecison,
			String priordisposition, String savingsstatus, String filtername,String pagename) {
		ProjectVariables.DB_Topiclist.clear();
		ProjectVariables.DB_DpkeyList.clear();
		ProjectVariables.DB_MPlist.clear();

		String DBTopic = null;
		Long DPkey = 0l;
		ArrayList<Bson> payerORqueryList = new ArrayList<>();
		Bson MatchFilter = new BsonDocument();

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		int i = 0;
		if(pagename.equalsIgnoreCase("RWO")&&filtername.equalsIgnoreCase("Combination filter")||pagename.equalsIgnoreCase("AWB"))
		{
			if(Insurancekelist!=null)
			{
				Intialaize_the_insurance_claimtype_queries(payerkeyList,Insurancekelist,ClaimtypeList);	
			}
				
		}
		
		
		// To set Latest Client Decision
		if (latestclientdecison.equalsIgnoreCase("None")) {
			latestclientdecison = null;
		} else if (latestclientdecison.equalsIgnoreCase("Approve with Modification")) {
			latestclientdecison = "Approve With Modifications";
		}

		// To set savings status
		if (savingsstatus.equalsIgnoreCase("Opportunity")) {
			savingsstatus = "0";
		} else if (savingsstatus.equalsIgnoreCase("Production")) {
			savingsstatus = "-1";
		}

		switch (filtername) {
		
		case "Latest Client Decision":
			if(pagename.equalsIgnoreCase("AWB"))
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("latestClientDecision.cdmDecision", latestclientdecison),
						Filters.eq("disposition.desc", "No Disposition"),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
						Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));
				//, ProjectVariables.Payerorquery
			}
			else
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("latestClientDecision.cdmDecision", latestclientdecison),Filters.ne("annualSavings.lines", 0),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null),
						Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));

			}
			break;
		case "Prior Disposition":
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("disposition.priorDisposition", priordisposition),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));
			 //ProjectVariables.Payerorquery
			
			
			break;
		case "Current Disposition":
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("disposition.desc", priordisposition),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
			
		break;

		case "Savings Status":

			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("ruleInBaseLine", Long.valueOf(savingsstatus)),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname), ProjectVariables.Payerorquery);

			break;

		case "Combination filter":
			if(pagename.equalsIgnoreCase("AWB"))
			{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("latestClientDecision.cdmDecision", latestclientdecison),
					Filters.eq("disposition.priorDisposition", priordisposition),
					Filters.eq("ruleInBaseLine", Long.valueOf(savingsstatus)),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
					Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname), ProjectVariables.Payerorquery);
			}
			else
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("latestClientDecision.cdmDecision", latestclientdecison),
						Filters.eq("disposition.desc", priordisposition),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),ProjectVariables.Payerorquery, ProjectVariables.Insuranceorquery,
								ProjectVariables.Claimtypeorquery);
				
			}
			break;

		default:

			Assert.assertTrue("Given selection was not found ==>" + filtername, false);
			break;

		}

		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);

		for (Document doc : results) {

			Document SubRuleDocumment = doc.get("subRule", Document.class);
			Document HierarchyDoc = SubRuleDocumment.get("hierarchy", Document.class);
			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			i = i + 1;

			// Long Edits=AnnualSavingsDoccument.getLong("lines");

			DPkey = HierarchyDoc.getLong("dpKey");
			DBTopic = HierarchyDoc.getString("topicDesc");
			
			if(!pagename.equalsIgnoreCase("AWB"))
			{
				
				String DB_MP=HierarchyDoc.getString("medPolicyDesc");
				
				ProjectVariables.DB_MPlist.add(DB_MP);
			}
			
			
			// if(!(Edits==0))
			{
				ProjectVariables.DB_Topiclist.add(DBTopic);

			}

			ProjectVariables.DB_DpkeyList.add(DPkey);

		}

		if (recordsCount == 0) {
			System.out.println("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"
					+ Serenity.sessionVariableCalled("clientkey") + ",Release ==>" + Serenity.sessionVariableCalled("release") + ",Disposition ==>No Disposition");
			return false;
		} else {
			System.out.println("Topics ==>" + ProjectVariables.DB_Topiclist);
			System.out.println("MPs ==>" + ProjectVariables.DB_MPlist);
			
			System.out.println("DP's ==>" + ProjectVariables.DB_DpkeyList);
			System.out.println("MP Size ==>" + ProjectVariables.DB_MPlist.size());
			System.out.println("Topics size==>" + ProjectVariables.DB_Topiclist.size());
			System.out.println("DP'size ==>" + ProjectVariables.DB_DpkeyList.size());
			return true;
		}

	}

	public static String Retrieve_the_medicalpolicy_and_savings_based_on_client_and_release_for_policyselection_Drawer(String payershort,String insurance,String claimtype,String LCD) {
		ArrayList<String> Disposition = new ArrayList<>();
		ArrayList<String> MPList = new ArrayList<>();
		
		Bson matchtext =null;
		AggregateIterable<Document> output3 =null;
		Disposition.add("Prior Disposition");
		Disposition.add("Invalid");
		ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.clear();
		
		//Intialaize the payershort,claimtype and insurance queries
		loadThePPSandLCDinList(payershort, insurance, claimtype, LCD);
		
		Bson DispositionNorquery = new BasicDBObject();
		ArrayList<Bson> DispositionORqueryList = new ArrayList<>();

		
		DispositionORqueryList.add(Filters.eq("disposition.desc", "Prior Approval"));
		DispositionORqueryList.add(Filters.eq("disposition.desc", "Invalid"));

		DispositionNorquery = Filters.nor(DispositionORqueryList);
	
		int i=0;
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				Filters.eq("disposition.desc", "No Disposition"),
				  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
				  );
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered Record count ==>" + recordsCount);
		 matchtext = Aggregates.match(Filters.and(MatchFilter));
		 output3 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$subRule.hierarchy.medPolicyDesc",Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"))));
		for (Document document : output3) 
		{
			i = i + 1;
			String medicalpolicy=StringUtils.substringBetween(document.toString(), "_id=", ", Raw");
			String rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=", ", Agg");
			String consavings=StringUtils.substringBetween(document.toString(), "Con savings=", "}}");
			String aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=", ", Con");
			if(!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Specialty Policy")&&!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Global Policy"))
			{
				String row=medicalpolicy+";Raw-"+rawsavings+";Agg-"+aggsavings+";Con-"+consavings;
				//ProjectVariables.Medicalpolicywithsavings_PolicySelectiondrawer.add(row);
				ProjectVariables.Medicalpolicy_PolicySelectiondrawer.add(medicalpolicy.trim());
			}
			MPList.add(medicalpolicy);
			System.out.println(medicalpolicy);
		}
		
		//To retrieve MPs and Topics from elldatabase
		retrieveTheeLLMPsbasedonPPSforFilterPanel(payershort,insurance,claimtype,LCD);
		
		if (ProjectVariables.Medicalpolicy_PolicySelectiondrawer.isEmpty()) 
		{
			Assert.assertTrue("Mecial policies is 'null' in the Mongo DB for the given matchfilter==>"+MatchFilter, false);
		}

		System.out.println(ProjectVariables.Medicalpolicy_PolicySelectiondrawer);
		System.out.println("Medical Policies size ==>" + ProjectVariables.Medicalpolicy_PolicySelectiondrawer.size());

		return null;

	}

	public static String GetTheDPRawsavingsInFilterPanel(String MP_Topic,String clientkey,String sCriteria) {
		Bson MatchFilter = new BsonDocument();
		ArrayList<String> TopicList = new ArrayList<>();
		Bson matchtext =null;
		Long iSavings=0l;
		AggregateIterable<Document> output3 =null;
		
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered Record count ==>" + recordsCount);
		
		
			System.out.println(""+sCriteria+":"+MP_Topic);
			if(sCriteria.equalsIgnoreCase("MP"))
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.ne("annualSavings.lines", 0),Filters.eq("subRule.hierarchy.medPolicyDesc", MP_Topic),
						Filters.eq("ruleInBaseLine", 0),
						Filters.eq("disposition.desc", "No Disposition"));
				
				 matchtext = Aggregates.match(Filters.and(MatchFilter));
					
				 output3 = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$subRule.hierarchy.topicDesc")));
				 for (Document document : output3)
				 {
					TopicList.add(StringUtils.substringBetween(String.valueOf(document), "_id=", "}}"));
				 }
			}
			else
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
						Filters.ne("annualSavings.lines", 0),Filters.eq("subRule.hierarchy.topicDesc", MP_Topic),
						Filters.eq("ruleInBaseLine", 0),
						Filters.eq("disposition.desc", "No Disposition"));
				
				TopicList.add(MP_Topic);
			}
			
			System.out.println(TopicList);
			System.out.println("Topics Size==>"+TopicList.size());
			
			 for (int j2 = 0; j2 < TopicList.size(); j2++) 
			 {
				 MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
							Filters.ne("annualSavings.lines", 0),Filters.eq("subRule.hierarchy.topicDesc", TopicList.get(j2)),
							Filters.eq("ruleInBaseLine", 0),Filters.eq("ruleInBaseLine", 0),
							Filters.eq("disposition.desc", "No Disposition"));
					
					 matchtext = Aggregates.match(Filters.and(MatchFilter));
					 Bson sort =descending("Rawsavings");
					
					 output3 = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$subRule.hierarchy.dpKey",Accumulators.sum("Rawsavings", "$annualSavings.raw")),Aggregates.sort(sort),Aggregates.limit(1)));
					 for (Document document : output3)
					 {
						System.out.println(j2+1+".DPKey:"+StringUtils.substringBetween(String.valueOf(document), "_id=", ", Rawsavings"));
						iSavings=iSavings+Long.valueOf(StringUtils.substringBetween(String.valueOf(document), "Rawsavings=", "}}"));
						
					 }
			 }
			 
			 String row=MP_Topic+";Raw-"+iSavings;
		
		System.out.println(row);
		return String.valueOf(iSavings);
	}

	public static String Retrieve_the_Topics_and_savings_based_on_client_release_and_medicalpolicy_for_policyselection_Drawer(
			 String medicalpolicy,String Payershorts, String Insuarances, String Claimtypes,String LatestClientDecision) {

		ProjectVariables.Topicwithsavings_PolicySelectiondrawer.clear();

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(Payershorts,Insuarances,Claimtypes,LatestClientDecision);
					
		int i = 0;
		
		Bson MatchFilter = new BsonDocument();
		
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
						Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0),
					  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		AggregateIterable<Document> output3 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$subRule.hierarchy.topicDesc",Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"))));

		
		for (Document document : output3) {
			i = i + 1;
			String topic=StringUtils.substringBetween(document.toString(), "_id=", ", Raw");
			String rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=", ", Agg");
			String consavings=StringUtils.substringBetween(document.toString(), "Con savings=", "}}");
			String aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=", ", Con");
			String row=topic+";Raw-"+rawsavings+";Agg-"+aggsavings+";Con-"+consavings;
			ProjectVariables.Topicwithsavings_PolicySelectiondrawer.add(row);
			System.out.println(row);
		}
		System.out.println("Record Count from DB ==>" + i);
		System.out.println("Topics size ==>" + ProjectVariables.Topicwithsavings_PolicySelectiondrawer.size());

		return null;

	}
	
	private static void Intialaize_the_insurance_claimtype_queries(List<String> payerkeyList,List<String> insurancelist,List<String> claimtypelist) {

		
		
		ArrayList<Bson> payerORqueryList = new ArrayList<>();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();

		for (String payer : payerkeyList) {

			Filters.eq("payerShort", payer.trim());

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("payerShort", payer.trim()));

		}

		ProjectVariables.Payerorquery = Filters.or(payerORqueryList);

		for (String INSurance : insurancelist) {

			Filters.eq("insuranceDesc", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("insuranceDesc", INSurance));

		}

		ProjectVariables.Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : claimtypelist) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		ProjectVariables.Claimtypeorquery = Filters.or(ClaimtypeORqueryList);

	}

	public static String Get_the_Rule_information_for_the_given(String clientkey, String release,
			List<String> payerkeyList,String savingsstatus,String DPKEy,String Rule) {
		
		String DBCoreEnhancedDesc = null;
		String DBRefDetails = null;
		String DBPrimaryRefsource = null;
		String DBSavingsstatus = null;
		
		Bson MatchFilter = new BsonDocument();
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		

		
		if(savingsstatus.isEmpty())
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPKEy)),Filters.eq("_id.subRuleId", Rule),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release))
					);
			//Filters.in("payerShort", payerkeyList)
		}
		else
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.ne("disposition.desc", "Prior Approval"),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPKEy)),Filters.eq("_id.subRuleId", Rule),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)),
					Filters.eq("ruleInBaseLine", Long.valueOf(savingsstatus)));
			//,Filters.in("payerShort", payerkeyList)
		}
		
		//
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record Count ===>" + recordsCount);
		
		if (recordsCount == 0) {
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey =>"+clientkey+" ,release ==>"+release+",payerkeyList==>"+payerkeyList+",savingstatus"+savingsstatus+",DPKEy==>"+DPKEy+",Rule==>"+Rule+",Medicalpolicy ==>"+Serenity.sessionVariableCalled("Medicalpolicy"), false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		
		//////////////

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$_id.subRuleId", Accumulators.addToSet("CoreEnhancedDesc", "$subRule.coreEnhancedDesc"),
						Accumulators.addToSet("PrimaryReference", "$subRule.refSource.desc"),Accumulators.addToSet("ReferenceDetails", "$subRule.refTitle.desc"),Accumulators.addToSet("Savingsstatus", "$ruleInBaseLine"))));

		// Accumulators.sum("count", MatchFilter_2)

		for (Document document : output2) {

			System.out.println("Rule Record ===>" + document.toString());

			DBCoreEnhancedDesc = StringUtils.substringBetween(document.toString(), "CoreEnhancedDesc=[", "], PrimaryReference");
			DBRefDetails = StringUtils.substringBetween(document.toString(), "ReferenceDetails=[", "], Savingsstatus");
			DBPrimaryRefsource = StringUtils.substringBetween(document.toString(), "PrimaryReference=[", "], ReferenceDetails");
			DBSavingsstatus=StringUtils.substringBetween(document.toString(), "Savingsstatus=[", "]}");
			
		
				ProjectVariables.DB_CoreenhancedDesc=DBCoreEnhancedDesc.trim();
				ProjectVariables.DB_refdetails=DBRefDetails.trim();
				ProjectVariables.DB_PrimaryRefsource=DBPrimaryRefsource.trim();
				
				if(DBSavingsstatus.equalsIgnoreCase("-1"))
				{
					DBSavingsstatus="Production";
				}
				else if(DBSavingsstatus.equalsIgnoreCase("0"))
				{
					DBSavingsstatus="Opportunity";
				}
				
				ProjectVariables.DB_Savingsstatus=DBSavingsstatus.trim();
		
		}

	
		if (ProjectVariables.DB_PrimaryRefsource.isEmpty()) {
			Assert.assertTrue("PrimaryRefSource is 'null' in the Mongo DB for the given filtering data,clientkey ==>" + clientkey
					+ ",Release ==>" + release + ",Disposition ==>No Disposition", false);
		}

	
	

		System.out.println("DB_CoreenhancedDesclist ==>" + ProjectVariables.DB_CoreenhancedDesc);
		System.out.println("DB_refdetailslist ==>" + ProjectVariables.DB_refdetails);
		System.out.println("DB_PrimaryRefsourcelist ==>" + ProjectVariables.DB_PrimaryRefsource);
		System.out.println("DB_Savingsstatus ==>" + ProjectVariables.DB_Savingsstatus);
	
		return null;

	}

	public static void Get_the_distinct_values_based_on_given(String clientkey,String fieldname) {
		ProjectVariables.PayershortList.clear();
		
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.ne("disposition.desc", "Prior Approval"));

			Distinctresults = mColl.distinct("_id.payerShort", MatchFilter, String.class);

			for (String Payershort : Distinctresults) {

				i = i + 1;

				ProjectVariables.PayershortList.add(Payershort);
				System.out.println(Payershort);

			}
			
			System.out.println("Payershortsize ==>"+ProjectVariables.PayershortList.size());
			System.out.println("Payershorts ==>"+ProjectVariables.PayershortList);
		}

	public static void Get_the_DPKeys_based_on_client_release_and_Descisions(String clientkey,
			String release, List<String> payerkeyList,String filtername,String Pagename) {
		ProjectVariables.DB_Topiclist.clear();
		ProjectVariables.DB_DpkeyList.clear();

		String DBTopic = null;
		String requiredfieldname=null;
		String requiredfielddata=null;
		Long DPkey = 0l;
		ArrayList<String> PriorDispositionList = new ArrayList<>();
		ArrayList<String> CurrentDispositionList = new ArrayList<>();
		ArrayList<String> LatestClientDecisionList = new ArrayList<>();
		Bson MatchFilter = new BsonDocument();

		PriorDispositionList.add("Not Reviewed");
		PriorDispositionList.add("Invalid");
		PriorDispositionList.add("No Disposition");
		PriorDispositionList.add("Prior Approval");
		
		CurrentDispositionList.add("No Disposition");
		CurrentDispositionList.add("Prior Approval");
		LatestClientDecisionList.add("Absence of Decision");
		LatestClientDecisionList.add("Approve Library");
		LatestClientDecisionList.add("Approve with Modification");
		LatestClientDecisionList.add("No Decision");
		LatestClientDecisionList.add("Reject");
		LatestClientDecisionList.add("Suppress");
		
		/*if(Pagename.equalsIgnoreCase("AWB"))
		{
		//Intialaizing the filter queries
		Intialaize_the_insurance_claimtype_queries(payerkeyList);
		}
		*/
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

	
		switch (filtername) {
		case "latest Client Decision":

			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.in("latestClientDecision.cdmDecision", LatestClientDecisionList)
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release))
					 );
			//ProjectVariables.LatestCLientDecisionOrquery
			requiredfieldname="latestClientDecision";
			requiredfielddata="cdmDecision";
			
			break;
		case "Prior Disposition":

			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.nin("disposition.priorDisposition", PriorDispositionList)
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release))
					);
			 //ProjectVariables.Payerorquery,,Filters.in("_id.payerShort", payerkeyList),ProjectVariables.PriorDispositionOrquery
			requiredfieldname="disposition";
			requiredfielddata="priorDisposition";
			break;

		case "Current Disposition":
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey))
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release))
					);
			//ProjectVariables.CurrentDispositionOrquery
			requiredfieldname="disposition";
			requiredfielddata="desc";
			break;

		

		default:

			Assert.assertTrue("Given selection was not found ==>" + filtername, false);
			break;

		}

		if(Pagename.equalsIgnoreCase("AWB"))
		{
			MatchFilter=Filters.and(MatchFilter,Filters.eq("disposition.desc", "No Disposition"));
			//,ProjectVariables.Payerorquery
		}
		else
		{
			MatchFilter=Filters.and(MatchFilter,Filters.nin("disposition.desc", CurrentDispositionList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile", null));
		}
		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);
		
		for (Document doc : results) {
		
			Document requireddoc = doc.get(requiredfieldname, Document.class);
			Document SubRuleDocumment = doc.get("subRule", Document.class);
			Document HierarchyDoc = SubRuleDocumment.get("hierarchy", Document.class);
			
			DPkey = HierarchyDoc.getLong("dpKey");
			DBTopic = HierarchyDoc.getString("topicDesc");
			String output=requireddoc.getString(requiredfielddata);
			
			
		/*	ProjectVariables.DB_DpkeyList.add(DPkey);
			ProjectVariables.DB_UNIQUEMedicalpolicylist.add(DBMedicalpolicy);
			ProjectVariables.DB_Requireddecisionlist.add(output);*/
			
			ProjectVariables.DB_DPKey=String.valueOf(DPkey);
			ProjectVariables.DB_UniqueTopic=DBTopic;
			ProjectVariables.DB_Requireddecision=output;
			
			break;
			

		}

		if (recordsCount == 0) {
			System.out.println("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"
					+ clientkey + ",Release ==>" + release + ",Disposition ==>No Disposition,payerkeyList ==>"+payerkeyList);
			
		} 
		
		if(ProjectVariables.DB_DPKey==null||ProjectVariables.DB_UniqueTopic==null) {
			
			Assert.assertTrue("DP Keys or Medical policy was null for the given filtering criteria from mongodb,MATCH FILTER ==>"+MatchFilter, false);
			
		}

		System.out.println("Topic ==>" + ProjectVariables.DB_UniqueTopic);
		System.out.println("DPKey ==>" + ProjectVariables.DB_DPKey);
		System.out.println(filtername+"==>" + ProjectVariables.DB_Requireddecision);
		
	}

	public static boolean Get_the_popup_data_based_on_client_release_and_PPS(String clientkey,
			String release,String dpkey,String midrule, String payer,String insurance,String claimtype,String popname) {
		Document DispositionDoc=null;
		List<String> DispositionreasonsList=null;
		Bson MatchFilter = new BsonDocument();
		ProjectVariables.DB_DispositionReasonslist.clear();
	
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
				Filters.eq("insuranceDesc", insurance),Filters.eq("_id.claimType", claimtype),Filters.eq("_id.payerShort", payer),Filters.eq("subRule.hierarchy.midRuleKey", Long.valueOf(midrule)),Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey))
				//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release))
						);
		
	
		
		
		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);

		for (Document doc : results) {

			
			
			switch (popname) {
			case "latest Client Decision":
				Document latestClientDecisionDoc = doc.get("latestClientDecision", Document.class);
				
				if(latestClientDecisionDoc!=null){
					String CDMDecision=latestClientDecisionDoc.getString("cdmDecision");
					String CDMModifications=latestClientDecisionDoc.getString("cdmModifications");
					Long CDMDecisionrelease=latestClientDecisionDoc.getLong("cdmTimestamp");
					
					//Converting Epoch time to given format
					String ExactRelease=GenericUtils.Convert_Epoch_time_to_given_format_for_the_given_date("MM-dd-yyyy",CDMDecisionrelease);
					
					ProjectVariables.DB_CDMDecision=CDMDecision;
					ProjectVariables.DB_CDMModifications=CDMModifications;
					ProjectVariables.DB_CDMDecisionRelease=ExactRelease;

				}
				else
				{
					ProjectVariables.DB_CDMDecision=null;
					ProjectVariables.DB_CDMModifications=null;
					ProjectVariables.DB_CDMDecisionRelease=null;

				}
				System.out.println("DB_CDMDecision ==>" + ProjectVariables.DB_CDMDecision);
				System.out.println("DB_CDMModifications ==>" + ProjectVariables.DB_CDMModifications);
				System.out.println("DB_CDMDecisionRelease==>" + ProjectVariables.DB_CDMDecisionRelease);
				
				
				break;
			case "Prior Disposition":
				//System.out.println(doc);
				 DispositionDoc = doc.get("disposition", Document.class);
				
				String priorDisposition=DispositionDoc.getString("priorDisposition");
				 DispositionreasonsList = (List<String>) DispositionDoc.get("reasons");
				 
				 String dispositionnotes=DispositionDoc.getString("notes");
				 
				 	ProjectVariables.DB_Disposition=priorDisposition;
					ProjectVariables.DB_Dispositionnotes=dispositionnotes;
					
					if(!(DispositionreasonsList==null))
					{
						ProjectVariables.DB_DispositionReasonslist.addAll(DispositionreasonsList);	
					}
					else
					{
						//ProjectVariables.DB_DispositionReasonslist.addAll(null);
					}
					
					
					System.out.println("DB_Disposition ==>" + ProjectVariables.DB_Disposition);
					System.out.println("DB_Dispositionnotes ==>" + ProjectVariables.DB_Dispositionnotes);
					System.out.println("DB_DispositionReasonslist==>" + ProjectVariables.DB_DispositionReasonslist);
					
				
				break;

			case "Current Disposition":
				 DispositionDoc = doc.get("disposition", Document.class);
				  
				 
				 String Currentdisposition=DispositionDoc.getString("desc");
				 
				 
				 	ProjectVariables.DB_Disposition=Currentdisposition;
				 	
				 	
				 	if(!((List<String>) DispositionDoc.get("reasons")==null))
					{
				 		DispositionreasonsList = (List<String>) DispositionDoc.get("reasons");
						ProjectVariables.DB_DispositionReasonslist.addAll(DispositionreasonsList);	
					}
					else
					{
						ProjectVariables.DB_DispositionReasonslist.addAll(null);
					}
				 	
				 	if(!(DispositionDoc.getString("notes")==null))
					{
				 		String Currentdispositionnotes=DispositionDoc.getString("notes");
				 		ProjectVariables.DB_Dispositionnotes=Currentdispositionnotes;	
					}
					else
					{
						ProjectVariables.DB_Dispositionnotes=null;
					}
				 	
					
					System.out.println("DB_Disposition ==>" + ProjectVariables.DB_Disposition);
					System.out.println("DB_Dispositionnotes ==>" + ProjectVariables.DB_Dispositionnotes);
					System.out.println("DB_DispositionReasonslist==>" + ProjectVariables.DB_DispositionReasonslist);
					
				
				
				break;

			

			default:

				Assert.assertTrue("Given selection was not found ==>" + popname, false);
				break;

			}

			
			
		}

		if (recordsCount == 0)
		{
			System.out.println(MatchFilter);
			System.out.println("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"+ clientkey + ",Release ==>" + release + ",Disposition ==>No Disposition");
			return false;
		} else {
			
			
			
			return true;
		}

	}

	public static void Get_the_policyreleasesummary_based_on_client_release_and_savingsstatus(String clientkey,
			String release,String savingstatus) {
		
		 ProjectVariables.RawSavings.clear();
		 ProjectVariables.AggSavings.clear();
		 ProjectVariables.ConSavings.clear();
		 ProjectVariables.Edits.clear();
		
		int i=0;
		Bson MatchFilter = new BsonDocument();
		List<String> DPKeyslist;
		List<String> TotalLinesRunList;
		Long TotalLinesRunSum=0l;
		String dpkeys=null;
		String Rawsavings=null;
		String Consavings=null;
		String Aggsavings=null;
		String TotalEdits=null;
		String TotalLinesRun=null;
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		
	if(savingstatus.equalsIgnoreCase("Production")){
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
				Filters.eq("ruleInBaseLine", -1l),
					Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)));
			
	}
	else if(savingstatus.equalsIgnoreCase("Opportunity")){
	
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
				Filters.eq("disposition.desc", "Present"),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("presentationProfile", null),Filters.eq("opptyFinalize", null),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)));
			
	}
	else if(savingstatus.equalsIgnoreCase("Total Edits"))
	{
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.ne("disposition.desc", "Prior Approval"),
				Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)));
			
	}
	else if(savingstatus.equalsIgnoreCase("Total Lines Run"))
	{
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(release)));
			
	}
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);

		if (recordsCount == 0) {
			System.out.println("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"
					+ clientkey + ",Release ==>" + release + ",Disposition ==>No Disposition");
			
		} 
		
		
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$clientDesc", Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),Accumulators.sum("Total Edits", "$annualSavings.lines"),Accumulators.addToSet("Total Lines Run", "$linesTotal"))));
		
		for (Document document : output2) {

			//System.out.println(document);
			
			 dpkeys=StringUtils.substringBetween(document.toString(), "DPkeys=[",", Raw savings");
			 Rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=",", Agg");
			 Consavings=StringUtils.substringBetween(document.toString(), "Con savings=",", Total Edits");
			 Aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=",", Con");
			 TotalEdits=StringUtils.substringBetween(document.toString(), "Total Edits=",", Total");
			 TotalLinesRun=StringUtils.substringBetween(document.toString(), "Total Lines Run=[","]}}");
			 
			 ProjectVariables.RawSavings.add(Long.valueOf(Rawsavings));
			 ProjectVariables.AggSavings.add(Long.valueOf(Aggsavings));
			 ProjectVariables.ConSavings.add(Long.valueOf(Consavings));
			 ProjectVariables.Edits.add(Long.valueOf(TotalEdits));
		}
		
		
		DPKeyslist=Arrays.asList(dpkeys.split(","));
		ProjectVariables.DB_DPKey=String.valueOf(DPKeyslist.size());
		
		if(savingstatus.equalsIgnoreCase("Opportunity"))
		{
			System.out.println("DPKeys size ==>"+DPKeyslist.size());
			System.out.println("Rawsavings ==>"+Rawsavings);
			System.out.println("Consavings ==>"+Consavings);
			System.out.println("Aggsavings ==>"+Aggsavings);
			
		}
		else if(savingstatus.equalsIgnoreCase("Production"))
		{
			System.out.println("Rawsavings ==>"+Rawsavings);
			System.out.println("Consavings ==>"+Consavings);
			System.out.println("Aggsavings ==>"+Aggsavings);
		}
		else if(savingstatus.equalsIgnoreCase("Total Edits"))
		{
			System.out.println("TotalEdits ==>"+TotalEdits);
		}
		else if(savingstatus.equalsIgnoreCase("Total Lines Run"))
		{
			System.out.println(TotalLinesRun);
			
			TotalLinesRunList=Arrays.asList(TotalLinesRun.split(","));
			
			for (int j = 0; j < TotalLinesRunList.size(); j++) {
				
				TotalLinesRunSum=TotalLinesRunSum+Long.valueOf(TotalLinesRunList.get(j).trim());
				
			}
			
			
			System.out.println("TotalLinesRun ==>"+TotalLinesRunSum);
		}

	}

	public static void Get_the_MedicalPolicySummary_based_on_client_release_and_savingsstatus(String medicalpolicy,String savingstatus,String pagename) {
		
		 ProjectVariables.RawSavings.clear();
		 ProjectVariables.ConSavings.clear();
		 ProjectVariables.AggSavings.clear();
		 
		
		int i=0;
		Bson MatchFilter = new BsonDocument();
		List<String> DPKeyslist;
		List<String> TotalLinesRunList;
		String dpkeys=null;
		String Rawsavings=null;
		String Consavings=null;
		String Aggsavings=null;
		String TotalEdits=null;
		ArrayList<String> DispositionList=new ArrayList<>();
		DispositionList.add("No Disposition");
		DispositionList.add("Prior Approval");
		/*DispositionList.add("Do Not Present - CPM Review");
		DispositionList.add("Present");
		DispositionList.add("Not Reviewed");
		DispositionList.add("Invalid");
		DispositionList.add("Do Not Present");
		DispositionList.add("Complete");*/
		
		//DispositionList.add("Complete");
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		switch(savingstatus)
		{
		case "Production":
			if(pagename.equalsIgnoreCase("AWB"))
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("ruleInBaseLine", -1l),Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
							Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
					
			}
			else
			{
				if(medicalpolicy.isEmpty())
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.eq("ruleInBaseLine", -1l),Filters.ne("disposition.desc", "No Disposition"),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
						
				}
				else
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.eq("ruleInBaseLine", -1l),Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),Filters.ne("disposition.desc", "No Disposition"),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
						
				}
					
			}
			
			
		break;
		
		case "Opportunity":
			if(pagename.equalsIgnoreCase("AWB"))
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey").toString())),
						Filters.eq("disposition.desc", "No Disposition"),Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),Filters.eq("ruleInBaseLine", 0),
							Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release").toString())));
				
				//Filters.ne("disposition.desc", "Prior Approval")
				
			}
			else
			{
				
				if(medicalpolicy.isEmpty())
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.nin("disposition.desc", DispositionList),Filters.eq("ruleInBaseLine", 0),Filters.ne("annualSavings.lines", 0),Filters.eq("presentationProfile", null),Filters.eq("opptyFinalize", null),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
					//Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval")Filters.eq("presentationProfile", null),Filters.eq("opptyFinalize", null),
					
				}
				else
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),Filters.eq("ruleInBaseLine", 0),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
					
				}
				
			}
			
			break;
		case "DPKEY":
			if(pagename.equalsIgnoreCase("AWB"))
			{
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),Filters.ne("annualSavings.lines", 0),
							Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
				//Filters.ne("annualSavings.lines", 0),,Filters.eq("ruleInBaseLine", 0),
			}
			else
			{
				if(medicalpolicy.isEmpty())
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.eq("ruleInBaseLine", -1l),Filters.ne("disposition.desc", "No Disposition"),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
						
				}
				else
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.eq("ruleInBaseLine", -1l),Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),Filters.ne("disposition.desc", "No Disposition"),
								Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
						
				}
					
			}
			
			
		break;
			
		
		
		default:
		Assert.assertTrue("given selection is not found ===>"+savingstatus, false);
			
		break;
		}
		
	
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);

		
		
		
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$_id.clientKey", Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),Accumulators.sum("Total Edits", "$annualSavings.lines"),Accumulators.addToSet("Total Lines Run", "$linesTotal"),Accumulators.addToSet("Dispositions", "$disposition.desc"))));
		
		
		
		
		for (Document document : output2) {

			System.out.println(document);
			
			 dpkeys=StringUtils.substringBetween(document.toString(), "DPkeys=[",", Raw savings");
			 Rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=",", Agg");
			 Consavings=StringUtils.substringBetween(document.toString(), "Con savings=",", Total Edits");
			 Aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=",", Con");
			 TotalEdits=StringUtils.substringBetween(document.toString(), "Total Edits=",", Total");
			
			 ProjectVariables.RawSavings.add(Long.valueOf(Rawsavings));
			 ProjectVariables.ConSavings.add(Long.valueOf(Consavings));
			 ProjectVariables.AggSavings.add(Long.valueOf(Aggsavings));
			 
			 //System.out.println("dpkeys ==>"+dpkeys);
		}
		
		if(pagename.equalsIgnoreCase("RWO"))
		{
			
		
			MatchFilter=Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.ne("presentationProfile", null),Filters.ne("opptyFinalize", null),
					Filters.eq("disposition.desc", "Defer"),Filters.eq("ruleInBaseLine", 0),Filters.ne("annualSavings.lines", 0),
							Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
			matchtext = Aggregates.match(Filters.and(MatchFilter));
			output2 = mColl.aggregate(Arrays.asList(matchtext,
					Aggregates.group("$_id.clientKey", Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
							Accumulators.sum("Agg savings", "$annualSavings.agg"),
							Accumulators.sum("Con savings", "$annualSavings.con"),Accumulators.sum("Total Edits", "$annualSavings.lines"),Accumulators.addToSet("Total Lines Run", "$linesTotal"),Accumulators.addToSet("Dispositions", "$disposition.desc"))));
			

			for (Document document : output2) {

				System.out.println(document);
				
				 dpkeys=StringUtils.substringBetween(document.toString(), "DPkeys=[",", Raw savings");
				 Rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=",", Agg");
				 Consavings=StringUtils.substringBetween(document.toString(), "Con savings=",", Total Edits");
				 Aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=",", Con");
				 TotalEdits=StringUtils.substringBetween(document.toString(), "Total Edits=",", Total");
				
				 Rawsavings=String.valueOf(Long.valueOf(Rawsavings)+ProjectVariables.RawSavings.get(0));
				 Consavings=String.valueOf(Long.valueOf(Consavings)+ProjectVariables.ConSavings.get(0));
				 Aggsavings=String.valueOf(Long.valueOf(Aggsavings)+ProjectVariables.AggSavings.get(0));
				 
				 //System.out.println("dpkeys ==>"+dpkeys);
			}
			
		}
		
		
		
		
		if (recordsCount == 0) {
			System.out.println("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"
					+ Serenity.sessionVariableCalled("clientkey") + ",Release ==>" + Serenity.sessionVariableCalled("release") + ",Disposition ==>No Disposition");
			
		} 
		else
		{
			DPKeyslist=Arrays.asList(dpkeys.split(","));
			System.out.println("Captured DPKeys size ==>"+DPKeyslist.size());
			System.out.println("Captured DPKeys ==>"+DPKeyslist);
			
			if(savingstatus.equalsIgnoreCase("Opportunity"))
			{
				ProjectVariables.RawSavings.clear();
				ProjectVariables.ConSavings.clear();
				ProjectVariables.AggSavings.clear();
				ProjectVariables.RawSavings.add(Long.valueOf(Rawsavings));
				ProjectVariables.ConSavings.add(Long.valueOf(Consavings));
				ProjectVariables.AggSavings.add(Long.valueOf(Aggsavings));
				System.out.println("Rawsavings ==>"+Rawsavings);
				System.out.println("Consavings ==>"+Consavings);
				System.out.println("Aggsavings ==>"+Aggsavings);
				System.out.println("TotalEdits ==>"+TotalEdits);
			}
			else if(savingstatus.equalsIgnoreCase("Production"))
			{
				
				System.out.println("Rawsavings ==>"+Rawsavings);
				
			}
			
		}
		
		

	}
		
	public static void Get_the_Savings_for_RWO_based_on(String medicapolicy,String topicname,String DPkey,List<String> Payershorts) {
		
		 ProjectVariables.RawSavings.clear();
		 ProjectVariables.ConSavings.clear();
		 ProjectVariables.AggSavings.clear();
		 
		
		
		Bson MatchFilter = new BsonDocument();
		
		String Rawsavings=null;
		String Consavings=null;
		String Aggsavings=null;
		String TotalEdits=null;
		
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		
				
		if(DPkey.isEmpty()&&Payershorts.isEmpty())
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("ruleInBaseLine", 0),Filters.eq("subRule.hierarchy.topicDesc", topicname),
						Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
			//Filters.eq("subRule.hierarchy.medPolicyDesc", medicapolicy),
		}
		else if(!DPkey.isEmpty()&&Payershorts.isEmpty())
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("ruleInBaseLine", 0),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPkey)),Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
			
		}
		else if(!DPkey.isEmpty()&&!Payershorts.isEmpty())
		{
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.in("_id.payerShort", Payershorts),
					Filters.ne("disposition.desc", "No Disposition"),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("ruleInBaseLine", 0),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPkey)),Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))));
			
		}
		
		
		
	
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record count ==>" + recordsCount);

		
		
		
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$_id.clientKey", Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),Accumulators.sum("Total Edits", "$annualSavings.lines"),Accumulators.addToSet("Total Lines Run", "$linesTotal"))));
		
		
		
		
		for (Document document : output2) {
			
			 Rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=",", Agg");
			 Consavings=StringUtils.substringBetween(document.toString(), "Con savings=",", Total Edits");
			 Aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=",", Con");
			 TotalEdits=StringUtils.substringBetween(document.toString(), "Total Edits=",", Total");
			
			 ProjectVariables.RawSavings.add(Long.valueOf(Rawsavings));
			 ProjectVariables.ConSavings.add(Long.valueOf(Consavings));
			 ProjectVariables.AggSavings.add(Long.valueOf(Aggsavings));
			 
			
		}
		
		if (recordsCount == 0) {
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>"
					+ Serenity.sessionVariableCalled("clientkey") + ",Release ==>" + Serenity.sessionVariableCalled("release") + ",Disposition ==>No Disposition",false);
			
		} 
		else
		{
			
				System.out.println("Rawsavings ==>"+Rawsavings);
				System.out.println("Consavings ==>"+Consavings);
				System.out.println("Aggsavings ==>"+Aggsavings);
				System.out.println("TotalEdits ==>"+TotalEdits);
			
			
		}
		
		

	}
	
    public static void Savings_summary_for_DPWB_based_on_insurance(String disposition,String insurance,String sRule,int sSavingStatus) {
        
        ProjectVariables.RawSavings.clear();
        ProjectVariables.AggSavings.clear();
        ProjectVariables.ConSavings.clear(); 
        ProjectVariables.Edits.clear();
        Bson sPayershortfilter = null;
        Bson MatchFilter = new BsonDocument();
        ArrayList<Long> SavingsStatusList=new ArrayList<>();
        
        if(sSavingStatus==-0)
        {
        	SavingsStatusList.add(0l);
        	SavingsStatusList.add(-1l);
        	System.out.println("added both savings statuses");
        }
        else
        {
        	SavingsStatusList.add(Long.valueOf(sSavingStatus));
        }
        
        
          //Method to connect mongoDB
          retrieveAllDocuments("cpd", "oppty");
          
          if(Serenity.sessionVariableCalled("sPayershort")!=null)
          {
        	sPayershortfilter=Filters.eq("payerShort", Serenity.sessionVariableCalled("sPayershort"));  
        	
        	 if(insurance.isEmpty() && sRule.isEmpty()){
                 MatchFilter = Filters.and(sPayershortfilter,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
                 //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
                 Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
                 Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
                 
        	 }
        	 else if(sRule.isEmpty() && !insurance.isEmpty()){
		                 MatchFilter = Filters.and(sPayershortfilter,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("insuranceDesc", insurance),
		                 //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
		                 Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
		                 Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
		
		     }
		    
                     
        	 else if(insurance.isEmpty() && !sRule.isEmpty()){
	                MatchFilter = Filters.and(sPayershortfilter,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.subRuleId", sRule),
	                //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
	                Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
	                Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
	              
	            }
	            
        	 else if(!insurance.isEmpty() && !sRule.isEmpty()){
	                MatchFilter = Filters.and(sPayershortfilter,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.subRuleId", sRule),
	               // Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
	                Filters.eq("insuranceDesc", insurance),
	                Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
	                Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));

	            }
        	 else if(!sRule.isEmpty()){
	                 MatchFilter = Filters.and(sPayershortfilter,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.subRuleId", sRule),
	                 //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
	                 Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
	                 Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
	     }
          }
          else
          {
        	  if(insurance.isEmpty() && sRule.isEmpty()){
                  MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
                  //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
                  Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
                  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));

        	  }
      
            if(sRule.isEmpty() && !insurance.isEmpty()){
		                  MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("insuranceDesc", insurance),
		                  //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
		                  Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
		                  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
		
		      }
           
            
		      if(!sRule.isEmpty()){
		                  MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.subRuleId", sRule),Filters.eq("opptyFinalize", null),Filters.eq("presentationProfile.profileName", null),
		                  //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
		                  Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.in("ruleInBaseLine", SavingsStatusList),
		                  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));
		      }
                      
          }
                                                          
          
       
          

         
         

          recordsCount = mColl.count(MatchFilter);

          System.out.println("Filtered_Count:" + recordsCount);

         /* if (recordsCount == 0) {
                          Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,disposition ==>"+disposition+",insurance ==>"+insurance+",Rule==>"+sRule, false);
          }*/

          Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

          AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
                                          Aggregates.group("$clientDesc", Accumulators.addToSet("DPDesc", "$subRule.hierarchy.dpDesc"),Accumulators.sum("Raw savings", "$annualSavings.raw"),
                                                                          Accumulators.sum("Agg savings", "$annualSavings.agg"),
                                                                          Accumulators.sum("Con savings", "$annualSavings.con"),
                                                                          Accumulators.sum("Edits", "$annualSavings.lines"),Accumulators.addToSet("PriorDisposition", "$disposition.priorDisposition"),Accumulators.addToSet("CurrentDisposition", "$disposition.desc"),Accumulators.addToSet("LatestClientDecision", "$latestClientDecision.cdmDecision"))));

          int i = 0;

          for (Document document : output2) {

                          System.out.println(document);
                          
                          i = i + 1;
                          ProjectVariables.DB_DPDesc=StringUtils.substringBetween(document.toString(), "DPDesc=[", "], Raw");
                          ProjectVariables.DB_CDMDecision=StringUtils.substringBetween(document.toString(), "LatestClientDecision=[", "]}");
                          ProjectVariables.Disposition=StringUtils.substringBetween(document.toString(), "CurrentDisposition=[", "], Latest");
                          ProjectVariables.DB_Priordisposition=StringUtils.substringBetween(document.toString(), "PriorDisposition=[", "], Current");
                          
                          ProjectVariables.RawSavings
                                                          .add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=", ",")));
                          ProjectVariables.AggSavings
                                                          .add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=", ",")));
                          ProjectVariables.ConSavings
                                                          .add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=", ",")));
                          ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=", ", PriorDisposition")));

          }

          if(ProjectVariables.RawSavings.isEmpty()){
                      ProjectVariables.RawSavings.add(Long.valueOf("0"));
          }
          if(ProjectVariables.AggSavings.isEmpty()){
                      ProjectVariables.AggSavings.add(Long.valueOf("0"));
          }
          if(ProjectVariables.ConSavings.isEmpty()){
                      ProjectVariables.ConSavings.add(Long.valueOf("0"));
          }
          if(ProjectVariables.Edits.isEmpty()){
                      ProjectVariables.Edits.add(Long.valueOf("0"));
          }
          System.out.println(MatchFilter);
          System.out.println("DPDesc ==>" + ProjectVariables.DB_DPDesc);
          System.out.println("DBRawSavings ==>" + ProjectVariables.RawSavings);
          System.out.println("DBAggSavings ==>" + ProjectVariables.AggSavings);
          System.out.println("DBConSavings ==>" + ProjectVariables.ConSavings);
          System.out.println("DBEdits ==>" + ProjectVariables.Edits);
          System.out.println("DB_CDMDecision ==>" + ProjectVariables.DB_CDMDecision);
          System.out.println("Disposition ==>" + ProjectVariables.Disposition);
          System.out.println("DB_Priordisposition ==>" + ProjectVariables.DB_Priordisposition);

}

    public static void RuleDatainDPWBWorkbench(String disposition,String sRule,int sSavingStatus) 
    {

    	//Method to connect mongoDB
        retrieveAllDocuments("cpd", "oppty");

        Bson MatchFilter = new BsonDocument();
        
      MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.subRuleId", sRule),
			       //Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
			        Filters.eq("disposition.desc", disposition),Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("ruleInBaseLine", sSavingStatus),
			        Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("dpkey"))));

         recordsCount = mColl.count(MatchFilter);
        System.out.println("Filtered_Count:" + recordsCount);
        Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

        AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
                                        Aggregates.group("$clientDesc", Accumulators.addToSet("RuleDesc", "$subRule.desc"),Accumulators.addToSet("Subrulenotes", "$subRule.notes"),Accumulators.addToSet("coreEnhancedDesc", "$subRule.coreEnhancedDesc"),Accumulators.addToSet("primaryrefsource", "$subRule.refSource.desc"),Accumulators.addToSet("referencedetails", "$subRule.refTitle.desc"),Accumulators.addToSet("Claimtypes", "$_id.claimType"))));

        int i = 0;

        for (Document document : output2) 
        {
        	i = i + 1;
            ProjectVariables.DB_RuleDesc=StringUtils.substringBetween(document.toString(), "RuleDesc=[", "], Subrulenotes");
            ProjectVariables.DB_Subrulenotes=StringUtils.substringBetween(document.toString(), "Subrulenotes=[", "], coreEnhancedDesc");
            ProjectVariables.DB_CoreenhancedDesc=StringUtils.substringBetween(document.toString(), "coreEnhancedDesc=[", "], primaryrefsource");
            ProjectVariables.DB_PrimaryRefsource=StringUtils.substringBetween(document.toString(), "primaryrefsource=[", "], referencedetails");
            ProjectVariables.DB_refdetails=StringUtils.substringBetween(document.toString(), "referencedetails=[", "], Claimtypes");
            ProjectVariables.DB_Claimtypes=StringUtils.substringBetween(document.toString(), "Claimtypes=[", "}");
        }

       

        System.out.println("DB_RuleDesc ==>" + ProjectVariables.DB_RuleDesc);
        System.out.println("DB_Subrulenotes ==>" + ProjectVariables.DB_Subrulenotes);
        System.out.println("DB_CoreenhancedDesc ==>" + ProjectVariables.DB_CoreenhancedDesc);
        System.out.println("DB_PrimaryRefsource ==>" + ProjectVariables.DB_PrimaryRefsource);
        System.out.println("DB_refdetails ==>" + ProjectVariables.DB_refdetails);
    
    }
    
    public static boolean GettheSubsequentDPKeyFromtheGiven(Long Clientkey) 
    {
    	boolean bstatus=false;
    	String DPKey=null;
    	String Medicalpolicy=null;
    	String Topic=null;
    	String Release=null;
    	String Clientname=null;
    	String Disposition=null;
    	//Method to connect mongoDB
        retrieveAllDocuments("cpd", "oppty");

        Bson MatchFilter = new BsonDocument();
        
        //Filter to form a match query based on inputs
        MatchFilter = Filters.and(Filters.eq("_id.clientKey",Clientkey),Filters.eq("disposition.desc", "No Disposition"),
			       Filters.ne("disposition.desc", "Prior Approval"),Filters.eq("ruleInBaseLine", 0));
        //Filters.eq("ruleInBaseLine", 0),Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))), Filters.eq("disposition.desc", "No Disposition")
        recordsCount = mColl.count(MatchFilter);
        System.out.println("Filtered_Count:" + recordsCount);
        
        
        Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

        //Aggregate filter to retrieve the output
        AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(matchtext,
                                        Aggregates.group("$subRule.hierarchy.dpKey", Accumulators.addToSet("Release", "$_id.dataVersion"),Accumulators.addToSet("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc"),Accumulators.addToSet("Topic", "$subRule.hierarchy.topicDesc"),Accumulators.addToSet("Clientname", "$clientDesc"),Accumulators.addToSet("Disposition", "$disposition.desc"))));

        int i = 0;

        //Loop to retrieve the output 
        for (Document document : output2) 
        {
        	i = i + 1;
        	//System.out.println(document);
        	DPKey=StringUtils.substringBetween(document.toString(), "_id=", ", Release");
        	Release=StringUtils.substringBetween(document.toString(), "Release=[", "], Medicalpolicy");
        	Medicalpolicy=StringUtils.substringBetween(document.toString(), "Medicalpolicy=[", "], Topic");
        	Topic=StringUtils.substringBetween(document.toString(), "Topic=[", "], Clientname");
        	Clientname=StringUtils.substringBetween(document.toString(), "Clientname=[", "Disposition");
        	Disposition=StringUtils.substringBetween(document.toString(), "Disposition=[", "]}}");
        	if(Release.contains(","))
        	{
        		System.out.println("Clientname ==>" + Clientname);
        		   System.out.println("DPKey ==>" + DPKey);
        	        System.out.println("Release ==>" + Release);
        	        System.out.println("Medicalpolicy ==>" + Medicalpolicy);
        	        System.out.println("Topic ==>" + Topic);
        	        System.out.println("Disposition ==>" + Disposition);
        	        bstatus=true;
        	        break;
        	}
        }
        
        return bstatus;
        
      }
    
    public static ArrayList<String> GettheDistinctDBResultsFromtheGiven(String Requiredcriteria,String Username,ArrayList<Long> Clientkeylist) 
    {
    	Bson MatchFilter = new BsonDocument();
    	AggregateIterable<Document> output=null;
    	ArrayList<String> Outputlist=new ArrayList<>();
    		
    	//Method to connect mongoDB
        retrieveAllDocuments("cpd", "oppty");

        //Filter to form a match query based on inputs
        MatchFilter = Filters.and(Filters.eq("disposition.desc", "Present"),Filters.eq("ruleInBaseLine", 0),Filters.ne("annualSavings.lines", 0),Filters.in("_id.clientKey", Clientkeylist));
        //,Filters.in("_id.clientKey", Clientkeylist),Filters.eq("disposition.userId", Username)
        System.out.println(MatchFilter);
        
        recordsCount = mColl.count(MatchFilter);
        System.out.println("Filtered_Count:" + recordsCount);
        
        Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
        
        switch(Requiredcriteria)
        {
        case "ClientKeys":
        	 //Aggregate filter to retrieve the output
            output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$_id.clientKey", Accumulators.addToSet("Clientname", "$clientDesc"))));
        break;
        case "Payerkeys":
       	 //Aggregate filter to retrieve the output
           output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$_id.clientKey", Accumulators.addToSet("Payerkeys", "$_id.payerKey"))));
       break;
        case "Topickeys":
          	 //Aggregate filter to retrieve the output
              output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$_id.clientKey", Accumulators.addToSet("Topickeys", "$subRule.hierarchy.topicKey"))));
        break;
        
        default:
        Assert.assertTrue("Case not found ===>"+Requiredcriteria, false);	
        break;
        	
        
        }

       
        //Loop to retrieve the output 
        for (Document document : output) 
        {
        	Outputlist.add(String.valueOf(document));
        }
      
        System.out.println(Outputlist);
        
        return Outputlist;
        
    }
    
	public static int GettheCapturedDispositionPayerLOBsFromtheGiven(String medicalpolicyname,String disposition,String dpkey) 
    {
		ProjectVariables.CapturedPayershortList.clear();
		ProjectVariables.CapturedInsuranceList.clear();
		String Insurance = null;
		String Payershort = null;
		String PayerKey = null;
		String claimtype=null;
		List<String> payers = null;

		// Method to connect mongoDB
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();

		// Filter to form a match query based on inputs
		MatchFilter = Filters.and(
				Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				// Filters.eq("_id.dataVersion",
				// java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),
				Filters.eq("disposition.desc", disposition),
				Filters.eq("disposition.userId", Serenity.sessionVariableCalled("user")),
				Filters.eq("presentationProfile", null), Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
				Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname),
				// ProjectVariables.Payerorquery,
				// ProjectVariables.Insuranceorquery,ProjectVariables.Claimtypeorquery,
				Filters.eq("ruleInBaseLine", 0));

		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered_Count:" + recordsCount);

		if (recordsCount == 0) {
			Assert.assertTrue("Record count was zero for the given Dpkey==>" + dpkey + ",Medicalpolicy==>"
					+ medicalpolicyname + ",Matchfilter===>" + MatchFilter, false);
		}

		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		// Aggregate filter to retrieve the output
		AggregateIterable<Document> output = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group(new Document().append("insurance", "$insuranceDesc").append("payershort",
						"$_id.payerShort").append("claimtype", "$_id.claimType")
						, Accumulators.addToSet("payerKey", "$_id.payerKey"),
						Accumulators.addToSet("payershort", "$_id.payerShort"),
						Accumulators.addToSet("claimtype", "$_id.claimType"))));
		
		int i = 0;

		// Loop to retrieve the output
		for (Document document : output) {

			// System.out.println(document);
			Insurance = StringUtils.substringBetween(document.toString(), "insurance=", ", payershort");
			PayerKey = StringUtils.substringBetween(document.toString(), "payerKey=[", "], payershort");
			Payershort = StringUtils.substringBetween(document.toString(), "payershort=[", "], claimtype");
			claimtype= StringUtils.substringBetween(document.toString(), "claimtype=[", "]}}");
			System.out.println(Payershort+"-"+Insurance+"-"+claimtype+"-"+PayerKey);
			payers = Arrays.asList(Payershort.split(","));
			ProjectVariables.CapturedInsuranceList.add(Payershort+"-"+Insurance+"-"+claimtype+"-"+PayerKey);
			ProjectVariables.CapturedPayershortList.addAll(payers);
			ProjectVariables.CapturedPayerLOBList.add(Insurance+"-" +Payershort);
			i = payers.size() + i;

		}
		System.out.println(ProjectVariables.CapturedInsuranceList);
		System.out.println(ProjectVariables.CapturedInsuranceList.size());
		System.out.println(ProjectVariables.CapturedInsuranceList.get(0));
		System.out.println(ProjectVariables.CapturedPayerLOBList);
		return i;

	}
    
	public static List<List<String>> retrieve_all_DocumentsFromDB(String dbName, String collectionName, String clientkey, String release) {
		List<List<String>> queryResults = new ArrayList<List<String>>();
		AggregateIterable<Document> output=null;
		ProjectVariables.Opportunity_oracle_collection_data.clear();
		
		
		if (dbName.equals("rva_data")) {
			ConnectTogivenDBandCollection("rva_data", "rva_unified");
		} else if (dbName.equals("cpd")) {
			ConnectTogivenDBandCollection("cpd", "oppty");
		} else {
			//connectWithCredentials();
		}

		switch (collectionName) {
		case "opportunity":
			queryResults.clear();
			try {

				Bson clientMatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0), Filters.eq("_id.dataVersion",java.util.regex.Pattern.compile(release)));

				FindIterable<Document> results_test;
				

				results_test = mColl.find(clientMatchFilter);
				recordsCount = mColl.count(clientMatchFilter);
				
				
				ProjectVariables.results=mColl.find(clientMatchFilter);
				System.out.println("Record count from Opportunity Collection ===>"+recordsCount);
				
				Serenity.setSessionVariable("Opportunity_count").to(recordsCount);
				
				Serenity.setSessionVariable("Clientkey").to(clientkey);
				Serenity.setSessionVariable("Release").to(release);
				
				
				for (Document outptDoc : results_test) {
					
					System.out.println("Outputdocumment ====>"+outptDoc);
					
					String Opp_Savings_Documment=StringUtils.substringBetween(String.valueOf(outptDoc), "annualSavings=Document{{","}}, subRule");
					
					String opp_clientKey=StringUtils.substringBetween(String.valueOf(outptDoc), "clientKey=",", payerKey");
					String opp_payerKey=StringUtils.substringBetween(String.valueOf(outptDoc), "payerKey=",", insuranceKey");
					String opp_insurancekey=StringUtils.substringBetween(String.valueOf(outptDoc), "insuranceKey=",", claimType");
					String opp_claimtype=StringUtils.substringBetween(String.valueOf(outptDoc), "claimType=",", subRuleKey");
					String opp_dataVersion=StringUtils.substringBetween(String.valueOf(outptDoc), "dataVersion=",", subRuleId");
					String opp_midrule=StringUtils.substringBetween(String.valueOf(outptDoc), "midRuleKey=","}}, refSource");
					String opp_dpkey=StringUtils.substringBetween(String.valueOf(outptDoc), "dpKey=",", dpDesc");
					String opp_subrule=StringUtils.substringBetween(String.valueOf(outptDoc), "subRuleKey=",", dataVersion");
					
					String opp_edits=StringUtils.substringBetween(String.valueOf(Opp_Savings_Documment), "lines=",", paid");
					String opp_rawsavings=StringUtils.substringBetween(String.valueOf(Opp_Savings_Documment), "raw=",", agg");
					String opp_aggsavings=StringUtils.substringBetween(String.valueOf(Opp_Savings_Documment), "agg=",", con");
					String opp_consavings=StringUtils.substringAfter(String.valueOf(Opp_Savings_Documment), "con=");
					
					String oppdoc=opp_clientKey+";"+opp_payerKey+";"+opp_insurancekey+";"+opp_claimtype+";"+opp_dataVersion+";"+opp_midrule+";"+opp_dpkey+";"+opp_subrule+";"+opp_edits+";"+opp_rawsavings+";"+opp_aggsavings+";"+opp_consavings;
					
					
					ProjectVariables.Opportunity_collection_data.add(oppdoc);
					
					
					
					
				}
				results=null;
				
				
			} catch (Exception e) {
				System.out.println("Exception: " + e);
			}
			break;
		case "opportunity-oracle":
			queryResults.clear();
			//try {
				List<String> DispositionResults = new ArrayList<String>();
				

				//Bson clientMatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.ne("disposition.desc", "Prior Approval"),Filters.ne("annualSavings.lines", 0), Filters.eq("_id.dataVersion",java.util.regex.Pattern.compile(release)));
				Bson clientMatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)), Filters.eq("_id.dataVersion",java.util.regex.Pattern.compile(release)));
				FindIterable<Document> results_test;
				

				results_test = mColl.find(clientMatchFilter);
				recordsCount = mColl.count(clientMatchFilter);
				
				
				ProjectVariables.results=mColl.find(clientMatchFilter);
				System.out.println("Record count from Opportunity Collection for the clientkey '"+clientkey+"', release '"+release+"' ===>"+recordsCount);
				
				Serenity.setSessionVariable("Opportunity_count").to(recordsCount);
				
				Serenity.setSessionVariable("Clientkey").to(clientkey);
				Serenity.setSessionVariable("Release").to(release);
				Bson matchtext = Aggregates.match(Filters.and(clientMatchFilter));

				output = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group(new Document().append("rvaKey", "$rvaKey").
								append("payerKey","$_id.payerKey").
								append("linesTotal", "$linesTotal").
								append("subRuleKey", "$_id.subRuleKey").
								append("midRuleKey", "$subRule.hierarchy.midRuleKey").
								append("medPolicyKey", "$subRule.hierarchy.medPolicyKey").
								append("topicKey", "$subRule.hierarchy.topicKey").
								append("dpKey", "$subRule.hierarchy.dpKey").
								append("claimType", "$_id.claimType").
								append("insuranceKey", "$_id.insuranceKey").
								append("insuranceDesc", "$insuranceDesc").
								append("rawpaid", "$rawSavings.paid").
								append("rawraw", "$rawSavings.raw").
								append("rawagg", "$rawSavings.agg").
								append("rawcon", "$rawSavings.con").
								append("rawedits", "$rawSavings.lines").
								append("opppaid", "$annualSavings.paid").
								append("oppraw", "$annualSavings.raw").
								append("oppagg", "$annualSavings.agg").
								append("oppcon", "$annualSavings.con").
								append("oppedits", "$annualSavings.lines").
								append("dataVersion", "$_id.dataVersion").
								append("ruleInBaseLine", "$ruleInBaseLine").
								append("subRule", "$_id.subRuleId"),
								Accumulators.addToSet("clientname", "$clientDesc")
								))).allowDiskUse(true);
				int i=0;
				
				int j=0;
				
				for (Document outptDoc : output) {
					//System.out.println(outptDoc);
					
					
					String opp_rvaKey=StringUtils.substringBetween(String.valueOf(outptDoc), "rvaKey=",", payerKey");
					String opp_clientKey=Serenity.sessionVariableCalled("clientkey");
					String opp_payerKey=StringUtils.substringBetween(String.valueOf(outptDoc), "payerKey=",", linesTotal");
					String opp_linestotal=StringUtils.substringBetween(String.valueOf(outptDoc), "linesTotal=",", subRuleKey");
					String opp_subrulekey=StringUtils.substringBetween(String.valueOf(outptDoc), "subRuleKey=",", midRuleKey");
					String opp_midrule=StringUtils.substringBetween(String.valueOf(outptDoc), "midRuleKey=",", medPolicyKey");
					String opp_midruleversion=StringUtils.substringAfter(StringUtils.substringBetween(String.valueOf(outptDoc), "subRule=","}}, clientname"),".");
					String opp_medicalpolicykey=StringUtils.substringBetween(String.valueOf(outptDoc), "medPolicyKey=",", topicKey");
					String opp_topickey=StringUtils.substringBetween(String.valueOf(outptDoc), "topicKey=",", dpKey");
					String opp_dpkey=StringUtils.substringBetween(String.valueOf(outptDoc), "dpKey=",", claimType");
					String opp_claimtype=StringUtils.substringBetween(String.valueOf(outptDoc), "claimType=",", insuranceKey");
					String opp_insurancekey=StringUtils.substringBetween(String.valueOf(outptDoc), "insuranceKey=",", insuranceDesc");
					String opp_insurancedesc=StringUtils.substringBetween(String.valueOf(outptDoc), "insuranceDesc=",", rawpaid");
					
					String opp_rawpaid=StringUtils.substringBetween(String.valueOf(outptDoc), "rawpaid=",", rawraw");
					String opp_rawrawsavings=StringUtils.substringBetween(String.valueOf(outptDoc), "rawraw=",", rawagg");
					String opp_rawaggsavings=StringUtils.substringBetween(String.valueOf(outptDoc), "rawagg=",", rawcon");
					String opp_rawconsavings=StringUtils.substringBetween(String.valueOf(outptDoc), "rawcon=",", rawedits");
					String opp_rawedits=StringUtils.substringBetween(String.valueOf(outptDoc), "rawedits=",", opppaid");
					
					
					String opp_paid=StringUtils.substringBetween(String.valueOf(outptDoc), "opppaid=",", oppraw");
					String opp_rawsavings=StringUtils.substringBetween(String.valueOf(outptDoc), "oppraw=",", oppagg");
					String opp_aggsavings=StringUtils.substringBetween(String.valueOf(outptDoc), "oppagg=",", oppcon");
					String opp_consavings=StringUtils.substringBetween(String.valueOf(outptDoc), "oppcon=",", oppedits");
					String opp_edits=StringUtils.substringBetween(String.valueOf(outptDoc), "oppedits=",", dataVersion");
					
					String opp_dataVersion=StringUtils.substringBetween(String.valueOf(outptDoc), "dataVersion=",", ruleInBaseLine");
					
					String opp_ruleinbaseline=StringUtils.substringBetween(String.valueOf(outptDoc), "ruleInBaseLine=",", subRule");
					
					
					
					j=j+1;
					
					//String oppdoc=opp_rvaKey+";"+opp_clientKey+";"+opp_payerKey+";"+opp_linestotal+";"+opp_subrulekey+";"+opp_midrule+";"+opp_midruleversion+";"+opp_medicalpolicykey+";"+opp_topickey+";"+opp_dpkey+";"+opp_claimtype+";"+opp_insurancekey+";"+opp_insurancedesc+";"+opp_rawpaid+";"+opp_rawrawsavings+";"+opp_rawaggsavings+";"+opp_rawconsavings+";"+opp_rawedits+";"+opp_paid+";"+opp_rawsavings+";"+opp_aggsavings+";"+opp_consavings+";"+opp_edits+";"+opp_dataVersion+";"+opp_ruleinbaseline;
					
					
					List<String> row = new ArrayList<>(25);
					
					/*if(opp_rvaKey.contains("rvaRunTimestamp"))
					{
						//System.out.println("Documment===>"+outptDoc);
						
						opp_rvaKey=StringUtils.substringBefore(opp_rvaKey, ", rvaRunTimestamp");
						opp_ruleinbaseline=StringUtils.substringBetween(String.valueOf(outptDoc), "ruleInBaseLine=",", _class");
						
						
						
					}
					
					if(opp_insurancedesc==null)
					{
						opp_insurancedesc=StringUtils.substringBetween(String.valueOf(outptDoc), "insuranceDesc=",", linesTotal");
					}
					
					if(opp_insurancedesc.contains("cdmDecisions"))
					{
						//System.out.println("Documment===>"+outptDoc);
						
						opp_insurancedesc=StringUtils.substringBefore(opp_insurancedesc, ", cdmDecisions");
						
					}
					
					if(opp_ruleinbaseline.contains("presentationProfiles"))
					{
						//System.out.println("Documment===>"+outptDoc);
						
						opp_ruleinbaseline=StringUtils.substringBetween(String.valueOf(outptDoc), "ruleInBaseLine=",", presentationProfiles");
						
					}*/
					
					
					
					//Check_the_savings_with_decimal_value_or_not(opp_rawrawsavings)
				
					
					
					
					row.add(opp_rvaKey);
					row.add(opp_clientKey);
					row.add(opp_payerKey);
					row.add(opp_linestotal);
					row.add(opp_subrulekey);
					row.add(opp_midrule);
					row.add(opp_midruleversion);
					row.add(opp_medicalpolicykey);
					row.add(opp_topickey);
					row.add(opp_dpkey);
					row.add(opp_claimtype);
					row.add(opp_insurancekey);
					row.add(opp_insurancedesc);
					row.add(opp_rawpaid);
					row.add(opp_rawrawsavings);
					row.add(opp_rawaggsavings);
					row.add(opp_rawconsavings);
					row.add(opp_rawedits);
					row.add(opp_paid);
					row.add(opp_rawsavings);
					row.add(opp_aggsavings);
					row.add(opp_consavings);
					row.add(opp_edits);
					row.add(opp_dataVersion);
					row.add(opp_ruleinbaseline);
				
					ProjectVariables.Opportunity_oracle_collection_data.add(row);
					
					
				}
				//results=null;
				System.out.println(" documment size===>"+j);
				
				if(ProjectVariables.Opportunity_oracle_collection_data.size()==0)
				{
					Assert.assertTrue("Record count was 'zero' in the opportunity collection for the clientkey ===>"+clientkey+", Release ===>"+release, false);

				}
				
				
				
		//	} catch (Exception e) {
			//	System.out.println("Exception: " + e);
			//}
			break;
		case "rva_unified":
			queryResults.clear();
			try {
				

				
				Bson clientMatch = Filters.and(Filters.eq("value.clientId", Long.valueOf(clientkey)), Filters.eq("value.dataVersion", java.util.regex.Pattern.compile(release)));

				FindIterable<Document> result;
				

				result = mColl.find(clientMatch);
				recordsCount = mColl.count(clientMatch);
				
				System.out.println("Record count from rva_unified Collection ===>"+recordsCount);
				
				Serenity.setSessionVariable("rva_unified_count").to(recordsCount);
				
				
				
				//int i=1;
				for (Document outptDoc : result) {
					
					
					String rvaunified_Savings_Documment=StringUtils.substringBetween(String.valueOf(outptDoc), "annualSavings=Document{{","}}, hierarchy");
					
					
					String rvaunified_clientKey=StringUtils.substringBetween(String.valueOf(outptDoc), "clientId=",", clientName");
					
					String rvaunified_payerKey=StringUtils.substringBetween(String.valueOf(outptDoc), "payerId=",", payerShort");
					String rvaunified_insurancekey=StringUtils.substringBetween(String.valueOf(outptDoc), "lobRaw=","}}, start");
					String rvaunified_claimtype=StringUtils.substringBetween(String.valueOf(outptDoc), "claimTypeRaw=",", lobRaw");
					String rvaunified_dataVersion=StringUtils.substringBetween(String.valueOf(outptDoc), "dataVersion=","}}, end");
					String rvaunified_midrule=StringUtils.substringBetween(String.valueOf(outptDoc), "midRule=",", midRuleVersion");
					String rvaunified_dpkey=StringUtils.substringBetween(String.valueOf(outptDoc), "decisionPoint=",", decisionPointDesc");
					String rvaunified_subrule=StringUtils.substringBetween(String.valueOf(outptDoc), "subRule=",", claimTypeRaw");
					
					
					String rvaunified_edits=StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "lines=",", paid");
					String rvaunified_rawsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "raw=",", agg"),".");
					String rvaunified_aggsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "agg=",", con"),".");
					String rvaunified_consavings=StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "con=",".");
					
					String rva_unifieddoc=rvaunified_clientKey+";"+rvaunified_payerKey+";"+rvaunified_insurancekey+";"+rvaunified_claimtype+";"+rvaunified_dataVersion+";"+rvaunified_midrule+";"+rvaunified_dpkey+";"+rvaunified_subrule+";"+rvaunified_edits+";"+rvaunified_rawsavings+";"+rvaunified_aggsavings+";"+rvaunified_consavings;
					
					ProjectVariables.rva_unified_collection_data.add(rva_unifieddoc);
					
					
				}

				//System.out.println("Record count from rva_unified Collection ===>"+i);
				
			} catch (Exception e) {
				System.out.println("Exception: " + e);
			}
			break;
		case "rva_unified-oracle":
			queryResults.clear();
			try {
				

				
				Bson clientMatch = Filters.and(Filters.eq("value.clientId", Long.valueOf(clientkey)), Filters.eq("value.dataVersion", java.util.regex.Pattern.compile(release)));

				FindIterable<Document> result;
				

				result = mColl.find(clientMatch);
				recordsCount = mColl.count(clientMatch);
				
				System.out.println("Record count from rva_unified Collection ===>"+recordsCount);
				
				Serenity.setSessionVariable("rva_unified_count").to(recordsCount);
				
				
				
				//int i=1;
				for (Document outptDoc : result) {
					
					//System.out.println(outptDoc);
					
					String rvaunified_Savings_Documment=StringUtils.substringBetween(String.valueOf(outptDoc), "annualSavings=Document{{","}}, hierarchy");
				
					String rvaunified_RawSavings_Documment=StringUtils.substringBetween(String.valueOf(outptDoc), "rawSavings=Document{{","}}, annualSavings");
					
					String rvaunified_clientKey=StringUtils.substringBetween(String.valueOf(outptDoc), "clientId=",", clientName");
					
					String rvaunified_payerKey=StringUtils.substringBetween(String.valueOf(outptDoc), "payerId=",", payerShort");
					String rvaunified_insurancekey=StringUtils.substringBetween(String.valueOf(outptDoc), "lobRaw=","}}, start");
					String rvaunified_claimtype=StringUtils.substringBetween(String.valueOf(outptDoc), "claimTypeRaw=",", lobRaw");
					String rvaunified_dataVersion=StringUtils.substringBetween(String.valueOf(outptDoc), "dataVersion=","}}, end");
					String rvaunified_linestotal=StringUtils.substringBetween(String.valueOf(outptDoc), "lineTotals=Document{{productTotal=","}}, dataVersion");
					String rvaunified_midrule=StringUtils.substringBetween(String.valueOf(outptDoc), "midRule=",", midRuleVersion");
					String rvaunified_midruleversion=StringUtils.substringBetween(String.valueOf(outptDoc), "midRuleVersion=",", midRuleDesc");
					String rvaunified_dpkey=StringUtils.substringBetween(String.valueOf(outptDoc), "decisionPoint=",", decisionPointDesc");
					String rvaunified_medicalpolicykey=StringUtils.substringBetween(String.valueOf(outptDoc), "medicalPolicy=",", medicalPolicyTitle");
					String rvaunified_topickey=StringUtils.substringBetween(String.valueOf(outptDoc), "topic=",", topicDesc");
					String rvaunified_subrule=StringUtils.substringBetween(String.valueOf(outptDoc), "subRule=",", claimTypeRaw");
					String rvaunified_rvakey=StringUtils.substringBetween(String.valueOf(outptDoc), "rvaKey=",", subRule");
					
					String rvaunified_RawPaid=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_RawSavings_Documment), "paid=",", raw"),".");
					String rvaunified_Rawedits=StringUtils.substringBetween(String.valueOf(rvaunified_RawSavings_Documment), "lines=",", paid");
					String rvaunified_Rawrawsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_RawSavings_Documment), "raw=",", agg"),".");
					String rvaunified_Rawaggsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_RawSavings_Documment), "agg=",", con"),".");
					String rvaunified_Rawconsavings=StringUtils.substringBetween(String.valueOf(rvaunified_RawSavings_Documment), "con=",".");
					
					
					String rvaunified_Paid=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "paid=",", raw"),".");
					String rvaunified_edits=StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "lines=",", paid");
					String rvaunified_rawsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "raw=",", agg"),".");
					String rvaunified_aggsavings=StringUtils.substringBefore(StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "agg=",", con"),".");
					String rvaunified_consavings=StringUtils.substringBetween(String.valueOf(rvaunified_Savings_Documment), "con=",".");
					
					//String rva_unifieddoc=rvaunified_clientKey+";"+rvaunified_payerKey+";"+rvaunified_insurancekey+";"+rvaunified_claimtype+";"+rvaunified_dataVersion+";"+rvaunified_midrule+";"+rvaunified_dpkey+";"+rvaunified_subrule+";"+rvaunified_edits+";"+rvaunified_rawsavings+";"+rvaunified_aggsavings+";"+rvaunified_consavings;
					
					//String rva_unifieddoc=rvaunified_clientKey+";"+rvaunified_payerKey+";"+rvaunified_edits+";"+rvaunified_subrule+";"+rvaunified_midrule+";"+rvaunified_midruleversion+";"+rvaunified_medicalpolicykey+";"+rvaunified_topickey+";"+rvaunified_dpkey+";"+rvaunified_claimtype+";"+rvaunified_insurancekey+";"+rvaunified_RawPaid+";"+rvaunified_Rawrawsavings+";"+rvaunified_Rawaggsavings+";"+rvaunified_Rawconsavings+";"+rvaunified_Rawedits+";"
					
					//ProjectVariables.rva_unified_collection_data.add(rva_unifieddoc);
					///////////////////
					
					List<String> row = new ArrayList<>();
					
					row.add(rvaunified_rvakey);
					row.add(rvaunified_clientKey);
					row.add(rvaunified_payerKey);
					//row.add(rvaunified_linestotal);
					row.add(rvaunified_subrule);
					row.add(rvaunified_midrule);
					row.add(rvaunified_midruleversion);
					row.add(rvaunified_medicalpolicykey);
					row.add(rvaunified_topickey);
					row.add(rvaunified_dpkey);
					row.add(rvaunified_claimtype);
					row.add(rvaunified_insurancekey);
					row.add(rvaunified_RawPaid);
					
					row.add(rvaunified_Rawrawsavings);
					row.add(rvaunified_Rawaggsavings);
					row.add(rvaunified_Rawconsavings);
					row.add(rvaunified_Rawedits);
					row.add(rvaunified_Paid);
					
					row.add(rvaunified_rawsavings);
					row.add(rvaunified_aggsavings);
					row.add(rvaunified_consavings);
					row.add(rvaunified_edits);
					row.add(rvaunified_dataVersion);
					//row.add(opp_ruleinbaseline);
				
					
					//if(opp_payerKey.equalsIgnoreCase("1095")&&opp_dpkey.equalsIgnoreCase("9763")&&opp_subrulekey.equalsIgnoreCase("66949")&&opp_claimtype.equalsIgnoreCase("S")&&opp_insurancekey.equalsIgnoreCase("1"))
					//{
						
				//	System.out.println(row);
						
						
						
						ProjectVariables.rvaunified_oracle_collection_data.add(row);
				
					
					
				}

				//System.out.println("Record count from rva_unified Collection ===>"+i);
				
			} catch (Exception e) {
				System.out.println("Exception: " + e);
			}
			break;

			
		default:
			Assert.assertTrue("Given collection name was not found ===>"+collectionName, false);
		}
		return queryResults;
	}
    
	public static void Get_the_distinct_clients_based_on_given(String environment,String requiredcoloumn) {
		
		//To retrieve all documments from the given DB
		if(environment.equalsIgnoreCase("PROD"))
		{
			retrieveAllDocuments("cpd", "oppty",ProjectVariables.MONGO_SERVER_PROD_URL,ProjectVariables.MONGO_SERVER_DEVPORT);	
		}
		else if(environment.equalsIgnoreCase("UAT"))
		{
			retrieveAllDocuments("cpd", "oppty",ProjectVariables.MONGO_SERVER_UAT_URL,ProjectVariables.MONGO_SERVER_UAT_PORT);
		}

		Bson MatchFilter = new BsonDocument();
	
		switch(requiredcoloumn)
		{
		case "Clientname":
			MatchFilter = Filters.and(Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),Filters.ne("disposition.desc", "Prior Approval"));

			Distinctresults = mColl.distinct("clientDesc", MatchFilter, String.class);

			for (String Client : Distinctresults) {

				
				if(environment.equalsIgnoreCase("PROD"))
				{
					ProjectVariables.PRODClientList.add(Client);	
				}
				else if(environment.equalsIgnoreCase("UAT"))
				{
					ProjectVariables.UATClientList.add(Client);	
				}
				
		
			}
		break;
		case "ClientKey":
			MatchFilter = Filters.and(Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),Filters.ne("disposition.desc", "Prior Approval"));

			Distinctresults_with_long = mColl.distinct("_id.clientKey", MatchFilter, Long.class);

			for (Long Clientkey : Distinctresults_with_long) 
			{
				if(environment.equalsIgnoreCase("PROD"))
				{
					ProjectVariables.PRODClientKeysList.add(Clientkey);	
				}
				else if(environment.equalsIgnoreCase("UAT"))
				{
					ProjectVariables.UATClientKeysList.add(Clientkey);	
				}
				
			}
			
			
			if(environment.equalsIgnoreCase("PROD"))
			{
				System.out.println("PROD ClientData  ==>"+ProjectVariables.PRODClientKeysList);
					
			}
			else if(environment.equalsIgnoreCase("UAT"))
			{
				System.out.println("UAT ClientData  ==>"+ProjectVariables.UATClientKeysList);
			}
			
		break;
		
		default:
			Assert.assertTrue("Given selection was not found ==>"+requiredcoloumn, false);
		break;
		
		}
	}
    
	public static void Get_the_client_data_based_on_given(String environment) {
		
		//To retrieve all documments from the given DB
		if(environment.equalsIgnoreCase("PROD"))
		{
			retrieveAllDocuments("cpd", "oppty",ProjectVariables.MONGO_SERVER_PROD_URL,ProjectVariables.MONGO_SERVER_DEVPORT);	
		}
		else if(environment.equalsIgnoreCase("UAT"))
		{
			retrieveAllDocuments("cpd", "oppty",ProjectVariables.MONGO_SERVER_UAT_URL,ProjectVariables.MONGO_SERVER_UAT_PORT);
		}

		Bson MatchFilter = new BsonDocument();
		
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Serenity.sessionVariableCalled("release"))),Filters.ne("disposition.desc", "Prior Approval"));
		
		results = mColl.find(MatchFilter);
		
		recordsCount = mColl.count(MatchFilter);
		
		if(recordsCount==0)
		{
			Assert.assertTrue("Record count is zero for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",release==>"+Serenity.sessionVariableCalled("release")+",Environment ==>"+environment, false);
		}
		System.out.println("Filtered Record==>"+recordsCount);		
		System.out.println("Oppty collecton filtered count for the clientkey==>"+Serenity.sessionVariableCalled("clientkey")+",release==>"+Serenity.sessionVariableCalled("release")+",Environment ==>"+environment+"==>"+recordsCount);
			int i=0;
		for (Document document : results) {
			i=i+1;
				
				if(environment.equalsIgnoreCase("PROD"))
				{
					
					ProjectVariables.PROD_Opportunity_collection_data.add(String.valueOf(document));	
				}
				else if(environment.equalsIgnoreCase("UAT"))
				{
					//System.out.println(document);
					ProjectVariables.UAT_Opportunity_collection_data.add(String.valueOf(document));	
				}
				
				
		
			}
		
		if(environment.equalsIgnoreCase("PROD"))
		{
			
			System.out.println(ProjectVariables.PROD_Opportunity_collection_data.get(0));
			System.out.println("PROD ClientData size ==>"+ProjectVariables.PROD_Opportunity_collection_data.size());
				
		}
		else if(environment.equalsIgnoreCase("UAT"))
		{
			System.out.println(ProjectVariables.UAT_Opportunity_collection_data.get(0));
			System.out.println("UAT ClientData size ==>"+ProjectVariables.UAT_Opportunity_collection_data.size());
		}
		
		
	}
 
	public static void Retrieve_the_mongodb_data_to_validate_the_CPW_oppotunityDashboard(
		    String clientkey,String Payershort,String Dataversion) throws Exception {
		
		ProjectVariables.RawSavings.clear();
		ProjectVariables.AggSavings.clear();
		ProjectVariables.ConSavings.clear();
		ProjectVariables.Edits.clear();
		
		retrieveAllDocumentsFromDB("cpd", "oppty",10070);
		
		
		Bson MatchFilter;
		
		
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(Dataversion)),Filters.eq("_id.payerShort", Payershort),Filters.ne("disposition.desc", "Prior Approval"));

		
			results = mColl.find(MatchFilter);
			recordsCount = mColl.count(MatchFilter);
		
		System.out.println("Record Count from DB ==>" + recordsCount);
		
		
		
		if (recordsCount == 0) 
		{
            Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data Clientkey ==>" + clientkey
                    + ",DataVersion ====>"+Dataversion+",Payershort ==>"+Payershort, false);
		}
		
		
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		
		AggregateIterable<Document> output2 = mColl.aggregate(Arrays.asList(
		                                matchtext,Aggregates.group("$_id.payerShort", Accumulators.sum("Raw savings", "$annualSavings.raw"),Accumulators.sum("Agg savings", "$annualSavings.agg"),Accumulators.sum("Con savings", "$annualSavings.con"),Accumulators.sum("Edits", "$annualSavings.lines"))));
		
		
		int i=0;
		
		
		
		for (Document document : output2) 
		{
			i=i+1;     
		ProjectVariables.RawSavings.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Raw savings=",",")));
		ProjectVariables.AggSavings.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Agg savings=",",")));
		ProjectVariables.ConSavings.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Con savings=",",")));
		ProjectVariables.Edits.add(Long.valueOf(StringUtils.substringBetween(document.toString(), "Edits=","}")));
		}
		    
		   
		    
		    
		  
		System.out.println("DB Raw Savings ===>"+ProjectVariables.RawSavings);
		System.out.println("DB AggSavings ===>"+ProjectVariables.AggSavings);
		System.out.println("DB ConSavings ===>"+ProjectVariables.ConSavings);
		System.out.println("DB Edits ===>"+ProjectVariables.Edits);
		    
		    
		
}
	
	private static void Intialaize_the_insurance_claimtype_queries(List<String> payerkeyList,List<String> insurancelist,List<String> claimtypelist,List<String> LCDList) {

		
		
		ArrayList<Bson> payerORqueryList = new ArrayList<>();

		ArrayList<Bson> InsuranceORqueryList = new ArrayList<>();

		ArrayList<Bson> ClaimtypeORqueryList = new ArrayList<>();
		
		ArrayList<Bson> LCDORqueryList = new ArrayList<>();

		for (String payer : payerkeyList) {

			Filters.eq("payerShort", payer.trim());

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			payerORqueryList.add(Filters.eq("payerShort", payer.trim()));

		}

		ProjectVariables.Payerorquery = Filters.or(payerORqueryList);

		for (String INSurance : insurancelist) {

			Filters.eq("insuranceDesc", INSurance);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			InsuranceORqueryList.add(Filters.eq("insuranceDesc", INSurance));

		}

		ProjectVariables.Insuranceorquery = Filters.or(InsuranceORqueryList);

		for (String claimtype : claimtypelist) {

			Filters.eq("_id.claimType", claimtype);

			// orquery=Filters.or(Filters.eq("payerShort", payer));
			ClaimtypeORqueryList.add(Filters.eq("_id.claimType", claimtype));

		}

		ProjectVariables.Claimtypeorquery = Filters.or(ClaimtypeORqueryList);
		
		for (String LCD : LCDList) {

			Filters.eq("latestClientDecision.cdmDecision", LCD);

			
			LCDORqueryList.add(Filters.eq("latestClientDecision.cdmDecision", LCD));

		}

		ProjectVariables.LatestCLientDecisionOrquery = Filters.or(LCDORqueryList);

	}
	
	public static void Retrieve_the_Topics_DPs_based_on_client_and_release_in_AWB(String clientkey,String medicalpolicyname,List<String> Payershorts,List<String> Insurances,List<String> Products,List<String> LCDs) {
		ProjectVariables.DB_Topiclist.clear();
		ProjectVariables.DB_DpkeyList.clear();

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		String DBTopic = null;
		Long DPkey = 0l;

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Filters.in("_id.claimType", Products),Filters.in("insuranceDesc", Insurances),Filters.in("payerShort", Payershorts),
				Filters.eq("disposition.desc", "No Disposition"),Filters.in("latestClientDecision.cdmDecision", LCDs),
				Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicyname));

		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		for (Document doc : results) {

			Document SubRuleDocumment = doc.get("subRule", Document.class);
			Document HierarchyDoc = SubRuleDocumment.get("hierarchy", Document.class);
			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			i = i + 1;

			Long Edits = AnnualSavingsDoccument.getLong("lines");

			DPkey = HierarchyDoc.getLong("dpKey");
			DBTopic = HierarchyDoc.getString("topicDesc");

			if (!(Edits == 0)) {
				ProjectVariables.DB_Topiclist.add(DBTopic);

			}

			ProjectVariables.DB_DpkeyList.add(DPkey);

		}

		if (recordsCount == 0) {
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,clientkey ==>" + clientkey
					+ ",Matchfilter==>"+MatchFilter, false);
		}

		if (ProjectVariables.DB_Topiclist.isEmpty()) {
			Assert.assertTrue("Topic keys  is 'null' in the Mongo DB for the given filtering data,client ==>" + clientkey
					+ ",Matchfilter==>"+MatchFilter, false);
		}

		System.out.println("Topics ==>" + ProjectVariables.DB_Topiclist);
		System.out.println("DP's ==>" + ProjectVariables.DB_DpkeyList);
		System.out.println("Topics size==>" + ProjectVariables.DB_Topiclist.size());
		System.out.println("DP'size ==>" + ProjectVariables.DB_DpkeyList.size());

		// System.out.println("Documments ==>"+Doclist);

	}

	//####################### PI-25 methods #################################################//
	
	public static void getAWBGriddatabasedonDPkeyandMP(String sDPkey,String sMP,String criteria) throws ParseException
	{
		int i=0;
		String sRawsavings=null;
		String sAggsavings=null;
		String sEdits=null;
		String sSavingsstatus=null;
		String sLCD=null;
		String sPD=null;
		AggregateIterable<Document> output=null;
		List<String> emptyList = new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(sDPkey)),
					  Filters.eq("subRule.hierarchy."+criteria+"", sMP),
					  Filters.ne("disposition.priorDisposition", "Prior Approval")
					  //java.util.regex.Pattern.compile
					  );
		
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
		System.out.println("#################### Connected to 'eLL hierarchy' collection as DPKey didin't find in 'oppty' ###################");
			verifyThegivenDPineLLhierarchyandCDMDecision(sDPkey,sMP,criteria,emptyList,
					emptyList,emptyList,emptyList);
		}
		else
		{
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$subRule.hierarchy.dpKey",
				Accumulators.sum("Rawsavings", "$annualSavings.raw"),
				Accumulators.sum("Aggsavings", "$annualSavings.agg"),
				Accumulators.sum("Edits", "$annualSavings.lines"),
				Accumulators.addToSet("Savingsstatus", "$ruleInBaseLine"),
				Accumulators.addToSet("LCD", "$latestClientDecision.cdmDecision"),
				Accumulators.addToSet("PD", "$disposition.priorDisposition")
				))).allowDiskUse(true);
		
		for (Document document : output) 
		{
			System.out.println(document);
			sRawsavings=StringUtils.substringBetween(String.valueOf(document), "Rawsavings=", ", Aggsavings");
			sAggsavings=StringUtils.substringBetween(String.valueOf(document), "Aggsavings=", ", Edits");
			sEdits=StringUtils.substringBetween(String.valueOf(document), "Edits=", ", Savingsstatus");
			sSavingsstatus=StringUtils.substringBetween(String.valueOf(document), "Savingsstatus=[", "], LCD");
			sLCD=StringUtils.substringBetween(String.valueOf(document), "LCD=[", "], PD");
			sPD=StringUtils.substringBetween(String.valueOf(document), "PD=[", "]}}");
			
		}
		Serenity.setSessionVariable("Savingsstatus").to(sSavingsstatus);
		Serenity.setSessionVariable("LCD").to(sLCD);
		Serenity.setSessionVariable("PD").to(sPD);
		Serenity.setSessionVariable("Rawsavings").to(sRawsavings);
		Serenity.setSessionVariable("Aggsavings").to(sAggsavings);
		Serenity.setSessionVariable("Edits").to(sEdits);
	}
		
		
		
	}

	public static void verifyThegivenDPineLLhierarchyandCDMDecision(String sDPkey, String sMP, String criteria,
			List<String> payershortlist,List<String> insurancelist,List<String> claimtypelist,
			List<String> LCDlist) {
		Bson MatchFilter = new BsonDocument();
		List<String> ClaimtypeList = new ArrayList<>();
		List<Long> insuranceKeyslist = new ArrayList<>();
		HashSet<String> lCDlist = new HashSet<>();
		ArrayList<Long> payerKeys=new ArrayList<>();
		
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		MatchFilter = Filters.and(
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(sDPkey)),
					  Filters.eq("subRule.hierarchy."+criteria+"", sMP)
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
		Assert.assertTrue("RecordCount is '0' for Matchfilter::"+MatchFilter, false);
		}
		System.out.println("#################### Connected to 'LatestClientDecision' collection to find decision for eLL DPkey ###################");
		if(payershortlist.isEmpty())
		{
			ClaimtypeList=Arrays.asList(ProjectVariables.ProductFilterOptions.split(","));
			insuranceKeyslist=Arrays.asList(1l,2l,3l,7l,8l,9l);
			payerKeys.addAll(getTheDistinctPayerkeysBasedOnClient(Serenity.sessionVariableCalled("clientkey")));
			
			MatchFilter = Filters.and(Filters.in("_id.payerKey", payerKeys),
					  Filters.in("_id.insuranceKey", insuranceKeyslist),
					  Filters.in("_id.claimType", ClaimtypeList),
					  Filters.eq("_id.dpKey", Long.valueOf(sDPkey))
					  );
		}
		else
		{
			for (int j = 0; j < insurancelist.size(); j++) {
				insuranceKeyslist.add(Long.valueOf(GenericUtils.Retrieve_the_insuranceKey_from_insurance(insurancelist.get(j).trim())));
			}
			for (int j = 0; j < payershortlist.size(); j++) {
				//To retrieve the payerkeys based on clientkey
				payerKeys.add(Long.valueOf(Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(payershortlist.get(j).trim(), "Payershort")));
					
			}
			
			MatchFilter = Filters.and(Filters.in("_id.payerKey", payerKeys),
					  Filters.in("_id.insuranceKey", insuranceKeyslist),
					  Filters.in("_id.claimType", claimtypelist),
					  Filters.eq("_id.dpKey", Long.valueOf(sDPkey))
					  );
		
		
		}
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cdm", "latestDecision");
				
		recordsCount = mColl.count(MatchFilter);
		results=mColl.find(MatchFilter);
		if(recordsCount==0)
		{
			System.out.println("RecordCount is '0' for Matchfilter::"+MatchFilter);
			Serenity.setSessionVariable("LCD").to("");
			
		}
		else
		{
			for (Document doc : results) 
			{
				String CDMDecision=doc.getString("decStatusDesc");
				lCDlist.add(CDMDecision);
			}
			
			if((lCDlist.contains("Approve Library")||lCDlist.contains("Approve With Modifications"))&&(lCDlist.contains("Reject")||lCDlist.contains("Suppress")))
			{
				Serenity.setSessionVariable("Savingsstatus").to("0,-1");
			}
			else if((lCDlist.contains("Approve Library")||lCDlist.contains("Approve With Modifications"))&&(!lCDlist.contains("Reject")&&!lCDlist.contains("Suppress")))
			{
				Serenity.setSessionVariable("Savingsstatus").to("-1");
			}
			else if((!lCDlist.contains("Approve Library")&&!lCDlist.contains("Approve With Modifications"))&&(lCDlist.contains("Reject")||lCDlist.contains("Suppress")))
			{
				Serenity.setSessionVariable("Savingsstatus").to("0");
			}
			String lcd=String.join(",", lCDlist);
			Serenity.setSessionVariable("LCD").to(lcd);
			//System.out.println(lcd);
			
		}
		
		Serenity.setSessionVariable("PD").to("No Disposition");
		Serenity.setSessionVariable("Rawsavings").to("0");
		Serenity.setSessionVariable("Aggsavings").to("0");
		Serenity.setSessionVariable("Edits").to("0");
		System.out.println(lCDlist);
	}

	public static ArrayList<Long> getTheDistinctPayerkeysBasedOnClient(String clientkey)
	{
		ArrayList<Long> Payershortlist=new ArrayList<>();
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
		
		AggregateIterable<Document> output=null;
		
		Bson MatchFilter = new BsonDocument();
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)));
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		Distinctresults_with_long  = mColl.distinct("_id.payerKey",Filters.eq("_id.clientKey", Long.valueOf(clientkey)),Long.class);
		for (Long payerKey:Distinctresults_with_long) 
		{
			Payershortlist.add(payerKey);
		}
		System.out.println("PayerKeys::"+Payershortlist);
		return Payershortlist;
	}

	public static ArrayList<String> getNoEditsTopicsandDPsinAWB(String sDatatype,
			List<String> payershortlist,List<String> insurancelist,List<String> claimtypelist,
			List<String> LCDlist) throws ParseException
	{
		int i=0;
		String edits=null;
		String sTopic=null;
		String sDPkeys=null;
		ArrayList<String> TopicswithDPs=new ArrayList<>();
		ArrayList<String> Topics=new ArrayList<>();
		List<String> DPkeyList=null;
		
		
		AggregateIterable<Document> output=null;
		
		Bson MatchFilter = new BsonDocument();
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
			
		if(!payershortlist.isEmpty())
		{
			
			//Filter to form a match query based on inputs
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						  Filters.eq("disposition.desc", "No Disposition"),
						  //Filters.eq("annualSavings.lines", 0),
						  Filters.in("payerShort", payershortlist),
							Filters.in("_id.claimType", claimtypelist),
							Filters.in("insuranceDesc", insurancelist),
							Filters.in("latestClientDecision.cdmDecision", LCDlist)
						  );
			
		}
		else
		{
			//Filter to form a match query based on inputs
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						  Filters.eq("disposition.desc", "No Disposition")
						  //Filters.eq("annualSavings.lines", 0)
						  );
				
		}
		
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("Record count is '0' for matchfilter::"+MatchFilter, false);
		}
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$subRule.hierarchy."+sDatatype+"",
				Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),
				Accumulators.sum("Edits", "$annualSavings.lines")
				))).allowDiskUse(true);
				
		for (Document document : output) 
		{
			//System.out.println(document);
			sTopic=StringUtils.substringBetween(String.valueOf(document), "_id=", ", DPkeys").trim();
			sDPkeys=StringUtils.substringBetween(String.valueOf(document), "DPkeys=[", "], Edits");
			edits=StringUtils.substringBetween(String.valueOf(document), "Edits=", "}}");
			/*if(!payershortlist.isEmpty())
			{
				//Filter to form a match query based on inputs
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							  Filters.eq("subRule.hierarchy."+sDatatype+"", sTopic),
							  Filters.eq("disposition.desc", "No Disposition"),
							  Filters.ne("annualSavings.lines", 0),
							  Filters.in("payerShort", payershortlist),
								Filters.in("_id.claimType", claimtypelist),
								Filters.in("insuranceDesc", insurancelist),
								Filters.in("latestClientDecision.cdmDecision", LCDlist)
							  //Filters.eq("ruleInBaseLine", 0)
							  );
					
			}
			else
			{
				//Filter to form a match query based on inputs
				MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							  Filters.eq("subRule.hierarchy."+sDatatype+"", sTopic),
							  Filters.eq("disposition.desc", "No Disposition"),
							  Filters.ne("annualSavings.lines", 0)
							  //Filters.eq("ruleInBaseLine", 0)
							  );
			}
			
			
			recordsCount = mColl.count(MatchFilter);*/
			
			//if(recordsCount==0)
			if(edits.equalsIgnoreCase("0"))
			{
				
				if(!sTopic.equalsIgnoreCase("Unassigned Topic Bucket for iHT Specialty Policy"))
				{
					TopicswithDPs.add(sTopic+"::"+sDPkeys);
					System.out.println(i+"."+sTopic+"::"+sDPkeys+"::"+edits);
					i=i+1;
					DPkeyList=Arrays.asList(sDPkeys.split(","));
					if(DPkeyList.size()>2)
					{
						ProjectVariables.TopicswithMultipleDPs.add(sTopic+"::"+sDPkeys);
						Serenity.setSessionVariable("Topic").to(sTopic);
						Serenity.setSessionVariable("DPkey").to(sDPkeys);
					}
						
				}
				
			}
		}
		System.out.println("Topicsize::"+TopicswithDPs.size());
		return TopicswithDPs;	
	}

	public static ArrayList<String> retrieveThePPSforDPkey(String DPKey,
			String UIpayershort,String UIinsurance,String UIclaimtype,String UILCD,String savingsstatus)
	{
		String payerKey=null;
		String insurancekey=null;
		String claimtype=null;
		String insuranceDesc=null;
		String payerShort=null;
		String DBdecision=null;
		Bson MatchFilter = new BsonDocument();
		ArrayList<String> FinalppsList=new ArrayList<>();
		
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(UIpayershort,UIinsurance,UIclaimtype,UILCD);
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.eq("_id.dpKey", Long.valueOf(DPKey)),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList)
					  );
		
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		
		for (Document doc : results) 
		{
			//System.out.println(doc);
			payerKey=StringUtils.substringBetween(String.valueOf(doc), "payerKey=", ", insuranceKey").trim();
			insurancekey=StringUtils.substringBetween(String.valueOf(doc), "insuranceKey=", ", claimType").trim();
			claimtype=StringUtils.substringBetween(String.valueOf(doc), "claimType=", ", dpKey").trim();
			insuranceDesc=GenericUtils.Retrieve_the_insuranceDesc_from_insuranceKey(insurancekey).trim();
			payerShort=Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(payerKey,"PayerKey");
			DBdecision=StringUtils.substringBetween(String.valueOf(doc), "decStatusDesc=", ", releaseLogKey").trim();

			if(ProjectVariables.PPSList.contains(payerShort+":"+insuranceDesc+":"+claimtype))
			{
				if(DBdecision.equalsIgnoreCase("Approve With Modifications")||DBdecision.equalsIgnoreCase("Approve Library"))
				{
					savingsstatus="Production";
				}
				else
				{
					savingsstatus="Opportunity";
				}
				System.out.println(payerShort+":"+insuranceDesc+":"+claimtype+":"+savingsstatus);
				FinalppsList.add(payerShort+":"+insuranceDesc+":"+claimtype+":"+savingsstatus);
			
			}
			
		}
		System.out.println("PPS count from the DB as per config service::"+FinalppsList.size());
			return FinalppsList;
	}

	public static List<String> getTheDistinctdataBasedOnClient(String fieldname,String col)
	{
		List<String> resultList=new ArrayList<>();
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
		Distinctresults  = mColl.distinct(fieldname,Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),String.class);
		for (String dbval:Distinctresults) 
		{
			System.out.println(dbval);
			resultList.add(dbval);
		}
		System.out.println(col+"::"+resultList);
		System.out.println(col+" size::"+resultList.size());
		return resultList;
	}

	public static String retrieveTheeLLMPsbasedonPPSforFilterPanel(String payershort,String insurance,String claimtype,String LCD)
	{
		HashSet<Long> dpKeys=new HashSet<>();
		HashSet<String> MPs=new HashSet<>();
		HashSet<String> ExactMPswithDPs=new HashSet<>();
		HashSet<String> Topics=new HashSet<>();
		Bson MatchFilter = new BsonDocument();
		String medicalpolicy=null;
		AggregateIterable<Document> output=null;
		String sDPkey=null;;
		ArrayList<String> dpKeysList=new ArrayList<>();
		HashSet<Long> rvapayerSwitchList=new HashSet<>();
		List<String> MPList = new ArrayList<>();
		List<String> DpKeys= new ArrayList<>();
		HashSet<String> MPswithDPs=new HashSet<>();
		HashSet<String> RequiredMPs=new HashSet<>();
		int i=0;	
		String dps=null;
		
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
	//################ To retrieve the DPkeys for the pps #######################################				
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("decStatusDesc", ProjectVariables.lCDlist));
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			Document iddoc=doc.get("_id",Document.class);
			dpKeys.add(iddoc.getLong("dpKey"));
		}
		System.out.println("DPKeysize::"+dpKeys.size());		
		
	//################ To retrieve the MP and Topics for the DPkeys #######################################
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		MatchFilter = Filters.and(Filters.in("_id.dpKey", dpKeys),Filters.eq("rvaPayerSwitch", 0),Filters.eq("subRule.hierarchy.dpTypeDesc", "Rules"));
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			Document idDoc=doc.get("_id",Document.class);
			Document suRuledoc=doc.get("subRule",Document.class);
			Document hierarchydoc=suRuledoc.get("hierarchy",Document.class);
			medicalpolicy=hierarchydoc.getString("medPolicyDesc");
			MPs.add(medicalpolicy);
			Topics.add(hierarchydoc.getString("topicDesc")+";"+medicalpolicy);
		}
	//################ To retrieve the MPs with corresponding DPkeys #######################################
		for (String sTopic : Topics) 
		{
			String exactTopic=StringUtils.substringBefore(sTopic, ";");
			MatchFilter = Filters.and(
						  Filters.eq("subRule.hierarchy.topicDesc", exactTopic),
						  Filters.eq("rvaPayerSwitch", 0),
						  Filters.eq("subRule.hierarchy.dpTypeDesc", "Rules")
						  );
			Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
			output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(new Document().append("Topic", "$subRule.hierarchy.topicDesc").append("MP",
					"$subRule.hierarchy.medPolicyDesc").append("dpKey", "$subRule.hierarchy.dpKey").append("rvapayerSwitch", "$rvaPayerSwitch"),
					Accumulators.addToSet("DPKeys", "$subRule.hierarchy.dpKey"),
					Accumulators.addToSet("rvaPayerswitch", "$rvaPayerSwitch"),
					Accumulators.addToSet("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc")
					))).allowDiskUse(true);
			for (Document document : output) 
			{
				medicalpolicy=StringUtils.substringBetween(String.valueOf(document), "Medicalpolicy=[", "]}}");
				sDPkey=StringUtils.substringBetween(String.valueOf(document),"DPKeys=[","], rvaPayerswitch").trim();
				MPList=Arrays.asList(medicalpolicy.split(","));
				for (int j = 0; j < MPList.size(); j++) 
				{
					if(!sDPkey.contains("."))
					{
						ExactMPswithDPs.add(MPList.get(j)+"::"+sDPkey);
						i=i+1;
					}
					
				}
			}
		}
	//####################### Verify the dpkey is having 'None' decision or not #########################################
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		
		for (String mP : ExactMPswithDPs) 
		{
			medicalpolicy=StringUtils.substringBefore(mP,"::");
			sDPkey=StringUtils.substringAfter(mP,"::");
			Serenity.setSessionVariable("DPkey").to(StringUtils.substringAfter(mP,"::"));
			String row=medicalpolicy+";Raw-0;Agg-0;Con-0";
			MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("decStatusDesc", ProjectVariables.lCDlist),
						  Filters.eq("_id.dpKey", Long.valueOf(sDPkey))
						  );
			recordsCount = mColl.count(MatchFilter);
			if(recordsCount!=0)
			{
				RequiredMPs.add(medicalpolicy.trim());
				MPswithDPs.add(medicalpolicy+"::"+sDPkey);
			}
		}
 //####################### Verify the dpkey is having rvaPayerswitch is '0' only #########################################
		ExactMPswithDPs.clear();
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		for (String MP : RequiredMPs) 
		{
			for (String mpwithdp : MPswithDPs) 
			{
				if(MP.equalsIgnoreCase(StringUtils.substringBefore(mpwithdp,"::").trim()))
				{
					
					//Filter to form a match query based on inputs
					MatchFilter = Filters.and(
								  Filters.eq("subRule.hierarchy.medPolicyDesc", StringUtils.substringBefore(mpwithdp,"::").trim()),
								  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(StringUtils.substringAfter(mpwithdp,"::").trim()))
								  );
					Distinctresults_with_long  = mColl.distinct("rvaPayerSwitch",MatchFilter,Long.class);
					for (Long rvapayeswitch:Distinctresults_with_long) 
					{
						rvapayerSwitchList.add(rvapayeswitch);
					}
					if(rvapayerSwitchList.size()==1&&rvapayerSwitchList.contains(0l))
					{
						dpKeysList.add(StringUtils.substringAfter(mpwithdp,"::").trim());
					}
					rvapayerSwitchList.clear();
				}
			
			}
			 dps=String.join(",", dpKeysList);
			if(dpKeysList.size()!=0)
			{
				ExactMPswithDPs.add(MP+"::"+dps);
			}
			dpKeysList.clear();
		}
//####################### Verify the dpkey is captured or not #########################################	
		ConnectTogivenDBandCollection("cpd", "oppty");
		for (String eLLdata : ExactMPswithDPs) 
		{
			medicalpolicy=StringUtils.substringBefore(eLLdata, "::").trim();
			DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
			for (int j = 0; j < DpKeys.size(); j++)
			{
				//Filter to form a match query based on inputs
				MatchFilter = Filters.and(
							Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							  Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy),
							  Filters.eq("disposition.desc", "No Disposition"),
							  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DpKeys.get(j).trim()))
							  );
				recordsCount = mColl.count(MatchFilter);
				dps=String.join(",", DpKeys);
				if(recordsCount!=0)
				{
					//System.out.println(medicalpolicy+"::"+DpKeys.size()+"::"+dps);
					ProjectVariables.Medicalpolicy_PolicySelectiondrawer.add(medicalpolicy);
					ProjectVariables.DB_MPlist.add(medicalpolicy+"::"+dps);
				}
			}
		}
		
		for (String eLLdata : ProjectVariables.DB_MPlist) {
			DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
			if(DpKeys.size()>5)
			{
				medicalpolicy=StringUtils.substringBefore(eLLdata, "::");
			}
			System.out.println(StringUtils.substringBefore(eLLdata, "::")+"::"+DpKeys.size()+"::"+DpKeys);
		}
		
		System.out.println("eLL MPsize::"+ProjectVariables.Medicalpolicy_PolicySelectiondrawer.size());
		System.out.println("eLL Topicsize::"+Topics.size());
		if(ProjectVariables.Medicalpolicy_PolicySelectiondrawer.isEmpty())
		{
			Assert.assertTrue("No eLL MPs are availabl for the client/PPS", false);
		}
		return medicalpolicy;
	
	}

	public static String Retrieve_the_medicalpolicy_based_on_PPS(String payershort,String insurance,String claimtype,String LCD) {
		
		List<String> topicslist=null;
		AggregateIterable<Document> output2 = null;
		ProjectVariables.Medicalpolicy_PolicySelectiondrawer.clear();
		
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
		
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		String DBMedicalpolicy = null;

		Bson MatchFilter = new BsonDocument();
		int i = 0;
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				Filters.eq("disposition.desc", "No Disposition"),
				Filters.in("payerShort", ProjectVariables.payerShortList),
				Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				Filters.in("insuranceDesc", ProjectVariables.insuranceList),
				Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
				);
				
	
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);

		System.out.println("Filtered Record Count ===>" + recordsCount);
		if (recordsCount == 0) 
		{
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,Matchfilter==>"+MatchFilter, false);
		}
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		output2 = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group("$subRule.hierarchy.medPolicyDesc",
						Accumulators.addToSet("Topics", "$subRule.hierarchy.topicDesc"))));
		for (Document document : output2) 
		{
			String Topics= StringUtils.substringBetween(document.toString(), "Topics=[", "]}}");
			topicslist=Arrays.asList(Topics.split(","));
			DBMedicalpolicy = StringUtils.substringBetween(document.toString(), "_id=", ", Topics");
			if(topicslist.size()>=4)
			{
				ProjectVariables.Medicalpolicy_PolicySelectiondrawer.add(DBMedicalpolicy);
			}
		}
		if (ProjectVariables.Medicalpolicy_PolicySelectiondrawer.isEmpty()) 
		{
			Assert.assertTrue("Mecial policies is 'null' in the Mongo DB for the given filtering data for the topic count > 4", false);
		}

		System.out.println(ProjectVariables.Medicalpolicy_PolicySelectiondrawer);
		System.out.println("Medical Policies size ==>" + ProjectVariables.Medicalpolicy_PolicySelectiondrawer.size());

		for (String DBmedicalpolicy : ProjectVariables.Medicalpolicy_PolicySelectiondrawer)
		{
			return DBmedicalpolicy;
		}

		return null;

	}

	public static void Retrieve_the_DPs_based_on_PPS_in_AWB(
			List<String> payershortlist,List<String> insurancelist,List<String> claimtypelist,List<String> LCDlist) {
		ProjectVariables.DB_Topiclist.clear();
		ProjectVariables.DB_DpkeyList.clear();

		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");
		String DBTopic = null;
		Long DPkey = 0l;

		Bson MatchFilter = new BsonDocument();
		int i = 0;

		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				Filters.eq("disposition.desc", "No Disposition"),
				Filters.eq("subRule.hierarchy.medPolicyDesc", Serenity.sessionVariableCalled("Medicalpolicy")),
				Filters.in("payerShort", payershortlist),
				Filters.in("_id.claimType", claimtypelist),
				Filters.in("insuranceDesc", insurancelist),
				Filters.in("latestClientDecision.cdmDecision", LCDlist));

		// Filters.eq("ruleInBaseLine", 0)
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if (recordsCount == 0) 
		{
			Assert.assertTrue("Record count is 'zero' in the Mongo DB for the given filtering data,Matchfilter ==>" + MatchFilter, false);
		}
		for (Document doc : results) {
			Document SubRuleDocumment = doc.get("subRule", Document.class);
			Document HierarchyDoc = SubRuleDocumment.get("hierarchy", Document.class);
			Document AnnualSavingsDoccument = doc.get("annualSavings", Document.class);
			i = i + 1;
			Long Edits = AnnualSavingsDoccument.getLong("lines");

			DPkey = HierarchyDoc.getLong("dpKey");
			DBTopic = HierarchyDoc.getString("topicDesc");
			ProjectVariables.DB_Topiclist.add(DBTopic);
			ProjectVariables.DB_DpkeyList.add(DPkey);

		}

		

		if (ProjectVariables.DB_Topiclist.isEmpty())
		{
			Assert.assertTrue("Topic keys  is 'null' in the Mongo DB for the given filtering data,Matchfilter ==>" + MatchFilter, false);
		}

		System.out.println("Topics ==>" + ProjectVariables.DB_Topiclist);
		System.out.println("DP's ==>" + ProjectVariables.DB_DpkeyList);
		System.out.println("Topics size==>" + ProjectVariables.DB_Topiclist.size());
		System.out.println("DP'size ==>" + ProjectVariables.DB_DpkeyList.size());

		

	}

	public static void getAWBGriddatabasedonDPkeyandPPS(String MPTopic,String sDPkey,String criteria,
			List<String> payershortlist,List<String> insurancelist,List<String> claimtypelist,
			List<String> LCDlist,ArrayList<Integer> svgstatuslist) throws ParseException
	{
		int i=0;
		String sRawsavings=null;
		String sAggsavings=null;
		String sEdits=null;
		String sSavingsstatus=null;
		String sLCD=null;
		String sPD=null;
		AggregateIterable<Document> output=null;
		
		Bson MatchFilter = new BsonDocument();
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
					
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(sDPkey)),
					  Filters.eq("subRule.hierarchy."+criteria+"", MPTopic),
					  Filters.in("payerShort", payershortlist),
					Filters.in("_id.claimType", claimtypelist),
					Filters.in("insuranceDesc", insurancelist),
					Filters.in("latestClientDecision.cdmDecision", LCDlist),
					Filters.in("ruleInBaseLine", svgstatuslist)
					 );
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			verifyThegivenDPineLLhierarchyandCDMDecision(sDPkey,MPTopic,criteria,payershortlist,insurancelist,claimtypelist,LCDlist);
		}
		else
		{
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group("$subRule.hierarchy.dpKey",
				Accumulators.sum("Rawsavings", "$annualSavings.raw"),
				Accumulators.sum("Aggsavings", "$annualSavings.agg"),
				Accumulators.sum("Edits", "$annualSavings.lines"),
				Accumulators.addToSet("Savingsstatus", "$ruleInBaseLine"),
				Accumulators.addToSet("LCD", "$latestClientDecision.cdmDecision"),
				Accumulators.addToSet("PD", "$disposition.priorDisposition")
				))).allowDiskUse(true);
		
		for (Document document : output) 
		{
			System.out.println(document);
			sRawsavings=StringUtils.substringBetween(String.valueOf(document), "Rawsavings=", ", Aggsavings");
			sAggsavings=StringUtils.substringBetween(String.valueOf(document), "Aggsavings=", ", Edits");
			sEdits=StringUtils.substringBetween(String.valueOf(document), "Edits=", ", Savingsstatus");
			sSavingsstatus=StringUtils.substringBetween(String.valueOf(document), "Savingsstatus=[", "], LCD");
			sLCD=StringUtils.substringBetween(String.valueOf(document), "LCD=[", "], PD");
			sPD=StringUtils.substringBetween(String.valueOf(document), "PD=[", "]}}");
			
		}
		Serenity.setSessionVariable("Savingsstatus").to(sSavingsstatus);
		Serenity.setSessionVariable("LCD").to(sLCD);
		Serenity.setSessionVariable("PD").to(sPD);
		Serenity.setSessionVariable("Rawsavings").to(sRawsavings);
		Serenity.setSessionVariable("Aggsavings").to(sAggsavings);
		Serenity.setSessionVariable("Edits").to(sEdits);
		
		}
		
		
		
	}

	public static HashSet<String> retrieveThePPSforRVADPkey(String clientKey,String DPKey)
	{
		String payerKey=null;
		String insurancekey=null;
		String claimtype=null;
		String payerShort=null;
		String insuranceDesc=null;
		HashSet<String> ppsList=new HashSet<>();
		ArrayList<Long> payerKeys=new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		//To retrieve the payerkeys based on clientkey
		payerKeys.addAll(getTheDistinctPayerkeysBasedOnClient(clientKey));
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.in("_id.payerKey", payerKeys),
					  Filters.eq("_id.dpKey", Long.valueOf(DPKey))
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		
		for (Document doc : results) 
		{
			//System.out.println(doc);
			payerKey=StringUtils.substringBetween(String.valueOf(doc), "payerKey=", ", insuranceKey").trim();
			insurancekey=StringUtils.substringBetween(String.valueOf(doc), "insuranceKey=", ", claimType").trim();
			claimtype=StringUtils.substringBetween(String.valueOf(doc), "claimType=", ", dpKey").trim();
			insuranceDesc=GenericUtils.Retrieve_the_insuranceDesc_from_insuranceKey(insurancekey).trim();
			payerShort=Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(payerKey,"PayerKey");
			//System.out.println(payerShort+":"+insuranceDesc+":"+claimtype);
			//if(ProjectVariables.PPSList.contains(payerShort+":"+insuranceDesc+":"+claimtype))
			{
				//System.out.println("#######################################################");
				System.out.println(payerShort+":"+insuranceDesc+":"+claimtype);
				ppsList.add(payerShort+":"+insuranceDesc+":"+claimtype);
				}
			
		}
		System.out.println(ppsList.size());
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cpd", "oppty");
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientKey)),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPKey))
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		
		for (Document doc : results) 
		{
			Document iddoc=doc.get("_id",Document.class);
			claimtype=iddoc.getString("claimType");
			insuranceDesc=doc.getString("insuranceDesc");
			payerShort=iddoc.getString("payerShort");
			//System.out.println(payerShort+":"+insuranceDesc+":"+claimtype);
			//if(ProjectVariables.PPSList.contains(payerShort+":"+insuranceDesc+":"+claimtype))
			{
				//System.out.println("#######################################################");
				//System.out.println(payerShort+":"+insuranceDesc+":"+claimtype);
				ppsList.add(payerShort+":"+insuranceDesc+":"+claimtype);
				}
			
		}
		for (String pps : ppsList) {
			System.out.println(pps);
		}
		System.out.println(ppsList.size());
		return ppsList;
	}

	public static String getLatestDecisionforgiveneLLDPkeyPPS(String dpkey,String payershort,String insurance,String claimtype,String LCD)
	{
	
		HashSet<String> CDMDecision=new HashSet<>();
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
		HashSet<String> statusList=new HashSet<>();
		String status=null;
		String latestdecision=null;
		
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
		
	//################ To retrieve the CDM Decision for DPkeys #######################################				
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("decStatusDesc", ProjectVariables.lCDlist),
					  Filters.eq("_id.dpKey", Long.valueOf(dpkey))
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			CDMDecision.add(doc.getString("decStatusDesc"));
		}
				
		for (String cdmdec:CDMDecision) {
			if(cdmdec.contains("Approve"))
			{
				statusList.add("Production");
				status="Production";
				latestdecision=cdmdec;
			}
			else
			{
				statusList.add("Opportunity");
				status="Opportunity";
				latestdecision=cdmdec;
			}
		}
		if(statusList.size()==2)
		{
			status="Multiple";
		}
		if(CDMDecision.size()>1)
		{
			latestdecision="Multiple";
		}
		System.out.println("For DPKey::"+dpkey+",CDMDecisions::"+CDMDecision);
		System.out.println("For DPKey::"+dpkey+",Status::"+statusList);
		System.out.println(latestdecision+"::"+status);
		return latestdecision+"::"+status;
	
	}

	public static String getDPkeywithmultipleRulerelations(String clientKey)
	{
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
		List<String> rulerelations=null;
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientKey)),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0)
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			Document SubRuleDocumment = doc.get("subRule", Document.class);
			rulerelations = (List<String>) SubRuleDocumment.get("ruleRelations");
			if(rulerelations!=null)
			{
				if(rulerelations.size()>1)
				{
					System.out.println(doc);
					break;
				}
				
			}
		}
				
		
		return null;
	
	}

	public static Long NoDispositionPPSforeLLDPkey(ArrayList<Long> dpkeys,
			String payershort,String insurance,String claimtype,String LCD)
	{
		Bson MatchFilter = new BsonDocument();
		Long cdmPPScount=0l;
		//To load the pps and LCD in arraylist
		loadThePPSandOpportunityLCDinList(payershort,insurance,claimtype,LCD);
		
	//################ To retrieve the DPkeys for the pps #######################################				
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("decStatusDesc", ProjectVariables.lCDlist),
					  Filters.in("_id.dpKey", dpkeys)
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		cdmPPScount=recordsCount;
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		System.out.println("Latestdecision PPS count::"+recordsCount);
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist),
					  Filters.in("subRule.hierarchy.dpKey", dpkeys),
					  Filters.in("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0)
					  );
		recordsCount = mColl.count(MatchFilter);
		System.out.println("oppty Nodisp PPS count::"+recordsCount);
		if(recordsCount==cdmPPScount||recordsCount==0)
		{
			System.out.println("eLL PPS count::"+cdmPPScount);
			return cdmPPScount;
		}
		else 
		{
			System.out.println("eLL PPS count::"+recordsCount);
			return recordsCount;
			
		}
		
	
	}

	private static void loadThePPSandLCDinList(String payershort,
			String insurance,String claimtype,String LCD) {
		
		
		//To load the given pps into lists
		if(!payershort.isEmpty())
		{
			ProjectVariables.lCDlist=Arrays.asList(LCD.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(claimtype.split(","));
			ProjectVariables.insuranceList=Arrays.asList(insurance.split(","));
			for (int j = 0; j < ProjectVariables.insuranceList.size(); j++) {
				ProjectVariables.insuranceKeyslist.add(Long.valueOf(GenericUtils.Retrieve_the_insuranceKey_from_insurance(ProjectVariables.insuranceList.get(j).trim())));
			}
			
			ProjectVariables.payerShortList=Arrays.asList(payershort.split(","));
			for (int j = 0; j < ProjectVariables.payerShortList.size(); j++) {
				//To retrieve the payerkeys based on clientkey
				ProjectVariables.payerKeys.add(Long.valueOf(Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(ProjectVariables.payerShortList.get(j).trim(), "Payershort")));
					
			}
		}
		else
		{
			ProjectVariables.lCDlist=Arrays.asList(ProjectVariables.LatestClientDecisionFilterOptions.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(ProjectVariables.ProductFilterOptions.split(","));
			ProjectVariables.insuranceKeyslist=Arrays.asList(1l,2l,3l,7l,8l,9l);
			//To retrieve the payerkeys based on clientkey
			ProjectVariables.payerKeys.addAll(getTheDistinctPayerkeysBasedOnClient(Serenity.sessionVariableCalled("clientkey")));
		}
		
	}
	
	private static void loadThePPSandOpportunityLCDinList(String payershort,
			String insurance,String claimtype,String LCD) {
		//To load the given pps into lists
		if(!payershort.isEmpty())
		{
			ProjectVariables.lCDlist=Arrays.asList(LCD.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(claimtype.split(","));
			ProjectVariables.insuranceList=Arrays.asList(insurance.split(","));
			for (int j = 0; j < ProjectVariables.insuranceList.size(); j++) {
				ProjectVariables.insuranceKeyslist.add(Long.valueOf(GenericUtils.Retrieve_the_insuranceKey_from_insurance(ProjectVariables.insuranceList.get(j).trim())));
			}
			
			ProjectVariables.payerShortList=Arrays.asList(payershort.split(","));
			for (int j = 0; j < ProjectVariables.payerShortList.size(); j++) {
				//To retrieve the payerkeys based on clientkey
				ProjectVariables.payerKeys.add(Long.valueOf(Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(ProjectVariables.payerShortList.get(j).trim(), "Payershort")));
					
			}
		}
		else
		{
			ProjectVariables.lCDlist=Arrays.asList(ProjectVariables.LCDWithOpportunity.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(ProjectVariables.ProductFilterOptions.split(","));
			ProjectVariables.insuranceKeyslist=Arrays.asList(1l,2l,3l,7l,8l,9l);
			//To retrieve the payerkeys based on clientkey
			ProjectVariables.payerKeys.addAll(getTheDistinctPayerkeysBasedOnClient(Serenity.sessionVariableCalled("clientkey")));
		}
		
	}
	
	private static void loadThePPSandPrductionLCDinList(String payershort,
			String insurance,String claimtype,String LCD) {
		//To load the given pps into lists
		if(!payershort.isEmpty())
		{
			ProjectVariables.lCDlist=Arrays.asList(LCD.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(claimtype.split(","));
			ProjectVariables.insuranceList=Arrays.asList(insurance.split(","));
			for (int j = 0; j < ProjectVariables.insuranceList.size(); j++) {
				ProjectVariables.insuranceKeyslist.add(Long.valueOf(GenericUtils.Retrieve_the_insuranceKey_from_insurance(ProjectVariables.insuranceList.get(j).trim())));
			}
			
			ProjectVariables.payerShortList=Arrays.asList(payershort.split(","));
			for (int j = 0; j < ProjectVariables.payerShortList.size(); j++) {
				//To retrieve the payerkeys based on clientkey
				ProjectVariables.payerKeys.add(Long.valueOf(Retrieve_the_PayerKey_From_mongodb_with_the_given_Payershort(ProjectVariables.payerShortList.get(j).trim(), "Payershort")));
					
			}
		}
		else
		{
			ProjectVariables.lCDlist=Arrays.asList(ProjectVariables.LCDWithProduction.split(","));
			ProjectVariables.ClaimtypeList=Arrays.asList(ProjectVariables.ProductFilterOptions.split(","));
			ProjectVariables.insuranceKeyslist=Arrays.asList(1l,2l,3l,7l,8l,9l);
			//To retrieve the payerkeys based on clientkey
			ProjectVariables.payerKeys.addAll(getTheDistinctPayerkeysBasedOnClient(Serenity.sessionVariableCalled("clientkey")));
		}
		
	}

	//################################# Rule Relationship Methods ############################################################
	
	public static ArrayList<String> retrieveRulerelationsTopicswithDPkeysinRVA(
			String payershort,String insurance,String claimtype,String LCD)
	{
		String sTopic=null;
		String sDPkeys=null;
		String DBpayershort=null;
		String sRulerelations=null;
		List<String> ruleRelationlist=null;
		List<String> payerShortsList=null;
		ArrayList<String> TopicswithDPs=new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
		//To load the pps and LCD in arraylist
		loadThePPSandOpportunityLCDinList(payershort,insurance,claimtype,LCD);
				
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.ne("subRule.ruleRelations", null),
					  Filters.eq("ruleInBaseLine", 0),
					  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		results=mColl.find(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
				new Document().append("Topic","$subRule.hierarchy.topicDesc").
				append("DPkey", "$subRule.hierarchy.dpKey").
				append("payershort", "$_id.payerShort"),
				Accumulators.addToSet("payershort", "$_id.payerShort"),
				Accumulators.addToSet("Rulerelations", "$subRule.ruleRelations.groupName")
				))).allowDiskUse(true);
		for (Document document : output) 
		{
			//System.out.println(document);
			sTopic=StringUtils.substringBetween(String.valueOf(document), "Topic=", ", DPkey");
			sDPkeys=StringUtils.substringBetween(String.valueOf(document), "DPkey=", ", payershort");
			DBpayershort=StringUtils.substringBetween(String.valueOf(document), "payershort=[", "], Rulerelations");
			sRulerelations=StringUtils.substringBetween(String.valueOf(document), "Rulerelations=[[", "]]}}");
			if(sRulerelations.contains("]"))
			{
				sRulerelations=sRulerelations.replace("]", "");
			}
			if(sRulerelations.contains("["))
			{
				sRulerelations=sRulerelations.replace("[", "");
			}
			ruleRelationlist=Arrays.asList(sRulerelations.split(","));
			payerShortsList=Arrays.asList(DBpayershort.split(","));
			String payers=String.join(",", payerShortsList);
			System.out.println(sTopic+"::"+sDPkeys+"::"+sRulerelations+"::"+payers);
			
			TopicswithDPs.add(sTopic+"::"+sDPkeys+"::"+sRulerelations+"::"+payers);
		}	
		System.out.println(TopicswithDPs.size());
		return TopicswithDPs;
	}

	public static ArrayList<String> retrieveSubrulesforRRinRVAtab(
			String dpkey,String payershort,String claimtype)
	{
		
		String subruleid=null;
		String rawsavings=null;
		String svgstatus=null;
		ArrayList<String> subrulewithsavings=new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
			
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("_id.payerShort", payershort),
					  //Filters.eq("_id.claimType", claimtype),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.ne("subRule.ruleRelations", null),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey))
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		results=mColl.find(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
				new Document().append("payershort","$_id.payerShort").
				append("DPkey", "$subRule.hierarchy.dpKey").append("Subruleid", "$_id.subRuleId"),
				Accumulators.sum("rawsavings", "$rawSavings.raw"),
				Accumulators.addToSet("savingstatus", "$ruleInBaseLine")
				
				))).allowDiskUse(true);
		for (Document document : output) 
		{
			//System.out.println(document);
			subruleid=StringUtils.substringBetween(String.valueOf(document), "Subruleid=", "}}, rawsavings");
			rawsavings=StringUtils.substringBetween(String.valueOf(document), "rawsavings=", ", savingstatus");
			svgstatus=StringUtils.substringBetween(String.valueOf(document), "savingstatus=[", "]}}");
			if(svgstatus.equalsIgnoreCase("0"))
			{
				svgstatus="Opportunity";
			}
			else if(svgstatus.equalsIgnoreCase("-1"))
			{
				svgstatus="Production";
			}
			else 
			{
				svgstatus="Multiple";
			}
				
			System.out.println(subruleid+"::"+rawsavings+"::"+svgstatus);
			subrulewithsavings.add(subruleid+"::"+rawsavings+"::"+svgstatus);
		}	
		System.out.println(subrulewithsavings.size());
		return subrulewithsavings;
	}
	
	public static ArrayList<String> retrieveActiverulesforRRinRVAtab(
			String dpkey,String payershort,String subruleid,String claimtype)
	{
		
		String actverule=null;
		String RR=null;
		String Activeruledpkey=null;
		String rawsavings=null;
		String savingstatus=null;
		ArrayList<String> activeruleRRdata=new ArrayList<>();
		List<String> activeRuleslist=new ArrayList<>();
		List<String> midRuleslist=new ArrayList<>();
		List<Document> rrList=null;
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
			
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("_id.payerShort", payershort),
					 // Filters.eq("_id.claimType", claimtype),
					  Filters.eq("_id.subRuleId", subruleid),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.ne("subRule.ruleRelations", null),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey))
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		results=mColl.find(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		
		//##################### To retrieve the rulerelations for the given dpkey and payershort ##################
		
		for (Document document : results) 
		{
			actverule=StringUtils.substringBetween(String.valueOf(document), "ruleRelations=[", "]}}, disposition");
			
			if(actverule==null)
			{
				actverule=StringUtils.substringBetween(String.valueOf(document), "ruleRelations=[", "], monthlyReleaseDate");
			}
			activeRuleslist=Arrays.asList(actverule.split("Document"));
			
			//##################### To retrieve the corresponding DPkeys and PPS from the midrulekey ##################
			
			for (int i = 1; i < activeRuleslist.size(); i++) 
			{
				//System.out.println(activeRuleslist.get(i));
				actverule=StringUtils.substringBetween(activeRuleslist.get(i), "activeRules=[", "]}}");
				RR=StringUtils.substringBetween(activeRuleslist.get(i), "groupName=", ", activeRules");
				//System.out.println(activeRuleslist.get(i).trim());
				midRuleslist=Arrays.asList(actverule.split(","));
				
				for (String midrule : midRuleslist) 
				{
					MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							  Filters.eq("_id.payerShort", payershort),
							  Filters.eq("_id.claimType", claimtype),
							  Filters.ne("subRule.ruleRelations", null),
							  Filters.eq("subRule.hierarchy.midRuleKey", Long.valueOf(midrule.trim()))
							  );
					recordsCount = mColl.count(MatchFilter);
					if(recordsCount!=0)
					{
						matchtext = Aggregates.match(Filters.and(MatchFilter));
						//Aggregate filter to retrieve the output
						output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
								"$subRule.hierarchy.midRuleKey",
								Accumulators.addToSet("subRuleid", "$_id.subRuleId"),
								Accumulators.addToSet("DPkey", "$subRule.hierarchy.dpKey"),
								Accumulators.addToSet("Savingstatus", "$ruleInBaseLine"),
								Accumulators.sum("rawsavings", "$rawSavings.raw")
								))).allowDiskUse(true);
						for (Document activeruledoc : output) 
						{
							actverule=StringUtils.substringBetween(String.valueOf(activeruledoc), "subRuleid=[", "], DPkey").trim();
							Activeruledpkey=StringUtils.substringBetween(String.valueOf(activeruledoc), "DPkey=[", "], Savingstatus").trim();
							savingstatus=StringUtils.substringBetween(String.valueOf(activeruledoc), "Savingstatus=[", "], rawsavings").trim();
							rawsavings=StringUtils.substringBetween(String.valueOf(activeruledoc), "rawsavings=", "}}").trim();
							if(savingstatus.equalsIgnoreCase("0"))
							{
								savingstatus="Opportunity";
							}
							else if(savingstatus.equalsIgnoreCase("-1"))
							{
								savingstatus="Production";
							}
							System.out.println("Rule-"+actverule+";Dpkey-"+Activeruledpkey+";svgstatus-"+savingstatus+";rawsvgs-"+rawsavings+";RR-"+RR);
							activeruleRRdata.add("Rule-"+actverule+";Dpkey-"+Activeruledpkey+";svgstatus-"+savingstatus+";rawsvgs-"+rawsavings+";RR-"+RR);
						}
					}
					else
					{
						System.out.println("Rule-"+midrule.trim()+";Dpkey-;svgstatus-;rawsvgs-0;RR-"+RR);
						activeruleRRdata.add("Rule-"+midrule.trim()+";Dpkey-;svgstatus-;rawsvgs-0;RR-"+RR);
					}
				}
				
				
				
			}
			
		}	
		System.out.println(activeruleRRdata.size());
		return activeruleRRdata;
	}
	
	//#######################################################################################################################

	public static String getRVATopicswithNoDisposition(
			String payershort,
			String insurance,String claimtype,String LCD,String svgstatus)
	{
		boolean bstatus=false;
		String sTopic=null;
		String sDPkeys=null;
		String sRequiredtopic=null;
		List<String> dpkeySize=null;
		ArrayList<Long> dps=new ArrayList<>();
		ArrayList<String> TopicswithDPs=new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
		if(svgstatus.isEmpty())
		{
			//To load the pps and LCD in arraylist
			loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
		}
		else
		{
			loadThePPSandOpportunityLCDinList(payershort, insurance, claimtype, LCD);
		}
				
		ConnectTogivenDBandCollection("cpd", "oppty");
		//
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0),
					  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("latestClientDecision.cdmDecision", ProjectVariables.lCDlist)
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		results=mColl.find(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
				"$subRule.hierarchy.topicDesc",
				Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey")
				))).allowDiskUse(true);
		//To verify whether dps are there or not in eLLhierarchy collection as per the new logic
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		
		for (Document document : output) 
		{
			//System.out.println(document);
			sTopic=StringUtils.substringBetween(String.valueOf(document), "_id=", ", DPkeys");
			sDPkeys=StringUtils.substringBetween(String.valueOf(document), "DPkeys=[", "]}}");
			dpkeySize=Arrays.asList(sDPkeys.split(","));
			for (int i = 0; i < dpkeySize.size(); i++) 
			{
				dps.add(Long.valueOf(dpkeySize.get(i).trim()));
			}
			MatchFilter = Filters.and(
					  Filters.eq("subRule.hierarchy.topicDesc", sTopic),
					  Filters.in("subRule.hierarchy.dpKey", dps),
					  Filters.eq("rvaPayerSwitch", -1)
					  );
			recordsCount = mColl.count(MatchFilter);
			if(recordsCount!=0)
			{
				//System.out.println(sTopic+"::"+dpkeySize.size()+"::"+sDPkeys);
				TopicswithDPs.add(sTopic+"::"+sDPkeys);
				if(dpkeySize.size()>3)
				{
					sRequiredtopic=sTopic;
				}
			}
			
			
		}	
		System.out.println("RVA TopicDPsize::"+TopicswithDPs.size());
		if(!svgstatus.isEmpty())
		{
			//To verify whether dps are having only opportunity decisions in latest decisoin collection
			ConnectTogivenDBandCollection("cdm", "latestDecision");
			ProjectVariables.lCDlist=Arrays.asList(ProjectVariables.LCDWithProduction.split(","));
			for (String data : TopicswithDPs) 
			{
				sTopic=StringUtils.substringBefore(data, "::");
				sDPkeys=StringUtils.substringAfter(data, "::");
				dpkeySize=Arrays.asList(sDPkeys.split(","));
				for (int i = 0; i < dpkeySize.size(); i++) 
				{
					MatchFilter = Filters.and(Filters.eq("_id.dpKey", Long.valueOf(dpkeySize.get(i).trim())),
							  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
							  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
							  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
							  Filters.in("decStatusDesc", ProjectVariables.lCDlist)
							  );
					recordsCount = mColl.count(MatchFilter);
					if(recordsCount==0)
					{
						
						bstatus=true;;
						sRequiredtopic=sTopic;
						break;
					}
				}
				if(bstatus)
				{
					break;
				}
			}
		}
		if(TopicswithDPs.isEmpty())
		{
			Assert.assertTrue("No oppty topic/dpkeys is avaiavle in eLLhierarchy collcetion", false);
		}
		System.out.println("Re::"+sRequiredtopic+",Dpkeys::"+sDPkeys);
		return sRequiredtopic;
	}

	public static String geteLLTopicswithNodisposition(String payershort,String insurance,String claimtype,String LCD
			,String svgstatus)
	{
		HashSet<Long> dpKeys=new HashSet<>();
		HashSet<String> MPs=new HashSet<>();
		HashSet<String> ExactTopicswithDPs=new HashSet<>();
		HashSet<String> Topics=new HashSet<>();
		Bson MatchFilter = new BsonDocument();
		String sTopic=null;
		AggregateIterable<Document> output=null;
		String sDPkey=null;
		ArrayList<Long> DPs=new ArrayList<>();
		ArrayList<String> dpKeysList=new ArrayList<>();
		HashSet<Long> rvapayerSwitchList=new HashSet<>();
		List<String> MPList = new ArrayList<>();
		List<String> DpKeys= new ArrayList<>();
		HashSet<String> TopicswithDPs=new HashSet<>();
		HashSet<String> RequiredTopics=new HashSet<>();
		int i=0;	
		String dps=null;
		boolean bstatus=false;
		if(svgstatus.isEmpty())
		{
			//To load the pps and LCD in arraylist
			loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
		}
		else
		{
			loadThePPSandOpportunityLCDinList(payershort, insurance, claimtype, LCD);
		}
				
		//################ To retrieve the DPkeys for the pps #######################################				
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("decStatusDesc", ProjectVariables.lCDlist));
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			Document iddoc=doc.get("_id",Document.class);
			dpKeys.add(iddoc.getLong("dpKey"));
		}
		System.out.println("DPKeysize::"+dpKeys.size());		
		
	//################ To retrieve the MP and Topics for the DPkeys #######################################
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		MatchFilter = Filters.and(Filters.in("_id.dpKey", dpKeys),Filters.eq("rvaPayerSwitch", 0),
				Filters.eq("subRule.hierarchy.dpTypeDesc", "Rules"));
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		for (Document doc : results) 
		{
			Document idDoc=doc.get("_id",Document.class);
			Document suRuledoc=doc.get("subRule",Document.class);
			Document hierarchydoc=suRuledoc.get("hierarchy",Document.class);
			Topics.add(hierarchydoc.getString("topicDesc"));
		}
	//################ To retrieve the MPs with corresponding DPkeys #######################################
		for (String topic : Topics) 
		{
			MatchFilter = Filters.and(
						  Filters.eq("subRule.hierarchy.topicDesc", topic),
						  Filters.eq("rvaPayerSwitch", 0),
						  Filters.eq("subRule.hierarchy.dpTypeDesc", "Rules")
						  );
			Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
			output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(new Document().
					append("Topic", "$subRule.hierarchy.topicDesc").append("MP",
					"$subRule.hierarchy.medPolicyDesc").
					append("dpKey", "$subRule.hierarchy.dpKey").append("rvapayerSwitch", "$rvaPayerSwitch"),
					Accumulators.addToSet("DPKeys", "$subRule.hierarchy.dpKey"),
					Accumulators.addToSet("rvaPayerswitch", "$rvaPayerSwitch"),
					Accumulators.addToSet("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc")
					))).allowDiskUse(true);
			for (Document document : output) 
			{
				sDPkey=StringUtils.substringBetween(String.valueOf(document),"DPKeys=[","], rvaPayerswitch").trim();
				if(sDPkey.contains("."))
				{
					sDPkey=StringUtils.substringBefore(sDPkey,".");
					//System.out.println(document);
				}
				ExactTopicswithDPs.add(topic+"::"+sDPkey);
				
			}
		}
	//####################### Verify the dpkey is having 'None' decision or not #########################################
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		
		for (String topic : ExactTopicswithDPs) 
		{
			sTopic=StringUtils.substringBefore(topic,"::");
			sDPkey=StringUtils.substringAfter(topic,"::");
			Serenity.setSessionVariable("DPkey").to(StringUtils.substringAfter(topic,"::"));
			MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.in("decStatusDesc", ProjectVariables.lCDlist),
						  Filters.eq("_id.dpKey", Long.valueOf(sDPkey))
						  );
			recordsCount = mColl.count(MatchFilter);
			if(recordsCount!=0)
			{
				RequiredTopics.add(sTopic.trim());
				TopicswithDPs.add(sTopic+"::"+sDPkey);
			}
		}
 //####################### Verify the dpkey is having rvaPayerswitch is '0' only #########################################
		ExactTopicswithDPs.clear();
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		for (String topic : RequiredTopics) 
		{
			for (String topicwithdp : TopicswithDPs) 
			{
				if(topic.equalsIgnoreCase(StringUtils.substringBefore(topicwithdp,"::").trim()))
				{
					
					//Filter to form a match query based on inputs
					MatchFilter = Filters.and(
								  Filters.eq("subRule.hierarchy.topicDesc", StringUtils.substringBefore(topicwithdp,"::").trim()),
								  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(StringUtils.substringAfter(topicwithdp,"::").trim()))
								  );
					Distinctresults_with_long  = mColl.distinct("rvaPayerSwitch",MatchFilter,Long.class);
					for (Long rvapayeswitch:Distinctresults_with_long) 
					{
						rvapayerSwitchList.add(rvapayeswitch);
					}
					if(rvapayerSwitchList.size()==1&&rvapayerSwitchList.contains(0l))
					{
						dpKeysList.add(StringUtils.substringAfter(topicwithdp,"::").trim());
					}
					rvapayerSwitchList.clear();
				}
			
			}
			 dps=String.join(",", dpKeysList);
			if(dpKeysList.size()!=0)
			{
				ExactTopicswithDPs.add(topic+"::"+dps);
			}
			dpKeysList.clear();
		}
//####################### Verify the dpkey is captured or not #########################################	
		ConnectTogivenDBandCollection("cpd", "oppty");
		for (String eLLdata : ExactTopicswithDPs) 
		{
			sTopic=StringUtils.substringBefore(eLLdata, "::").trim();
			DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
			for (int j = 0; j < DpKeys.size(); j++)
			{
				//Filter to form a match query based on inputs
				MatchFilter = Filters.and(
							Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							  Filters.eq("subRule.hierarchy.topicDesc", sTopic),
							  Filters.eq("disposition.desc", "No Disposition"),
							  Filters.eq("ruleInBaseLine", 0),
							  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DpKeys.get(j).trim()))
							  );
				recordsCount = mColl.count(MatchFilter);
				dps=String.join(",", DpKeys);
				if(recordsCount!=0)
				{
					ProjectVariables.DB_Topiclist.add(sTopic+"::"+dps);
				}
			}
		}
		
		for (String eLLdata : ProjectVariables.DB_Topiclist) {
			DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
			if(DpKeys.size()>3)
			{
				bstatus=true;
				sTopic=StringUtils.substringBefore(eLLdata, "::");
			}
			System.out.println(StringUtils.substringBefore(eLLdata, "::")+"::"+DpKeys.size()+"::"+DpKeys);
		}
		System.out.println("eLL Topicsize::"+ProjectVariables.DB_Topiclist.size());
		if(ProjectVariables.DB_Topiclist.isEmpty())
		{
			Assert.assertTrue("No eLL Topics are available for the client/PPS", false);
		}
		if(bstatus=false)
		{
			Assert.assertTrue("No eLL Topics with more than 3 DPs are available for the client/PPS", false);
		}
		
		if(!svgstatus.isEmpty())
		{
			//To verify whether dpkeys are having opportunity data or not
			ConnectTogivenDBandCollection("cdm", "latestDecision");
			ProjectVariables.lCDlist=Arrays.asList(ProjectVariables.LCDWithProduction.split(","));
			for (String eLLdata : ProjectVariables.DB_Topiclist) 
			{
				sTopic=StringUtils.substringBefore(eLLdata, "::");
				DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
				for (int j = 0; j < DpKeys.size(); j++) 
				{
					MatchFilter = Filters.and(Filters.eq("_id.dpKey", Long.valueOf(DpKeys.get(j).trim())),
							  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
							  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
							  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
							  Filters.in("decStatusDesc", ProjectVariables.lCDlist)
							  );
					recordsCount = mColl.count(MatchFilter);
					if(recordsCount==0)
					{
						bstatus=true;;
						break;
					}
				}
				if(bstatus)
				{
					break;
				}
			}
		}
		Serenity.setSessionVariable("DPkey").to(DpKeys);
		System.out.println("Re::"+sTopic+","+DpKeys);
		return sTopic;
	
	}

	public static String getMPwithallDPtypes(String clientkey,
			String payershort)
	{
		int i=0;
		String sMP=null;
		String sDptype=null;
		String sRequiredtopic=null;
		List<String> dpTypesSize=null;
		ArrayList<String> MPs=new ArrayList<>();
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output=null;
		//To load the pps and LCD in arraylist
		loadThePPSandLCDinList(payershort,"","","");
		
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					  Filters.eq("disposition.desc", "Present"),
					  Filters.eq("ruleInBaseLine", 0)
					  );
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter::"+MatchFilter, false);
		}
		results=mColl.find(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		//Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
				"$subRule.hierarchy.medPolicyDesc")));
		for (Document document : output) 
		{
			//System.out.println(document);
			sMP=StringUtils.substringBetween(String.valueOf(document), "_id=", "}}");
			MPs.add(sMP);
		}	
		
		System.out.println("MPSize::"+MPs.size());
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		for (String mp : MPs) {
			
			MatchFilter = Filters.and(Filters.eq("subRule.hierarchy.medPolicyDesc", mp));
			matchtext = Aggregates.match(Filters.and(MatchFilter));
			//Aggregate filter to retrieve the output
			output = mColl.aggregate(Arrays.asList(matchtext,Aggregates.group(
					"$subRule.hierarchy.medPolicyDesc",Accumulators.addToSet("DPTypes", "$subRule.hierarchy.dpTypeDesc"))));
			for (Document document : output) 
			{
				//System.out.println(document);
				sDptype=StringUtils.substringBetween(String.valueOf(document), "DPTypes=[", "]}}");
				dpTypesSize=Arrays.asList(sDptype.split(","));
				if(dpTypesSize.size()>1)
				{
					i=i+1;
					System.out.println(mp+"::"+sDptype);
				}
			}
		}
		System.out.println("Multiple DPtype MPs::"+i);
		return sRequiredtopic;
	}
	
	public static Long DispositionRecordsinMongoDBForgivenPayerLOBinAWBPage(
			String disposition,String pagename) {
		//To connecto to database
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		
		switch (pagename) {
		case "RVA":
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("DPkey"))),
						Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0),
					  Filters.in("_id.payerShort", ProjectVariables.payerShortList),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.ne("latestClientDecision.cdmDecision", null)
					);
		break;

		case "RWO":
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(Serenity.sessionVariableCalled("DPkey"))),
					Filters.eq("disposition.desc", "Present"),
				  Filters.eq("ruleInBaseLine", 0),
				  Filters.in("_id.payerShort", ProjectVariables.payerShortList),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.ne("latestClientDecision.cdmDecision", null)
				);

			
		
			break;
			default:
				Assert.assertTrue("Given selection was not found ==>"+pagename, false);
				
			break;

		}
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Disposition_Count for the given Payer/LOB combination:" + recordsCount);
		if (recordsCount == 0) {
			Assert.assertTrue("Record count was 'zero' in the Mongo DB for the given filtering data,Matchfilter:;"+MatchFilter, false);
		}
		return recordsCount;
		
		
	}

	public static Long NoDispositionPayerLOBforeLLDPkey()
	{
		Bson MatchFilter = new BsonDocument();
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
					  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
					  Filters.eq("_id.dpKey", Long.valueOf(Serenity.sessionVariableCalled("DPkey")))
					  );
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			Assert.assertTrue("RecordCount is '0' for the given matchfilter===>"+MatchFilter, false);
		}
		System.out.println("PPS count::"+recordsCount);
		return recordsCount;
	
	}

	public static void getRVAMPsforNoneScenarios(String payershort,String insurance,String claimtype,String LCD) {
		int i=0;
		boolean bstatus=false;
		//String lcd=null;
		Bson matchtext =null;
		String dpkey=null;
		String rawsavings=null;
		String aggsavings=null;
		String consavings=null;
		String midRuleclaimtypes=null;
		ArrayList<String> lcd = new ArrayList<String>();
		ArrayList<String> Disposition = new ArrayList<>();
		ArrayList<String> MPList = new ArrayList<>();
		List<String> dpKeyList = new ArrayList<>();
		List<String> midruleCalimtypeList = new ArrayList<>();
		AggregateIterable<Document> output3 =null;
		ProjectVariables.DB_NoneMPlist.clear();
		//List<String> LCDlist=Arrays.asList("Approve Library,Approve With Modifications");
		//Intialaize the payershort,claimtype and insurance queries
		loadThePPSandLCDinList(payershort, insurance, claimtype, LCD);
		if(ProjectVariables.lCDlist.contains("None"))
		{	
			lcd.add(null);
			lcd.addAll(ProjectVariables.lCDlist);
		}
		else
		{
			lcd.addAll(ProjectVariables.lCDlist);
		}
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				//Filters.eq("disposition.desc", "No Disposition"),
				  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("latestClientDecision.cdmDecision",lcd)
				  );
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered Record count ==>" + recordsCount);
		 matchtext = Aggregates.match(Filters.and(MatchFilter));
		 output3 = mColl.aggregate(Arrays.asList(matchtext,
				   Aggregates.group("$subRule.hierarchy.medPolicyDesc",Accumulators.sum("Raw savings", "$annualSavings.raw"),
						Accumulators.sum("Agg savings", "$annualSavings.agg"),
						Accumulators.sum("Con savings", "$annualSavings.con"),
						Accumulators.addToSet("dpkey", "$subRule.hierarchy.dpKey"))));
		// Connection method for Mongo DB
		ConnectTogivenDBandCollection("cdm", "latestDecision");

		for (Document document : output3) 
		{
			//System.out.println(document);
			i = i + 1;
			String medicalpolicy=StringUtils.substringBetween(document.toString(), "_id=", ", Raw");
			 rawsavings=StringUtils.substringBetween(document.toString(), "Raw savings=", ", Agg");
			 consavings=StringUtils.substringBetween(document.toString(), "Con savings=", ", LCD");
			 aggsavings=StringUtils.substringBetween(document.toString(), "Agg savings=", ", Con");
			dpkey=StringUtils.substringBetween(document.toString(), "dpkey=[", "]}}");
			dpKeyList=Arrays.asList(dpkey.split(","));
			if(!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Specialty Policy")&&!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Global Policy"))
			{	
				for (int j = 0; j < dpKeyList.size(); j++)
				{
					MatchFilter = Filters.and( 
							//Filters.eq("disposition.desc", "No Disposition"),
							  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
							  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
							  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
							  Filters.in("_id.dpKey", Long.valueOf(dpKeyList.get(j).trim())),
							  Filters.in("decStatusDesc",ProjectVariables.lCDlist)
							  );
					recordsCount = mColl.count(MatchFilter);
					//if(recordsCount<ProjectVariables.PPSList.size())
					if(recordsCount<10)
					{
						String row=medicalpolicy+";Raw-"+rawsavings+";Agg-"+aggsavings+";Con-"+consavings;
						System.out.println(medicalpolicy);
						MPList.add(medicalpolicy);
						ProjectVariables.DB_NoneMPlist.add(medicalpolicy);	
						bstatus=true;
					}
					if(bstatus)
					{
						bstatus=false;
						break;
					}
					
				}
			}
			
		}
		
		if (ProjectVariables.DB_NoneMPlist.isEmpty()) 
		{
			Assert.assertTrue("Mecial policies is 'null' in the Mongo DB for the given matchfilter==>"+MatchFilter, false);
		}
		System.out.println(ProjectVariables.DB_NoneMPlist);
		System.out.println("None RVA MPsize::" + ProjectVariables.DB_NoneMPlist.size());


	}
	
	public static void geteLLMPsfornone(
			String payershort,String insurance,String claimtype,String LCD)
	{
		boolean bstatus=false;
		List<String> DpKeys=null;
		String medicalpolicy=null;
		Bson MatchFilter = new BsonDocument();
		ArrayList<String> dpKeyList = new ArrayList<>();
		
		
		//To retrieve MPs and Topics from elldatabase
		retrieveTheeLLMPsbasedonPPSforFilterPanel(payershort,insurance,claimtype,LCD);
		
		//Intialaize the payershort,claimtype and insurance queries
		loadThePPSandLCDinList(payershort, insurance, claimtype, LCD);
						
		// Connection method for Mongo DB
		retrieveAllDocuments("cdm", "latestDecision");
		System.out.println("############################# None MPs verifications start #############################");
		
		for (String eLLdata : ProjectVariables.DB_MPlist)
		{
			DpKeys=Arrays.asList(StringUtils.substringAfter(eLLdata, "::").split(","));
			medicalpolicy=StringUtils.substringBefore(eLLdata, "::");
			/*if(medicalpolicy.equalsIgnoreCase("Multiple Procedure Reduction for Therapy Services Policy"))
			{
				//System.out.println("hiiiiiiiiii");
			}*/
			for (String dp : DpKeys) 
			{
				MatchFilter = Filters.and(Filters.in("_id.payerKey", ProjectVariables.payerKeys),
						  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
						  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
						  Filters.in("decStatusDesc", ProjectVariables.lCDlist),
							  Filters.eq("_id.dpKey", Long.valueOf(dp))
							  );
				recordsCount = mColl.count(MatchFilter);
				if(recordsCount<ProjectVariables.PPSList.size())
				//if(recordsCount<10)
				{
					dpKeyList.add(dp);
					//MPList.add(medicalpolicy);
					bstatus =true;
				}
				if(bstatus)
				{
					ProjectVariables.DB_NoneMPlist.add(medicalpolicy);
					//System.out.println(medicalpolicy);
				}
				bstatus=false;
			
			}
			
			
		}
		
		for (String mp : ProjectVariables.DB_NoneMPlist) {
			System.out.println(mp);
		}
		
		System.out.println("None eLLMPs size::"+ProjectVariables.DB_NoneMPlist.size());		
	}
	
	public static boolean verifygivenMPishavingNonedecision(String MP,
			String payershort,String insurance,String claimtype,String LCD) {
		boolean bstatus=false;
		Bson matchtext =null;
		String dpkey=null;
		List<String> dpKeyList = new ArrayList<>();
		AggregateIterable<Document> output3 =null;
		Bson MatchFilter = new BsonDocument();
		//Intialaize the payershort,claimtype and insurance queries
		loadThePPSandLCDinList(payershort, insurance, claimtype, LCD);
		// Connection method for Mongo DB
		ConnectTogivenDBandCollection("cpd", "oppty");
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
							Filters.eq("subRule.hierarchy.medPolicyDesc", MP.trim())
					  		);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered Record count ==>" + recordsCount);
		 matchtext = Aggregates.match(Filters.and(MatchFilter));
		 output3 = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group("$subRule.hierarchy.medPolicyDesc",
						Accumulators.addToSet("dpkey", "$subRule.hierarchy.dpKey"))));
		// Connection method for Mongo DB
		 ConnectTogivenDBandCollection("cdm", "latestDecision");
		for (Document document : output3) 
		{
			//Document{{_id=Urology Policy, dpkey=[9797, 4715, 6641, 5147, 4717, 4702]}}
			//System.out.println(document);
			String medicalpolicy=StringUtils.substringBetween(document.toString(), "_id=", ", dpkey");
			dpkey=StringUtils.substringBetween(document.toString(), "dpkey=[", "]}}");
			dpKeyList=Arrays.asList(dpkey.split(","));
			
				for (int j = 0; j < dpKeyList.size(); j++)
				{
					MatchFilter = Filters.and(
							  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
							  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
							  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
							  Filters.eq("_id.dpKey", Long.valueOf(dpKeyList.get(j).trim()))
							  );
					recordsCount = mColl.count(MatchFilter);
					if(recordsCount<ProjectVariables.PPSList.size())
					//if(recordsCount<10)
					{
						bstatus=true;
					}
					if(bstatus)
					{
						bstatus=false;
						break;
					}
					
				}
		}
		
		if(!bstatus)
		{
			// Connection method for Mongo DB
			ConnectTogivenDBandCollection("cpd", "ellHierarchy");
			Distinctresults_with_long=mColl.distinct("subRule.hierarchy.dpKey",Filters.eq("subRule.hierarchy.medPolicyDesc", MP.trim()), Long.class);
			// Connection method for Mongo DB
			ConnectTogivenDBandCollection("cdm", "latestDecision");
			
			for (Long dp : Distinctresults_with_long) 
			{
				MatchFilter = Filters.and(
						  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
						  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
						  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
						  Filters.eq("_id.dpKey", dp)
						  );
				recordsCount = mColl.count(MatchFilter);
				if(recordsCount<ProjectVariables.PPSList.size())
				//if(recordsCount<10)
				{
					bstatus=true;
				}
				if(bstatus)
				{
					bstatus=false;
					break;
				}
			}
			
		}
		
		if(bstatus)
		{
			System.out.println("MP '"+MP+"' shouldn't display in filterpanel as it doesn't have dps with 'none' decisions as per latestdecisoin collection and mdm service");
		}
		else
		{
			System.out.println("MP '"+MP+"' should be displayed in filterpanel as it's having dps with 'none' decisions as per latestdecisoin collection and mdm service");	
		}
		
				
		return bstatus;

	}

	public static void verifyMPsinOpptyandeLLhierarchy(String payershort,String insurance,String claimtype,String LCD) {
		int i=0;
		boolean bstatus=false;
		String medicalpolicy=null;
		Bson matchtext =null;
		String dpkey=null;
		ArrayList<String> ndpkeys = new ArrayList<>();
		ArrayList<String> MPList = new ArrayList<>();
		ArrayList<String> DPList = new ArrayList<>();
		List<String> dpKeyList = new ArrayList<>();
		AggregateIterable<Document> output3 =null;
		ProjectVariables.DB_NoneMPlist.clear();
		List<String> LCDlist=Arrays.asList("Approve Library,Approve With Modifications");
		//Intialaize the payershort,claimtype and insurance queries
		loadThePPSandLCDinList(payershort, insurance, claimtype, LCD);
				
		// Connection method for Mongo DB
		retrieveAllDocuments("cpd", "oppty");

		Bson MatchFilter = new BsonDocument();
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
				 Filters.eq("disposition.desc", "No Disposition"),
				  Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.eq("ruleInBaseLine",0),
				  Filters.eq("latestClientDecision.cdmDecision",null)
				  );
		results = mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("Filtered Record count ==>" + recordsCount);
		 matchtext = Aggregates.match(Filters.and(MatchFilter));
		 output3 = mColl.aggregate(Arrays.asList(matchtext,
				 		 Aggregates.group("$subRule.hierarchy.medPolicyDesc",
						 Accumulators.addToSet("dpkey", "$subRule.hierarchy.dpKey"))));
		//Connection method for Mongo DB
		retrieveAllDocuments("cpd", "ellHierarchy");

		for (Document document : output3) 
		{
			//System.out.println(document);
			i = i + 1;
			 medicalpolicy=StringUtils.substringBetween(document.toString(), "_id=", ", dpkey");
			dpkey=StringUtils.substringBetween(document.toString(), "dpkey=[", "]}}");
			dpKeyList=Arrays.asList(dpkey.split(","));
			if(!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Specialty Policy")&&!medicalpolicy.equalsIgnoreCase("Unassigned Medical Policy Bucket for iHT Global Policy"))
			{
				for (int j = 0; j < dpKeyList.size(); j++)
				{
					if(!dpKeyList.get(j).trim().equalsIgnoreCase("-1")&&!dpKeyList.get(j).trim().equalsIgnoreCase("-2"))
					{
						MatchFilter = Filters.and(
						  		Filters.eq("_id.dpKey", Long.valueOf(dpKeyList.get(j).trim())),
						  		Filters.eq("subRule.hierarchy.medPolicyDesc", medicalpolicy)
						  	  );
						recordsCount = mColl.count(MatchFilter);
						if(recordsCount==0)
						{
							DPList.add(dpKeyList.get(j).trim());
							ndpkeys.add(dpKeyList.get(j).trim());
						//Assert.assertTrue("MP::"+medicalpolicy+",DPkey::"+dpKeyList.get(j).trim()+", is not avaialable in eLLHerarchy collection", false);
						}
					}
				}
			 }
			
			if(!DPList.isEmpty())
			{
				//System.out.println(medicalpolicy+"::"+DPList.size()+"::"+DPList);
				System.out.println("Medicalpolicy::"+medicalpolicy+";DPkeys::"+DPList);
				MPList.add(medicalpolicy+"::"+DPList.size()+"::"+DPList);
			}
			DPList.clear();
			
		}
		
		System.out.println("MPs Size::"+MPList.size());
		System.out.println("DPs Size::"+ndpkeys.size());
	}
	
	public static String getmidRuleClaimtypeineLLhierarchy(String dpkey) {
		int i=0;
		boolean bstatus=false;
		Bson matchtext =null;
		String midruleclaimtypes=null;
		ArrayList<String> ndpkeys = new ArrayList<>();
		ArrayList<String> MPList = new ArrayList<>();
		ArrayList<String> DPList = new ArrayList<>();
		List<String> dpKeyList = new ArrayList<>();
		AggregateIterable<Document> output3 =null;
		Bson MatchFilter = new BsonDocument();
		
		//Connection method for Mongo DB
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		MatchFilter = Filters.and(
		  		Filters.eq("_id.dpKey", Long.valueOf(dpkey))
		  		);
		results=mColl.find(MatchFilter);
		recordsCount=mColl.count(MatchFilter);
		if(recordsCount==0)
		{
			GenericUtils.Verify("Record count is zero in eLLhierarchy for the dpkey::"+dpkey+",so unable to find midRuleclaimtypes", false);
		}

		for (Document document : results) 
		{
			Document subruledoc=document.get("subRule",Document.class);
			Document hierarcydoc=subruledoc.get("hierarchy",Document.class);
			midruleclaimtypes=hierarcydoc.getString("midRuleClaimTypes");
		}
		System.out.println("DPKey::"+dpkey+",midruleclaimtypes::"+midruleclaimtypes);
		return midruleclaimtypes;
	}

	public static boolean verifygivenPPSiscapturedOrNot(String DPKey,
			String UIpayershort,String UIinsurance,String UIclaimtype,String UILCD)
	{
		boolean bstatus=false;
		Bson MatchFilter = new BsonDocument();
					
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("_id.payerShort", UIpayershort),
					  Filters.eq("insuranceDesc", UIinsurance),
					  Filters.eq("_id.claimType", UIclaimtype),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(DPKey)),
					  Filters.eq("disposition.desc", "No Disposition")
					  );
		
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cpd", "oppty");
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			System.out.println("The given PPS is already Captured,"+UIpayershort+"::"+UIinsurance+"::"+UIclaimtype+",DPkey::"+DPKey);
			return true;
		}
		System.out.println("The given PPS is not yet Captured,"+UIpayershort+"::"+UIinsurance+"::"+UIclaimtype+",DPkey::"+DPKey);
		return false;
	}

	//############################### To retrieve the PPS for the given RR DPkey ###############################################3
	
	public static ArrayList<String> getPPSforRRDPkey(String activeDPkey, String payershort,
			String activeRule,String rulerelation,String claimtype)
	{
		boolean bstatus=false;
		String sinsurance=null;
		String sClaimtype=null;
		Bson MatchFilter = new BsonDocument();
		ArrayList<String> PPSList=new ArrayList<>();
					
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("_id.payerShort", payershort),
					  Filters.eq("_id.subRuleId", activeRule),
					  Filters.eq("_id.claimType", claimtype),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(activeDPkey)),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0)
					  
					  );
		
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cpd", "oppty");
		
		results=mColl.find(MatchFilter);
		
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			System.out.println("NO PPS are avaialble for given RR DPkey and Payershort::"+MatchFilter);
			return PPSList;
		}
		
		for (Document doc : results) 
		{
			Document Iddoc=doc.get("_id",Document.class);
			sinsurance=doc.getString("insuranceDesc");
			sClaimtype=Iddoc.getString("claimType");
			if(ProjectVariables.PPSList.contains(payershort+":"+sinsurance+":"+sClaimtype))
			{
				PPSList.add("Dpkey-"+activeDPkey+";Payershort-"+payershort+";Insurance-"+sinsurance+";Claimtype-"+sClaimtype+";Subrule-"+activeRule+";RR-"+rulerelation);
				System.out.println("Dpkey-"+activeDPkey+";Payershort-"+payershort+";Insurance-"+sinsurance+";Claimtype-"+sClaimtype+";Subrule-"+activeRule+";RR-"+rulerelation);
			
			}
		}
		System.out.println("ActivePPS size::"+PPSList.size());
		return PPSList;
	}
	
	/*public static ArrayList<String> getPPSforRRDPkey(String activeDPkey, String payershort,
			String activeRule,String rulerelation)
	{
		boolean bstatus=false;
		String sinsurance=null;
		String sClaimtype=null;
		Bson MatchFilter = new BsonDocument();
		ArrayList<String> PPSList=new ArrayList<>();
					
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					Filters.eq("_id.payerShort", payershort),
					  Filters.eq("_id.subRuleId", activeRule),
					  //Filters.eq("_id.claimType", claimtype),
					  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(activeDPkey)),
					  Filters.eq("disposition.desc", "No Disposition"),
					  Filters.eq("ruleInBaseLine", 0)
					  
					  );
		
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cpd", "oppty");
		results=mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			System.out.println("NO PPS are avaialble for given RR DPkey and Payershort::"+MatchFilter);
			return PPSList;
		}
		
		for (Document doc : results) 
		{
			Document Iddoc=doc.get("_id",Document.class);
			sinsurance=doc.getString("insuranceDesc");
			sClaimtype=Iddoc.getString("claimType");
			if(ProjectVariables.PPSList.contains(payershort+":"+sinsurance+":"+sClaimtype))
			{
				PPSList.add("Dpkey-"+activeDPkey+";Payershort-"+payershort+";Insurance-"+sinsurance+";Claimtype-"+sClaimtype+";Subrule-"+activeRule+";RR-"+rulerelation);
				System.out.println("Dpkey-"+activeDPkey+";Payershort-"+payershort+";Insurance-"+sinsurance+";Claimtype-"+sClaimtype+";Subrule-"+activeRule+";RR-"+rulerelation);
			
			}
		}
		System.out.println("ActivePPS size::"+PPSList.size());
		return PPSList;
	}*/

	//############################### verify given RR DPkey and PPS is captured or not ###############################################

	public static void verifygivenRRPPSiscapturedOrNot(HashSet<String> PPSlist,String sDisposition)
	{
		boolean bstatus=false;
		String Disposition=null;
		Bson MatchFilter = new BsonDocument();
		//To connect to given db and collection		
		ConnectTogivenDBandCollection("cpd", "oppty");
		for (String pps : PPSlist) 
		{
			String dpkey=StringUtils.substringBetween(pps, "Dpkey-", ";Payershort");
			String payershort=StringUtils.substringBetween(pps, "Payershort-", ";Insurance");
			String Insurance=StringUtils.substringBetween(pps, "Insurance-", ";Claimtype");
			String Claimtype=StringUtils.substringBetween(pps, "Claimtype-", ";Subrule");
			String Subrule=StringUtils.substringBetween(pps, "Subrule-", ";RR");
			String RR=StringUtils.substringAfterLast(pps, "RR-");
			
			if(RR.contains("MUTUALLY EXCLUSIVE"))
			{
				Disposition="No Disposition";
			}
			else
			{
				Disposition=sDisposition;
			}
			//Filter to form a match query based on inputs
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
						Filters.eq("_id.payerShort", payershort),
						Filters.eq("_id.subRuleId", Subrule),
						  Filters.eq("insuranceDesc", Insurance),
						  Filters.eq("_id.claimType", Claimtype),
						  Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey)),
						  Filters.eq("disposition.desc", Disposition)
						  );
			
			recordsCount = mColl.count(MatchFilter);
			System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
			if(recordsCount==0)
			{
				GenericUtils.Verify("Record count is zero for captured RR dpkey and PPS::"+MatchFilter+",RR::"+RR, false);
			}
			else
			{
				GenericUtils.Verify("Disposition is captured successfully for RR dpkey and PPS::"+pps+",Disposition::"+Disposition, true);
			}
			
		}
					
		
	}

	// ==================================================================================================================================================>
		public static void Check_the_captured_record_exists_or_not() {

			/*if(Serenity.sessionVariableCalled("user").toString()=="nkumar")
			{
				Serenity.setSessionVariable("user").to("natuva");
			}*/
			// Method to connect mongoDB
			retrieveAllDocuments("cpd", "oppty");

			Bson MatchFilter = new BsonDocument();

			// Filter to form a match query based on inputs
			MatchFilter = Filters.and(
					Filters.eq("_id.clientKey", Long.valueOf(Serenity.sessionVariableCalled("clientkey"))),
					//Filters.eq("_id.dataVersion", java.util.regex.Pattern.compile(ProjectVariables.DataVersion)),
					Filters.eq("ruleInBaseLine", 0),
					Filters.eq("disposition.desc", Serenity.sessionVariableCalled("Disposition")),
					Filters.eq("subRule.hierarchy.medPolicyDesc", Serenity.sessionVariableCalled("Medicalpolicy")),
					Filters.eq("subRule.hierarchy.topicDesc", Serenity.sessionVariableCalled("Topic")),
					Filters.eq("subRule.hierarchy.dpKey", ProjectVariables.CapturedDPkey),
					Filters.eq("disposition.userId", Serenity.sessionVariableCalled("user")),
					Filters.eq("source", Serenity.sessionVariableCalled("source")));
			// ,Filters.ne("annualSavings.lines",0)
			recordsCount = mColl.count(MatchFilter);
			System.out.println("Filtered_Count:" + recordsCount);

			if (recordsCount == 0) 
			{
				System.out.println(MatchFilter);
				Assert.assertTrue(
						"Captured record was not available in DB from service,MtchFilter==>"+MatchFilter,false);
			} else {
				System.out.println("Captured record was available in DB from service,MatchFilter==>"
						+ MatchFilter);
			}

		}
	
		
		// To retrieve the DPkeys with NoDisposition
		public static void GetAvailableDPKeyfromCPW(String Clientkey, String DPKeyCriteria, int NoofInsuranceKeys) {
			boolean bstatus = false;
			String Payerkeys = null;
			String Release = null;
			String Medicalpolicy = null;
			String Topic = null;
			String DPKey = null;
			// String Clientkey=null;
			String InsuranceKeys = null;
			List<String> InsuranceKeysList = null;
			List<String> DPkeysList = null;
			List<String> payerkeysList = null;
			AggregateIterable<Document> output = null;

			// Method to connect mongoDB
			ConnectTogivenDBandCollection("cpd", "oppty");

			Bson MatchFilter = new BsonDocument();

			// Filter to form a match query based on inputs
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(Clientkey)),
					Filters.eq("disposition.desc", "No Disposition"),
					Filters.eq("ruleInBaseLine", 0));

			recordsCount = mColl.count(MatchFilter);
			System.out.println("Filtered_Count for the client key '" + Clientkey + "':" + recordsCount);
			System.out.println("Filtered_Count for the client key '" + Clientkey + "':" + recordsCount + ",Time==>"
					+ GenericUtils.getDateGivenFormat("dd/MM/yyyy h:mm:ss a"));

			if (recordsCount == 0) 
			{
				Assert.assertTrue(
						"Record count was zero for the given Clientkey==>" + Clientkey + ",Disposition==>No Disposition",
						false);
			}

			Bson matchtext = Aggregates.match(Filters.and(MatchFilter));

			if (DPKeyCriteria.contains("Single")) 
			{
				// Aggregate filter to retrieve the output
				output = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group(
								new Document().append("DPKey", "$subRule.hierarchy.dpKey").append("Release",
										"$_id.dataVersion"),
								Accumulators.addToSet("Payerkeys", "$_id.payerKey"),
								Accumulators.addToSet("Release", "$_id.dataVersion"),
								Accumulators.addToSet("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc"),
								Accumulators.addToSet("Topic", "$subRule.hierarchy.topicDesc"),
								Accumulators.addToSet("Clientkey", "$_id.clientKey"),
								Accumulators.addToSet("InsuranceKeys", "$_id.insuranceKey"))));

			} 
			else if (DPKeyCriteria.equalsIgnoreCase("Multiple"))
			{
				// Aggregate filter to retrieve the output
				output = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group(
								new Document().append("Topic", "$subRule.hierarchy.topicDesc")
								.append("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc").append("Release",
										"$_id.dataVersion"),
								Accumulators.addToSet("Payerkeys", "$_id.payerKey"),
								Accumulators.addToSet("Release", "$_id.dataVersion"),
								Accumulators.addToSet("Medicalpolicy", "$subRule.hierarchy.medPolicyDesc"),
								Accumulators.addToSet("DPkeys", "$subRule.hierarchy.dpKey"),
								Accumulators.addToSet("Clientkey", "$_id.clientKey"),
								Accumulators.addToSet("InsuranceKeys", "$_id.insuranceKey"))));

			} 
			else 
			{
				Assert.assertTrue("Case not found -->" + DPKeyCriteria, false);
			}

			// Loop to retrieve the output
			for (Document document : output) 
			{

				Payerkeys = StringUtils.substringBetween(String.valueOf(document), "Payerkeys=[", "], Release");
				Release = StringUtils.substringBetween(String.valueOf(document), "Release=[", "], Medicalpolicy");
				Medicalpolicy = StringUtils.substringBetween(String.valueOf(document), "Medicalpolicy=[", "], Topic");
				Clientkey = StringUtils.substringBetween(String.valueOf(document), "Clientkey=[", "], InsuranceKeys");
				InsuranceKeys = StringUtils.substringBetween(String.valueOf(document), "InsuranceKeys=[", "]}}");

				payerkeysList = Arrays.asList(Payerkeys.split(","));
				InsuranceKeysList = Arrays.asList(InsuranceKeys.split(","));

				if (payerkeysList.size() > 2 && InsuranceKeysList.size() > NoofInsuranceKeys) 
				{
					if (DPKeyCriteria.contains("Single")) 
					{
						System.out.println(document);
						DPKey = StringUtils.substringBetween(String.valueOf(document), "DPKey=", ", Release");
						if (!DPKey.contains("-")) 
						{
							Topic = StringUtils.substringBetween(String.valueOf(document), "Topic=[", "], Clientkey");
							Medicalpolicy = StringUtils.substringBetween(String.valueOf(document), "Medicalpolicy=[",
									"], Topic");

							Serenity.setSessionVariable("clientkey").to(Clientkey);
							Serenity.setSessionVariable("DPkey").to(DPKey);
							Serenity.setSessionVariable("release").to(Release);
							Serenity.setSessionVariable("Medicalpolicy").to(Medicalpolicy);
							Serenity.setSessionVariable("Topic").to(Topic);
							Serenity.setSessionVariable("Payerkeys").to(Payerkeys);
							Serenity.setSessionVariable("InsuranceKeys").to(InsuranceKeys);
							bstatus = true;
							// System.out.println(document);
							break;
						}

					} 
					else if (DPKeyCriteria.equalsIgnoreCase("Multiple"))
					{

						DPKey = StringUtils.substringBetween(String.valueOf(document), "DPkeys=[", "], Clientkey");
						if (!DPKey.contains("-")) 
						{
							Topic = StringUtils.substringBetween(String.valueOf(document), "Topic=", ", Medicalpolicy");
							Medicalpolicy = StringUtils.substringBetween(String.valueOf(document), "Medicalpolicy=",
									", Release");

							DPkeysList = Arrays.asList(DPKey.split(","));

							if (DPkeysList.size() > 2) 
							{
								System.out.println(document);
								Serenity.setSessionVariable("clientkey").to(Clientkey);
								Serenity.setSessionVariable("DPkey").to(DPKey);
								Serenity.setSessionVariable("release").to(Release);
								Serenity.setSessionVariable("Medicalpolicy").to(Medicalpolicy);
								Serenity.setSessionVariable("Topic").to(Topic);
								Serenity.setSessionVariable("Payerkeys").to(Payerkeys);
								Serenity.setSessionVariable("InsuranceKeys").to(InsuranceKeys);
								bstatus = true;
								// System.out.println(document);
								break;
							}

						}
					}
				}

			}

			if (Release.contains(","))
			{
				Assert.assertTrue("Reteieved Multiple 'Dataversions' instead of single,Dataversion ==>" + Release
						+ ",Clientkey==>" + Serenity.sessionVariableCalled("clientkey") + ",Medicalpolicy==>"
						+ Serenity.sessionVariableCalled("Medicalpolicy") + ",Topic==>"
						+ Serenity.sessionVariableCalled("Topic") + ",DPkey==>" + Serenity.sessionVariableCalled("DPkey"),
						false);
			}
			if (!bstatus) 
			{

				Assert.assertTrue("Unable to find the records from Mongo DB,for the clientkey=>" + Clientkey
						+ ",DPKeyCriteria=>" + DPKeyCriteria
						+ ",Disposition=>No Disposition,PayerKeys count > 2 and Insurancekeys count > " + NoofInsuranceKeys
						+ "", false);

			}

			System.out.println("Clientkey ==>" + Clientkey);
			System.out.println("DPKeys ==>" + DPKey);
			System.out.println("Payerkeys ==>" + Payerkeys);
			System.out.println("Release ==>" + Release);
			System.out.println("Medicalpolicy ==>" + Medicalpolicy);
			System.out.println("Topic ==>" + Topic);
			System.out.println("InsuranceKeys ==>" + InsuranceKeys);

			System.out.println("Output got at the Time==>" + GenericUtils.getDateGivenFormat("dd/MM/yyyy h:mm:ss a"));

		}
		
		public static boolean getPPSfromthecdm(String dpkey, String clientkey,ArrayList<Long> payerkeys) 
		{
			boolean bstatus=false;
			Bson MatchFilter = new BsonDocument();
			String sPayerkeys=null;
			String sClaimtypes=null;
			String sInsuranceKeys = null;
			List<String> InsuranceKeysList = null;
			List<String> PayerKeysList = null;
			
			AggregateIterable<Document> output = null;
			
			ArrayList<String> arPPS=new ArrayList<>();
			
			List<String> cdmdecisionOpportunity=Arrays.asList(ProjectVariables.LCDWithOpportunity.split(","));
			
			
			//Method to connect mongoDB
			ConnectTogivenDBandCollection("cdm", "latestDecision");
			
			//Filter to form a match query based on inputs
			MatchFilter = Filters.and(Filters.in("_id.payerKey", payerkeys),
					Filters.eq("_id.dpKey", Long.valueOf(dpkey)),
					Filters.in("decStatusDesc", cdmdecisionOpportunity)
					);
			results= mColl.find(MatchFilter);
			recordsCount = mColl.count(MatchFilter);
			Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
			System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
			if(recordsCount==0)
			{
				return false;
			}
			else
			{
				// Aggregate filter to retrieve the output
				output = mColl.aggregate(Arrays.asList(matchtext,
						Aggregates.group("$_id.dpKey",
								Accumulators.addToSet("Payerkeys", "$_id.payerKey"),
								Accumulators.addToSet("Insurancekeys", "$_id.insuranceKey"),
								Accumulators.addToSet("Claimtype", "$_id.claimType")
								)));
				
				for (Document doc : output) 
				{
					//System.out.println(doc);
					sPayerkeys=StringUtils.substringBetween(String.valueOf(doc), "Payerkeys=[", "], Insurancekeys");
					sInsuranceKeys=StringUtils.substringBetween(String.valueOf(doc), "Insurancekeys=[", "], Claimtype");
					sClaimtypes=StringUtils.substringBetween(String.valueOf(doc), "], Claimtype=[", "]}}");
					InsuranceKeysList=Arrays.asList(sInsuranceKeys.split(","));
					PayerKeysList=Arrays.asList(sPayerkeys.split(","));
					if(InsuranceKeysList.size()>1&&PayerKeysList.size()>1)
					{
						Serenity.setSessionVariable("Payerkeys").to(sPayerkeys);
						Serenity.setSessionVariable("Insurancekeys").to(sInsuranceKeys);
						Serenity.setSessionVariable("Claimtypes").to(sClaimtypes);
						return true;
					}
					
				}
			}
			
			return false;
			
		}

	//########################### get Pure eLL DPs from eLL hierarchy #################################################################	
	public static void getpureEllDPkeysfromeLLhierarchy(String clientkey)
	{
		boolean bstatus=false;
		String dpkey=null;
		String MP=null;
		String Topic=null;
		String subrule=null;
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output = null;
		List<String> arPPS;
		ArrayList<String> dataList=new ArrayList<>();
		ArrayList<Long> payerkeys=new ArrayList<>();
		
		payerkeys.addAll(getTheDistinctPayerkeysBasedOnClient(clientkey));
		
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("rvaPayerSwitch", 0));
		//results= mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			GenericUtils.Verify("Pure eLL DPkey is not available available in eLLhierarchy collection", false);
		}
		
		// Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group(
						new Document().append("DPKey", "$subRule.hierarchy.dpKey").append("Release",
								"$_id.dataVersion"),
						Accumulators.addToSet("MP", "$subRule.hierarchy.medPolicyDesc"),
						Accumulators.addToSet("Topic", "$subRule.hierarchy.topicDesc"),
						Accumulators.addToSet("Subrule", "$_id.subRuleId")
						)));
			for (Document doc : output) 
			{
				//System.out.println(doc);
				dpkey=StringUtils.substringBetween(String.valueOf(doc), "DPKey=", "}}, MP");
				MP=StringUtils.substringBetween(String.valueOf(doc), "MP=[", "], Topic");
				Topic=StringUtils.substringBetween(String.valueOf(doc), "Topic=[", "], Subrule");
				subrule=StringUtils.substringBetween(String.valueOf(doc), "Subrule=[", "]}}");
				
				
				
				dataList.add("dpkey-"+dpkey+";MP-"+MP+";Topic-"+Topic+";Subrule-"+subrule);
			}
		System.out.println("eLL Dpkeys size::"+dataList.size());
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
		
		for (String elldata : dataList) 
		{
			dpkey=StringUtils.substringBetween(String.valueOf(elldata), "dpkey-", ";MP");
			MP=StringUtils.substringBetween(String.valueOf(elldata), "MP-", ";Topic");
			Topic=StringUtils.substringBetween(String.valueOf(elldata), "Topic-", ";Subrule");
			subrule=StringUtils.substringAfter(String.valueOf(elldata), "Subrule-");
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey.trim())));
			
			recordsCount = mColl.count(MatchFilter);
			if(recordsCount==0)
			{
				
				bstatus=getPPSfromthecdm(dpkey, clientkey,payerkeys);
				
				if(bstatus)
				{
					Serenity.setSessionVariable("Medicalpolicy").to(MP);
					Serenity.setSessionVariable("Topic").to(Topic);
					Serenity.setSessionVariable("Subrule").to(subrule);
					Serenity.setSessionVariable("DPkey").to(dpkey);
					System.out.println("MP::"+Serenity.sessionVariableCalled("Medicalpolicy").toString());
					System.out.println("Topic::"+Serenity.sessionVariableCalled("Topic").toString());
					System.out.println("DPkey::"+dpkey);
					System.out.println("Subrule::"+subrule);
					System.out.println("Payerkeys::"+Serenity.sessionVariableCalled("Payerkeys"));
					System.out.println("Insurancekeys::"+Serenity.sessionVariableCalled("Insurancekeys"));
					break;
				}
			}
		}
		if(!bstatus)
		{
			GenericUtils.Verify("Unable to find the pure eLldpkey for the given client::"+Serenity.sessionVariableCalled("client"), false);
		}
		
		
	}

	public static String getpureEllDPkeysfromeLLhierarchy(String clientkey,String payershort,String insurance,String claimtype,String LCD
			,String svgstatus)
	{
		boolean bstatus=false;
		String dpkey=null;
		String MP=null;
		String Topic=null;
		String subrule=null;
		Bson MatchFilter = new BsonDocument();
		AggregateIterable<Document> output = null;
		List<String> arPPS;
		ArrayList<String> dataList=new ArrayList<>();
		ArrayList<Long> payerkeys=new ArrayList<>();
		
		/*if(svgstatus.isEmpty())
		{
			//To load the pps and LCD in arraylist
			loadThePPSandLCDinList(payershort,insurance,claimtype,LCD);
		}
		else
		{*/
			loadThePPSandOpportunityLCDinList(payershort, insurance, claimtype, LCD);
		//}
		
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "ellHierarchy");
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("rvaPayerSwitch", 0));
		//results= mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			GenericUtils.Verify("Pure eLL DPkey is not available available in eLLhierarchy collection", false);
		}
		
		// Aggregate filter to retrieve the output
		output = mColl.aggregate(Arrays.asList(matchtext,
				Aggregates.group(
						new Document().append("DPKey", "$subRule.hierarchy.dpKey").append("Release",
								"$_id.dataVersion"),
						Accumulators.addToSet("MP", "$subRule.hierarchy.medPolicyDesc"),
						Accumulators.addToSet("Topic", "$subRule.hierarchy.topicDesc"),
						Accumulators.addToSet("Subrule", "$_id.subRuleId")
						)));
			for (Document doc : output) 
			{
				//System.out.println(doc);
				dpkey=StringUtils.substringBetween(String.valueOf(doc), "DPKey=", "}}, MP");
				MP=StringUtils.substringBetween(String.valueOf(doc), "MP=[", "], Topic");
				Topic=StringUtils.substringBetween(String.valueOf(doc), "Topic=[", "], Subrule");
				subrule=StringUtils.substringBetween(String.valueOf(doc), "Subrule=[", "]}}");
				
				
				if(!Topic.equalsIgnoreCase("TEST")&&!subrule.isEmpty())
				{
					dataList.add("dpkey-"+dpkey+";MP-"+MP+";Topic-"+Topic+";Subrule-"+subrule);
				}
				
			}
		System.out.println("eLL Dpkeys size::"+dataList.size());
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cpd", "oppty");
		
		for (String elldata : dataList) 
		{
			dpkey=StringUtils.substringBetween(String.valueOf(elldata), "dpkey-", ";MP");
			MP=StringUtils.substringBetween(String.valueOf(elldata), "MP-", ";Topic");
			Topic=StringUtils.substringBetween(String.valueOf(elldata), "Topic-", ";Subrule");
			subrule=StringUtils.substringAfter(String.valueOf(elldata), "Subrule-");
			MatchFilter = Filters.and(Filters.eq("_id.clientKey", Long.valueOf(clientkey)),
					Filters.eq("subRule.hierarchy.dpKey", Long.valueOf(dpkey.trim())));
			
			recordsCount = mColl.count(MatchFilter);
			if(recordsCount==0)
			{
				System.out.println("eLL DPkey::"+dpkey);
				bstatus=getPPSfromthecdm(dpkey, clientkey);
				
				if(bstatus)
				{
					Serenity.setSessionVariable("Medicalpolicy").to(MP);
					Serenity.setSessionVariable("Topic").to(Topic);
					Serenity.setSessionVariable("Subrule").to(subrule);
					Serenity.setSessionVariable("DPkey").to(dpkey);
					System.out.println("MP::"+Serenity.sessionVariableCalled("Medicalpolicy").toString());
					System.out.println("Topic::"+Serenity.sessionVariableCalled("Topic").toString());
					System.out.println("DPkey::"+dpkey);
					System.out.println("Subrule::"+subrule);
					System.out.println("Payerkeys::"+Serenity.sessionVariableCalled("Payerkeys"));
					System.out.println("Insurancekeys::"+Serenity.sessionVariableCalled("Insurancekeys"));
					break;
				}
			}
			else
			{
				System.out.println("RVA DPkey::"+dpkey);
			}
		}
		if(!bstatus)
		{
			GenericUtils.Verify("Unable to find the pure eLldpkey for the given client::"+Serenity.sessionVariableCalled("client"), false);
		}
		
		return Serenity.sessionVariableCalled("Topic").toString();
	}
	
	public static boolean getPPSfromthecdm(String dpkey, String clientkey) 
	{
		boolean bstatus=false;
		Bson MatchFilter = new BsonDocument();
		String sPayerkeys=null;
		String sClaimtypes=null;
		String sInsuranceKeys = null;
		List<String> InsuranceKeysList = null;
		List<String> PayerKeysList = null;
		
		AggregateIterable<Document> output = null;
		
		ArrayList<String> arPPS=new ArrayList<>();
		
		List<String> cdmdecisionOpportunity=Arrays.asList(ProjectVariables.LCDWithOpportunity.split(","));
		
		
		//Method to connect mongoDB
		ConnectTogivenDBandCollection("cdm", "latestDecision");
		
		//Filter to form a match query based on inputs
		MatchFilter = Filters.and(Filters.eq("_id.dpKey", Long.valueOf(dpkey)),
				Filters.in("_id.payerKey", ProjectVariables.payerKeys),
				  Filters.in("_id.insuranceKey", ProjectVariables.insuranceKeyslist),
				  Filters.in("_id.claimType", ProjectVariables.ClaimtypeList),
				  Filters.in("decStatusDesc", ProjectVariables.lCDlist));
		results= mColl.find(MatchFilter);
		recordsCount = mColl.count(MatchFilter);
		Bson matchtext = Aggregates.match(Filters.and(MatchFilter));
		System.out.println("RecordCount::"+recordsCount+",for matchfilter==>"+MatchFilter);
		if(recordsCount==0)
		{
			return false;
		}
		else
		{
			// Aggregate filter to retrieve the output
			output = mColl.aggregate(Arrays.asList(matchtext,
					Aggregates.group("$_id.dpKey",
							Accumulators.addToSet("Payerkeys", "$_id.payerKey"),
							Accumulators.addToSet("Insurancekeys", "$_id.insuranceKey"),
							Accumulators.addToSet("Claimtype", "$_id.claimType")
							)));
			
			for (Document doc : output) 
			{
				//System.out.println(doc);
				sPayerkeys=StringUtils.substringBetween(String.valueOf(doc), "Payerkeys=[", "], Insurancekeys");
				sInsuranceKeys=StringUtils.substringBetween(String.valueOf(doc), "Insurancekeys=[", "], Claimtype");
				sClaimtypes=StringUtils.substringBetween(String.valueOf(doc), "], Claimtype=[", "]}}");
				InsuranceKeysList=Arrays.asList(sInsuranceKeys.split(","));
				PayerKeysList=Arrays.asList(sPayerkeys.split(","));
				if(InsuranceKeysList.size()>1&&PayerKeysList.size()>1)
				{
					Serenity.setSessionVariable("Payerkeys").to(sPayerkeys);
					Serenity.setSessionVariable("Insurancekeys").to(sInsuranceKeys);
					Serenity.setSessionVariable("Claimtypes").to(sClaimtypes);
					return true;
				}
				
			}
		}
		
		return false;
		
	}
}

