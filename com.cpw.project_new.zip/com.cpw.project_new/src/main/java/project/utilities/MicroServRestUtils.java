package project.utilities;

import java.io.BufferedReader;

import java.io.IOException;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;

import org.apache.http.HttpResponse;

import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;

import org.apache.http.impl.client.HttpClientBuilder;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.junit.Assert;

import com.google.gson.Gson;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import net.serenitybdd.core.Serenity;
import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;




 
public class MicroServRestUtils extends SeleniumUtils {
	
	public static String sBase;

	public MicroServRestUtils(){
		EnvironmentVariables environmentVariables = SystemEnvironmentVariables.createEnvironmentVariables();       
		//String myCustomProperty = variables.getProperty("restapi.baseurl");*/
		
		String APP_URL = EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("restapi.baseuri");
		sBase = APP_URL;

	} 
	
    public static boolean Post_the_Data__through_service_using_HTTP_Client(String jsondata, String ServiceUrl) throws IOException
	{
		

		 CloseableHttpClient httpClient = HttpClientBuilder.create().build();
		
		try {
			//HttpParams httpParams = httpClient.getParams();
		    HttpPost request = new HttpPost(ServiceUrl);
		    StringEntity params = new StringEntity(jsondata);
		    request.addHeader("content-type", "application/json");
		    request.setEntity(params);
		  
		    HttpResponse response = httpClient.execute(request);
		    httpClient.execute(request);
		    int Code=response.getStatusLine().getStatusCode();
		    
		    HttpEntity ReponseStatus=response.getEntity();
		    
			
		    
		    System.out.println("Response ======>"+ReponseStatus.toString());
		    System.out.println("Response code======>"+Code);
		    
		    Serenity.setSessionVariable("ResponseCode").to(Code);
		    
		    if(Code==201||Code==200)
		    {
		    	GenericUtils.logMessage("Json data was inserted successsully through service url ======>"+ServiceUrl);
		    	
		    	return true;
		    }
		    else
		    {
		    	GenericUtils.logMessage("Json data was not inserted through service url ======>"+ServiceUrl+",Response code was ======>"+Code);
		    	
		    	return false;
		    }
		  
		    
		    
		    
		// handle response here...
		} catch (Exception ex) {
		    // handle exception here
		} finally {
		    httpClient.close();
		}
		
		return false;
		
	}
    
    public static boolean Post_the_Data(String jsondata, String ServiceUrl) throws IOException
   	{ 
   	    System.out.println(jsondata);
   	    URL obj = new URL("https://jsonplaceholder.typicode.com/posts");
   	    HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
   	    postConnection.setRequestMethod("POST");
   	    postConnection.setRequestProperty("userId", "a1bcdefgh");
   	    postConnection.setRequestProperty("Content-Type", "application/json");
   	    postConnection.setDoOutput(true);
   	    OutputStream os = postConnection.getOutputStream();
   	    os.write(jsondata.getBytes());
   	    os.flush();
   	    os.close();
   	    int responseCode = postConnection.getResponseCode();
   	    System.out.println("POST Response Code :  " + responseCode);
   	    System.out.println("POST Response Message : " + postConnection.getResponseMessage());
   	 //System.out.println("POST Response  : " + postConnection.getHeaderFields());
   	//System.out.println("POST Response  : " + postConnection.getContent().toString());
   	    if (responseCode==201||responseCode==200) 
   	    { //success
   	        BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
   	        String inputLine;
   	        StringBuffer response = new StringBuffer();
   	        System.out.println(response);
   	        
   	        while ((inputLine = in .readLine()) != null) {
   	            response.append(inputLine);
   	        } in .close();
   	        // print result
   	        System.out.println(response.toString());
   	        return true;
   	    } else {
   	        System.out.println("POST NOT WORKED");
   	        return false;
   	    }
   	   
   }
    
    @SuppressWarnings("deprecation")
	public static boolean Post_the_Data_with_Rest_Assured(String jsondata, String ServiceUrl) throws IOException
   	{
    	
    	ProjectVariables.ResponseOutput=null;
    	
    	int statusCode = 0;
	
    	Response response;
    	response = RestAssured.given().contentType(ContentType.JSON).accept(ContentType.JSON).body(jsondata).when().post(ServiceUrl);
    	
    	//response = RestAssured.given().auth().basic("TestAuto", "Ihealth@123").post(ServiceUrl);
    	String jsonResponseStr = response.getBody().asString();
    	statusCode = response.getStatusCode();
			
    	String Output=jsonResponseStr.replaceAll("\"","");
    	
    	//System.out.println(Output);
    	
    	String ExactOutput=StringUtils.substringBetween(Output, "result:[", "],error");
		//System.out.println("Original Posted Response BOdy ===>"+ExactOutput);
		System.out.println("POST Response Code :  " + statusCode);
		
		Serenity.setSessionVariable("ResponseCode").to(statusCode);
		
		ProjectVariables.ResponseOutput=ExactOutput;
	
		
		
	  if(statusCode==201||statusCode==200)
	    {
	    	System.out.println("Json data was posted successsully through service url ======>"+ServiceUrl);
	    	
	    	if(ExactOutput.isEmpty())
	    	{
	    		
	    		return false;
	    		
	    	}
	    	
	    	
	    	return true;
	    }
	    else
	    {
	    	System.out.println("Json data was not posted through service url ======>"+ServiceUrl+",Response code was ======>"+statusCode);
	    	
	    	return false;
	    }
	
	  
	
   	}
    
    @SuppressWarnings("deprecation")
   	public static ArrayList<String> Post_the_Data_with_Rest_Assured_And_Fetch_Clients(String jsondata, String ServiceUrl) throws IOException
   	
      	{
       	
       	ProjectVariables.ResponseOutput=null;
       	ArrayList<String> list = new ArrayList<>();
       	int statusCode = 0;
   	
       	Response response;
       	response = RestAssured.given().contentType(ContentType.JSON).accept(ContentType.JSON).body(jsondata).when().post(ServiceUrl);
       
       	String jsonResponseStr = response.getBody().asString();
       	statusCode = response.getStatusCode();
    	String colData=StringUtils.substringBetween(jsonResponseStr, "[", "]");
       	String[] jsonData = colData.split("},");
       
      
       	for(int i=0;i<jsonData.length;i++){
       		String ExactData=jsonData[i].replaceAll("\"","");
       		
       		String ClientKey=StringUtils.substringBetween(ExactData, "clientId:", ",clientName");	   
       		
       		
       		String strClient=StringUtils.substringAfter(jsonData[i],  "clientName");
       		String ClientName=StringUtils.substringBetween(strClient, ":\"", "\"");	      				
       				list.add(ClientName+"="+ClientKey);
       		ProjectVariables.clientKeysList.add(ClientKey);
       		//System.out.println(i+1+"."+ClientName+"="+ClientKey);
       	}
   			
    
   		System.out.println("POST Response Code :  " + statusCode);
   		
   		Serenity.setSessionVariable("ResponseCode").to(statusCode);
   		
   		ProjectVariables.clientNamesList=list;
   	
   		
   		
   	  if(statusCode==201||statusCode==200)
   	    {
   	    	GenericUtils.logMessage("Json data was inserted successsully through service url ======>"+ServiceUrl);
   	    	
   	    }
   	    else
   	    {
   	    	GenericUtils.logMessage("Json data was not inserted through service url ======>"+ServiceUrl+",Response code was ======>"+statusCode);
   	    	
   	    }
   	
   	  	if(list.isEmpty())
   	  	{
   	  		Assert.assertTrue("Unable to retrieve the clientkeys from the service", false);
   	  	}
   	  
   	  return list;
   	
      	}

	public JsonPath getResponseBodyPostService(String sEndPointURL ,String sBody)
	{	
		System.out.println("RequestURI::"+sEndPointURL);
		JsonPath sJsonExtract = getPostResponse(sEndPointURL,sBody).then().assertThat().statusCode(200).extract().jsonPath();
		return sJsonExtract;

	}
	
	public Response getPostResponse(String sEndPointURL ,String sBody){

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");

		System.out.println("BaseURI::"+sBase);
		System.out.println("RequestBody::"+sBody);
		Response sResponse =  SerenityRest.given().baseUri(sBase)
				.contentType("application/json")
				.headers(headers)
				.body(sBody)
				.when()
				.post(sEndPointURL);

		return sResponse;

	}
	
	public static String getRequestPayload(String sRequestname , HashMap<String,Object> sInput ) throws ParseException, IOException{
		
		//Loading all the services from Excel
		//ExcelUtils.loadServices();
		
		String getDPRequestBody = ProjectVariables.sServices.get(sRequestname).get("RequestBody");

		JSONParser parser = new JSONParser();
		JSONObject json = (JSONObject) parser.parse(getDPRequestBody);
		
		json.putAll(sInput);
	
		Gson g = new Gson();		
		String str = g.toJson(json);

		System.out.println(str);
		
		return str;
		
	}
    
	public Response getRequestWithPathParams(String sEndpointURL){

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("X-Session-Id", Serenity.sessionVariableCalled("sessionID"));
		Response sResponse =  SerenityRest.given().headers(headers).baseUri(sBase).when().get(sEndpointURL);

		return sResponse;

	}

	public JsonPath getResponseBodyforPostServiceWithSessionID(String sEndPointURL ,String sBody){
		Response sReponse = PostServiceWithSessionID(sEndPointURL,sBody);
		sReponse.then().assertThat().statusCode(200);
		JsonPath sResponse = sReponse.jsonPath();
		return sResponse;

	}
	

	public Response PostServiceWithSessionID(String sEndPointURL ,String sBody){

		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("X-Session-Id", Serenity.sessionVariableCalled("sessionID"));

		Response sResponse =  SerenityRest.given().baseUri(sBase)
				.contentType("application/json")
				.headers(headers)
				.body(sBody)
				.when()
				.post(sEndPointURL);

		return sResponse;

	}

}
